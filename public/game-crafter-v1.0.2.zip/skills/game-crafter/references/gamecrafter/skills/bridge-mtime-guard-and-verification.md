---
id: bridge-mtime-guard-and-verification
title: "mtime guard and proving files actually landed"
category: delivery-pc-bridge
when: "Overwriting PC files; reporting a delivery."
related: []
origin: FNAP
---

# mtime guard and proving files actually landed

**When to use:** Overwriting PC files; reporting a delivery.

## Do this

The mtime guard refuses to overwrite a PC file that changed since staging: re-stage, or use `force` deliberately (the export presets file needed force). A "written" result is NOT proof the content is latest: verify by listing the folder (size + mtime) or staging the file back. Report where it landed in plain words.

## Pitfalls (mistakes seen)

`export_presets.cfg` commit "did not land" -> ARM64 build produced no exe. Prevention: list/stage-back after every commit of critical files.

## Verify

folder listing with new mtime/size; staged-back diff.

## Origin

FNAP. Source notes: pc-bridge-delivery/SKILL.md bullet 5; godot-export-release/SKILL.md line 40.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
