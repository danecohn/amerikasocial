---
id: mistake-gdscript-variant-inference-errors
title: ":=` on Variant-returning expressions is a parse error in Godot 4.7 (treated as error)"
category: mistake
when: ""
related: []
origin: Caesarea
---

# :=` on Variant-returning expressions is a parse error in Godot 4.7 (treated as error)

**When to use:** 

## What happened, root cause, fix, prevention

- `detection_cone.gd`: `var point := target.call(&"stealth_point") if target.has_method(...) else target.global_position + ...` → "Cannot infer the type" (Node.call returns Variant). Fix: `var point: Vector3 = target.global_position + Vector3(0, 1, 0)`; `var r: Variant = target.call(&"stealth_point"); if r is Vector3: point = r`.
- `ui_settings.gd`: `var q := [RenderingServer.SHADOW_QUALITY_HARD, ...][shadows]` (untyped array element) → fixed with `Array[RenderingServer.ShadowQuality]`.
- `shot.gd`: `var c := _args["cam"].split_floats(",")` (Dictionary value) → explicit type.
- Prevention: use explicit types for anything from `call()`, `get()`, Dictionary/Array indexing, `JSON.parse_string`, `get_meta`; the compile sweep in test_main catches these, so run it after every agent's edits.

## Origin

Caesarea. Source notes: MANIFEST gate notes; Caesarea/game/actors/stealth/detection_cone.gd; ui_settings.gd:137; shots/qa/title.log.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
