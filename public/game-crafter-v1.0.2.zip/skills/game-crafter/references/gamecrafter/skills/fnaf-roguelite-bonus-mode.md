---
id: fnaf-roguelite-bonus-mode
title: "Roguelite bonus mode reusing the office (map, cards, permadeath, meta)"
category: roguelike-procgen
when: "Adding replayable post-story content to a FNAF-like."
related: [mistake-missing-card-pool-silent-empty]
origin: FNAP
---

# Roguelite bonus mode reusing the office (map, cards, permadeath, meta)

**When to use:** Adding replayable post-story content to a FNAF-like.

## Do this

- `BrineRun` autoload: 3 acts x 5 rows; row 0 = shift, last row = boss, others weighted `shift 45 / shelf 18 / barrel 10 /
  cursed 12 / phone 15`; each node links to 1-2 nodes in the next row (guarantee every next-row node is reachable).
- `shift_config()` builds the SAME config dict as story nights (levels scale with depth, 3 hours x 70 s, deck effects via
  `_apply_deck`). Permadeath (`on_shift_lost -> end_run(false)`); meta progression `brine_meta` / `brine_best_act` with
  unlockable starting perks. Bosses table (`dark_office`, `banshee_speed 1.4`). Lore lines for flavour.
- Cards: `BrineCard` Resource (`id, title, description, kind perk/curse, rarity, effect, amount, jar_color,
  starting_unlock_acts`); effects: `power_bonus, drain_reduction, door_speed, stamina, door_cams, auto_close,
  golden_active, banshee_speed, flicker_cams, assistant_reliability, assistant_speed, assistant_hallucinate, ai_plus`.
  UI: `UiKit.jar_card` (card drawn as a glass jar).
- Flow `brine_start -> brine_map -> night_intro -> office (in_shift) -> brine_map ... -> brine_over`.

## Pitfalls (mistakes seen)

mistake-missing-card-pool-silent-empty.

## Verify

`--fnap-brine-test`; assert card pool size > 0 at load.

## Origin

FNAP. Source notes: REF §2.14, §1.5, §2.1, caveats.

---------------------------------------------------------------------------------------------------

## Related skills

- [mistake-missing-card-pool-silent-empty](mistake-missing-card-pool-silent-empty.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
