# Tool: verify_export.sh

**Purpose:** Export a pack, run the export probe from the PACK, take a screenshot from the PACK. The proof step before any 'done'.

**Usage:** `bash verify_export.sh <project_dir> <preset_name> <scene_to_screenshot>`

**Skill:** see `skills/verify-the-exported-build.md`

**Extract:** save the block below as `verify_export.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# THE gate before telling anyone a build is "fixed": test the EXPORTED PACK, not the editor.
# Editor runs see raw files and look perfect; a shipped PCK only contains imported resources behind .import/.remap
# entries, so code that checks FileAccess/globalize_path silently falls back to placeholder boxes/capsules.
# Usage: verify_export.sh <project_dir> <preset_name=Linux> [probe_scene=res://tools/export_probe.tscn] [screenshot_scene=res://scenes/main.tscn]
# Steps: import -> --export-pack -> run probe scene from the PACK (exit code = fails) -> optional screenshot of the real main scene from the PACK.
# Prereq: copy templates/godot_dev/export_probe.{gd,tscn} + a probe_manifest.json into <project>/tools/ and add "*.json" to include_filter.
set -uo pipefail
P="${1:?project dir}"; PRESET="${2:-Linux}"; PROBE="${3:-res://tools/export_probe.tscn}"; SHOT="${4:-}"
HERE="$(cd "$(dirname "$0")" && pwd)"; GODOT="${GODOT:-godot}"; OUT="${OUT:-/tmp/gm_verify}"; mkdir -p "$OUT"
echo "== import";  "$GODOT" --headless --path "$P" --import --quit >"$OUT/import.log" 2>&1; echo "import exit $?"; grep -iE "error|parse" "$OUT/import.log" | head -5
echo "== export-pack '$PRESET'"; "$GODOT" --headless --path "$P" --export-pack "$PRESET" "$OUT/test.pck" >"$OUT/export.log" 2>&1; rc=$?; echo "export exit $rc"
[ -s "$OUT/test.pck" ] || { echo "FAIL no pack produced"; tail -15 "$OUT/export.log"; exit 2; }
ls -la "$OUT/test.pck"
echo "== probe FROM THE PACK (no project dir => proves the shipped resources resolve)"
( cd "$OUT" && timeout 120 "$GODOT" --headless --main-pack "$OUT/test.pck" "$PROBE" 2>&1 | grep -E "PROBE|SCRIPT ERROR|ERROR" | head -60 ); prc=${PIPESTATUS[0]}
echo "probe exit $prc  (0 = every probed resource loaded from the pack)"
if [ -n "$SHOT" ]; then
  echo "== screenshot of $SHOT FROM THE PACK (software Vulkan) - OPEN THE PNG AND LOOK AT IT"
  cat > "$OUT/pack_shot.gd" <<'GD'
extends SceneTree
func _initialize() -> void:
	var a := OS.get_cmdline_user_args()
	var inst := (load(a[0]) as PackedScene).instantiate()
	root.add_child(inst)
	_run.call_deferred(a[1], int(a[2]) if a.size() > 2 else 90)
func _run(out: String, frames: int) -> void:
	for i in frames: await process_frame
	await RenderingServer.frame_post_draw
	root.get_texture().get_image().save_png(out); print("SHOT_OK ", out); quit(0)
GD
  # NOTE: -s scripts live outside the pack; --main-pack loads the pack's resources. Both are allowed together.
  bash "$HERE/../../headless-render-capture/scripts/godot_xvfb.sh" -r 1280x720 -t 300 -l "$OUT/shot.log" -- --main-pack "$OUT/test.pck" -s "$OUT/pack_shot.gd" -- "$SHOT" "$OUT/pack_shot.png" 90
  ls -la "$OUT/pack_shot.png" 2>/dev/null || { echo "no screenshot"; tail -20 "$OUT/shot.log"; }
  # The probe only proves resources EXIST in the pack. Your CODE can still pick a placeholder (it did in the eval: probe passed on a broken build).
  # So make the game print a wiring line per role (e.g. "WIRING hero=real" / "MAIN: PLACEHOLDER ...") and fail here if any placeholder/missing shows:
  if grep -aiE "PLACEHOLDER|MISSING|WIRING .*=(placeholder|missing)" "$OUT/shot.log"; then echo "FAIL: game fell back to a placeholder INSIDE THE PACK (see lines above)"; prc=3; fi
fi
exit $prc
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
