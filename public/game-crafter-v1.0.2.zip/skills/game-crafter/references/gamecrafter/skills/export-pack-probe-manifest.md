---
id: export-pack-probe-manifest
title: "Prove the exported pack contains every asset (probe scene + manifest)"
category: testing-qa
when: "Before shipping any export; 'works in editor, missing in build' worries; JSON/raw files packed?"
related: [mistake-templated-verification-claims]
origin: Roguelike series
---

# Prove the exported pack contains every asset (probe scene + manifest)

**When to use:** Before shipping any export; "works in editor, missing in build" worries; JSON/raw files packed?

## Do this

- Build step writes `tools/probe_manifest.json` listing every res:// asset (.png/.ogg/.wav/.ttf) plus raw files (`res://game/game.json`). Include it in the export via include_filter.
- probe.gd (run as main scene of the exported binary or with `--main-pack`):
```gdscript
extends Node
func _ready() -> void:
	var fails := 0
	var m: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://tools/probe_manifest.json")) if FileAccess.file_exists("res://tools/probe_manifest.json") else null
	if m == null:
		print("PROBE_FAIL manifest missing"); get_tree().quit(2); return
	print("PROBE renderer=", RenderingServer.get_current_rendering_method())
	for p in m.get("resources", []):
		var res: Resource = load(p) if ResourceLoader.exists(p) else null
		if res == null:
			print("PROBE_FAIL load ", p); fails += 1
	for p in m.get("raw_files", []):
		if not FileAccess.file_exists(p):
			print("PROBE_FAIL raw ", p); fails += 1
	print("PROBE_COUNT ", m.get("resources", []).size())
	print("PROBE_DONE fails=", fails)
	get_tree().quit(1 if fails else 0)
```
- probe.tscn: `[gd_scene load_steps=2 format=3]` + ext_resource Script res://tools/probe.gd + `[node name="Probe" type="Node"]`.
- Report: "PROBE_DONE fails=0 (N resources)" - take N from PROBE_COUNT, never from memory.
- Godot 4.4+ writes `probe.gd.uid` next to scripts; keep it in the project.

## Pitfalls (mistakes seen)

MANIFEST claimed "72 resources" for every game while the real manifests had 75 (LAST LAMP) and 77 (WARD SEVEN) - see mistake-templated-verification-claims.

## Verify

exit code 0 and `PROBE_DONE fails=0`.

## Origin

Roguelike series. Source notes: _tools/probe.gd, probe.tscn; buildgame.py L243-252; roguelikes/*/tools/probe_manifest.json.

## Related skills

- [mistake-templated-verification-claims](mistake-templated-verification-claims.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
