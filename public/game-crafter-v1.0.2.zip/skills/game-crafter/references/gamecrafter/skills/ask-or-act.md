---
id: ask-or-act
title: "Ask or act: when to ask the user and when to just start"
category: core-workflow
when: "At the start of any request, before deciding whether to ask a clarifying question."
related: [master-game-loop, standing-instructions, mistake-ambiguous-literal]
origin: GameCrafter (all projects)
---

# Ask or act

> **Rule:** If a wrong guess is cheap to redo, start now and state your reading. If it's expensive or can't be undone, and the request is ambiguous, ask ONE question first.

## Do this
1. Re-read the user's last two messages. Short instructions ("pack it up", "import the videos to the folder") usually continue the previous goal.
2. **Act immediately** when the request is clear or quick to redo: write one sentence about what you're doing, then the first tool call.
3. **Ask first** (one question, multiple choice if you can) when the work is expensive (a full export cycle, a large file transfer, many agents, deleting or overwriting the user's files) AND it could reasonably go two ways.
4. If the user is away or doesn't answer, take the most reasonable reading, write it at the top of the work and in STATE.md, and continue. Stop before irreversible steps.
5. Never ask permission for something the user already asked for. Never offer to do a thing instead of doing it.

## Pitfalls
- **The user had to repeat "package it up, get it on my computer, now"** → cause: long silent work with no visible progress → fix: one status line before long jobs, and deliver the moment it's ready.
- **A literal reading of an ambiguous direction** produced the wrong deliverable (FNAP) → re-read the goal of the previous turn.

## Verify
- Your first reply has a one-line plan and real work, or exactly one question.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
