---
id: humanoid-facing-plus-z-convention
title: "Characters face +Z in Godot (Blender −Y); never look_at() a model without use_model_front"
category: 3d-blender
when: "Importing characters/props from Blender; writing character controllers or AI facing."
related: []
origin: Caesarea
---

# Characters face +Z in Godot (Blender −Y); never look_at() a model without use_model_front

**When to use:** Importing characters/props from Blender; writing character controllers or AI facing.

## Do this

Every asset faces −Y in Blender → glTF export (+Y up) → +Z forward in Godot (`Vector3.MODEL_FRONT`, SkeletonProfileHumanoid convention). Never rotate an asset in Godot to fix facing. Controllers: `MODEL_FORWARD = +Z`; `face_direction()` uses `Basis.looking_at(dir, Vector3.UP, true)` (use_model_front=true); `model_forward()` = `model.global_basis.z`. `Node3D.look_at()` without use_model_front points −Z at the target (character faces backward). Cameras/RayCast3D still use −Z. Player movement from camera −Z, turn model +Z toward it; NPCs turn +Z along NavigationAgent3D path. AI facing pattern: `global_basis = global_basis.slerp(Basis.looking_at(flat_dir, Vector3.UP, true), 0.25)`. Detection cones need a `front_is_plus_z` flag (cameras/drones −Z). Include a facing (+Z) test in test_main.

## Pitfalls (mistakes seen)

Asset list doc said "+Y forward → −Z" — conflicting canon; scene plan overrode it and asked the owner to update.

## Origin

Caesarea. Source notes: design/08 §6.3; godot_starter README; enemy.gd face_at; detection_cone.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
