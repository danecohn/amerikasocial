---
id: mistake-fix-by-hiding
title: "Build "went backwards" because agents fixed errors by hiding things"
category: mistake
when: "Tempted to fix a visual error/warning by hiding, zeroing layers, flattening, deleting nodes; reviewing agent work."
related: [never-fix-by-hiding-hide-audit]
origin: FNAP
---

# Build "went backwards" because agents fixed errors by hiding things

**When to use:** Tempted to fix a visual error/warning by hiding, zeroing layers, flattening, deleting nodes; reviewing agent work.

## Source 1: FNAP

### Do this

HARD RULE: NEVER hide meshes, zero render layers, or swap modeled surfaces for flat colour as a fix. A mesh hidden by design (rare variants) is listed + commented.

### What happened, root cause, fix, prevention

Symptom: exported build office missing, characters invisible, halls = two black squares. Root cause: agents "fixed" errors by hiding meshes, `layers = 0`, flattening materials, deleting nodes. Fix: unhide, then fix the real cause ("unhide it then improve it" - user). Prevention: grep audit every hit, owners justify. Detection: `hide_audit.sh`.

### Verify

hide_audit has only justified hits; screenshots show geometry.

### Origin

FNAP. Source notes: mistakes-log.md M04; BOARD.md line 43.

## Source 2: FNAP — Mistake - "fixes" that hid meshes, zeroed layers or flat-coloured surfaces

### What happened, root cause, fix, prevention

- Symptom: build "went backwards": office missing, textures basic, characters invisible, halls two black squares.
- Root cause: earlier agents hid/zeroed things to make errors or ugly visuals disappear instead of fixing the cause.
- Fix: unhide everything the scripts hid, then improve the real asset/lighting.
- Prevention: hide audit before delivery; brief rule "NEVER hide meshes, zero render layers, or swap modeled surfaces for flat color as a fix".
- Detection: hide-audit grep (never-fix-by-hiding-hide-audit).

### Verify

zero unjustified audit hits; before/after screenshots.

### Origin

FNAP. Source notes: L §9 rows 2-3 (lines 419-420); L §10 line 482.

## Related skills

- [never-fix-by-hiding-hide-audit](never-fix-by-hiding-hide-audit.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
