---
id: eye-rig-glow-and-look-at
title: "Eye rig: emissive irises, pupil blendshapes, LookAtModifier3D tracking"
category: 3d-lighting-horror
when: "Characters with eye.L/eye.R bones and iris meshes with blend shapes; want glowing eyes in darkness and eyes that follow the player."
related: []
origin: Pickle's Pickle Shop
---

# Eye rig: emissive irises, pupil blendshapes, LookAtModifier3D tracking

**When to use:** Characters with eye.L/eye.R bones and iris meshes with blend shapes; want glowing eyes in darkness and eyes that follow the player.

## Do this

Arm only if skeleton has bones `eye.L`/`eye.R` and iris meshes with blend shape `pupil_shrink`. Duplicate the iris material (so two instances don't share emission), set opaque, PER_PIXEL shading, emission enabled; apply as surface override. Per bone add `LookAtModifier3D` (forward_axis BONE_AXIS_PLUS_Y, primary_rotation_axis AXIS_Z, secondary on, angle limits 70/50 deg, symmetry, duration 0.08, influence 0) targeting player camera; ramp influence to 1 when at door or on camera (`move_toward(..., delta*6)`). Base glow per char: pickle 1.8, remi 1.8, dilly 1.6, banshee 2.2, golden 1.8. Energy priority (first match wins): jumpscaring 7.0; blackout 5.5; on camera = base; revealed by light = 4.2 at door else base; at door and dark = 0.0 (pitch black); hidden or dark = 6.0; dark = base*1.7. Pupil "pinprick" on flashlight hit: shrink 1.0, hold 0.35 s, decay 1.4/s; while shrink>0.2 energy = base. Never scale eyes to 0 or remove them; restore `layers=1` and scale ONE if a polish pass zeroed them.

## Pitfalls (mistakes seen)

eye energy 0 during jumpscare in dark nook -> blank face; fixed by jumpscaring branch first. A duplicate "elif at_door and dark" branch after the first is dead code - order of elifs matters.

## Verify

Probe prints energy per state; screenshot eyes in dark hall feed.

## Origin

Pickle's Pickle Shop. Source notes: scripts/animatronics/eye_rig.gd L1-247.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
