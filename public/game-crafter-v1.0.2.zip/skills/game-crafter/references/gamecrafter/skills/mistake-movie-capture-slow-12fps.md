---
id: mistake-movie-capture-slow-12fps
title: "Movie capture ~5 s/frame; gameplay delivered at 12 fps"
category: mistake
when: "Recording gameplay video on CPU."
related: []
origin: FNAP
---

# Movie capture ~5 s/frame; gameplay delivered at 12 fps

**When to use:** Recording gameplay video on CPU.

## Do this

`--write-movie f.png --fixed-fps 12` (game time = frames/fps); render stills at full 1920x1080 directly; budget frames x 5 s. Tell user up front about 12 fps.

## What happened, root cause, fix, prevention

Symptom: very slow; low fps. Cause: SwiftShader on 2 cores. Fix above; disclose.

## Verify

Frame count x 5 s budget fits.

## Origin

FNAP. Source notes: mistakes-log.md M53.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
