---
id: hall-light-system-assistant-controlled
title: "Hall light system controlled from an in-game terminal (with power cost)"
category: gameplay-systems
when: "Horror office game where light is a resource and the user wants halls dark unless explicitly lit."
related: [mistake-assistant-light-command-not-affecting-cameras, mistake-hall-cameras-pitch-black]
origin: Pickle's Pickle Shop
---

# Hall light system controlled from an in-game terminal (with power cost)

**When to use:** Horror office game where light is a resource and the user wants halls dark unless explicitly lit.

## Do this

State `hall_lit = {"L": false, "R": false}` with a computed `light_on` property ("L"/"R"/""; setter accepts "LR"). Physical A/D keys and wall switches are DEAD: `_hall_switch_denied()` plays a denied buzz and subtitle "The hall switches are dead. Ask Pickle-GPT at the desk (T)." (2.8 s). Only the assistant calls `assistant_set_hall_lights(side, on)` (side "" = both) -> `_set_light(side,on)`: refuse during power_out, refuse "on" if that side is jammed by an intruder, set flag, LIGHT_CLICK sfx, set door/hall Light3D energies from cached authored energy (fallback 1.2), set bulb mesh emission, `level.set_hall_room_lights(side,on)` (hall room Light3D energy 1.8/0 and light-fixture emission 1.2), `monitor.refresh_isolation()`, door-scare sting if someone is there (once per arrival), buzz loop while any light on. Power: each lit hall costs `HALL_LIGHT_BARS = 3` usage bars (door = 1, flashlight = 1, monitor). Intruder in office turns that side's light off. Power out: all lights off, doors jam. `is_watching_room(OFFICE_DOOR_x)` = hall lit or flashlight on at that door (watched characters with `moves_only_unwatched` freeze).

## Pitfalls (mistakes seen)

see mistake-assistant-light-command-not-affecting-cameras, mistake-hall-cameras-pitch-black. Lights were initially tied to the office "full" light state, which turned hall lights back on: fix `_darken_halls()` sets `Light_Hall_L/R` energy 0 at build and `_write_office_light_energies()` skips hall-button lights (`_is_hall_button_light` by normalized name prefix lighthall/halllight/doorlight). Hall lights under a hidden hall stub never lit -> `_detach_hall_button_lights()` reparents them to the office root.

## Verify

Toggle via terminal in a probe; print `is_hall_lit`, light energies, feed exposure values; screenshot.

## Origin

Pickle's Pickle Shop. Source notes: office_controller.gd L62-70, L352-363, L699-797, L1236-1246, L1373-1418, L1592-1604; STATUS.md "This pass"; MANIFEST.md "HALL LIGHTS".

## Related skills

- [mistake-assistant-light-command-not-affecting-cameras](mistake-assistant-light-command-not-affecting-cameras.md)
- [mistake-hall-cameras-pitch-black](mistake-hall-cameras-pitch-black.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
