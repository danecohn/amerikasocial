---
id: mistake-delta-hitch-eats-reaction
title: "Reaction window eaten by frame hitch"
category: mistake
when: "Timers for player reaction windows."
related: []
origin: FNAP
---

# Reaction window eaten by frame hitch

**When to use:** Timers for player reaction windows.

## Do this

`_approach_left -= minf(delta, 0.1)`.

## What happened, root cause, fix, prevention

Symptom: unfair instant deaths after a stutter. Root cause: decrementing timer by full delta. Fix: clamp delta. Detection: test with artificial hitch.

## Verify

Window survives a 1 s hitch.

## Origin

FNAP. Source notes: mistakes-log.md M15.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
