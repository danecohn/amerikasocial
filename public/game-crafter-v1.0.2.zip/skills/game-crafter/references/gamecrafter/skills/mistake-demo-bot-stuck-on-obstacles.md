---
id: mistake-demo-bot-stuck-on-obstacles
title: "Demo bot pressed against a pillar forever (no un-stick)"
category: mistake
when: "Writing any autopilot/bot that moves by steering straight toward a target in a room with obstacles (no pathfinding)."
related: []
origin: Roguelike series
---

# Demo bot pressed against a pillar forever (no un-stick)

**When to use:** Writing any autopilot/bot that moves by steering straight toward a target in a room with obstacles (no pathfinding).

## What happened, root cause, fix, prevention

- Symptom (SALT MINE 9 verification): the automated run stalled - the bot walked into a block/pillar between it and the enemy/door and slid in place; the room never cleared, autorun timed out with no RUN_END.
- Root cause: direct steering `mv = (want - position)` with axis-separated wall sliding can deadlock when the obstacle is perpendicular to the target direction; no pathfinding.
- Fix (kit): stuck detector - every 1.2s, if the bot moved < 3px since the last check, choose a random waypoint inside the open area (x 60..324, y 60..170) and follow it for 1.6s, then resume normal targeting.
```gdscript
_stuck_t += delta
if _stuck_t > 1.2:
    if position.distance_to(_last_p) < 3.0 and _wp_t <= 0.0:
        _wp = Vector2(Game.rng.randf_range(60, 324), Game.rng.randf_range(60, 170))
        _wp_t = 1.6
    _last_p = position
    _stuck_t = 0.0
if _wp_t > 0.0:
    _wp_t -= delta
    want = _wp
```
- Prevention: every bot needs a progress watchdog (position delta, or room-timer) plus a recovery behaviour; log the watchdog firing in debug.
- Detection: autorun with a timeout; missing RUN_END or ROOM count stops increasing => stuck.

## Verify

autorun completes on many seeds (`--seed=1..5`).

## Origin

Roguelike series. Source notes: WIP_BIBLE_AND_MANIFEST.md Game 3 "Kit fix: demo player now un-sticks itself from obstacles"; player.gd 36-39, 139-148.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
