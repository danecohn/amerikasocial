# Project memory protocol
An AI has no memory between sessions, and the next worker on the project may be a different AI (Cursor, another chat, a teammate agent). So the project remembers for you, in files that live **inside the project folder**.

## The memory files (create from `os/templates/` on day one)
| File | Purpose | Update when |
|---|---|---|
| `STATE.md` | **First file anyone reads.** Where things are, current status, last change, open problems, next steps, standing user instructions, how to build | every change, same turn |
| `GAME_BIBLE.md` | design truth: pillars, story, systems, art and audio direction, scope | design decisions |
| `MANIFEST.md` | what has been delivered: files, sizes, SHA256, verified/not verified | every delivery |
| `CHANGELOG.md` | dated list of changes and fixed bugs (in player words) | every change |
| `KNOWN_GAPS.md` | honest list of missing, unverified or placeholder things | whenever you find or close a gap |
| `docs/handoff/LOG.md` | timestamped work log for multi-session or multi-agent projects | each work block |
| `docs/handoff/<TOOL>_PROMPT.md` | the prompt that lets another AI continue | at hand-off points |
| `BOARD.md` / `OWNERS.md` | multi-agent coordination | team work |

## Session start
1. Read `STATE.md`, then `KNOWN_GAPS.md`, then the latest `CHANGELOG.md` entry, then `GAME_BIBLE.md` sections you'll touch.
2. Check the **project of record** (the folder the user calls authoritative, e.g. "THE FOLDER") against your working copy. If the user edited files since your last session, theirs win. Diff and merge, don't overwrite. (See `skills/mistake-user-edited-code-parse-error.md`.)
3. Re-read the standing user instructions in STATE.md before planning.

## Session end (or before any long wait or risky step)
1. Update STATE.md: status, last change, verified/not verified, next steps.
2. Append to CHANGELOG.md and LOG.md.
3. Sync the memory files to the user's project folder along with the code.

## Standing instructions
When the user states a lasting preference ("hallways must be dark", "never upload to itch", "credit line is X", "always include a soundtrack"), write it into `STATE.md → Standing instructions` the moment you hear it. Check every deliverable against that list.

## Where truth lives (in priority order)
1. What the user said most recently
2. The project of record on the user's machine
3. STATE.md / GAME_BIBLE.md
4. Your working copy (cloud working copies can be reset at any time, so never treat them as the only copy)

## GameCrafter's own memory
GameCrafter learns through `skills/`. A new mistake becomes a `mistake-*.md` skill. A new technique becomes a skill. Both get a line in `skills/SKILLS.md`. See BOOT.md §5.
