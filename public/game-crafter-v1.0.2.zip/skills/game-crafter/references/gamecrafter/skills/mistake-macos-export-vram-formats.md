---
id: mistake-macos-export-vram-formats
title: "macOS export refused (universal build texture formats)"
category: mistake
when: "Adding a macOS export preset."
related: []
origin: FNAP
---

# macOS export refused (universal build texture formats)

**When to use:** Adding a macOS export preset.

## Do this

project.godot: `rendering/textures/vram_compression/import_s3tc_bptc=true` AND `import_etc2_astc=true`.

## What happened, root cause, fix, prevention

Symptom: macOS export refused (reproduced twice in evals). Cause: universal build needs both VRAM formats. Fix above. Detection: export log.

## Verify

mac zip produced.

## Origin

FNAP. Source notes: mistakes-log.md M27.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
