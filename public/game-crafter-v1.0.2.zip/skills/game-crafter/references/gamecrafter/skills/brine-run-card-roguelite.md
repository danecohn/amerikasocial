---
id: brine-run-card-roguelite
title: "Slay-the-Spire-style roguelite mode on top of a survival office (map, jars, events, shop, bosses)"
category: roguelike-procgen
when: "Adding replayable meta mode after the story."
related: []
origin: Pickle's Pickle Shop
---

# Slay-the-Spire-style roguelite mode on top of a survival office (map, jars, events, shop, bosses)

**When to use:** Adding replayable meta mode after the story.

## Do this

`BrineRun` autoload holds ALL rules so a headless sim can play runs without scenes. 3 acts x 6 rows; row 0 all "shift"; rows 1-3 2-3 nodes of weighted types {shift 40, shelf 13, barrel 7, cursed 9, phone 7, event 15, shop 4, rest 5}; row 4 = rest + shop (random order); row 5 = boss. Links: each node to round(c/(n-1)*(m-1)) plus 50% a neighbour; then ensure every next-row node is reachable. Shift config per row: act params (hours 3/4/5, sec/hour 55/55/50, base AI 2/6.5/10 + slope 0.9/1.0/1.1 per row, extra drain 0/0.12/0.25, golden 0/4/6), 2-4 active characters at base+slope*row +-1, drain 1 + 0.04*depth + act drain. Bosses: act 1 Banshee 10 (+speed 1.15), act 2 "The Duo" Remi/Dilly 14, act 3 "Lights Out" Pickle 16 + dark office. Cards (`BrineCard` Resource: perk/trade/curse, common/rare/boss, effect + amount + secondary effect, price 6/8/12/16) apply to the office config in two passes (non-level effects, then AI-level effects): power_bonus, drain_reduction/increase, door_speed, stamina, clock_speed, extra_hour, door_cams, auto_close, golden_active, banshee_speed/calm, flicker_cams, assistant_reliability/unreliable/speed/hallucinate, ai_plus/minus, duo_calm, plus run-level scrip_bonus, shop_discount, shelf_choices, shift_reward_power, second_chance. Scrip income (3+act) or boss (8+2*act). Events are data dicts with choices {label, cost_scrip, needs_curse, chance, result, effects, fail_result, fail_effects}. Run save/resume. `brine_sim.gd` (refuses to run without --fnap-no-save) plays 300 runs with random/smart policies against a survival model fed by the real shift_config; tuned so random play wins 8-25%.

## Verify

brine_sim report; all KNOWN_EFFECTS covered.

## Origin

Pickle's Pickle Shop. Source notes: scripts/brine/brine_run.gd L1-460; brine_card.gd; brine_map.gd; dev/brine_sim.gd header.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
