---
id: design-bible-for-ai-writers
title: "Master design bible as source of truth for a writer-AI (Grok) + builder agents"
category: planning-design
when: "Starting a story-heavy RPG where one AI writes and others build; any project with lore that many agents must agree on."
related: []
origin: Caesarea
---

# Master design bible as source of truth for a writer-AI (Grok) + builder agents

**When to use:** Starting a story-heavy RPG where one AI writes and others build; any project with lore that many agents must agree on.

## Do this

- Bible sections that worked: 1 Brief/role for the writer AI + standing rules; 2 World & premise (timeline table: year | event | why it matters; social orders table); 3 Design pillars & tone + "Writing rules"; 4 Factions (goal | offer | cost); 5 Geography (region | setting | role); 6 Characters (backgrounds table with starting position + secret; companions with perspective + personal quest; antagonists each with an understandable want); 7 Act-by-act story, each act ending with a **Hinge Choice**, flag names in `monospace`; 8 Moral dilemmas (≥3 defensible options each); 9 Endings table (core requirement | outcome) + hidden failure state; 10 Gameplay systems; 11 Engine & Blender pipeline (autoload list, naming `CAE_<Category>_<Name>_<LOD>`, animation sets, audio direction); 12 Ordered production instructions for the writer (script → character bibles → quest sheets → dilemma scripts → ending scripts → remaining acts → systems docs → asset requests → engine scene plan) + style/format rules + **Open items for the human lead**.
- Writer notation that converts cleanly to data: `[CHOICE]` per branch, `{flag_name = value}` for every flag set, `[IF flag]` for conditional lines, `[CHECK Speech 20]`, `→ [NODE]`, screenplay headers `INT./EXT. LOCATION, TIME`. "Always mention, in design notes, which flag a line or choice sets and which later events read that flag."
- "Write for production: named assets, named scenes, named quests, clear triggers and flags." "Flag any change to canon in a short **CANON CHANGE** note at the top of the relevant document."
- Numbered production docs: 00 canon reconciliation, 01 script prologue+act I, 02 asset list, 03 character bibles, 05 dilemma scripts, 06 ending scripts, 07 systems, 08 Godot scene plan.

## Pitfalls (mistakes seen)

Bible assumed full voice acting and a dialogue wheel; the owner later ruled text-only → systems doc carries CANON CHANGE notes and keeps the data format wheel/list-agnostic so only the panel changes. Bible axis convention conflicted with asset list ("+Y forward → −Z") → scene plan declares canon and lists "owner should update" as an open item.

## Verify

every flag in the scripts exists in the ledger schema (`ledger_flags.py` check); every open item has a recorded answer or stays listed.

## Origin

Caesarea. Source notes: design/master_design_bible.md §1, §3, §12; design/07 header notes; design/08 §12.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
