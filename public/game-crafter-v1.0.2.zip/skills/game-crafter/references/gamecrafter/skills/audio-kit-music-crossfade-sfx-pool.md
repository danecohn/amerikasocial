---
id: audio-kit-music-crossfade-sfx-pool
title: "AudioKit: two-player music crossfade, 10-voice SFX pool, headless-safe"
category: audio-music
when: "Simple robust audio manager for a Godot game."
related: []
origin: Roguelike series
---

# AudioKit: two-player music crossfade, 10-voice SFX pool, headless-safe

**When to use:** Simple robust audio manager for a Godot game.

## Do this

- Music at `res://assets/audio/music/<name>.ogg`; play_music(name, fade=1.2): no-op if same; "" stops (fade to -60 dB then stop); alternate players A/B; new starts at -60 dB, tween to `linear_to_db(max(0.0001, vol))` while old fades to -60 then stops; previous tween killed. `loop = true` set on AudioStreamOggVorbis except stings.
- SFX `res://assets/audio/sfx/<name>.wav`; 10 AudioStreamPlayers, first free one used; pitch random 0.96-1.04 x requested; volume sfx*vol; skipped when `DisplayServer.get_name() == "headless"`.
- AudioKit node PROCESS_MODE_ALWAYS so fades work during pause.
- SFX vocabulary the kit calls: hit, die, boss_die, boom, hurt, heal, pickup, fragment, boon, clear, door, death, dash, shield, pulse, swing, shoot, enemy_shoot, warn, boss_roar, boss_slam, step, select, confirm, deny, bell, sting (27 numpy-synthesised per game, pitch/grit/seed varied per game: spec `sfx: {pitch 0.85-1.2, grit 0-2, seed}`).
- Music set per game (9 tracks): title, hub, run1-4, boss, sorrow, ending - each defined as (name, mood, key, mode, bpm, bars, seed), e.g. ("boss","boss","D","phrygian",140,32,17); moods sorrow/dread/chase/boss/hope; modes minor/dorian/phrygian/locrian/harmonic/major.

## Pitfalls (mistakes seen)

Missing audio prints PLACEHOLDER (never silent).

## Verify

no PLACEHOLDER missing audio lines in autorun log.

## Origin

Roguelike series. Source notes: audio_kit.gd; spec.py SPEC["music"], "sfx".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
