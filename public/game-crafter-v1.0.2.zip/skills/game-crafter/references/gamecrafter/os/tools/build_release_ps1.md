# Tool: build_release.ps1

**Purpose:** Same release build on the user's Windows PC (x64 or ARM64 Godot).

**Usage:** `powershell -ExecutionPolicy Bypass -File build_release.ps1 -Project <dir> -Out <dir>`

**Skill:** see `skills/export-presets-four-platforms.md`

**Extract:** save the block below as `build_release.ps1` (exact contents) and run it. Adapt paths marked `<...>`.

```powershell
<# Game Maker: build release zips ON A WINDOWS PC (x64 or ARM64 host). Exec bits preserved for Linux/Mac targets.
   powershell -NoProfile -ExecutionPolicy Bypass -File build_release.ps1 -Godot "C:\GameTools\godot\Godot_v4.7.2-stable_win64_console.exe" -Project "C:\Games\MyGame\Godot" -Out "C:\Games\MyGame\DISTRIBUTION" -Name MyGame [-Extras C:\Games\MyGame\DISTRIBUTION\_inputs] [-Targets Windows,Linux,Mac,WindowsARM64]
   - Use the *_console.exe Godot so output and $LASTEXITCODE are capturable.  - Templates for the SAME version (and arm64 templates for the ARM64 target) must be installed on this PC.
   - Writes <script dir>\release.log (Start-Transcript) so a remote agent can read the result back. READ IT before reporting success.
   - Preset names must match export_presets.cfg exactly: "Windows Desktop", "Linux", "macOS", "Windows ARM64" (edit $Presets below if yours differ). #>
param(
  [Parameter(Mandatory)][string]$Godot, [Parameter(Mandatory)][string]$Project, [Parameter(Mandatory)][string]$Out, [Parameter(Mandatory)][string]$Name,
  [string]$Extras = "", [string[]]$Targets = @("Windows","Linux","Mac","WindowsARM64")
)
$ErrorActionPreference = "Stop"
Start-Transcript -Path (Join-Path $PSScriptRoot "release.log") -Force | Out-Null
try {
  Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
  $Presets = @{ Windows="Windows Desktop"; Linux="Linux"; Mac="macOS"; WindowsARM64="Windows ARM64" }
  $Stage = Join-Path $env:TEMP "gm_release"; if (Test-Path $Stage) { Remove-Item -Recurse -Force $Stage }
  New-Item -ItemType Directory -Force $Stage, $Out | Out-Null
  & $Godot --headless --path $Project --import --quit; if ($LASTEXITCODE -ne 0) { throw "import failed ($LASTEXITCODE)" }
  function Export($preset, $file) {
    New-Item -ItemType Directory -Force (Split-Path $file) | Out-Null
    & $Godot --headless --path $Project --export-release $preset $file
    if ($LASTEXITCODE -ne 0) { throw "export '$preset' failed ($LASTEXITCODE) - preset missing from export_presets.cfg? templates not installed?" }
  }
  function AddExtras($dir) { if ($Extras -and (Test-Path $Extras)) { Copy-Item -Recurse -Force (Join-Path $Extras "*") $dir } }
  # Zip a folder; entries matching $exe patterns get unix mode 755 so Linux binaries run without chmod. PowerShell's default loses exec bits.
  function ZipDir($src, $zip, $exe) {
    if (Test-Path $zip) { Remove-Item -Force $zip }
    $fs = [IO.File]::Open($zip, 'Create'); $za = New-Object IO.Compression.ZipArchive($fs, 'Create')
    $base = (Resolve-Path $src).Path.TrimEnd('\') + '\'
    Get-ChildItem -Recurse -File $src | ForEach-Object {
      $rel = $_.FullName.Substring($base.Length).Replace('\','/')
      $e = $za.CreateEntry("$Name/$rel", 'Optimal')
      $mode = 420; if ($exe | Where-Object { $rel -like $_ }) { $mode = 493 }
      $e.ExternalAttributes = (0x8000 + $mode) -shl 16
      $s = $e.Open(); $f = [IO.File]::OpenRead($_.FullName); $f.CopyTo($s); $f.Dispose(); $s.Dispose()
    }
    $za.Dispose(); $fs.Dispose()
  }
  foreach ($t in $Targets) {
    $d = Join-Path $Stage "$t\$Name"
    switch ($t) {
      "Windows"      { Export $Presets.Windows      "$d\$Name.exe";      AddExtras $d; ZipDir $d (Join-Path $Out "${Name}_Windows.zip") @() }
      "WindowsARM64" { Export $Presets.WindowsARM64 "$d\$Name.exe";      AddExtras $d; ZipDir $d (Join-Path $Out "${Name}_Windows_ARM64.zip") @() }
      "Linux"        { Export $Presets.Linux        "$d\$Name.x86_64";   AddExtras $d; ZipDir $d (Join-Path $Out "${Name}_Linux.zip") @("$Name.x86_64") }
      "Mac"          {   # keep Godot's own mac zip (carries .app exec bits) and APPEND extras with ZipFile Update - never unzip/rezip on Windows
                        $mz = Join-Path $Stage "$Name-mac.zip"; Export $Presets.Mac $mz
                        $o = Join-Path $Out "${Name}_Mac.zip"; Copy-Item -Force $mz $o
                        if ($Extras -and (Test-Path $Extras)) {
                          $za = [IO.Compression.ZipFile]::Open($o, 'Update')
                          Get-ChildItem -Recurse -File $Extras | ForEach-Object { [void][IO.Compression.ZipFileExtensions]::CreateEntryFromFile($za, $_.FullName, $_.FullName.Substring($Extras.TrimEnd('\').Length + 1).Replace('\','/')) }
                          $za.Dispose() } }
    }
  }
  Get-ChildItem $Out -Filter *.zip | Format-Table Name, @{n='MB';e={[math]::Round($_.Length/1MB,1)}}, LastWriteTime
  Remove-Item -Recurse -Force $Stage
  Write-Host "RELEASE_DONE"
} catch { Write-Host "FAILED: $_" }
Stop-Transcript | Out-Null
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
