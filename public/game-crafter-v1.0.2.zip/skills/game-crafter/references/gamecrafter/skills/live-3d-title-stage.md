---
id: live-3d-title-stage
title: "Title screen with the live 3D cast on a lit stage in a SubViewport"
category: ui-ux
when: "A 3D game's main menu should show the real characters animated."
related: []
origin: Pickle's Pickle Shop
---

# Title screen with the live 3D cast on a lit stage in a SubViewport

**When to use:** A 3D game's main menu should show the real characters animated.

## Do this

SubViewport 1600x900 own_world_3d, UPDATE_ALWAYS, shown full-screen. Environment: dark BG, ambient (0.16,0.2,0.3) 0.32, filmic, glow 0.7 bloom 0.08, fog 0.035. Camera fov 34 at (0.6,2.3,11.8). Box-built stage, arch, 3 shelves x 22 cylinder jars, Label3D marquee sign, 9-fold velvet curtains each side + valance, 28 marquee bulbs chasing (on/off materials, every 3rd off; steady when reduce_flicker), footlight + green fill. Each cast member: ModelLoader by stem, signature clip forced LOOP_LINEAR (remi play_bass, dilly idle with periodic `serve` then back to idle via CONNECT_ONE_SHOT, pickle sing, banshee cove_peek, golden slump), coloured SpotLight3D 6.0 (golden 2.2) + additive cone mesh (alpha 0.05) + light pool disc; spots breathe +-4%, Banshee's stutters. CPUParticles3D dust. Mouse parallax via camera h/v_offset; `set_frame_shift(-2.6)` pushes the cast right of the menu; gradient TextureRect fades the left side for the menu text.

## Verify

ui_shot of main_menu.tscn.

## Origin

Pickle's Pickle Shop. Source notes: scripts/ui/cast_stage.gd; main_menu.gd L20-50; MANIFEST.md "cast-on-stage main menu".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
