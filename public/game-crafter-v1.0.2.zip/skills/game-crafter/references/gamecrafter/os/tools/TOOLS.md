# os/tools — ready-to-extract scripts
Every tool is a Markdown file holding one script in a code block. Save the block under the given file name, then run it. These are the real tools used to ship FNAP, Pickle's Pickle Shop, Caesarea and the roguelike series.

**Paths:** the factory tools assume a root like `/home/claude/evac/` (`_tools/`, `kit/`, `games/`, `build/`, `out/`). Replace it with your own root, or better, make it relative to `__file__` (see `skills/mistake-hardcoded-absolute-tool-paths.md`).

| Tool file | Script | What it does | Skill |
|---|---|---|---|
| `lint_export_safety.md` | `lint_export_safety.py` | Static lint that catches code which works in the editor but breaks in an exported build (raw res:// file APIs, globalize_path, DirAccess listings without packed_name, data files missing from include_filter). | `godot-export-safe-asset-loading` |
| `verify_export.md` | `verify_export.sh` | Export a pack, run the export probe from the PACK, take a screenshot from the PACK. The proof step before any 'done'. | `verify-the-exported-build` |
| `build_release_sh.md` | `build_release.sh` | Export all platform presets and zip them with correct executable bits (Linux/macOS). | `export-presets-four-platforms` |
| `build_release_ps1.md` | `build_release.ps1` | Same release build on the user's Windows PC (x64 or ARM64 Godot). | `export-presets-four-platforms` |
| `godot_xvfb.md` | `godot_xvfb.sh` | Run Godot with a virtual display and software rendering on a GPU-less cloud machine (screenshots, Movie Maker). | `headless-screenshot-harness-xvfb` |
| `bg_run.md` | `bg_run.sh` | Run a long job in the background with a log and timeout so the agent can poll instead of blocking. | `background-long-jobs-bg-run` |
| `ensure_swap.md` | `ensure_swap.sh` | Add swap on small cloud boxes so Godot imports / Blender / ffmpeg don't get OOM-killed. | `cloud-swapfile-for-oom` |
| `check_env.md` | `check_env.sh` | Environment check: Godot + matching export templates, Blender, ffmpeg, Xvfb, Python libs, disk, RAM. | `check-env-game-tools` |
| `install_tools_sh.md` | `install_tools.sh` | Install Godot (standard) + export templates + Blender + ffmpeg + Xvfb on Linux/macOS. | `godot-install-export-templates` |
| `install_tools_ps1.md` | `install_tools.ps1` | Install Godot + templates on Windows x64/ARM64. | `godot-install-export-templates` |
| `inspect_glb.md` | `inspect_glb.py` | List nodes, meshes, materials, skins and animations inside a .glb (no Blender needed). | `blender-godot-node-name-contract` |
| `pose_render.md` | `pose_render.py` | Headless Blender: pose an armature on an action frame (no T-pose) and render a Cycles still for title/store art. | `pose-render-character` |
| `make_test_glb.md` | `make_test_glb.py` | Headless Blender: make a tiny rigged test .glb to prove the Blender→Godot pipeline end to end. | `make-test-glb` |
| `ffmpeg_recipes.md` | `ffmpeg_recipes.sh` | ffmpeg recipes for trailers, vertical reels, music beds, fades, title cards, thumbnails. | `ffmpeg-recipe-library` |
| `export_probe.md` | `export_probe.gd` | A probe scene script that loads every required resource from inside the exported pack and prints PROBE_FAIL / PROBE_DONE fails=N. | `export-probe-template` |
| `glb_check.md` | `glb_check.gd` | Checks that every node name the code expects exists in each GLB (the Blender↔code name contract). | `blender-godot-node-name-contract` |
| `node_finder.md` | `node_finder.gd` | Name-based node lookup helpers + packed_name() for export-safe directory listings. | `godot-export-safe-asset-loading` |
| `model_loader.md` | `model_loader.gd` | Export-safe GLB loading with a LOUD placeholder fallback. | `loud-placeholders` |
| `clip_manifest.md` | `clip_manifest.gd` | Required animation clips per character; fails loudly when a clip is missing. | `clip-manifest-json` |
| `anim_import.md` | `anim_import.gd` | EditorScenePostImport that sets loop modes / names on imported animation clips. | `clip-manifest-json` |
| `game_state_template.md` | `game_state_template.gd` | Crash-safe save system: atomic write (tmp+rename), save on progress + close request + quit. | `godot-crash-safe-forward-only-save` |
| `static_shader.md` | `static.gdshader` | Camera-feed static/noise shader for security monitors. | `security-camera-feed-subviewport` |
| `hide_audit.md` | `hide_audit.sh` | Greps for 'fixes' that hide problems (visible=false, energy=0, layer zeroing, flat materials) so each can be justified. | `never-fix-by-hiding-hide-audit` |
| `static_checks.md` | `static_checks.py` | Project static checks used on Caesarea (parse sanity, forbidden patterns, data references). | `static-checks-no-godot` |
| `shot_gd.md` | `shot.gd` | Screenshot scene: load a target scene, wait frames, save PNG; args via environment variables. | `headless-screenshot-harness-xvfb` |
| `run_all_tests.md` | `run_all_tests.sh` | Runs every headless test scene and summarizes PASS/FAIL with exit codes. | `static-checks-no-godot` |
| `sprites.md` | `sprites.py` | Procedural pixel-art sprite toolkit: palettes, ASCII sprite maps, outlines, shading, animation frames, sheets. | `sprite-recipe-grammar` |
| `tiles.md` | `tiles.py` | Procedural pixel-art tiles, props and UI frames for 8-bit games. | `tileset-theme-dict` |
| `fonts.md` | `fonts.py` | Original 5x7 pixel font generator with several stylings → TTF/bitmap fonts for Godot. | `bitmap-pixel-font-to-ttf` |
| `cover.md` | `cover.py` | Builds a 630x500 itch.io cover from a native-resolution screenshot + title font. | `itch-cover-630x500-from-screenshot` |
| `contact.md` | `contact.py` | Contact sheet of generated sprites/tiles so you can LOOK at all the art at once. | `evidence-rule` |
| `sfx.md` | `sfx.py` | Procedural SFX with numpy (hits, steps, pickups, doors, stingers), per-game flavour by pitch + grit. | `numpy-sfx-synth-primitives` |
| `bbcompose.md` | `bbcompose.py` | Composes BeepBox songs (chiptune) as BeepBox URL hashes from mood parameters. | `beepbox-offline-render-node-typescript` |
| `render_bb.md` | `render_bb.ts` | Renders a BeepBox song hash to WAV offline with the real BeepBox synth (MIT) — works when beepbox.co is unreachable. | `beepbox-offline-render-node-typescript` |
| `buildgame.md` | `buildgame.py` | Assembles one complete Godot game project from the shared kit + a game spec (art, fonts, music, sfx, data). | `factory-spec-to-game-assembly` |
| `gk.md` | `gk.py` | Game-authoring helpers used by every game spec (dialogue, rooms, enemies, items, story beats). | `game-spec-module-contract` |
| `release_py.md` | `release.py` | Exports 4 platforms, builds zips with soundtrack + README, splits big zips into parts with SHA256. | `export-presets-four-platforms` |
| `pack.md` | `pack.py` | Assembles the finished game folder: ADVERTISEMENTS, DOCS, bible, manifest, README, soundtrack.txt. | `per-game-delivery-folder-layout` |
| `finish.md` | `finish.py` | Zips the project source, writes MANIFEST.md, stages the whole game folder for delivery. | `per-game-delivery-folder-layout` |
| `probe_gd.md` | `probe.gd` | Minimal probe used by the factory to boot a game in the exported build and log. | `export-probe-template` |
| `autorun.md` | `autorun.sh` | Runs the game with the automatic demo player for N seconds and prints the interesting log lines. | `automated-demo-player-bot` |
| `shot_sh.md` | `shot.sh` | Native-resolution (384x216) screenshot of a pixel game under Xvfb. | `headless-screenshot-harness-xvfb` |

**Third-party:** `render_bb.ts` drives the open-source BeepBox synth (MIT, github.com/johnnesky/beepbox). Get its `synth/` sources from that repo (or the `beepbox` npm package) rather than copying from here.
