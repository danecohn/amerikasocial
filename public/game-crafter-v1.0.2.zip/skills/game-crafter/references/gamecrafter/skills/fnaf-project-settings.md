---
id: fnaf-project-settings
title: "Project settings worth copying for a 3D horror game"
category: godot-engine
when: "Creating project.godot for a similar game."
related: []
origin: FNAP
---

# Project settings worth copying for a 3D horror game

**When to use:** Creating project.godot for a similar game.

## Do this

- `window/size 1920x1080`, `window_width_override 1600 x 900` (smaller window, full-res canvas), `stretch/mode=canvas_items`,
  `rendering/anti_aliasing/quality/msaa_3d=1`, VRAM compression `import_s3tc_bptc=true` and `import_etc2_astc=true`
  (needed so the macOS export is allowed), clear color black, custom user dir, `config/windows_native_icon=.ico`.
- Custom `[fnap]` section for project data (`branding/splash_video`) read via `ProjectSettings.get_setting`.
- Autoload order matters: `GameState` (save + CLI) first; `Director._ready` reads `GameState.capture`;
  `AudioManager.process_mode = ALWAYS`.
- Buses: Master + Music, SFX, Ambience (`default_bus_layout.tres`).

## Pitfalls (mistakes seen)

macOS preset invalid without s3tc/bptc or etc2/astc VRAM compression enabled.

## Verify

All 4 export presets show valid in a headless export.

## Origin

FNAP. Source notes: REF §1.6, §1.3, §1.1, §4.1.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
