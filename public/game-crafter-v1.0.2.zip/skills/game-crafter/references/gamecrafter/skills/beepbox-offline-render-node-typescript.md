---
id: beepbox-offline-render-node-typescript
title: "Render BeepBox songs offline with the real BeepBox synth (beepbox.co unreachable)"
category: audio-music
when: "You want chiptune music with editable source but the cloud cannot reach beepbox.co; any procedural music need."
related: [mistake-runtime-doc-mismatch-node-vs-bun]
origin: Roguelike series
---

# Render BeepBox songs offline with the real BeepBox synth (beepbox.co unreachable)

**When to use:** You want chiptune music with editable source but the cloud cannot reach beepbox.co; any procedural music need.

## Do this

- Vendor BeepBox's MIT synth source (`synth.ts`, `SynthConfig.ts`, `FFT.ts`, `filtering.ts`, `Deque.ts`) into `_tools/bb_synth/` with `index.ts` = `export * from "./synth.js";` and compile with tsc using tsconfig: `{"compilerOptions":{"target":"ES2020","module":"ES2020","moduleResolution":"node","outDir":"bb_out","rootDir":"bb_synth","ignoreDeprecations":"6.0","strict":false,"noEmitOnError":false,"skipLibCheck":true,"lib":["ES2020","DOM"]},"include":["bb_synth/**/*.ts"]}`. `strict:false`/`noEmitOnError:false` are needed: the browser-oriented source has DOM bits and private members.
- Driver render_bb.ts (run with `bun run render_bb.ts <song.json|hash|URL> out.wav [seamless]`):
```ts
import { Song, Synth } from "./bb_out/synth";
let song: any;
if (input.endsWith(".json")) { song = new Song(); song.fromJsonObject(JSON.parse(fs.readFileSync(input,"utf8")));
  fs.writeFileSync(out + ".hash.txt", song.toBase64String()); }   // -> beepbox.co link
else { song = new Song(input.includes("#") ? input.split("#")[1] : input); }
const synth: any = new Synth(song);
synth.samplesPerSecond = 44100;
synth.loopRepeatCount = seamless ? 1 : 0;
synth.isPlayingSong = true;          // private field, hence `any`
synth.warmUpSynthesizer(song);       // private method
while (synth.playing && guard++ < 100000) { synth.synthesize(l, r, 4096, true); push... }
```
- Then write a 16-bit stereo PCM WAV by hand (RIFF header, 44100 Hz, block align 4, clamp to [-1,1], *32767). Non-seamless renders trim trailing digital silence below 1e-4 (but keep at least 1 s).
- `synth.playing` becomes false after `loopRepeatCount` extra loops; the guard prevents infinite loops.
- Disclose honestly: "real BeepBox synth output rendered offline; links open the same songs on beepbox.co; not hand-edited in the website".

## Pitfalls (mistakes seen)

WIP doc says the factory "needs node" but bbcompose.py calls `bun run` - see mistake-runtime-doc-mismatch-node-vs-bun. The compiled output was found twice (`bb_out/` and `bb_out/bb_synth/`) - set rootDir correctly so tsc emits one tree.

## Verify

render prints `wrote out.wav <secs>s bars N loopStart loopLen`; WAV plays; pasting `https://www.beepbox.co/#<hash>` in a browser loads the same song.

## Origin

Roguelike series. Source notes: _tools/render_bb.ts L1-48; tsconfig.json; bb_synth/index.ts; synth.ts L4609-4700 (warmUpSynthesizer private, loopRepeatCount, isPlayingSong, get playing), L4917 synthesize().

## Related skills

- [mistake-runtime-doc-mismatch-node-vs-bun](mistake-runtime-doc-mismatch-node-vs-bun.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
