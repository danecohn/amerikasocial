---
id: mistake-pkill-killed-shell
title: "pkill -f godot` killed the controlling shell"
category: mistake
when: "Killing Godot processes."
related: []
origin: FNAP
---

# pkill -f godot` killed the controlling shell

**When to use:** Killing Godot processes.

## Do this

`pkill -x godot` or kill by saved PID (`kill_godot.sh`).

## What happened, root cause, fix, prevention

Symptom: shell died. Cause: pattern matched own command line. Fix above.

## Verify

Shell survives.

## Origin

FNAP. Source notes: mistakes-log.md M55.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
