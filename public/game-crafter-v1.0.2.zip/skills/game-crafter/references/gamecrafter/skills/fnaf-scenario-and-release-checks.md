---
id: fnaf-scenario-and-release-checks
title: "Scenario sims and release assertions against the real office"
category: testing-qa
when: "Proving door/enemy/marker behaviour headlessly before release."
related: [mistake-test-asset-path-drift]
origin: FNAP
---

# Scenario sims and release assertions against the real office

**When to use:** Proving door/enemy/marker behaviour headlessly before release.

## Do this

- `door_lurker_sim.gd/.tscn`: drives the real office with a Stub controller: real door parts present, lurk layout, door
  motion, Pickle/Dilly advance, Remi flashlight retreat, half-shut door blocks scare, Banshee sprint; optional
  `-- --shots <dir>`.
- `release_check.gd/.tscn`: 20+ named assertions: 11 room models loaded, real office, hall lights start at 0, required
  marker names exist (`Lurk_DoorL/R`, `AutoConsole`, `DoorMotor/Lamp`, `AlarmLight(_Spinner)`, `PlayerCamera`), curtain
  grip/mesh resolve.
- Visual checks: `cam_feed_check` (PNG per camera), `hall_check` (structure dump + dark/flashlight/hall-light shots),
  `curtain_check`, `char_check`, `visual_check` (screenshot tour), `phone_check`, `poster_swaps_test`.
- Convention: print `PASS/FAIL` or `SHOT <label>`/`OK`/`FAIL`; set `GameState.cli["skip-intro"]="1"`,
  `o.clock.running=false`, `o.set_process(false)` to freeze the world; `quit(1)` on failure.
- Rendering checks need Xvfb + software Vulkan: `xvfb-run -a -s '-screen 0 1280x720x24' godot --path <proj>
  --rendering-driver vulkan --resolution 1280x720 -- <flags>`; screenshot idiom `await RenderingServer.frame_post_draw`
  then `get_viewport().get_texture().get_image().save_png(path)`.

## Pitfalls (mistakes seen)

mistake-test-asset-path-drift.

## Verify

All checks exit 0; PNGs opened and looked at.

## Origin

FNAP. Source notes: REF §5.1, §5.2.

## Related skills

- [mistake-test-asset-path-drift](mistake-test-asset-path-drift.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
