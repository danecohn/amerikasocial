---
id: honest-ship-report
title: "Final ship report: what changed, what was verified, what was NOT"
category: core-workflow
when: "Ending any delivery to the user."
related: []
origin: Pickle's Pickle Shop
---

# Final ship report: what changed, what was verified, what was NOT

**When to use:** Ending any delivery to the user.

## Do this

Structure used: location + how to unpack (run BUILD_ALL.bat); "What changed" bullets in player terms (dark rooms, jumpscares, HUD, animations, assistant commands, source synced + JOIN_OFFICE_GLB.bat note); "What I checked" (screenshots of 5 jumpscares, dark door unlit/lit, hall cam - on a DEBUG export of the same code, not the zips; lint 0 errors); "What I didn't check" (zips not launched on real Windows/ARM64/macOS; final brightness constants changed after the last screenshots - ask the user to look; balance/minigames lightly tested); "Nothing was uploaded to itch.io." Also update SHIP_NOTES.txt / MANIFEST with Done / Not verified / TODO.

## Pitfalls (mistakes seen)

Earlier SHIP_NOTES admitted "NOT verified: screenshot from the exported build (hall darkness and textures)" - and that is exactly where the user then found the placeholder/no-texture bug. Prevention: never ship without screenshots from an exported build of the user-visible states.

## Verify

Report contains both verified and not-verified lists.

## Origin

Pickle's Pickle Shop. Source notes: transcript L324-344; SHIP_NOTES.txt; MANIFEST.md TODO.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
