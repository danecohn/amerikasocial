---
id: godot-crash-safe-forward-only-save
title: "Crash-safe, forward-only save system (atomic write + .bak + fallback chain)"
category: gdscript-patterns
when: "Any game that saves progress."
related: []
origin: FNAP
---

# Crash-safe, forward-only save system (atomic write + .bak + fallback chain)

**When to use:** Any game that saves progress.

## Do this

- Write: save to `.tmp` -> copy current save to `.bak` -> rename `.tmp` over the save (with a remove+rename fallback when rename fails because target exists).
- Forward-only merge: before writing, read the disk save and take `max()` of progress, `or` of completion flags, so a stale in-memory state can never regress progress.
- Load fallback chain `[save, .bak, .tmp]`: first file that parses AND has the expected section wins; clamp every value.
- Save triggers: night/level change, `NOTIFICATION_WM_CLOSE_REQUEST`, `NOTIFICATION_APPLICATION_FOCUS_OUT`, `NOTIFICATION_APPLICATION_PAUSED`, and inside the single `quit_game()`. `get_tree().set_auto_accept_quit(false)` so the close request can save first.
- Dev/QA flags must NEVER overwrite the real save (`_dev_switch_active()`).
```gdscript
const SAVE_PATH := "user://save.cfg"; const SAVE_TMP := "user://save.cfg.tmp"; const SAVE_BAK := "user://save.cfg.bak"
func save() -> void:
    if _dev_switch_active(): return
    var disk := ConfigFile.new()
    var disk_ok := FileAccess.file_exists(SAVE_PATH) and disk.load(SAVE_PATH) == OK
    if disk_ok:
        highest_level = maxi(highest_level, clampi(int(disk.get_value("progress","highest_level",1)),1,MAX_LEVEL))
        completed = completed or bool(disk.get_value("progress","completed",false))
    var out := ConfigFile.new()
    out.set_value("progress","highest_level",highest_level); out.set_value("progress","completed",completed)
    if out.save(SAVE_TMP) != OK: return
    if disk_ok: DirAccess.copy_absolute(SAVE_PATH, SAVE_BAK)
    if DirAccess.rename_absolute(SAVE_TMP, SAVE_PATH) != OK:
        DirAccess.remove_absolute(SAVE_PATH); DirAccess.rename_absolute(SAVE_TMP, SAVE_PATH)
func load_save() -> void:
    for path in [SAVE_PATH, SAVE_BAK, SAVE_TMP]:
        var cfg := ConfigFile.new()
        if FileAccess.file_exists(path) and cfg.load(path) == OK and cfg.has_section("progress"):
            highest_level = clampi(int(cfg.get_value("progress","highest_level",1)),1,MAX_LEVEL)
            completed = bool(cfg.get_value("progress","completed",false)); level = highest_level; return
```

## Pitfalls (mistakes seen)

Multiple raw `get_tree().quit()` calls skipped saving; replaced all with the wrapper.

## Verify

Headless `scripts/dev/save_test.tscn`: write -> reload -> simulated close -> simulated crash; prints `RESULT: OK (0 failures)`, exit 0/1. FNAP's save "survived close/crash tests; dev flags never touched the real save".

## Origin

FNAP. Source notes: T/godot_core/game_state_template.gd lines 1-83; G "Save system" (lines 51-52); L §2.11 (lines 131-133); S Non-negotiable 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
