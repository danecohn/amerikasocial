---
id: mistake-placeholder-hide-breaks-real-model
title: "Mistake - hiding the placeholder after a "load" that failed or that removed nodes other code needed"
category: mistake
when: "Writing `load model -> hide placeholder` code; characters invisible; halls as 'two black squares'; office missing; door rigs not found."
related: [never-fix-by-hiding-hide-audit]
origin: FNAP
---

# Mistake - hiding the placeholder after a "load" that failed or that removed nodes other code needed

**When to use:** Writing `load model -> hide placeholder` code; characters invisible; halls as "two black squares"; office missing; door rigs not found.

## Do this

n/a (pure mistake).

## What happened, root cause, fix, prevention

- Symptom: characters invisible in play, halls = "two black squares", office missing.
- Root cause: pattern `load model -> hide placeholder` ran the hide even when the model was null/wrong; or it hid ALL `GeometryInstance3D` on the placeholder, including door shutter boxes the door rigs were bound to. `level_builder.gd` hid every placeholder mesh once `office.glb` loaded, so `DoorRig_L/R` lookups broke.
- Fix: hide the placeholder only AFTER a successful instantiate that contains mesh nodes; look up rigs on the real model; keep a loud `push_warning` on fallback; never hide meshes / zero render layers / flatten to a colour as a fix.
- Prevention: placeholder removal condition = "real instance exists AND has >=1 MeshInstance3D AND required rig nodes found".
- Detection: hide audit grep (see never-fix-by-hiding-hide-audit); `tools/glb_check.gd`, `loader_check.gd`.

## Verify

Hide-audit hits all justified; loader_check `LOADER_DONE missing=0`; pack screenshot shows real models and working doors.

## Origin

FNAP. Source notes: L §2.2 (lines 82-86); L §10 line 446 (hide-audit hits: `level_builder.gd:192 hall Room lights energy=0`, `:250/252 hides PLACEHOLDER office`, `:838-840 _hide_placeholder_meshes`, `animatronic.gd:287 _placeholder hidden after _model added`, `door.gd:53 Shutter placeholder hidden`).

## Related skills

- [never-fix-by-hiding-hide-audit](never-fix-by-hiding-hide-audit.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
