---
id: game-bible-template
title: "GAME_BIBLE.md template for a shipped small game"
category: planning-design
when: "Documenting a game for the user, future agents or a sequel."
related: []
origin: Roguelike series
---

# GAME_BIBLE.md template for a shipped small game

**When to use:** Documenting a game for the user, future agents or a sequel.

## Do this

Sections: header line (Studio | Engine Godot 4.7.2 (GDScript, 2D, gl_compatibility) | Resolution 384x216 integer scaled | Version); Pitch; Story (protagonist, THE TWIST and when revealed, THE CHOICE, Endings with conditions, Tone); Cast table (ID, Name, Role, Talk-blip Hz/wave, boss HP); Structure (hub contents, run shape 5/5/5/4 rooms + boss, door/reward types, floor names, meta upgrade names, difficulty tiers, story gating); Mechanics (weapon, ability + cooldown, resource system numbers, counts of boons/events/enemies/bosses); Art/Audio (procedural tools, font, palette words, 9 songs list, SFX count); Content notes.

## Pitfalls (mistakes seen)

none.

## Verify

bible numbers match game.json.

## Origin

Roguelike series. Source notes: */DOCS/GAME_BIBLE.md; meta.py "bible".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
