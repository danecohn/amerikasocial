---
id: mistake-demo-too-big-to-stage
title: "850 MB demo couldn't be staged (400 MB limit)"
category: mistake
when: "Need to inspect a large file on the user PC."
related: []
origin: FNAP
---

# 850 MB demo couldn't be staged (400 MB limit)

**When to use:** Need to inspect a large file on the user PC.

## Do this

Bridge stage limit ~400 MB/file. Say so; ask for screenshots; never invent what it contains.

## What happened, root cause, fix, prevention

Symptom: stage refused. Fix above.

## Verify

n/a - honesty rule.

## Origin

FNAP. Source notes: mistakes-log.md M75.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
