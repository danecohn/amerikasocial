---
id: mistake-approval-per-call
title: "Each stage/commit call needs user approval"
category: mistake
when: "Transferring many files to/from PC."
related: []
origin: FNAP
---

# Each stage/commit call needs user approval

**When to use:** Transferring many files to/from PC.

## Do this

Batch up to 45-50 files per call; never repeat calls unnecessarily.

## What happened, root cause, fix, prevention

Symptom: user flooded with approvals. Fix above.

## Verify

Number of calls minimal.

## Origin

FNAP. Source notes: mistakes-log.md M76.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
