---
id: canon-reconciliation-doc
title: "Canon reconciliation — KEEP / FOLD IN / RETIRE table between old project and new bible"
category: planning-design
when: "A project restarts/reboots over an older build (different engine, renamed city, retired mechanics) or multiple writers produced conflicting docs."
related: []
origin: Caesarea
---

# Canon reconciliation — KEEP / FOLD IN / RETIRE table between old project and new bible

**When to use:** A project restarts/reboots over an older build (different engine, renamed city, retired mechanics) or multiple writers produced conflicting docs.

## Do this

- State the **order of authority**: (1) owner's direct rules → (2) master bible → (3) older project files → (4) anything invented, marked CANON CHANGE / CANON ADDITION.
- Key: KEEP = canon as-is; FOLD IN = keep the idea, rename/relocate; RETIRE = drop from canon (files kept for reference).
- Table columns: # | Existing project | Bible/owner | Rec. | Resolution. Examples: old capital RETIRED as city but its planning grammar FOLDED into the new capital; radio renamed (re-record only cues that say the name); 4 origins become an optional Heritage tag (flavor lines only, never gates a path); voxel look RETIRED but keep boot.gd and the autoload pattern; Java build RETIRED as code, KEPT as lore source; region ID remap (`rubicon→roma, spire→new_caesarea, shore→littoral`); old "five sealable paths" mapped to seven endings; old flags mapped (`house_aware → house_found`).
- Separate list of **CANON CHANGES** (owner overrides: text-only dialogue, only spoken audio is the radio announcer, fully modeled 3D, boot/credits flow) and **CANON ADDITIONS** (fill gaps without contradicting).
- Answer the bible's open items with a recommendation each (tone limits, romance scope, target length, voice plan).
- Required boot/credits flow table at top (step | visual | audio | notes) because it applies to every build.

## Pitfalls (mistakes seen)

leaving old names in assets (`radio-00-vox-rubicon-ident`) → listed as an open "canon question" rather than silently renamed.

## Verify

grep the codebase for retired names; each hit is either in a legacy folder or listed.

## Origin

Caesarea. Source notes: design/00_canon_reconciliation.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
