---
id: boss-phase-pattern-presets
title: "Three-phase boss attack presets (gunner/caster/brute/swarm/trickster)"
category: ai-enemies
when: "Designing bullet-pattern bosses quickly; giving each of 4 bosses a distinct feel from data."
related: []
origin: Roguelike series
---

# Three-phase boss attack presets (gunner/caster/brute/swarm/trickster)

**When to use:** Designing bullet-pattern bosses quickly; giving each of 4 bosses a distinct feel from data.

## Do this

- Boss = `{"name","title","hp","speed","size","damage":1,"mem","keep"(preferred distance),"music":"boss","phases":[...], "phase_lines":[[p2 lines],[p3 lines]]}`.
- Phase = `{"at": hp_fraction_threshold, "gap": seconds between patterns, "patterns": [...]}` with at = 1.0 / 0.6 / 0.3 (trickster 0.65), gaps shrink (1.3->1.0->0.8; trickster 1.0->0.8->0.65).
- Pattern types: `aimed {n, spread, speed, homing}`, `ring {n, speed}`, `spiral {dur, rate, turn}`, `rain {dur, rate}`, `charge`, `slam {r}`, `teleport`, `summon {enemy, n}`.
- Example gunner: P1 aimed n3 spread0.3 sp90 + ring n10 sp60 + summon 2; P2 aimed n5 sp100, charge, ring n14 sp62, slam r56; P3 spiral 3.0s, aimed n5 sp115, charge, ring n18 sp66. Rings grow 10->14->18->22 across phases; speeds 55-120.
- Boss HP progression in THE LAST LAMP: 110, 150, 210, 260; sizes 13/11/20/11.
- Each phase change speaks a line (`phase_lines`) - bosses "talk to you" is a selling point.

## Pitfalls (mistakes seen)

none.

## Verify

autoplay with god mode clears all 4 bosses; each phase fires (log "BOSS").

## Origin

Roguelike series. Source notes: _tools/gk.py L152-187; games/g1_lamp/spec.py L212-235.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
