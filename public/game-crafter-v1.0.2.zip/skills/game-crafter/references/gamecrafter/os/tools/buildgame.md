# Tool: buildgame.py

**Purpose:** Assembles one complete Godot game project from the shared kit + a game spec (art, fonts, music, sfx, data).

**Usage:** `python3 buildgame.py games/gN`

**Skill:** see `skills/factory-spec-to-game-assembly.md`

**Extract:** save the block below as `buildgame.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Assemble one game project from kit + spec. Forgotten Woods Studios.
usage: python3 buildgame.py <games/gN_dir> [--no-music]
spec module exposes: SPEC (art/audio/fonts description) and GAME (the game.json dict) and optional hooks.
"""
import sys, os, json, shutil, importlib.util, subprocess, math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import sprites as SP
import tiles as TL
import fonts as FT
import sfx as SFX
import bbcompose as BB
from sprites import hexc, Pal, new, finish, scale_up, light, dark

SKILL = None
for d in os.listdir("/root/.claude/plugins/synced"):
    p = os.path.join("/root/.claude/plugins/synced", d, "game-maker/skills/godot-export-release/templates/export_presets.template.cfg")
    if os.path.exists(p):
        SKILL = p


def load_spec(gdir):
    sp = importlib.util.spec_from_file_location("gspec", os.path.join(gdir, "spec.py"))
    m = importlib.util.module_from_spec(sp)
    sys.path.insert(0, gdir)
    sp.loader.exec_module(m)
    return m


def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def crop_rows(img, cut_from, cut_to):
    """remove rows [cut_from, cut_to) to shorten a humanoid (kids)."""
    top = img.crop((0, 0, img.width, cut_from))
    bot = img.crop((0, cut_to, img.width, img.height))
    out = Image.new("RGBA", (img.width, top.height + bot.height))
    out.paste(top, (0, 0))
    out.paste(bot, (0, top.height))
    return out


def make_creature(e, scale_k=1):
    frames = SP.make(e["recipe"], e["pal"], frames=e.get("frames", 2), seed=e.get("seed", 1), **e.get("kw", {}))
    if e.get("kid"):
        frames = [crop_rows(f, 11, 14) for f in frames]
    if e.get("alpha"):
        out = []
        for f in frames:
            f = f.copy()
            px = f.load()
            for y in range(f.height):
                for x in range(f.width):
                    r, g, b, a = px[x, y]
                    if a:
                        px[x, y] = (r, g, b, int(a * e["alpha"]))
            out.append(f)
        frames = out
    if e.get("scale", 1) > 1:
        frames = [scale_up(f, e["scale"]) for f in frames]
    return frames


def build_art(spec, proj):
    S = spec.SPEC
    A = os.path.join(proj, "assets")
    pal = S["pal"]
    # fonts
    FT.make_font(os.path.join(A, "fonts/body.ttf"), S["font_name"] + " Body", **S["fonts"]["body"])
    FT.make_font(os.path.join(A, "fonts/title.ttf"), S["font_name"] + " Title", **S["fonts"]["title"])
    # sprites
    sheets = {}
    pl = S["player"]
    fr = make_creature(pl)
    sh, w, h = SP.sheet(fr)
    save(sh, os.path.join(A, "sprites/player.png"))
    sheets["player"] = fr
    for name, e in S.get("npcs", {}).items():
        fr = make_creature(e)
        sh, w, h = SP.sheet(fr)
        save(sh, os.path.join(A, "sprites/%s.png" % name))
        sheets[name] = fr
    for name, e in S["enemies"].items():
        fr = make_creature(e)
        sh, w, h = SP.sheet(fr)
        save(sh, os.path.join(A, "sprites/enemy_%s.png" % name))
        sheets["enemy_" + name] = fr
    for name, e in S["bosses"].items():
        frames = SP.boss_from(e["recipe"], e["pal"], k=e.get("k", 2), seed=e.get("seed", 1), extra=e.get("extra"), **e.get("kw", {}))
        sh, w, h = SP.sheet(frames)
        save(sh, os.path.join(A, "sprites/boss_%s.png" % name))
        sheets["boss_" + name] = frames
    # hub props
    for name, fn in S.get("props", {}).items():
        frames = fn()
        sh, w, h = SP.sheet(frames if isinstance(frames, list) else [frames])
        save(sh, os.path.join(A, "sprites/%s.png" % name))
        sheets[name] = frames if isinstance(frames, list) else [frames]
    # pickups, projectiles, ui
    pk = TL.pickup_sheets(S["accent_hex"], S.get("mem_col", "#f0c860"))
    save(pk["mem"], os.path.join(A, "sprites/pickup_mem.png"))
    save(pk["mem_icon"], os.path.join(A, "sprites/pickup_mem_icon.png"))
    save(pk["heart"], os.path.join(A, "sprites/pickup_heart.png"))
    save(pk["fragment"], os.path.join(A, "sprites/pickup_fragment.png"))
    save(pk["boon"], os.path.join(A, "sprites/pickup_boon.png"))
    for n, im in TL.proj_sprites(S.get("proj_col", S["accent_hex"]), S.get("eproj_col", "#ff5a5a")).items():
        save(im, os.path.join(A, "sprites/%s.png" % n))
    save(TL.prop_altar(S["accent_hex"], S["tiles"][list(S["tiles"])[0]]["wall"][1]), os.path.join(A, "sprites/prop_altar.png"))
    hf = TL.heart_frames(S.get("heart_col", "#d02840"))
    hs = Image.new("RGBA", (11 * 3, 10))
    for i, f in enumerate(hf):
        hs.paste(f, (i * 11, 0))
    save(hs, os.path.join(A, "ui/heart.png"))
    save(TL.build_icons(S.get("icon_col", S["accent_hex"]), "#ffffff"), os.path.join(A, "ui/icons.png"))
    save(TL.build_door_icons(S["accent_hex"], S.get("danger_hex", "#d83a3a")), os.path.join(A, "ui/door_icons.png"))
    # tiles
    for tname, th in S["tiles"].items():
        save(TL.build_tiles(th, seed=S.get("seed", 1) + hash(tname) % 50), os.path.join(A, "tiles/%s.png" % tname))
    return sheets


def title_bg(spec, sheets, proj, size=(384, 216), big=False):
    S = spec.SPEC
    W, H = size
    k = 1
    bg = Image.new("RGBA", (W, H), hexc(S["title"]["sky_top"]))
    px = bg.load()
    top, bot = hexc(S["title"]["sky_top"]), hexc(S["title"]["sky_bot"])
    for y in range(H):
        t = y / H
        c = SP.mix(top, bot, t)
        for x in range(W):
            px[x, y] = c
    rng = random.Random(7)
    d = ImageDraw.Draw(bg)
    d.fontmode = "1"
    # hook for a hero scene
    if hasattr(spec, "title_scene"):
        spec.title_scene(bg, d, sheets, W, H)
    # floor pattern strip + silhouettes
    return bg


def vignette(img, strength=0.65):
    w, h = img.size
    px = img.load()
    for y in range(h):
        for x in range(w):
            dx, dy = (x - w / 2) / (w / 2), (y - h / 2) / (h / 2)
            v = max(0.0, 1 - strength * (dx * dx * 0.8 + dy * dy * 0.8))
            r, g, b, a = px[x, y]
            px[x, y] = (int(r * v), int(g * v), int(b * v), a)
    return img


def render_text(img, text, xy, size_px, color, font_path, shadow=True, anchor="mm"):
    f = ImageFont.truetype(font_path, size_px)
    d = ImageDraw.Draw(img)
    d.fontmode = "1"
    if shadow:
        d.text((xy[0] + size_px // 10 + 1, xy[1] + size_px // 10 + 1), text, font=f, fill=(0, 0, 0, 255), anchor=anchor)
    d.text(xy, text, font=f, fill=color, anchor=anchor)


def render_music(spec, proj, out_root):
    A = os.path.join(proj, "assets/audio/music")
    os.makedirs(A, exist_ok=True)
    sout = os.path.join(out_root, "soundtrack")
    os.makedirs(sout, exist_ok=True)
    info = []
    for (name, style, key, mode, bpm, bars, seed) in spec.SPEC["music"]:
        r = BB.make_song(sout, name, style, key, mode, bpm, bars, seed)
        wav = os.path.join(sout, name + ".wav")
        ogg = os.path.join(A, name + ".ogg")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-c:a", "libvorbis", "-q:a", "4", ogg], check=True)
        os.makedirs(os.path.join(out_root, "ogg"), exist_ok=True)
        shutil.copy(ogg, os.path.join(out_root, "ogg", name + ".ogg"))
        info.append(r)
    json.dump(info, open(os.path.join(out_root, "soundtrack_info.json"), "w"), indent=1)
    return info


def write_presets(proj, product, bundle, slug):
    txt = open(SKILL).read()
    # drop comment header lines
    txt = "\n".join(l for l in txt.splitlines() if not l.startswith(";"))
    inc = "*.txt, *.csv, *.cues, *.xml, *.cfg, game/*, tools/probe_manifest.json"
    exc = "_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*, build/*"
    txt = txt.replace('include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, assets/audio/voice/*, assets/branding/*, tools/probe_manifest.json"', 'include_filter="%s"' % inc)
    txt = txt.replace('exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"', 'exclude_filter="%s"' % exc)
    txt = txt.replace("__NAME__", slug).replace("__COMPANY__", "Forgotten Woods Studios").replace("__PRODUCT__", product).replace("__BUNDLE__", bundle)
    txt = txt.replace("application/modify_resources=true", "application/modify_resources=false")
    txt = txt.replace('application/icon="res://icon.ico"\n', "")
    open(os.path.join(proj, "export_presets.cfg"), "w").write(txt)


def build(gdir, music=True):
    spec = load_spec(gdir)
    S = spec.SPEC
    slug = S["slug"]
    out_root = os.path.join(ROOT, "build", slug)
    proj = os.path.join(out_root, "project")
    if os.path.exists(proj):
        shutil.rmtree(proj)
    os.makedirs(out_root, exist_ok=True)
    shutil.copytree(os.path.join(ROOT, "kit"), proj)
    pg = open(os.path.join(proj, "project.godot")).read()
    pg = pg.replace("GAMETITLE", S["title"]["name"])
    pg = pg.replace("[rendering]", "[rendering]\n\ntextures/vram_compression/import_s3tc_bptc=true\ntextures/vram_compression/import_etc2_astc=true")
    open(os.path.join(proj, "project.godot"), "w").write(pg)
    os.makedirs(os.path.join(proj, "game"), exist_ok=True)
    json.dump(spec.GAME, open(os.path.join(proj, "game/game.json"), "w"), indent=1)
    sheets = build_art(spec, proj)
    # title background
    A = os.path.join(proj, "assets")
    bg = title_bg(spec, sheets, proj)
    vignette(bg, 0.5)
    save(bg, os.path.join(A, "ui/title_bg.png"))
    # ending images
    if hasattr(spec, "extra_art"):
        spec.extra_art(proj, sheets)
    # icon
    pl = sheets["player"][0]
    ic = Image.new("RGBA", (64, 64), hexc(S["title"]["sky_bot"]))
    big = scale_up(pl, 3)
    ic.alpha_composite(big, ((64 - big.width) // 2, 64 - big.height - 2))
    shutil.copy(os.path.join(ROOT, "kit/assets/branding/fw_icon.png"), os.path.join(proj, "icon.png"))
    # sfx
    SFX.write(os.path.join(A, "audio/sfx"), S["sfx"]["pitch"], S["sfx"].get("grit", 0), S["sfx"].get("seed", 1))
    if music:
        render_music(spec, proj, out_root)
    elif os.path.isdir(os.path.join(out_root, "ogg")):
        os.makedirs(os.path.join(A, "audio/music"), exist_ok=True)
        for f in os.listdir(os.path.join(out_root, "ogg")):
            shutil.copy(os.path.join(out_root, "ogg", f), os.path.join(A, "audio/music", f))
    write_presets(proj, S["title"]["name"].title(), "com.evacstudios." + slug.replace("_", ""), slug)
    # probe
    os.makedirs(os.path.join(proj, "tools"), exist_ok=True)
    res = []
    for dp, dn, fn in os.walk(os.path.join(proj, "assets")):
        for f in fn:
            if f.endswith((".png", ".ogg", ".wav", ".ttf")):
                res.append("res://" + os.path.relpath(os.path.join(dp, f), proj))
    json.dump({"resources": sorted(res), "raw_files": ["res://game/game.json"], "dirs": []}, open(os.path.join(proj, "tools/probe_manifest.json"), "w"))
    shutil.copy(os.path.join(HERE, "probe.gd"), os.path.join(proj, "tools/probe.gd"))
    shutil.copy(os.path.join(HERE, "probe.tscn"), os.path.join(proj, "tools/probe.tscn"))
    return proj, out_root, sheets


if __name__ == "__main__":
    g = sys.argv[1]
    build(g, music="--no-music" not in sys.argv)
    print("built")
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
