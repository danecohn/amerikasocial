# Subagents — how GameCrafter splits big work
Use this when your environment can spawn helper agents (subagents, workers, parallel chats). If it can't, do the roles yourself one at a time in the same order.

## When to fan out
- **Do fan out:** mining a large codebase or document set, building many independent assets (sprites, rooms, songs), a full QA audit, a promo kit (art + copy + video), several games from one kit, and the final independent verification.
- **Don't fan out:** a single bug, anything where step 2 depends on what step 1 finds, or before ONE vertical slice works end to end. On FNAP a 16-agent team stalled within an hour with nothing playable. Start with 3–5 roles.

## Rules
1. **One owner per file.** Write `OWNERS.md` (template in `os/templates/OWNERS.md`) before agents start. Shared files get named regions, and edits to them must be surgical and announced first.
2. **One shared board.** Every agent appends timestamped lines to `BOARD.md`: started, owning, request, PASS/FAIL with evidence, blocked. New user requirements go on the board immediately.
3. **Self-contained prompts.** A subagent starts cold. Give it the goal, exact input paths, exact output path, the format, the done-criteria, and which skills to read. Never just "continue the work".
4. **Write to files, report in 3 lines.** Subagents write results to an output file in several appends, so a crash loses little. Their final message is the path plus a short summary. The lead reads the file.
5. **Independent verification.** The agent that built something doesn't certify it. A fresh agent that hasn't seen the build process runs the checklist against the exported build.
6. **Budget for interruptions.** Usage limits and crashes happen. Keep partial outputs on disk, and if an agent dies, re-launch only that role with the same prompt.
7. **The lead integrates.** Only the lead merges, exports, delivers and talks to the user.

## Role prompts (copy, fill the <…>)

### Harvester (mine knowledge from a codebase or docs)
```
Read <files> completely (big files in chunks). Extract every reusable technique, constant, command, code pattern and every
mistake (symptom → root cause → fix → prevention → detection). Write them to <out.md> in this structure: <structure>.
Write in several appends. Don't modify sources. Final message: path, count, top 3 finds.
```

### Builder (one system or asset set)
```
Goal: <feature> for <game>. Read STATE.md, GAME_BIBLE.md §<n>, and skills: <ids>. You own: <files>. Don't edit: <files>.
Build it data-driven, export-safe, with loud placeholders. Add a headless test scene that prints PASS/FAIL and exits non-zero on fail.
Done = test passes AND a screenshot from an exported pack shows it (you opened the PNG). Append status to BOARD.md.
```

### Artist (procedural pixel art / 3D)
```
Make <assets> for <game> following skills <pixel-*/blender-*>. Palette: <hex list>. Native resolution: <WxH>. Output: <dir>.
Make a contact sheet PNG of everything you produced and LOOK at it. Fix anything unreadable at 1x. Report the sheet path.
```

### Composer / sound
```
Make <n> tracks and <sfx list> for <game> following skills chiptune-music-beepbox / procedural-sfx-numpy. Mood: <...>.
Render to OGG for the game and WAV/OGG for the Soundtrack folder. Listen-check by analysing levels (no clipping, no silence),
and loop-check the seams. Write soundtrack.txt (title, mood, where it plays).
```

### Verifier (independent; never the builder)
```
You did not build this. Using os/checklists/pre-delivery.md and os/checklists/export-verify.md, verify <game> from its EXPORTED
build in <path>. For each item: PASS/FAIL + evidence (command output or an image path you opened and described).
Try to break it: new game, quit and reload, every enemy, every jumpscare, lights off/on, dark rooms, settings, pause.
Write <out.md>. Don't fix anything; report.
```

### Promo
```
Make the marketing kit for <game> per workflow os/workflows/promo-kit.md: 5 in-game screenshots, 630x500 itch cover, itch.txt,
socials.txt, horizontal + vertical trailer with the game's own music. Look at every image/frame. Don't post anything.
```

## Lead checklist
- [ ] OWNERS.md and BOARD.md exist before launch
- [ ] each prompt names inputs, outputs, skills and done-criteria
- [ ] partial outputs are on disk; dead agents get relaunched with the same prompt
- [ ] a fresh verifier signed off on the exported build
- [ ] the lead updated STATE/MANIFEST/CHANGELOG and delivered
