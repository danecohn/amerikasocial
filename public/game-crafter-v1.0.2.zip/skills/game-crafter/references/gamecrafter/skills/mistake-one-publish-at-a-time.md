---
id: mistake-one-publish-at-a-time
title: "A publish job is already running"
category: mistake
when: "Publishing multiple Descript compositions."
related: []
origin: FNAP
---

# A publish job is already running

**When to use:** Publishing multiple Descript compositions.

## Do this

One publish per project at a time; publish sequentially.

## What happened, root cause, fix, prevention

Symptom: error. Fix above.

## Verify

Each publish URL.

## Origin

FNAP. Source notes: mistakes-log.md M86.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
