---
id: fnaf-placeholder-first-real-asset-adoption
title: "Build placeholder first, adopt real nodes, report role resolution"
category: godot-engine
when: "Loading authored GLBs for an office/level whose roles code must control."
related: [mistake-duplicate-room-furniture, mistake-hiding-controlled-placeholder-door, mistake-room-glb-offset-twice]
origin: FNAP
---

# Build placeholder first, adopt real nodes, report role resolution

**When to use:** Loading authored GLBs for an office/level whose roles code must control.

## Do this

- `LevelBuilder` always builds a box office + map first, then `_try_real_office()` / `_try_real_rooms()`.
- Controlled rigs (doors) live on the placeholder and ADOPT real nodes (`adopt_model_node`, `adopt_lever`,
  `adopt_button`). `find_office(names)` searches the real model first, then the placeholder.
- `office_wiring` dict records for every role whether it resolved to `"office"`, `"PLACEHOLDER"` or `"missing"` (printed
  in debug) - "great QA tool": missing art degrades visibly, never silently hides.
- `_furnish_rooms()` adds prop GLBs only if the room GLB lacks that dressing (`_room_has_named(root, "Arcade")`).
- Rooms: prefer one `Building` GLB, else `Room_<short>` GLBs placed on the placeholder slot transform ONCE.
- `_force_pixel_nearest` flips only decal/console-face materials to `TEXTURE_FILTER_NEAREST_WITH_MIPMAPS`.

## Pitfalls (mistakes seen)

mistake-hiding-controlled-placeholder-door; mistake-room-glb-offset-twice; mistake-duplicate-room-furniture.

## Verify

`release_check.gd` asserts 11 room models loaded, real office (not placeholder), required markers exist.

## Origin

FNAP. Source notes: REF §2.2, §2.7, §8.1 K.

## Related skills

- [mistake-duplicate-room-furniture](mistake-duplicate-room-furniture.md)
- [mistake-hiding-controlled-placeholder-door](mistake-hiding-controlled-placeholder-door.md)
- [mistake-room-glb-offset-twice](mistake-room-glb-offset-twice.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
