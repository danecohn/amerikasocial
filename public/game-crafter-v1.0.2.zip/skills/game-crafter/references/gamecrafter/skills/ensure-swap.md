---
id: ensure-swap
title: "Add swap when RAM is tight (ensure_swap.sh)"
category: environment-tools
when: "First import of large GLB sets (~600 MB), SwiftShader renders, OOM kills on 8 GB boxes."
related: []
origin: FNAP
---

# Add swap when RAM is tight (ensure_swap.sh)

**When to use:** First import of large GLB sets (~600 MB), SwiftShader renders, OOM kills on 8 GB boxes.

## Do this

```bash
SZ="${1:-12}"; P="${2:-/tmp/swapfile}"
if [ "$(free -g | awk '/Swap:/{print $2}')" -ge "$SZ" ]; then echo "swap already >= ${SZ}GB"; exit 0; fi
if [ ! -f "$P" ]; then fallocate -l "${SZ}G" "$P" 2>/dev/null || dd if=/dev/zero of="$P" bs=1M count=$((SZ*1024)) status=none; fi
chmod 600 "$P"; mkswap "$P" >/dev/null 2>&1; swapon "$P" 2>&1 || { echo "swapon failed (no privilege?). Lower resolution / clip length instead."; exit 1; }
free -h | sed -n '1,3p'
```
Swap is gone on a fresh container -> recreate each session.

## Pitfalls (mistakes seen)

OOM during first import -> no swap.

## Verify

`free -h` swap >= 12G.

## Origin

FNAP. Source notes: install-godot-blender/scripts/ensure_swap.sh; SKILL.md rule 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
