---
id: dialogue-box-typewriter-talk-blips
title: "Pause-safe typewriter dialogue box with portraits, moods, choices and inline commands"
category: narrative-dialogue
when: "Adding RPG/Undertale-style dialogue to a 2D game."
related: [mistake-black-screen-after-new-game-paused-fade-tween]
origin: Roguelike series
---

# Pause-safe typewriter dialogue box with portraits, moods, choices and inline commands

**When to use:** Adding RPG/Undertale-style dialogue to a 2D game.

## Do this

- Dialogue = CanvasLayer layer 40, `process_mode = PROCESS_MODE_ALWAYS`; on `play(lines)` saves `_was_paused`, sets `get_tree().paused = true`, restores at end and emits `finished`.
- Panel at (8,150) size 368x60, StyleBoxFlat panel colour 94% alpha with 1px accent border, portrait frame 36x50 at (5,5) (TextureRect 32x46, STRETCH_KEEP_CENTERED, nearest filter, first frame of speaker sprite strip), name label (48,3) in speaker colour, text (48,15) 312x44 autowrap, blinking "v" next-hint at (356,48).
- Line format (data): `{"w": speaker_id, "t": text, "m": mood, "fx": [...], "c": [choices]}` or `{"cmd": ...}`. `^` inside text = 0.28s pause (stripped from display). `{player}` replaced with player name.
- Typing speed per char 0.030s; moods: whisper (text darkened 35%, 0.045s), shout (danger colour, 0.02s, shake 3), sad (0.055s), glitch (accent colour, 0.02s, then 6 frames of random-character corruption at 12%, 0.04s each). Extra pause 0.12s after .!? and 0.05s after ,;:.
- Uses `visible_characters` to reveal; pressing confirm while typing completes the line; then waits for press.
- Input: mouse left click (captured in `_input`), interact, ui_accept, confirm; `--auto` presses every 25 frames.
- Choices: `{"t": label, "say": [lines inserted next], "set": {flag: value}, "fx": [effects]}`; navigate with move_up/down or ui_up/down, "> " marker, accent colour; sfx select/confirm.
- Commands: `flag`(k,v), `sfx`(n), `shake`(a), `music`(n), `fade`(a,d - tween on own black ColorRect, fine because node is ALWAYS), `wait`(d; timer with process_always), `hide`.
- Effects are emitted as `fx_cmd` signal; the RunScene applies them (heal, hurt (never below 1 HP), mem, boon (deferred card pick), maxhp, dmg, light, sanity, rflag, spawn (turns an event room into combat and closes the doors)).

## Pitfalls (mistakes seen)

Dialogue pausing the tree froze the scene-fade tween (black screen) -> see mistake-black-screen-after-new-game-paused-fade-tween. Event effect "hurt" uses `max(1, hp-n)` so an event can never kill the player outside combat.

## Verify

screenshot mid-dialogue; `--auto=1` runs through all scenes without hanging.

## Origin

Roguelike series. Source notes: kit/kit/dialogue.gd; run.gd 468-505.

## Related skills

- [mistake-black-screen-after-new-game-paused-fade-tween](mistake-black-screen-after-new-game-paused-fade-tween.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
