---
id: install-godot-blender-windows
title: "Install on Windows x64/ARM64 (install_tools.ps1)"
category: environment-tools
when: "User's Windows PC needs Godot/Blender (agent may only have bridge + launcher)."
related: []
origin: FNAP
---

# Install on Windows x64/ARM64 (install_tools.ps1)

**When to use:** User's Windows PC needs Godot/Blender (agent may only have bridge + launcher).

## Do this

`powershell -NoProfile -ExecutionPolicy Bypass -File install_tools.ps1 [-GodotVersion 4.7.2] [-BlenderVersion 5.2.2] [-Prefix $env:USERPROFILE\GameTools]`. Detect ARM: `$env:PROCESSOR_ARCHITECTURE -eq "ARM64" -or $env:PROCESSOR_ARCHITEW6432 -eq "ARM64"`. Godot suffix `windows_arm64` vs `win64` (`Godot_v<ver>-stable_<suffix>.exe.zip`), Blender arch `windows-arm64` vs `windows-x64` zip from `download.blender.org/release/Blender<maj.min>/`. Templates to `%APPDATA%\Godot\export_templates\<ver>.stable\` (must contain version.txt). Transcript to `install_tools.log` beside script; prints `GODOT: <console exe>`, `TEMPLATES: ... version.txt=...`, `BLENDER: ...`, `INSTALL_DONE` or `FAILED:` + fallback `winget install GodotEngine.GodotEngine ; winget install BlenderFoundation.Blender` (x64 builds; templates still needed). `$ProgressPreference="SilentlyContinue"` speeds Invoke-WebRequest. Use `*_console.exe` for CLI. Optional `rcedit` for exe icon. Editor route: Editor > Manage Export Templates > Download.

## Pitfalls (mistakes seen)

ARM64 PC running x64 builds under emulation -> slow and different adapter reported -> install native arm64.

## Verify

Read install_tools.log for INSTALL_DONE.

## Origin

FNAP. Source notes: install-godot-blender/scripts/install_tools.ps1; install-guide.md Windows.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
