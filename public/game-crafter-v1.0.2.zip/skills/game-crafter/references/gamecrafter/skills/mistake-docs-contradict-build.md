---
id: mistake-docs-contradict-build
title: "Docs/credits that contradict the shipped build (gamepad support, font name)"
category: mistake
when: "Writing MANIFEST, README, credits, store page for a templated game."
related: []
origin: Roguelike series
---

# Docs/credits that contradict the shipped build (gamepad support, font name)

**When to use:** Writing MANIFEST, README, credits, store page for a templated game.

## What happened, root cause, fix, prevention

- Gamepad: all MANIFESTs say "No gamepad support" while project.godot binds joypad axes/buttons for every action (move, aim, attack trigger, ability A, interact Y, pause Start). Either test pad play and claim it, or remove/describe it as untested ("gamepad bindings present but untested"). Never leave a contradiction.
- Font name: SALT MINE 9 spec/bible call the custom font "Rivet" but in-game CREDITS say "CUSTOM FONT: BRINE" - copy-edited templated credits drifted from the spec. Prevention: generate credits/bible font lines from the same spec value (`SPEC["font_name"]`) instead of hand-typing.
- Detection: a doc-lint script that cross-checks spec values (font name, weapon, enemy count, boon count) against credits/bible/store text.

## Verify

grep credits for SPEC font_name; boon counts in store copy equal len(GAME["boons"]).

## Origin

Roguelike series. Source notes: kit/project.godot [input] joypad events vs MANIFEST.md "No gamepad support"; g3_salt/spec.py font_name "Rivet" vs g3_salt/content.py CREDITS "CUSTOM FONT: BRINE"; SALT MINE 9 GAME_BIBLE "custom pixel font Rivet".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
