---
id: mistake-exported-build-shows-placeholders
title: "Mistake - shipped build shows grey boxes/capsules while the editor run looks perfect"
category: mistake
when: "User says the exported/zipped game 'looks different', 'has none of the upgrades', shows boxes/capsules/black squares, missing audio lines or subtitles; before any release."
related: []
origin: FNAP
---

# Mistake - shipped build shows grey boxes/capsules while the editor run looks perfect

**When to use:** User says the exported/zipped game "looks different", "has none of the upgrades", shows boxes/capsules/black squares, missing audio lines or subtitles; before any release.

## Do this

This was THE big user complaint of the FNAP project and cost the most trust. The agent first assumed "old scripts were compiled" - wrong.

## What happened, root cause, fix, prevention

- Symptom: user: "It still looks like shit, it had none of the upgrades I saw in what you showed me. Like you're still compiling with the old version of the scripts or something" (screenshots: box office, capsule characters); then "Figure out the problem and fix it"; "What's going on? Finish!". Also phone had no subtitles, voice lines missing.
- Root cause: code looked for real assets with `DirAccess.get_files()` (sees `office.glb.import`), `FileAccess.file_exists()/open()`, `globalize_path()`; in the PCK the raw files don't exist, so every check failed SILENTLY and the code fell back to placeholder box/capsule. Raw data (`*.cues`, `*.csv`, voice wavs read by custom code, branding) was not exported at all because it wasn't in include_filter.
- Fix: (1) `packed_name()` on every listed file (node_finder.gd); (2) `load()` / `ResourceLoader.exists()` everywhere (animatronic.gd, splash.gd, shop_assistant.gd face frames, main_menu.gd textures); (3) include_filter in EVERY preset: `include_filter="*.json, *.csv, *.txt, *.cues, assets/audio/voice/*, assets/assistant_face/*, assets/branding/*"`; (4) on-screen renderer/version diagnostic label.
- Prevention: never test only in the editor / `--path` run; test the exported artifact. Grep for fallback-to-placeholder code paths and make each one loud.
- Detection: `godot --headless --path <proj> --export-pack "Linux" /tmp/test.pck` then `xvfb-run -a godot --main-pack /tmp/test.pck res://scenes/<scene>.tscn` + screenshot, open the image; export probe prints `PROBE_FAIL` for missing resources.

## Verify

Pack screenshot shows real models; probe `PROBE_DONE fails=0`; main prints `MAIN: REAL MODEL <name>` not `MAIN: PLACEHOLDER`. Closure phrase used: "Fixed and verified in an exported pack in the cloud".

## Origin

FNAP. Source notes: L §2.1 (lines 51-80), L §9 row 1 (line 418), L §10 user quotes (lines 472-473); G lines 5-10.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
