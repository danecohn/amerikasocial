---
id: gotcha-scene-change-busy-drops-calls
title: "Scene-change guard silently drops overlapping goto calls"
category: gdscript-patterns
when: "Using a single scene switcher with a `_busy` flag (fade in progress)."
related: []
origin: Roguelike series
---

# Scene-change guard silently drops overlapping goto calls

**When to use:** Using a single scene switcher with a `_busy` flag (fade in progress).

## Do this

boot.change_scene returns immediately if `_busy` (a fade is running, ~0.6s). A second `Game.goto` during a transition (e.g. death screen + quick Esc->Title, or demo hub door firing during the hub fade-in) is ignored without a log. Callers that must navigate should await the transition or the switcher should queue the latest request. Also: change_scene resets `Engine.time_scale` and `paused` - good hygiene after hitstop/menus.

## Pitfalls (mistakes seen)

Potential silent no-op; add `print("GOTO_DROPPED ", name)` when busy so tooling sees it.

## Verify

grep logs.

## Origin

Roguelike series. Source notes: boot.gd 90-98; hub.gd _intro demo path.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
