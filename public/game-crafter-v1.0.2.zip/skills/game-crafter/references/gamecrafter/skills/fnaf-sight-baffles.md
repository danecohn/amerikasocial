---
id: fnaf-sight-baffles
title: "Line-of-sight baffles + headless proof that the chair can't see the hall"
category: gameplay-systems
when: "The real office model has open doorways but the design says the hall must not be visible from the chair."
related: [mistake-hide-mesh-to-silence-errors]
origin: FNAP
---

# Line-of-sight baffles + headless proof that the chair can't see the hall

**When to use:** The real office model has open doorways but the design says the hall must not be visible from the chair.

## Do this

- Invisible (collidable) AABB "jambs" `LevelBuilder.SIGHT_BAFFLES` plus `blocks_sight(from, to)` (slab ray/AABB test,
  `_ray_hits_aabb`).
- `scripts/dev/seat_sight_test.gd` samples every allowed seated yaw and lurker sample point and proves none is
  visible except through baffles.
- Lesson: "constrain the camera yaw and add sight blockers instead of hiding meshes".
- Slab test sketch (standard):
  ```gdscript
  static func ray_hits_aabb(o: Vector3, d: Vector3, box: AABB, max_t: float) -> bool:
      var tmin := 0.0
      var tmax := max_t
      for i in 3:
          if absf(d[i]) < 1e-6:
              if o[i] < box.position[i] or o[i] > box.end[i]: return false
          else:
              var t1 := (box.position[i] - o[i]) / d[i]
              var t2 := (box.end[i] - o[i]) / d[i]
              tmin = maxf(tmin, minf(t1, t2)); tmax = minf(tmax, maxf(t1, t2))
              if tmin > tmax: return false
      return true
  ```

## Pitfalls (mistakes seen)

mistake-hide-mesh-to-silence-errors (hiding geometry is the wrong fix).

## Verify

seat_sight_test prints PASS for all yaws.

## Origin

FNAP. Source notes: REF §2.2 "Line-of-sight baffles", §5.2, §8 (level_builder extract list).

## Related skills

- [mistake-hide-mesh-to-silence-errors](mistake-hide-mesh-to-silence-errors.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
