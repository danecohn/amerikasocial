---
id: mistake-caveats-hidden
title: "Wrong-resolution/fps deliverables presented as final"
category: mistake
when: "Delivering media."
related: []
origin: FNAP
---

# Wrong-resolution/fps deliverables presented as final

**When to use:** Delivering media.

## Do this

List caveats up front (res, fps, unauditioned); offer the better route.

## What happened, root cause, fix, prevention

Symptom: user disappointed. Fix above.

## Verify

Caveats in reply.

## Origin

FNAP. Source notes: mistakes-log.md M97.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
