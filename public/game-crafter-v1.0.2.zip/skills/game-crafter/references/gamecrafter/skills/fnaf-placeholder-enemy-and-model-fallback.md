---
id: fnaf-placeholder-enemy-and-model-fallback
title: "Enemy placeholder (capsule + Label3D) with real-model swap only on success"
category: godot-engine
when: "Loading enemy GLBs that may be missing or broken."
related: [mistake-unshaded-import-flashlight-cant-light]
origin: FNAP
---

# Enemy placeholder (capsule + Label3D) with real-model swap only on success

**When to use:** Loading enemy GLBs that may be missing or broken.

## Do this

- `_build_placeholder()` makes capsule + Label3D. `_try_load_model()` loads `res://assets/models/animated/<id>.glb`,
  validates it contains a MeshInstance3D, hides the placeholder ONLY on success, runs `ClipManifest.apply`, attaches
  `EyeRig`.
- Clip lookups tolerate prefixes: `NodeFinder.resolve_clip(player, "walk")` matches `Armature|walk`, `_walk`, `/walk`.
- `_ensure_lit_materials` flips any unshaded imported material to per-pixel so flashlight can light it.
- Placeholder jumpscare = a scale pop.

## Pitfalls (mistakes seen)

mistake-unshaded-import-flashlight-cant-light.

## Verify

Delete one GLB in a copy: game still runs with a labelled capsule.

## Origin

FNAP. Source notes: REF §2.5, §2.6, §3.3.

## Related skills

- [mistake-unshaded-import-flashlight-cant-light](mistake-unshaded-import-flashlight-cant-light.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
