// Amerika OS top bar: Amerika menu, global menu, tray and clock. Always visible.
var bar = new Panel
bar.location = "top"
bar.height = 2 * Math.ceil(gridUnit * 1.7 / 2)
bar.floating = false
bar.hiding = "none"

var menu = bar.addWidget("org.kde.plasma.kickoff")
menu.currentConfigGroup = ["General"]
menu.writeConfig("icon", "amerika-hub")
menu.writeConfig("favorites", [
    "applications:amerika-social.desktop",
    "applications:amerika-ai.desktop",
    "applications:amerika-venture.desktop",
    "applications:amerika-files.desktop",
    "applications:amerika-terminal.desktop",
    "applications:amerika-office.desktop",
    "applications:amerika-software.desktop",
    "applications:amerika-hub.desktop"
])

bar.addWidget("org.kde.plasma.appmenu")
bar.addWidget("org.kde.plasma.panelspacer")
bar.addWidget("org.kde.plasma.marginsseparator")
bar.addWidget("org.kde.plasma.systemtray")
bar.addWidget("org.kde.plasma.digitalclock")

// Amerika OS dock: floating, centred, and never hidden.
var dock = new Panel
dock.location = "bottom"
dock.height = 2 * Math.ceil(gridUnit * 3.4 / 2)
dock.floating = true
dock.hiding = "none"
dock.alignment = "center"
dock.lengthMode = "fit"

var tasks = dock.addWidget("org.kde.plasma.icontasks")
tasks.currentConfigGroup = ["General"]
tasks.writeConfig("launchers", [
    "applications:amerika-social.desktop",
    "applications:amerika-ai.desktop",
    "applications:amerika-venture.desktop",
    "applications:amerika-files.desktop",
    "applications:amerika-terminal.desktop",
    "applications:amerika-software.desktop"
])
tasks.writeConfig("iconSpacing", 2)

// Amerika OS desktop wallpaper (panels are defined above; also shipped as org.amerika.* layout templates).

var desktopsArray = desktopsForActivity(currentActivity());
for (var j = 0; j < desktopsArray.length; j++) {
    desktopsArray[j].wallpaperPlugin = 'org.kde.image';
    desktopsArray[j].currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desktopsArray[j].writeConfig("Image", "file:///usr/share/wallpapers/Amerika/contents/images/3840x2160.png");
}
