---
id: godot-pixel-perfect-project-settings
title: "Godot 4 project settings for crisp integer-scaled pixel art (384x216)"
category: godot-engine
when: "Setting up any pixel-art Godot project; art is blurry, shimmering or non-square pixels."
related: []
origin: Roguelike series
---

# Godot 4 project settings for crisp integer-scaled pixel art (384x216)

**When to use:** Setting up any pixel-art Godot project; art is blurry, shimmering or non-square pixels.

## Do this

```ini
[application]
config/features=PackedStringArray("4.7", "GL Compatibility")
boot_splash/show_image=false
boot_splash/bg_color=Color(0.02, 0.02, 0.03, 1)
[display]
window/size/viewport_width=384
window/size/viewport_height=216
window/size/window_width_override=1152      ; 3x
window/size/window_height_override=648
window/stretch/mode="viewport"               ; render at 384x216 then upscale
window/stretch/scale_mode="integer"          ; whole-number scaling only (letterbox the rest)
window/vsync/vsync_mode=1
[rendering]
renderer/rendering_method="gl_compatibility"
renderer/rendering_method.mobile="gl_compatibility"
textures/canvas_textures/default_texture_filter=0    ; Nearest for every CanvasItem
environment/defaults/default_clear_color=Color(0.02, 0.02, 0.03, 1)
```
- 384x216 is 16:9 and divides 1920x1080 by exactly 5 and 1280x720 by 3.33 (integer mode -> 3x with borders on 720p), 3840x2160 by 10.
- Build step also adds `textures/vram_compression/import_s3tc_bptc=true` and `import_etc2_astc=true` (export to all desktop incl. ARM64/mac); any runtime `get_image()` on a texture must then `decompress()` first.
- Per-node `texture_filter = TEXTURE_FILTER_NEAREST` is set on TextureRect portraits as belt-and-braces.
- The F11 key toggles fullscreen (`DisplayServer.window_set_mode`), skipped when headless/capture.

## Pitfalls (mistakes seen)

stretch mode "canvas_items" + non-integer scale gives uneven pixel sizes; default filter linear blurs everything - both avoided here.

## Verify

run at 1152x648: each art pixel = 3x3 screen pixels; screenshot via viewport at 384x216.

## Origin

Roguelike series. Source notes: kit/project.godot; buildgame.py line 215; room.gd 36-37; dialogue.gd 52; boot.gd F11 handler.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
