---
id: itch-pricing-launch-strategy
title: "Pricing and launch advice for a small paid itch.io horror game"
category: promo-marketing
when: "User wants to make money from an itch.io release."
related: []
origin: Roguelike series
---

# Pricing and launch advice for a small paid itch.io horror game

**When to use:** User wants to make money from an itch.io release.

## Do this

- Paid $4.99 (roguelikes with real story sell $3-$8; $4.99 = impulse zone with room for 20-30% sale). Launch sale 20% off for 7 days ($3.99): Edit game > Pricing > "Start a sale". Keep "Let people pay more" on.
- Do not make it free ("free horror games on itch get downloaded and never bought"); optional free demo later (floor 1 only) as a separate build.
- First 48 hours matter: post both reels on publish day, then horror subreddits that allow self-promo days, itch jams/tag pages.
- Bundle when several games exist: "Forgotten Woods Collection" via itch Bundles at ~30% off the sum; cross-link every page footer.
- State plainly: "I cannot guarantee sales."

## Pitfalls (mistakes seen)

none.

## Verify

n/a (advice); prices consistent in itch.txt, socials end card, trailer.

## Origin

Roguelike series. Source notes: pack.py L40-45, L106-111; itch.txt L26-31, L121-125.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
