---
id: mistake-hardcoded-blocked-environment-assumptions
title: "Cloud blocks (Blender download, Google Fonts/npm, Python on PC) — plan alternatives up front"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Cloud blocks (Blender download, Google Fonts/npm, Python on PC) — plan alternatives up front

**When to use:** 

## What happened, root cause, fix, prevention

Blender not installable in the cloud (download blocked) → 3D built procedurally in GDScript and existing GLBs used; Google Fonts/npm blocked → original fonts generated with fontTools (or OFL system fonts); Python not installed on the converting machine → ledger generator not rerun; no audio device in container (ALSA errors → dummy driver, harmless). Prevention: environment check at session start listing tools available (godot + templates, blender, python3, fontTools, ffmpeg, xvfb, Vulkan ICD) and write it into MANIFEST "Cloud setup" so agents don't plan around missing tools.

## Origin

Caesarea. Source notes: MANIFEST hard rule 3, fonts note, LOG 10:59, shots/qa/title.log.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
