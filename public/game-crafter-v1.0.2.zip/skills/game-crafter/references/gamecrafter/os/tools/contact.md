# Tool: contact.py

**Purpose:** Contact sheet of generated sprites/tiles so you can LOOK at all the art at once.

**Usage:** `python3 contact.py <dir> out.png`

**Skill:** see `skills/evidence-rule.md`

**Extract:** save the block below as `contact.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
import sys, os, glob
from PIL import Image
proj = sys.argv[1]; out = sys.argv[2]
A = os.path.join(proj, "assets")
def sheet(files, k, bg=(40,36,52,255), cols=None, pad=3):
    ims=[Image.open(f).convert("RGBA") for f in files]
    W=sum(i.width*k+pad for i in ims); H=max(i.height*k for i in ims)+pad*2
    s=Image.new("RGBA",(W,H),bg); x=pad
    for i in ims:
        s.alpha_composite(i.resize((i.width*k,i.height*k),Image.NEAREST),(x,H-pad-i.height*k)); x+=i.width*k+pad
    return s
rows=[]
rows.append(sheet(sorted(glob.glob(A+"/sprites/enemy_*.png")),4))
rows.append(sheet([A+"/sprites/player.png"]+sorted(glob.glob(A+"/sprites/npc_*.png"))+sorted(glob.glob(A+"/sprites/hub_*.png")),4))
rows.append(sheet(sorted(glob.glob(A+"/sprites/boss_*.png")),3))
for t in sorted(glob.glob(A+"/tiles/*.png")): rows.append(sheet([t],4))
rows.append(sheet([A+"/ui/icons.png",A+"/ui/door_icons.png",A+"/ui/heart.png"],4))
W=max(r.width for r in rows); H=sum(r.height for r in rows)
o=Image.new("RGBA",(W,H),(20,18,28,255)); y=0
for r in rows: o.paste(r,(0,y)); y+=r.height
o.save(out); print(o.size)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
