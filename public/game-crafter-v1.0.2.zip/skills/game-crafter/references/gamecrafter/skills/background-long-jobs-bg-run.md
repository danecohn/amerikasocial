---
id: background-long-jobs-bg-run
title: "Run long jobs in background and poll (bg_run.sh)"
category: environment-tools
when: "Any command longer than ~2 minutes (imports, renders, exports, Cycles)."
related: []
origin: FNAP
---

# Run long jobs in background and poll (bg_run.sh)

**When to use:** Any command longer than ~2 minutes (imports, renders, exports, Cycles).

## Do this

Tool calls die at ~2 min default (10 max). Pattern:
```bash
case "$1" in
 start) n=$2; shift 3; rm -f /tmp/gm_$n.done; nohup bash -c "\"\$@\"; echo \$? > /tmp/gm_$n.done" _ "$@" > /tmp/gm_$n.log 2>&1 & echo "pid $! log /tmp/gm_$n.log";;
 status) n=$2; if [ -f /tmp/gm_$n.done ]; then echo "done:$(cat /tmp/gm_$n.done)"; else echo running; fi; tail -5 /tmp/gm_$n.log;;
 wait) n=$2; m=${3:-100}; for i in $(seq 1 $m); do [ -f /tmp/gm_$n.done ] && break; sleep 1; done; "$0" status $n;;
esac
```
Usage: `bg_run.sh start render -- <cmd>`, then `bg_run.sh wait render 100` repeatedly, sending the user a one-line status between waits. Done marker file holds exit code. One capture at a time; log to a file; poll.

## Pitfalls (mistakes seen)

Long foreground commands killed by tool timeout.

## Verify

`done:0`.

## Origin

FNAP. Source notes: headless-render-capture/scripts/bg_run.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
