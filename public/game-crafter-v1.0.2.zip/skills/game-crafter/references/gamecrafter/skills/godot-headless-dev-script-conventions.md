---
id: godot-headless-dev-script-conventions
title: "Headless dev/check scripts: SceneTree scripts, exit codes, greppable tokens, bounded runs"
category: testing-qa
when: "Writing any check, test, sim, screenshot or capture script for Godot."
related: [mistake-autoloads-missing-in-s-scripts]
origin: FNAP
---

# Headless dev/check scripts: SceneTree scripts, exit codes, greppable tokens, bounded runs

**When to use:** Writing any check, test, sim, screenshot or capture script for Godot.

## Do this

- `godot --headless -s x.gd` scripts must `extends SceneTree` (or MainLoop), do work in `_init()` / `_initialize()`, and end with `quit(code)`.
- Print machine-greppable tokens: `SHOT_OK`, `AUDIO_CHECK PASS`, `RESULT: OK (0 failures)`, `CHECK PASS`, `GLB_CHECK_DONE bad=0`, `LOADER_DONE missing=0`, `LOAD name -> OK|MISSING`, `PROBE_DONE fails=0`.
- Bound every run: `--quit-after N` (frames), `timeout 60`, or `--gm-quit-after=<s>`.
- Check scenes per subsystem: `scripts/dev/<x>_check.gd` + `.tscn` (`hall_check`, `curtain_check`, `save_test`, `audio_check`, `release_check` (assert required nodes/models), `patrol_sim`, `balance_regression`, `door_lurker_sim`, `seat_sight_test`, screenshot rigs).
- Exclude dev scripts from exports: `exclude_filter="scripts/dev/*, *_check.gd, ..."`.
- Run as `.tscn` when autoloads are needed (mistake-autoloads-missing-in-s-scripts).

## Pitfalls (mistakes seen)

dev scenes without quit() kept processes alive and blocked tool calls (mistake-capture-process-never-quits).

## Verify

`echo $?` equals expected; grep token present.

## Origin

FNAP. Source notes: S Non-negotiable 6 and Architecture bullet 5 (lines 14, 23); G "Scene/script patterns" (lines 18-26); L §2.9 (lines 121-123), §5.5 (lines 271-278).

## Related skills

- [mistake-autoloads-missing-in-s-scripts](mistake-autoloads-missing-in-s-scripts.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
