---
id: fnaf-crash-safe-forward-only-save
title: "Crash-safe, forward-only progress save (ConfigFile + tmp/bak/rename)"
category: gameplay-systems
when: "Saving night progress/unlocks in any game."
related: [mistake-dev-run-overwrites-player-save, mistake-save-wiped-on-close]
origin: FNAP
---

# Crash-safe, forward-only progress save (ConfigFile + tmp/bak/rename)

**When to use:** Saving night progress/unlocks in any game.

## Do this

- ConfigFile `user://fnap_save.cfg`: `[story] night, highest_night, brine_run_unlocked, story_complete`,
  `[brine] best_act, meta (Dictionary)`, `[meta] version`.
- Write `.tmp` -> copy previous good to `.bak` -> rename `.tmp` over target (fallback remove + rename).
- Forward-only merge: re-read the disk file before writing and `max()` highest_night / best_act and OR the booleans,
  so stale in-memory state can never regress progress.
- Load fallback chain `[save, .bak, .tmp]`: first that parses and has `[story]`. Clamp every loaded value.
- Save triggers: night start, night complete, run end, `_notification` for `WM_CLOSE_REQUEST`, `APPLICATION_FOCUS_OUT`,
  `APPLICATION_PAUSED`, `PREDELETE`, and `quit_game()`.
- (quoted)
  ```gdscript
  var disk := ConfigFile.new()
  var disk_ok := FileAccess.file_exists(SAVE_PATH) and disk.load(SAVE_PATH) == OK
  if disk_ok:
  	highest_night = maxi(highest_night, clampi(int(disk.get_value("story", "highest_night", 1)), 1, MAX_STORY_NIGHT))
  	story_complete = story_complete or bool(disk.get_value("story", "story_complete", false))
  ...
  if out.save(SAVE_TMP_PATH) != OK: return
  if disk_ok: DirAccess.copy_absolute(SAVE_PATH, SAVE_BAK_PATH)
  if DirAccess.rename_absolute(SAVE_TMP_PATH, SAVE_PATH) != OK:
  	DirAccess.remove_absolute(SAVE_PATH)          # rename can fail when target exists on some FS
  	DirAccess.rename_absolute(SAVE_TMP_PATH, SAVE_PATH)
  ```
- Project settings: `config/use_custom_user_dir=true`, `custom_user_dir_name="<Studio>/<Game>"` -> save at
  `%APPDATA%\<Studio>\<Game>\fnap_save.cfg`.

## Pitfalls (mistakes seen)

mistake-save-wiped-on-close; mistake-dev-run-overwrites-player-save.

## Verify

`XDG_DATA_HOME=/tmp/fnap_savetest godot --headless --path . res://scripts/dev/save_test.tscn` (write, reload,
simulated close, simulated crash mid-write; PASS/FAIL lines; exit 0/1).

## Origin

FNAP. Source notes: REF §2.15, §8.1 B, §1.6.

## Related skills

- [mistake-dev-run-overwrites-player-save](mistake-dev-run-overwrites-player-save.md)
- [mistake-save-wiped-on-close](mistake-save-wiped-on-close.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
