# Template: OWNERS.md — one owner per file (prevents agents overwriting each other)
```
<role> (<id>): <files/globs owned>
godot-build (2): project.godot, export_presets.cfg, default_bus_layout.tres, scripts/core/model_loader.gd, node_finder.gd, clip_manifest.gd, anim_import.gd, tools/smoke.sh
characters (6): scripts/enemies/*.gd, resources/ai/*.tres
rooms/cams (5): scripts/ui/camera_monitor.gd, scripts/core/room_ids.gd
audio (15): scripts/autoload/audio_manager.gd, scripts/core/sfx.gd, assets/audio wiring
SHARED FILE <file>: regions owned by <role A> (<functions>) and <role B> (<functions>) — surgical edits only, announce on BOARD first.
```
Blender/art pass owns meshes, rigs, clips, textures. Godot pass owns scenes, scripts, tests, manifests. Neither "fixes" the other's files.
