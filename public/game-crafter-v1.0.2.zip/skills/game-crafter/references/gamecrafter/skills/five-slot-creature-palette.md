---
id: five-slot-creature-palette
title: "The 5-slot creature palette (Pal) and per-game palette choices"
category: pixel-art-2d
when: "Defining colours for a sprite/creature so every sprite in the game reads as one set."
related: []
origin: Roguelike series
---

# The 5-slot creature palette (Pal) and per-game palette choices

**When to use:** Defining colours for a sprite/creature so every sprite in the game reads as one set.

## Do this

- `Pal(base, base2=None, eye="#ff3030", accent="#c8c8c8", outline="#0b0a10")`; `base2` defaults to `dark(base,0.3)`.
  Slots: base = main body fill; base2 = limbs/secondary/clothes-dark; eye = glowing eyes (horror read: red/white/teal);
  accent = hats, horns, trims; outline = universal `#0b0a10`.
- Rule: 2 body colours + 1 glow + 1 accent + outline, then `finish()` derives highlight/shade -> ~6-10 colours per sprite.
- Eyes are the focal point in horror sprites: use saturated eye colours that are NOT in the body ramp (#ff3030, #ffee66, #40ff90, #aaffee).
- Real examples (THE LAST LAMP): player `Pal("#c99a3a","#2a3c4a","#ff3030","#c99a3a")` (amber coat, slate legs);
  drowned `Pal("#3f6b6a","#2a4a4a","#aaffee","#9ac")`; widow ghost `Pal("#b79fe8","#8a70c0","#ff6a6a","#d8c8ff")`;
  final boss "dark" `Pal("#14141e","#0a0a12","#ff3030","#ff3030")` (near-black body + red eyes = silhouette villain).
- Per-game identity (accent / sky_top->sky_bot / fx tint):
  | game | accent | sky gradient | tint (r,g,b) | palette words |
  |---|---|---|---|---|
  | THE LAST LAMP | #ffcf6b | #04070b -> #0d1a24 | 0.95,1.0,1.05 | slate blue + lamp amber on night black |
  | SAINT MARROW'S | #f4a8c4 | #0a0610 -> #241626 | 1.04,0.98,1.04 | dusty plum, candle gold, pink |
  | SALT MINE 9 | #ff9a7a | #0a0608 -> #2a1614 | (default) | grey stone, white salt, orange hi-vis |
  | WARD SEVEN | #7ef0b0 | #04100c -> #12302a | 0.98,1.04,1.02 | hospital teal/mint, off-white |
- UI palette per game in game.json: `panel` (HUD/dialog bg), `accent`, `text`, `danger`, `res` (resource bar colour).

## Pitfalls (mistakes seen)

none recorded.

## Verify

contact sheet: every creature has the same outline colour and same light direction; eyes pop at 1x.

## Origin

Roguelike series. Source notes: _tools/sprites.py lines 29-37; games/g1..g4 spec.py SPEC/GAME palettes.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
