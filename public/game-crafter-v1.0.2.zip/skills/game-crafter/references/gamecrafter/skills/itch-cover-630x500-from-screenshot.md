---
id: itch-cover-630x500-from-screenshot
title: "Pixel-perfect itch cover (630x500) composed at 210x167 and scaled x3"
category: promo-marketing
when: "Making an itch.io cover from a real gameplay capture."
related: [mistake-hardcoded-absolute-tool-paths]
origin: Roguelike series
---

# Pixel-perfect itch cover (630x500) composed at 210x167 and scaled x3

**When to use:** Making an itch.io cover from a real gameplay capture.

## Do this

- `cover.py <shot 384x216> <title.ttf> <line1> <line2> <tagline> <out.png> [cropx=100] [cropy=40] [title_color=#f2e7c8] [accent=#ff9a3c]`.
- Compose at native 210x167 (630/3 x 500/3 rounded): bg (6,8,12); top band 210x62 from the shot darkened (sky/title area); real gameplay crop 210x105 at y=62; gradient fades at y 62-76 (alpha (76-y)*14) and 150-167 (alpha (y-150)*10).
- Text with the game's own generated title font: auto-fit size from 20 down to 8 so width <= 192 px; centred; 1-px black shadow at (1,1),(0,1),(1,0); two title lines from y=4; tagline in accent colour at y=49 (max width 196, start size 10).
- Studio icon 16x16 bottom-left at (3,148).
- `convert("RGB").resize((630,500), Image.NEAREST)` - exact x3, crisp pixels.
- Screenshots: native 384x216 captures nearest-scaled x5 = 1920x1080; 5 of them, real in-game.

## Pitfalls (mistakes seen)

167*3 = 501 so the final resize is not perfectly integer vertically (one row); compose at 210x166.67 is impossible - accept or crop 630x501 to 500. Hard-coded icon path `/home/claude/evac/kit/...` (see mistake-hardcoded-absolute-tool-paths).

## Verify

output is exactly 630x500; title legible at 315x250 thumbnail.

## Origin

Roguelike series. Source notes: _tools/cover.py L1-43; MANIFEST "5 screenshots are real captures ... nearest-scaled 5x".

## Related skills

- [mistake-hardcoded-absolute-tool-paths](mistake-hardcoded-absolute-tool-paths.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
