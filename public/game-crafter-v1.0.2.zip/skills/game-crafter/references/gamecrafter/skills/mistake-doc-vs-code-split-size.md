---
id: mistake-doc-vs-code-split-size
title: "Split-size documented as 29/30 MB but code splits at 20 MB"
category: mistake
when: "Any size-limit constant that is also mentioned in docs."
related: []
origin: Roguelike series
---

# Split-size documented as 29/30 MB but code splits at 20 MB

**When to use:** Any size-limit constant that is also mentioned in docs.

## Do this

Define the limit once (e.g. `PART_BYTES = 20_000_000`) and interpolate it into docstrings/MANIFEST text.

## What happened, root cause, fix, prevention

- Symptom: release.py docstring "split >29MB parts", MANIFEST says the transfer "is limited to ~30 MB per file", actual parts are 20,000,000 bytes - users/agents get conflicting numbers.
- Root cause: limit lowered for safety margin without updating text.
- Fix/prevention: single constant; generated text reads it. 20 MB is a sensible margin below a ~30 MB per-file bridge limit.

## Verify

MANIFEST part sizes == constant.

## Origin

Roguelike series. Source notes: release.py L2, L49; MANIFEST.md L12 and DISTRIBUTION rows.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
