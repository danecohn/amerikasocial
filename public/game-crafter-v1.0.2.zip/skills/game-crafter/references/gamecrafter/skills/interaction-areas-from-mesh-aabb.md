---
id: interaction-areas-from-mesh-aabb
title: "Interaction without colliders in imported models (Area3D from mesh AABBs)"
category: gameplay-systems
when: "Imported glb props (buttons, doors, consoles) need to be clickable/interactable but have no collision shapes."
related: []
origin: FNAP
---

# Interaction without colliders in imported models (Area3D from mesh AABBs)

**When to use:** Imported glb props (buttons, doors, consoles) need to be clickable/interactable but have no collision shapes.

## Do this

```gdscript
func add_interact_area(mi: MeshInstance3D, action: String) -> Area3D:
    var aabb := mi.get_aabb()
    var area := Area3D.new()
    var cs := CollisionShape3D.new(); var box := BoxShape3D.new()
    box.size = aabb.size; cs.shape = box; cs.position = aabb.get_center()
    area.add_child(cs); mi.add_child(area)
    area.set_meta("action", action)
    return area
# ray: query.collide_with_areas = true; query.collide_with_bodies = false; read collider.get_meta("action")
```
- Ray-cast areas only.

## Pitfalls (mistakes seen)

n/a.

## Verify

a check that rays from the player camera hit each expected action.

## Origin

FNAP. Source notes: S line 26.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
