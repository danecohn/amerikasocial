---
id: godot-smoke-test-script
title: "smoke.sh - boot + model checks in one command"
category: testing-qa
when: "After any code change, before handing over."
related: []
origin: FNAP
---

# smoke.sh - boot + model checks in one command

**When to use:** After any code change, before handing over.

## Do this

```bash
timeout 60 godot --headless --path . --quit-after 300 2>&1 | grep -iE "error|warning|script|parse" | head -40
godot --headless --path . -s tools/glb_check.gd 2>&1 | grep -E "^(OK|FAIL|GLB|  \^)"
godot --headless --path . -s tools/loader_check.gd -- <stems...> | tail -1
```
- `--quit-after N` counts frames (300 frames = a few seconds of boot).

## Pitfalls (mistakes seen)

n/a.

## Verify

empty error grep; `bad=0`; `missing=0`.

## Origin

FNAP. Source notes: L §5.5 (lines 272-276), §2.3 verify.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
