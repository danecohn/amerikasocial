---
id: blender-godot-name-contract
title: "Node names are an API (Blender -> Godot naming contract)"
category: 3d-blender
when: "Modeling rooms/props that code looks up by name."
related: []
origin: FNAP
---

# Node names are an API (Blender -> Godot naming contract)

**When to use:** Modeling rooms/props that code looks up by name.

## Do this

Code looks up nodes by normalized name; NodeFinder tolerates `.001` suffixes and Left/Right spellings, but the base name must exist. FNAP contract: `PlayerCamera`, `Door_L/R`, `DoorMotor_L/R`, `DoorLamp_L/R`, `Lurk_DoorL/R`, `Light_Hall_L/R`, `Cam_<room>`, `CamSpot_<room>`, `WP_<room>_<Character>`, `Curtain*`, `AlarmLight`, `CRT_Screen`. Keep it in `docs/NAME_CONTRACT.md` and assert in a `release_check` script. Custom properties export as glTF `extras` (e.g. `hidden_by_default`).

## Pitfalls (mistakes seen)

Re-exporting a GLB renamed/dropped custom nodes and changed light energies -> diff the GLB JSON chunk before/after (small python reader of GLB header) and keep `PlayerCamera`.

## Verify

release_check passes; inspect_glb lists all names.

## Origin

FNAP. Source notes: blender-assets/SKILL.md "Blender -> Godot contract".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
