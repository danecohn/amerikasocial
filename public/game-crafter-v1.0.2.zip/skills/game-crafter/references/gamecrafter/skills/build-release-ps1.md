---
id: build-release-ps1
title: "build_release.ps1 + BUILD_RELEASE.bat (zips on the user's Windows PC)"
category: export-release
when: "Builds must happen on the user's Windows PC (x64 or ARM64), e.g. because zips exceed bridge limits."
related: []
origin: FNAP
---

# build_release.ps1 + BUILD_RELEASE.bat (zips on the user's Windows PC)

**When to use:** Builds must happen on the user's Windows PC (x64 or ARM64), e.g. because zips exceed bridge limits.

## Do this

`powershell -NoProfile -ExecutionPolicy Bypass -File build_release.ps1 -Godot <console.exe> -Project <dir> -Out <DISTRIBUTION> -Name MyGame [-Extras <dir>] [-Targets Windows,Linux,Mac,WindowsARM64]`. Key parts:
```powershell
$ErrorActionPreference = "Stop"
Start-Transcript -Path (Join-Path $PSScriptRoot "release.log") -Force | Out-Null
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem
$Presets = @{ Windows="Windows Desktop"; Linux="Linux"; Mac="macOS"; WindowsARM64="Windows ARM64" }
& $Godot --headless --path $Project --import --quit; if ($LASTEXITCODE -ne 0) { throw "import failed ($LASTEXITCODE)" }
function ZipDir($src, $zip, $exe) {
  $fs = [IO.File]::Open($zip, 'Create'); $za = New-Object IO.Compression.ZipArchive($fs, 'Create')
  $base = (Resolve-Path $src).Path.TrimEnd('\') + '\'
  Get-ChildItem -Recurse -File $src | ForEach-Object {
    $rel = $_.FullName.Substring($base.Length).Replace('\','/')
    $e = $za.CreateEntry("$Name/$rel", 'Optimal')
    $mode = 420; if ($exe | Where-Object { $rel -like $_ }) { $mode = 493 }
    $e.ExternalAttributes = (0x8000 + $mode) -shl 16
    $s = $e.Open(); $f = [IO.File]::OpenRead($_.FullName); $f.CopyTo($s); $f.Dispose(); $s.Dispose() }
  $za.Dispose(); $fs.Dispose() }
```
Mac: export Godot's own `<Name>-mac.zip`, copy to `<Name>_Mac.zip`, then APPEND extras with `[IO.Compression.ZipFile]::Open($o,'Update')` + `ZipFileExtensions::CreateEntryFromFile` (never unzip/rezip the .app on Windows). Stage in `$env:TEMP\gm_release`, print table of zips with MB + LastWriteTime, print `RELEASE_DONE` or `FAILED: $_`; Stop-Transcript. Export function throws "export '<preset>' failed - preset missing from export_presets.cfg? templates not installed?".
BUILD_RELEASE.bat (double-click launcher for user or computer-use Explorer):
```bat
@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build_release.ps1" -Godot "C:\GameTools\godot-4.7.2-win64\Godot_v4.7.2-stable_win64_console.exe" -Project "%~dp0..\Godot" -Out "%~dp0..\DISTRIBUTION" -Name "MyGame" -Extras "%~dp0..\DISTRIBUTION\_inputs"
pause
```

## Pitfalls (mistakes seen)

PowerShell ZipArchive default loses exec bits -> Linux binary not executable -> set ExternalAttributes 755 (493) for binary, 644 (420) otherwise. Unzipping/rezipping the mac .app on Windows breaks it -> append to Godot's zip.

## Verify

Read `release.log`, check `RELEASE_DONE`, list DISTRIBUTION for new timestamps/sizes.

## Origin

FNAP. Source notes: scripts/build_release.ps1, scripts/BUILD_RELEASE.bat.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
