---
id: mistake-model-switch-rederive
title: "Model switch mid-session re-derived work"
category: mistake
when: "Long sessions, handoffs, model switches."
related: []
origin: FNAP
---

# Model switch mid-session re-derived work

**When to use:** Long sessions, handoffs, model switches.

## Do this

Keep a state file (STATE.md) with "verified / unverified / next step".

## What happened, root cause, fix, prevention

Symptom: repeated work. Fix above.

## Verify

STATE.md current.

## Origin

FNAP. Source notes: mistakes-log.md M94.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
