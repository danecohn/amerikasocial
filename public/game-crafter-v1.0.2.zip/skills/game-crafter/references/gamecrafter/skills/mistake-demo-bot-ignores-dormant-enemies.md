---
id: mistake-demo-bot-ignores-dormant-enemies
title: "Demo bot never cleared rooms with dormant/ambush or far enemies"
category: mistake
when: "Bot targets enemies only by aiming/shooting from where it stands; enemies that hide until approached (ambush) or stand out of weapon range."
related: []
origin: Roguelike series
---

# Demo bot never cleared rooms with dormant/ambush or far enemies

**When to use:** Bot targets enemies only by aiming/shooting from where it stands; enemies that hide until approached (ambush) or stand out of weapon range.

## What happened, root cause, fix, prevention

- Symptom (SAINT MARROW'S): rooms with a hidden "MOTH-EATEN BEAR" (ai ambush; invisible alpha 0.12, wakes only within keep=52px or when hit) or out-of-range enemies never cleared; the room state stayed "combat" and the bot circled its patrol ellipse forever.
- Root cause: the bot's patrol path didn't approach dormant enemies, and short-range weapons (throw range 105, nova 68) couldn't reach.
- Fix: in combat/boss state, if nearest live non-fake enemy is farther than 80px, move to a point 60px from it (`want = np + (position - np).normalized() * 60.0`), still aiming at it. Exclude `fake` enemies (sanity phantoms) from targeting and from room-clear counting.
- Prevention: room-clear conditions and bot targeting must use the same enemy set; give the bot an approach behaviour for every AI archetype that waits for the player.

## Verify

autorun clear of every floor in SAINT MARROW'S and WARD SEVEN (both have ambush enemies + nova/throw weapons).

## Origin

Roguelike series. Source notes: WIP_BIBLE_AND_MANIFEST.md Game 2 "demo walks to dormant enemies"; player.gd 124-134; enemy.gd ambush 288-301; run.gd 593-596.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
