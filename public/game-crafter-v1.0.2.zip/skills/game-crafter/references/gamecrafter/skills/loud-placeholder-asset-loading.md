---
id: loud-placeholder-asset-loading
title: "Never-silent asset loading (magenta placeholder + PLACEHOLDER log)"
category: gdscript-patterns
when: "Loading textures/audio/fonts at runtime in a data-driven game, especially to make export bugs visible."
related: []
origin: Roguelike series
---

# Never-silent asset loading (magenta placeholder + PLACEHOLDER log)

**When to use:** Loading textures/audio/fonts at runtime in a data-driven game, especially to make export bugs visible.

## Do this

- `Art.tex(path)`: cache; `ResourceLoader.exists(path)` then `load`; if null -> `push_warning` + `print("PLACEHOLDER missing asset: ", path)`, append to `Art.missing`, return 16x16 magenta `Color(1,0,1)` ImageTexture. Never crash, never silent.
- `Art.frames(path, n)`: horizontal strip -> array of AtlasTexture, frame width = tex_w / n, cached by `"path#n"`.
- AudioKit `_stream(path)` same pattern: `PLACEHOLDER missing audio:`.
- Tooling greps `PLACEHOLDER` in logs (autorun.sh, shot.sh) and the shot line prints `missing=<Art.missing.size()>`.
- Use `ResourceLoader.exists` + `load` (works with imported resources inside exported .pck), not FileAccess on res:// image files.

## Pitfalls (mistakes seen)

Silent fallback hides missing exports; prevention = loud placeholder + grep in every automated run.

## Verify

`grep PLACEHOLDER log` empty; `SHOT_OK ... missing=0`.

## Origin

Roguelike series. Source notes: kit/kit/art.gd, audio_kit.gd _stream, boot.gd _shots, _tools/autorun.sh, shot.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
