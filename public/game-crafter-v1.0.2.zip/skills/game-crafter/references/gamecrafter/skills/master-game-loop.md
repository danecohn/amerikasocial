---
id: master-game-loop
title: "The master game-making loop (every game, every milestone)"
category: core-workflow
when: "Any request to make, continue, fix, export, ship or advertise a game; start of every milestone. Load first; it routes to specialist skills."
related: []
origin: FNAP
---

# The master game-making loop (every game, every milestone)

**When to use:** Any request to make, continue, fix, export, ship or advertise a game; start of every milestone. Load first; it routes to specialist skills.

## Do this

Seven-step loop, repeated per milestone:
1. **Env**: run an environment check (`check_env.sh`). Fix what is missing BEFORE writing code. Godot version must equal export-template version EXACTLY (e.g. 4.7.2.stable == templates 4.7.2.stable).
2. **Plan small**: make ONE thing work end to end first (the exported build showing the real art), then widen. Over-wide scope (16 agents, tooling for everything) stalled FNAP for ~1 hour with nothing to show.
3. **Build**: code-built scenes + data-driven JSON/Resources + name-based node lookups. Keep a placeholder for every authored asset so the game always runs, but placeholder use must be LOUD (push_warning + on-screen note), never silent.
4. **Verify in the BUILT artifact, not the editor**: export, run a probe + screenshot from the exported pack (`verify_export.sh`), then OPEN the PNG and look at it.
5. **Audit**: `lint_export_safety.py`, `hide_audit.sh`, headless smoke/check scenes that print PASS/FAIL and set exit codes.
6. **Document**: README / manifest / changelog / handoff updated in the SAME turn as the change.
7. **Deliver**: to the exact path the user named; confirm it landed (list the folder / read the log); state plainly what is verified and what is not.
Routing table (specialist skills): install/check tools -> install-godot-blender; code/scenes/save/audio/AI/UI/tests -> godot-gamedev; export/zips/ARM64/Mac/Linux/prove build -> godot-export-release; 3D models/glb -> blender-assets; screenshots/video with no GPU -> headless-render-capture; store art/trailer/copy/Descript -> game-promo-pipeline; files to/from user PC -> pc-bridge-delivery.

## Pitfalls (mistakes seen)

Shipped build silently showed placeholder boxes (M01); "fixes" that hid problems (M04); deliverables declared done without looking (M90); tool/network limits discovered late (M49, M80). Each loop step exists to block one of these.

## Verify

At each milestone you can point to: env check output, an opened screenshot from the exported pack, audit outputs with every hit justified, updated docs, a folder listing at the delivery path.

## Origin

FNAP. Source notes: skills/game-maker/SKILL.md "The loop" (lines 21-28), "Route to the right skill" (10-19).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
