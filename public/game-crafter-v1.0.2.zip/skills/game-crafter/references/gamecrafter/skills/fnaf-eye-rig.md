---
id: fnaf-eye-rig
title: "Eyes that track the player and pupils that pinprick in the flashlight"
category: 3d-blender
when: "Adding eye tracking / pupil reactions to enemy models."
related: [mistake-shared-material-tint]
origin: FNAP
---

# Eyes that track the player and pupils that pinprick in the flashlight

**When to use:** Adding eye tracking / pupil reactions to enemy models.

## Do this

- Activates only if the skeleton has bones `eye.L`/`eye.R` and iris meshes with a `pupil_shrink` blend shape (no-op
  otherwise).
- Two `LookAtModifier3D` (forward axis +Y, limits 70/50 deg) targeting the player camera, driven by `influence` (tracks
  only when at a door or on camera).
- Duplicates the iris material per actor so two characters never share emission. `pinprick()` animates pupil shrink on
  flashlight hit.
- Eyes are plain lit surfaces; emission 0.5 only on a camera feed.

## Pitfalls (mistakes seen)

mistake-shared-material-tint.

## Verify

char_check screenshots at doors with flashlight.

## Origin

FNAP. Source notes: REF §2.5 EyeRig.

## Related skills

- [mistake-shared-material-tint](mistake-shared-material-tint.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
