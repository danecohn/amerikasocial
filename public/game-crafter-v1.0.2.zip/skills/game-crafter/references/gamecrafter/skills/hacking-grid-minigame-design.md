---
id: hacking-grid-minigame-design
title: "Turn-based hacking grid (Argus Weave) with trace meter"
category: gameplay-systems
when: "Designing a non-reflex hacking mini-game."
related: []
origin: Caesarea
---

# Turn-based hacking grid (Argus Weave) with trace meter

**When to use:** Designing a non-reflex hacking mini-game.

## Do this

Grid 4×4 (tier 1) to 7×7 (tier 5); thread from Entry to Target one adjacent node per pulse. Nodes: Relay (path), ICE (needs a Key; 1 key per 25 Hacking), Watcher (trace +15; revealed at Literacy ≥ 40), Cache (bonus), Mirror (trace −10; revealed at 60), Target (choose payload). Trace rises `max(2, 8 − hacking/15)` per pulse + node effects; 100 = traced (lockout counter, faction event). Jack out any time without penalty. Tier table (hacking needed 0/25/50/75/90; watchers 1/2/3/4/6; ICE 0/1/2/3/4). Payloads: tap camera, loop camera 120 s, forge record, drone malfunction, extract log, leak log. Separate "literacy" skill reveals hidden info (camera cones at 20, watchers 40, mirrors 60, drone routes 80). 30–90 s per hack.

## Verify

generator always produces a path from Entry to Target (BFS) at each tier.

## Origin

Caesarea. Source notes: design/07 §6.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
