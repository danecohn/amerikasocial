# CHANGELOG — <GAME TITLE>
## [<x.y.z>] — <date>
### Added
### Changed
### Fixed
- <bug in player words> — cause: <...> — verified: <...>
### Not verified
