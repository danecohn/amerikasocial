---
id: itch-long-description-template
title: "Store description structure that sells a short story-driven horror game"
category: promo-marketing
when: "Writing an itch.io/Steam long description."
related: []
origin: Roguelike series
---

# Store description structure that sells a short story-driven horror game

**When to use:** Writing an itch.io/Steam long description.

## Do this

- 1) Bold one-line hook in present tense (eerie, specific): "**The lamp has gone out. The stairs go down. They should not go this far down.**" / "**The shaft has been sealed for six days. ... Three taps means alive.**" / "**It is 3:07 in the morning on Ward Seven...**".
- 2) Second-person premise paragraph naming the protagonist, place, the stakes and the goal in 3-4 sentences ("You are Nurse Ellie, the only one on the night shift, and twelve patients are missing. Find them. Bring them back.").
- 3) Genre paragraph: "**<TITLE>** is a short, story-driven **pixel-art horror roguelike**." + core mechanic expressed in fiction (resource = light: OIL/AIR/NERVE/COMPOSURE drains, kills refill) + the death loop explained diegetically ("Die, and the lighthouse takes you back").
- 4) **WHAT YOU DO** bullets (floors+bosses that talk, weapon, ability, N named boons with 3 flavourful examples, currency + 8 permanent upgrades + difficulty levels, 8 strange events with 3-4 evocative examples).
- 5) **WHAT YOU FIND** (12 lore documents, reactive scenes "change with how often you have died...", "Three endings. One of them is the kind you will think about for a week.").
- 6) **FEATURES** (pixel art, custom pixel fonts, 9-song soundtrack, talk-blips "in the tradition of the great retro RPGs", ~20 rooms/run, "Small, polished, finished. No microtransactions, no online, no nonsense.").
- 7) Platforms line + "Soundtrack included in the download."; 8) italic content warning + one-line thesis ("A game about a man who let the light go out - and how he lights it again."); 9) "More from Forgotten Woods Studios: forgottenwoods.itch.io" footer for cross-promotion.
- Numbers in copy must match the data (boons 17/18/19 per game).

## Pitfalls (mistakes seen)

none.

## Verify

count claims vs game.json.

## Origin

Roguelike series. Source notes: four itch.txt DESCRIPTION blocks (diffed).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
