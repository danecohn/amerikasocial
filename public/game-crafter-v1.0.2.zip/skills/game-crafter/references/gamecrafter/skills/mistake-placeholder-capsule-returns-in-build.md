---
id: mistake-placeholder-capsule-returns-in-build
title: "Placeholder capsule shown instead of the real textured character"
category: mistake
when: "Any game that builds a primitive placeholder (capsule/box + nameplate) and later swaps in a loaded model; any code that toggles mesh visibility per frame (darkness, LOD, eyes-only, stealth)."
related: []
origin: Pickle's Pickle Shop
---

# Placeholder capsule shown instead of the real textured character

**When to use:** Any game that builds a primitive placeholder (capsule/box + nameplate) and later swaps in a loaded model; any code that toggles mesh visibility per frame (darkness, LOD, eyes-only, stealth).

## Do this

Pattern used: `_build_placeholder()` makes a CapsuleMesh (radius 0.32, height 1.7, y 0.95, per-character colour) plus a Label3D nameplate; `_try_load_model()` loads `res://assets/models/animated/<id>.glb`, and only if a mesh is found sets `_placeholder.visible = false`. Later a darkness routine `_apply_eyes_only()` toggled visibility of the model's meshes AND re-enabled the placeholder when restoring "full visibility". Result: the user saw the coloured capsule (Remi) in-game and in a jumpscare.

## What happened, root cause, fix, prevention

Symptom: user screenshot showed "character textures look like this" (a flat-coloured capsule with name) and later "I got jumpscared and saw ... an unfinished placeholder". Root cause: a visibility helper that touched `_placeholder.visible = not only` (or similar) whenever eyes-only mode turned off. Fix: once a real model is loaded the placeholder is never shown again:
```gdscript
func _apply_eyes_only(only: bool, hide_eyes: bool = false) -> void:
    if _model == null: return
    for node in NodeFinder.collect(_model):
        if node is MeshInstance3D:
            var lname := String(node.name).to_lower()
            var is_eye := "iris" in lname or "eye" in lname or "sclera" in lname or "pupil" in lname
            node.visible = not only or (is_eye and not hide_eyes)
    if _placeholder:
        _placeholder.visible = false  # real model loaded: stand-in must never come back
```
Prevention: placeholder visibility is decided in exactly one place (model load). Any per-frame visibility code only touches the real model's meshes. Add a probe that asserts `Placeholder.visible == false` for every character after load and during jumpscare.

## Verify

Screenshot each character in each state (idle on camera, at door lit/unlit, jumpscare) from an EXPORTED build; grep scene tree in a probe: for each Animatronic, `get_node("Placeholder").visible == false` and `get_node("Model") != null`.

## Origin

Pickle's Pickle Shop. Source notes: transcript.txt summary sec.4 "Remi showed as the capsule placeholder"; scripts/animatronics/animatronic.gd L148-172, L275-299, L348-358.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
