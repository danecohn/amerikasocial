---
id: fnaf-6am-and-ending
title: "6 AM win sequence and the ending card"
category: ui-ux
when: "Implementing the win moment and the end of the story week."
related: []
origin: FNAP
---

# 6 AM win sequence and the ending card

**When to use:** Implementing the win moment and the end of the story week.

## Do this

- 3D: win_screen with a 5 -> 6 AM number slide; after Night 5 a thank-you + studio credit + social handle, then Credits.
- 2D: hold on 5 AM card -> 12-frame roll `6am-roll-01..12.png` (frame 12 == the 6 AM card) -> hold 6 AM; audio
  `6am-chime` (four-note tune then six strikes) + `6am-cheer` (kids "yaaay", claps, party blowers) or pre-mixed
  `6am-chime-cheer`. End of Night 5: paycheck card "Good job. Same time next week?".
- Story intent: the shop looks the same in the morning as on Night 1; "whether the six o'clock bell is a real ending"
  stays unanswered; the last call's final line is an instruction ("Leave through the front door").

## Pitfalls (mistakes seen)

none.

## Verify

`--fnap-hour=2` run reaches the sequence; `--fnap-shot-credits` screenshot.

## Origin

FNAP. Source notes: REF §2.13; STATEMAP lines 180-185, 219-221; BIBLE "How the Week Is Meant to Feel".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
