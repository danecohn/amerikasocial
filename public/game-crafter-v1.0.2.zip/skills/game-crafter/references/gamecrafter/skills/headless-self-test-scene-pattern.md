---
id: headless-self-test-scene-pattern
title: "test_main.tscn — headless self-test that compiles every script and checks every system"
category: testing-qa
when: "Any Godot project with autoload systems; before claiming anything works."
related: []
origin: Caesarea
---

# test_main.tscn — headless self-test that compiles every script and checks every system

**When to use:** Any Godot project with autoload systems; before claiming anything works.

## Do this

- A scene with a test script that, with autoloads live, loads every `.gd` and `.tscn` under `res://game` (compile sweep — catches parse errors in files nobody instanced), then tests ledger, conditions, factions, dialogue→quest flow, endings gates, companions, time, saves, buses, model facing (+Z), radio. Prints `RESULT: PASS (n passed, 0 failed)` or `RESULT: FAIL (...)` and calls `get_tree().quit(code)`.
- Per-area tests `tests/<area>/<area>_test.tscn` (flow_test: player on floor after 40 physics frames, NPCs present, kit surfaces > 6, quest active, zone exits load the next zone, player on the next floor; world_test 64 checks).
- Tests intentionally exercise rejection paths and print warnings (`'cheered' is not an allowed value for forum_stand`, `unknown ledger key 'no_such_flag_xyz'`, `ending chosen but E1 is not eligible`, `song '__selftest_missing' is not in this build`) — document these as expected.
- Counts grew 107 → 111 → 130 → 143 → 163/192/203 as systems landed; each LOG entry records the count.

## Pitfalls (mistakes seen)

Count differences between trees are normal when the compile sweep counts more scripts; "0 failed" is the bar.

## Verify

`godot --headless --path . res://tests/test_main.tscn` prints RESULT: PASS.

## Origin

Caesarea. Source notes: design/godot_starter/README.md Validation, design/08 §11, LOG.md, godot_import_report.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
