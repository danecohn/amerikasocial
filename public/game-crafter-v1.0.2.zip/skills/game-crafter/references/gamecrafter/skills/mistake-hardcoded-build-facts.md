---
id: mistake-hardcoded-build-facts
title: "Hard-coded zip timestamps, engine version and dates in generators"
category: mistake
when: "Writing release/packaging scripts meant to be reused."
related: []
origin: Roguelike series
---

# Hard-coded zip timestamps, engine version and dates in generators

**When to use:** Writing release/packaging scripts meant to be reused.

## Do this

Read engine version from `godot --version`, use today's date or SOURCE_DATE_EPOCH, pass version from META.

## What happened, root cause, fix, prevention

- Symptom: every zip entry dated 2026-10-09 regardless of build date; MANIFEST "Engine Godot 4.7.2 | Version 1.0.0" literal.
- Root cause: constants typed during the first game.
- Fix: `DATE = time.localtime()[:6]` (or a fixed epoch for reproducibility, but chosen deliberately); version from META/game.json.

## Verify

rebuild next day -> dates/version reflect reality.

## Origin

Roguelike series. Source notes: release.py L36; finish.py L31.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
