---
id: fnaf-director-capture-moments
title: "Scripted, music-synced gameplay "moments" for trailers using the live game code"
category: promo-marketing
when: "Capturing trailer footage that must hit music beats."
related: []
origin: FNAP
---

# Scripted, music-synced gameplay "moments" for trailers using the live game code

**When to use:** Capturing trailer footage that must hit music beats.

## Do this

- `Director` autoload, inert unless `--capture=<moment>`. Moments: pickle_eyes_4b, power_out, remi_flashlight,
  dilly_kitchen, banshee_run, golden_pickle, run_and_pant, assistant_fail, six_am, brine_run.
- When active: forces the night per moment; window 1920x1080 or portrait 1080x1920 (`--aspect=vertical`: HUD/monitor/
  assistant re-layout for 9:16, FOV 70, `KEEP_WIDTH`); freezes the game (`drain_multiplier 0`, `clock.hour 3`,
  animatronics `scripted = true`, hallucination check disabled); runs an await script per moment keyed to cue times from
  a JSON cue sheet: array of `{file, seconds, hits:[{t|frame60, what}]}` ("jumpscare", "peeks", "runs", "last bar").
- `until("jumpscare", 17.0)` waits for the cue or a default time; `_shift` retimes the whole script so the climax lands on
  the music hit. Live game functions (`_power_out_sequence`) await `Director.until` so the trailer uses real code.
- Alternative: `promo_capture.tscn` shot list (`wait`, `place(id, room, clip)`, `hide_all`, camera select, flashlight,
  forced scares) with Movie Maker: `godot --path . res://scenes/promo_capture.tscn --write-movie promo/clips/f.png
  --fixed-fps 12 -- clips` (writes `f00000000.png ...` + `f.wav`) or `--write-movie out.avi --fixed-fps 30 -- movie`.
- Example: `--capture=<moment> --aspect=vertical --seed=1337 --cues=reel-pickle-20s`.

## Pitfalls (mistakes seen)

none; but captures must not save (dev switch).

## Verify

Rendered clip's scare frame aligns to the cue time.

## Origin

FNAP. Source notes: REF §2.16, §6.1.

---------------------------------------------------------------------------------------------------

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
