---
id: fnaf-story-bible-template
title: "Story bible for a FNAF-like (sections that keep a team consistent)"
category: narrative-dialogue
when: "Writing the lore for a horror night game before scripting calls or UI text."
related: [mistake-phone-audio-drift-from-script]
origin: FNAP
---

# Story bible for a FNAF-like (sections that keep a team consistent)

**When to use:** Writing the lore for a horror night game before scripting calls or UI text.

## Do this

- FNAP bible sections (copy the outline): The Location (history, founder, a house rule e.g. "nothing in this shop goes
  bad"); Who Built the Robots (builder, why, what powers them - a hidden ingredient no one asked about); The Secret Room
  (not on the original floor plan, roped off "for repairs"); Why the Player Took the Night Shift (needs the money; the
  hire was suspiciously easy - "the first thing that should feel strange"); The Last Guard (the phone voice; his story
  stops lining up); What the Robots Want (motive that explains their behaviour); The Hallucination (never explained);
  What the Player Should Still Not Understand After Night 5 (explicit list); How the Week Is Meant to Feel (per-night
  emotional arc); Rules the Story Keeps (mechanics as fiction: paths, sides); Tone Notes; credit line.
- Emotional arc per night (BIBLE): N1 warm and a little funny ("a coworker handing over the keys"); N2 jokes thin out,
  warning about one robot; N3 skips details, contradicts himself; N4 frightened but clear; N5 barely gets through. The
  morning looks the same as Night 1 - "a job that was never meant to end", "the friendly voice on the phone was the
  shop's oldest trick".
- Tone: "Dark humor first, then dread. The mystery belongs to this shop: a dumb local restaurant that became wrong. No
  gore for its own sake." Comic relief voice (the terminal) is kept separate from the phone voice.
- Final line of the last call gives "an instruction to follow, not an explanation".

## Pitfalls (mistakes seen)

mistake-phone-audio-drift-from-script (assets described from an older script).

## Verify

Every phone line, UI string and enemy rule can be traced to a bible section; the "never understand" list is
not answered anywhere in game text.

## Origin

FNAP. Source notes: BIBLE entire.

## Related skills

- [mistake-phone-audio-drift-from-script](mistake-phone-audio-drift-from-script.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
