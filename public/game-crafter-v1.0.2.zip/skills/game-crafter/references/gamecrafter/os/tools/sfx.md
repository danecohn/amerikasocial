# Tool: sfx.py

**Purpose:** Procedural SFX with numpy (hits, steps, pickups, doors, stingers), per-game flavour by pitch + grit.

**Usage:** `python3 sfx.py <out_dir> <pitch> <grit>`

**Skill:** see `skills/numpy-sfx-synth-primitives.md`

**Extract:** save the block below as `sfx.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Procedural SFX (numpy), per-game flavour via pitch + grit. Forgotten Woods Studios."""
import numpy as np, wave, os
SR = 22050


def _t(d): return np.arange(int(SR * d)) / SR
def osc(f, t, kind="square"):
    ph = (np.cumsum(np.broadcast_to(f, t.shape)) / SR) % 1.0
    if kind == "square": return np.where(ph < 0.5, 1.0, -1.0)
    if kind == "tri": return 4 * np.abs(ph - 0.5) - 1
    if kind == "saw": return 2 * ph - 1
    if kind == "pulse": return np.where(ph < 0.25, 1.0, -1.0)
    if kind == "sine": return np.sin(2 * np.pi * ph)
    return np.random.uniform(-1, 1, t.shape)
def env(t, a=0.005, d=0.1, s=0.0):
    e = np.minimum(t / max(a, 1e-4), 1.0) * np.exp(-t / max(d, 1e-4))
    return np.maximum(e, 0)
def lp(x, k):
    out = np.copy(x); a = 1 / max(k, 1)
    for i in range(1, len(x)): out[i] = out[i - 1] + a * (x[i] - out[i - 1])
    return out
def crush(x, bits):
    q = 2 ** bits
    return np.round(x * q) / q

def sweep(f0, f1, d, kind="square", dec=None, vol=0.6):
    t = _t(d); f = np.linspace(f0, f1, len(t)); return osc(f, t, kind) * env(t, 0.003, dec or d / 2) * vol
def noise_hit(d, dec, cut=6, vol=0.7):
    t = _t(d); n = np.random.uniform(-1, 1, len(t)); n = lp(n, cut) if cut > 1 else n
    return n * env(t, 0.002, dec) * vol
def seq(notes, d, kind="square", vol=0.5, dec=0.1):
    out = []
    for f in notes:
        t = _t(d); out.append(osc(f, t, kind) * env(t, 0.003, dec) * vol)
    return np.concatenate(out)
def mixs(*xs):
    n = max(len(x) for x in xs); o = np.zeros(n)
    for x in xs: o[:len(x)] += x
    return o

def build(p=1.0, grit=0, seed=1):
    np.random.seed(seed)
    S = {}
    S["hit"] = mixs(noise_hit(0.12, 0.04, 3, 0.6), sweep(220 * p, 90 * p, 0.1, "square", 0.05, 0.4))
    S["hurt"] = mixs(sweep(300 * p, 70 * p, 0.35, "saw", 0.15, 0.55), noise_hit(0.3, 0.1, 4, 0.4))
    S["shoot"] = sweep(700 * p, 220 * p, 0.12, "pulse", 0.05, 0.4)
    S["swing"] = noise_hit(0.14, 0.06, 2, 0.35) * np.linspace(0.3, 1, int(SR * 0.14))
    S["dash"] = mixs(noise_hit(0.2, 0.08, 4, 0.4), sweep(180 * p, 520 * p, 0.18, "tri", 0.1, 0.25))
    S["pickup"] = seq([660 * p, 880 * p, 1320 * p], 0.04, "square", 0.3, 0.05)
    S["door"] = mixs(sweep(110 * p, 60 * p, 0.5, "saw", 0.3, 0.4), noise_hit(0.5, 0.2, 8, 0.3))
    S["die"] = mixs(sweep(260 * p, 50 * p, 0.3, "saw", 0.12, 0.45), noise_hit(0.3, 0.09, 3, 0.45))
    S["boss_roar"] = mixs(sweep(90 * p, 55 * p, 0.9, "saw", 0.5, 0.6), sweep(95 * p, 50 * p, 0.9, "square", 0.4, 0.3), noise_hit(0.9, 0.3, 6, 0.35))
    S["boss_die"] = mixs(sweep(200 * p, 30 * p, 1.6, "saw", 0.8, 0.6), noise_hit(1.6, 0.6, 5, 0.6))
    S["boss_slam"] = mixs(sweep(120 * p, 30 * p, 0.5, "square", 0.2, 0.7), noise_hit(0.5, 0.15, 5, 0.7))
    S["boom"] = mixs(noise_hit(0.45, 0.14, 5, 0.8), sweep(100 * p, 35 * p, 0.4, "square", 0.15, 0.5))
    S["select"] = sweep(500 * p, 600 * p, 0.04, "square", 0.04, 0.3)
    S["confirm"] = seq([520 * p, 780 * p], 0.05, "square", 0.35, 0.06)
    S["deny"] = seq([180 * p, 140 * p], 0.07, "square", 0.35, 0.08)
    S["bell"] = mixs(*[osc(f * p, _t(1.4), "sine") * env(_t(1.4), 0.002, 0.5) * v for f, v in ((440, .5), (880, .3), (1320, .2), (1780, .12))])
    S["step"] = noise_hit(0.05, 0.02, 6, 0.18)
    S["warn"] = seq([330 * p, 247 * p], 0.09, "pulse", 0.4, 0.1)
    S["enemy_shoot"] = sweep(380 * p, 160 * p, 0.14, "tri", 0.07, 0.4)
    S["shield"] = mixs(sweep(300 * p, 900 * p, 0.3, "sine", 0.2, 0.4), noise_hit(0.3, 0.1, 2, 0.15))
    S["pulse"] = mixs(sweep(400 * p, 80 * p, 0.35, "sine", 0.15, 0.6), noise_hit(0.2, 0.06, 4, 0.3))
    S["clear"] = seq([392 * p, 494 * p, 587 * p, 784 * p], 0.09, "tri", 0.45, 0.14)
    S["boon"] = seq([523 * p, 659 * p, 784 * p, 1047 * p, 1319 * p], 0.07, "square", 0.3, 0.1)
    S["heal"] = seq([440 * p, 554 * p, 659 * p], 0.07, "sine", 0.5, 0.12)
    S["fragment"] = mixs(seq([392 * p, 523 * p, 659 * p, 784 * p, 988 * p], 0.11, "sine", 0.45, 0.25))
    S["death"] = mixs(sweep(220 * p, 40 * p, 1.4, "tri", 0.6, 0.6), noise_hit(1.0, 0.3, 8, 0.25))
    S["sting"] = mixs(seq([196 * p, 233 * p, 294 * p, 392 * p], 0.45, "sine", 0.5, 0.5))
    for k in S:
        x = S[k]
        if grit: x = crush(x, 7 - grit)
        S[k] = x
    return S

def write(outdir, p=1.0, grit=0, seed=1):
    os.makedirs(outdir, exist_ok=True)
    S = build(p, grit, seed)
    for k, x in S.items():
        x = np.clip(x / max(1.0, np.abs(x).max()) * 0.85, -1, 1)
        w = wave.open(os.path.join(outdir, k + ".wav"), "wb")
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes()); w.close()
    return list(S)

if __name__ == "__main__":
    print(write("/tmp/sfxtest"))
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
