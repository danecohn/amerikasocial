---
id: mistake-asset-reference-wrong-extension
title: "Marketing instructions reference a studio file name/format that is not in the delivered kit"
category: mistake
when: "Writing instructions that point at user files (paths in socials/itch docs)."
related: []
origin: Roguelike series
---

# Marketing instructions reference a studio file name/format that is not in the delivered kit

**When to use:** Writing instructions that point at user files (paths in socials/itch docs).

## Do this

Before citing a path, check it exists in the user's tree; prefer naming the folder and listing alternatives.

## What happened, root cause, fix, prevention

- Symptom: socials.txt tells the user to use `Eva C Studios\audio\eva-c-studios-splash-sting.mp3`; the factory's `studio_branding/audio` has `eva-c-studios-splash-sting.wav` (+ theme mp3) only. Branding paths `branding\forgotten-woods-logo-on-night.png` are relative with no root.
- Root cause: copy written from the README table (which lists ".wav / .mp3") instead of the actual files present.
- Fix: reference the exact existing file (and its full relative root), or "the splash sting (.wav or .mp3)".
- Detection: script that extracts every path-like token from ADVERTISEMENTS/*.txt and checks existence.

## Verify

all referenced files resolve.

## Origin

Roguelike series. Source notes: socials.txt PART 2 step 5; studio_branding/ listing; studio_branding/README.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
