# STATE — <GAME TITLE>
*The first file any AI or person reads to pick up this project. Keep it current: update it in the same turn as every change.*

Last updated: <date/time> · By: <agent> · Version: <x.y.z>

## Where things are
- Project of record (authoritative): `<path>`
- Working copy (cloud): `<path>` (may be reset)
- Distribution folder: `<path>`
- Engine: Godot <x.y.z> standard · Export templates: <x.y.z> (must match exactly)

## Current status (one paragraph)
<What works now in the EXPORTED build, verified how.>

## Last change
- <what changed> → files: <list> → verified by: <screenshot/probe/test> → not verified: <...>

## Open problems (ranked)
1. <...>

## Next steps
1. <...>

## Standing instructions from the user
- <e.g. "Hallways must be dark; only hall lights or the flashlight reveal characters">
- <e.g. "Never upload to itch.io">

## How to run / build / verify
```
<exact commands>
```
