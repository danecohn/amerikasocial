---
id: mistake-dead-experimental-code-in-generators
title: "Leftover `if False` experiments and unused values in art generators"
category: mistake
when: "Cleaning/porting a procedural art toolchain."
related: []
origin: Roguelike series
---

# Leftover `if False` experiments and unused values in art generators

**When to use:** Cleaning/porting a procedural art toolchain.

## What happened, root cause, fix, prevention

- Symptom: confusing code paths; reviewers think features exist that do not.
- Instances: tiles.pickup_sheets `finish_icon(...).crop(...).resize(...) if False else im`; gk.prop_shrine `im.alpha_composite(im) if False else None`; fonts.variant bold `(r+"0") if False else ...` and serif `if ...: pass`; tiles.build_tiles `cols = 14 + 0` unused; ICON_SHAPES "sword" unused; fonts LOW "g" unused; buildgame icon `ic`/`big` composed then discarded (every game ships the studio icon instead); `SPEC["pal"] = {}` unused; `title_bg(... big=False, k=1, rng)` unused.
- Fix/prevention: run `pyflakes`/`ruff` on the toolchain; delete dead branches; keep features either wired or removed.

## Verify

`ruff check _tools` clean of F841/unused.

## Origin

Roguelike series. Source notes: files/lines listed above.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
