---
id: autotiling-extension-guidance
title: "Autotiling - what the shipped kit does (position rules) and how to extend to 4-bit/blob autotiles"
category: pixel-art-2d
when: "Rooms need irregular wall shapes, corners, or caves instead of rectangular arenas."
related: []
origin: Roguelike series
---

# Autotiling - what the shipped kit does (position rules) and how to extend to 4-bit/blob autotiles

**When to use:** Rooms need irregular wall shapes, corners, or caves instead of rectangular arenas.

## Do this

- Shipped approach = positional rules only (rectangular room: top rows = top/face, side columns = side, interior obstacles = self-contained "block" props drawn over floor). This avoids autotiling entirely and is the cheapest robust option for arena roguelikes: obstacles are 1-tile props, never connected walls.
- Extension (not in source; standard technique): compute a 4-bit mask per wall cell `N=1,E=2,S=4,W=8` of same-type neighbours -> 16 tile variants; generate them procedurally by drawing the wall_face pattern and then drawing edge highlight (hi) on exposed N edge, dark shade on exposed S edge, side lines on exposed E/W edges - exactly the finish() logic applied at tile level. For inner corners use the 8-neighbour 47-tile blob set.
- Keep the tile strip 1 row; index = mask (0-15) offset by a base.

## Pitfalls (mistakes seen)

corners currently reuse wall_side, bottom wall reuses wall_top; acceptable for rectangles only.

## Verify

generate a cave layout and ensure no wall tile shows a highlight on a side touching another wall.

## Origin

Roguelike series. Source notes: kit/kit/room.gd _compose lines 142-168 (positional rules); extension is harvester guidance.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
