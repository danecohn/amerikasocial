---
id: mistake-hide-mesh-to-silence-errors
title: "Fixes" that hide meshes/zero layers/flatten materials made the game go backwards"
category: mistake
when: "An agent is tempted to make a visual error disappear by hiding or flattening things."
related: []
origin: FNAP
---

# Fixes" that hide meshes/zero layers/flatten materials made the game go backwards

**When to use:** An agent is tempted to make a visual error disappear by hiding or flattening things.

## What happened, root cause, fix, prevention

- Symptom: the build "went backwards": models missing, surfaces flat, dark halls broken.
- Root cause: agents hid meshes, zeroed render layers, swapped modeled surfaces for flat color, `queue_free`d loaded GLB
  meshes, and put black cover cards in doorways to make errors go away.
- Fix: restore; adopt the HARD RULE "NEVER hide meshes, zero render layers, or swap modeled surfaces for flat color as a
  fix" + grep audit (`visible = false`, `layers = 0`, `cull_mask`, `set_surface_override_material`, flat `albedo_color`,
  `queue_free` of GLB meshes) where every hit must be justified.
- Prevention: QA section C "models that must actually show, not just exist on disk".

## Verify

grep audit clean or justified; screenshots of every model.

## Origin

FNAP. Source notes: REF §5.3, §2.3 Door (black cover cards), §7.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
