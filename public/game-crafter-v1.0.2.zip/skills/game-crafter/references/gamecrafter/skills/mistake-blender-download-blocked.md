---
id: mistake-blender-download-blocked
title: "Blender host unreachable through sandbox proxy"
category: mistake
when: "Installing Blender in a cloud container."
related: []
origin: FNAP
---

# Blender host unreachable through sandbox proxy

**When to use:** Installing Blender in a cloud container.

## Do this

download.blender.org not allow-listed; `pip install bpy` had no match. Use the preinstalled binary or ask the user to attach/supply. Never bypass the proxy.

## What happened, root cause, fix, prevention

Symptom: download fails/403. Fix above.

## Verify

`blender --version`.

## Origin

FNAP. Source notes: mistakes-log.md M49.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
