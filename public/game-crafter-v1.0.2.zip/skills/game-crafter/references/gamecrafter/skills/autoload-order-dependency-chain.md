---
id: autoload-order-dependency-chain
title: "Ordered autoload singletons where each may only use those above it in _ready()"
category: gdscript-patterns
when: "Designing an RPG's global systems in Godot."
related: []
origin: Caesarea
---

# Ordered autoload singletons where each may only use those above it in _ready()

**When to use:** Designing an RPG's global systems in Godot.

## Do this

- Order: ConsequenceLedger → FactionManager → TimeOfDay (+curfew) → SuspicionSystem → QuestManager → CompanionManager → DialogueManager → RadioManager → EndingResolver → SaveManager → Game. "The order matters: each autoload only uses those above it in `_ready()`."
- Autoloads have **no class_name** (the autoload name is the global); helper classes do (`LedgerExpr`, `VoxRomaeBus`, `CaeHumanoidBody`, `DialoguePanel`).
- Each autoload doc: responsibility, API table, signals. Signal flow: Area3D/NPC → DialogueManager → effects → LedgerExpr → ConsequenceLedger → `flag_changed` → QuestManager re-evaluate + SaveManager hinge autosave; DialogueManager `command_requested` → scene scripts; FactionManager.apply_event → SuspicionSystem.add → tier_changed → patrol/drone spawners; CompanionManager.react → approval_changed; TimeOfDay day_passed → suspicion decay/neighbor roll, ration_day → inventory, curfew_changed → HUD/patrols.
- Keep the legacy API when replacing an autoload (`TITLE`, `CREDITS`, `play_sting()`, `play_click()`).

## Pitfalls (mistakes seen)

Static vars in a helper class (cached `Expression`s, a self-typed instance, `RegEx`, callables bound to autoloads) outliving the autoloads corrupted Godot 4.7.2's heap at quit → `ConsequenceLedger._exit_tree()` calls `LedgerExpr.shutdown()` to clear them. Rule: any class with static caches clears them on exit of the owning autoload.

## Verify

test_main passes; quit is clean (only the known AudioStreamWAV leak lines).

## Origin

Caesarea. Source notes: design/08 §3, §11; godot_starter/README Conventions + Validation; project.godot [autoload].

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
