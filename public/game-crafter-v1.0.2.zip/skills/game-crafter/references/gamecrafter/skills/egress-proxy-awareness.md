---
id: egress-proxy-awareness
title: "Check the sandbox egress proxy before building a workflow on a host"
category: environment-tools
when: "Any download/upload from the container (asset sites, Descript uploads, presigned URLs)."
related: []
origin: FNAP
---

# Check the sandbox egress proxy before building a workflow on a host

**When to use:** Any download/upload from the container (asset sites, Descript uploads, presigned URLs).

## Do this

- The proxy blocks most hosts; a blocked CONNECT gives `curl: (56) CONNECT tunnel failed, response 403` and a proxy note `connect_rejected (the egress proxy denied the CONNECT (organization policy)...)`.
- Status: `curl -sS "$HTTPS_PROXY/__agentproxy/status"`. Never disable TLS verification or unset HTTPS_PROXY.
- Test reachability with a HEAD request before designing a workflow around a host.
- GitHub release downloads worked.

## Pitfalls (mistakes seen)

Descript upload via presigned storage URL blocked (descript-upload-failure-protocol); download of published Descript video blocked.

## Verify

HEAD request returns 2xx/3xx.

## Origin

FNAP. Source notes: L §1.4 line 43, §8.1, §9 row 8, §10 lines 448-452.

<!-- CONTINUE -->

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
