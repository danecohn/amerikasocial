---
id: kitslot-placeholder-until-glb-exists
title: "KitSlot — contract-sized stand-in that auto-swaps to the real GLB when the file lands"
category: multi-agent
when: "Code (Godot) and art (Blender) are produced in parallel by different agents; you need a playable scene before the art exists; you must never block on art."
related: []
origin: Caesarea
---

# KitSlot — contract-sized stand-in that auto-swaps to the real GLB when the file lands

**When to use:** Code (Godot) and art (Blender) are produced in parallel by different agents; you need a playable scene before the art exists; you must never block on art.

## Do this

- A `KitSlot` node holds `asset_path` (e.g. `res://assets/arch/roma_subura/CAE_Arch_SuburaInsula_Facade.glb`), an origin mode and a contract size. On ready: `if ResourceLoader.exists(asset_path): instance the GLB else build a placeholder box of the contract size` (+ `push_warning("PLACEHOLDER: ...")`). Dropping a GLB at the exact path needs **no scene edit**.
- Origin modes: **corner** = occupies x 0..W, y 0..H, z 0..D, front +Z. **base_center** = origin at bottom-face center, standing on y=0. **hinge** (barrier: origin at hinge, arm along +X). **wall mount** (camera points +Z). Paving: corner, top at y=0, slab to y=-0.2.
- Contract sheet per file (W x H x D m) and named sockets as empties: `SOCKET_Light`, `SOCKET_Speaker`, `SOCKET_Barrier`, weapon `SOCKET_grip`, `SOCKET_muzzle`, `SOCKET_rail_*`.
- Tests compare `KitSlot.measured_aabb()` (union of mesh AABBs in slot local space, nested kit slots excluded) to the contract within **5% per axis** (min, max and size).
- Collision: when the instanced GLB has no StaticBody, KitSlot adds a layer-1 `StaticBody3D` + `CollisionShape3D` box matching `measured_aabb()`; an asset with its own StaticBody does not get a second one. Placeholder adds its own street body.
- Docs must say "Missing means KitSlot placeholders. Present means the real mesh. Both are valid. Do not document 'placeholders forever.'"

## Pitfalls (mistakes seen)

- Symptom: test `player stands on the street` failed once real paving GLB landed. Root cause: KitSlot added a street StaticBody only while the placeholder showed; the real paving GLB had no collider, and the district had no other floor collider → player fell. Fix: KitSlot adds a box collider from measured AABB when the GLB lacks a StaticBody. Prevention: placeholder and real-asset paths must provide the same gameplay contract (collision, sockets), and a test must exercise the real-asset path.
- Symptom: `barrier hinge extends +X` failed. Measured AABB pos (-0.042,-0.06,-0.084) size (7.642,0.12,0.168) vs expected pos (0,-0.06,-0.08) size (7.6,0.12,0.16): a hinge-pin primitive stuck out behind the origin. Fix was in the art (trim the pin in the .blend, re-export), NOT weakening the test or deleting the GLB.

## Verify

run the scene with the GLB absent (placeholder + PLACEHOLDER warning) and present (real mesh, no warning); AABB test passes; player stands on floor after 40 physics frames.

## Origin

Caesarea. Source notes: docs/handoff/godot_import_report.md, glb_report.md, attachment.txt "KitSlot already instances a GLB when ResourceLoader.exists...", CURSOR_MODEL_REQUEST.md rules, KNOWN_GAPS.md last bullet.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
