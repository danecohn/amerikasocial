---
id: mistake-embedded-textures-bloat
title: "Each building GLB embedded all trim sheets (7–15 MB each)"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Each building GLB embedded all trim sheets (7–15 MB each)

**When to use:** 

## What happened, root cause, fix, prevention

Civic GLBs (Inn 14.9 MB, WallSegment 14.7 MB, Watchtower 11.7 MB…) embedded the five `CAE_Tex_*` PNG sheets inside each file instead of referencing the shared trim folder; other pieces used only baseColorFactor. Effect: pack size bloat (zips 118–150 MB) and inconsistent materials. Prevention: in the art contract specify "materials named `CAE_Mat_<Trim>` without embedded images; Godot remaps to shared ORMMaterial3D via import material remap" or export with external textures; QA report flags embedded images.

## Origin

Caesarea. Source notes: glb_report.md "Civic" + "Trim sheets".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
