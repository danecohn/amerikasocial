---
id: mistake-folder-name-drift-chars-vs-characters
title: "Two folders for the same asset class (assets/chars vs assets/characters)"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Two folders for the same asset class (assets/chars vs assets/characters)

**When to use:** 

## What happened, root cause, fix, prevention

Contract used `assets/chars/`, the characters agent used `assets/characters/` (skinned Legionary, proxy, v1_lastgood); one tree had both, the other neither; QA skipped the unscored folder. Prevention: scene plan defines folder names once (`assets/chars/ CAE_Char_*`); agents grep the plan before creating folders; static check for duplicate asset basenames across folders.

## Origin

Caesarea. Source notes: glb_report "Outside the four folders"; design/08 §2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
