# Tool: ffmpeg_recipes.sh

**Purpose:** ffmpeg recipes for trailers, vertical reels, music beds, fades, title cards, thumbnails.

**Usage:** `source ffmpeg_recipes.sh; <function> ...`

**Skill:** see `skills/ffmpeg-recipe-library.md`

**Extract:** save the block below as `ffmpeg_recipes.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Game Maker ffmpeg recipe library. `source ffmpeg_recipes.sh` then call the functions, or run: ffmpeg_recipes.sh selftest
# All functions encode H.264 yuv420p 30 fps so the concat demuxer can join segments with -c copy.
# Font: set FONT (default Poppins-Bold if present, else DejaVu Sans Bold). Look-grade chain in GRADE.
FONT="${FONT:-$(ls /usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf 2>/dev/null | head -1)}"
GRADE="${GRADE:-noise=alls=10:allf=t+u,vignette=PI/5,eq=contrast=1.06:saturation=1.05}"
ENC="-c:v libx264 -crf 19 -preset fast -pix_fmt yuv420p -r 30"

# png_seq_to_clip <out.mp4> <pattern e.g. clips/f%08d.png> <start_frame> <n_frames> <src_fps> [WxH=1920:1080]
# Godot --write-movie writes f00000000.png...; use -t (seconds = n/src_fps), NOT -frames:v (counts OUTPUT frames after the fps filter -> wrong length).
png_seq_to_clip(){ local out=$1 pat=$2 st=$3 n=$4 fps=$5 wh=${6:-1920:1080}
  ffmpeg -v error -y -framerate "$fps" -start_number "$st" -i "$pat" -vf "scale=$wh:flags=lanczos,fps=30,$GRADE,format=yuv420p" -t "$(python3 -c "print($n/$fps)")" $ENC "$out"; }

# still_kenburns <out.mp4> <img> <seconds> [zoom_per_frame=0.0007] [WxH=1920x1080]
# Pre-scale to 2400 wide so zoompan does not pixelate; d=1 with -loop 1 advances one step per input frame.
still_kenburns(){ local out=$1 img=$2 sec=$3 z=${4:-0.0007} wh=${5:-1920x1080}
  ffmpeg -v error -y -loop 1 -framerate 30 -i "$img" -t "$sec" -vf "scale=2400:-1,zoompan=z='1.0+${z}*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=$wh:fps=30,$GRADE,format=yuv420p" $ENC "$out"; }

# vertical_from_landscape <out.mp4> <in.mp4> [title_text] [title_y=1560]
# 9:16 = blurred+darkened full-bleed copy as background + the sharp centre crop on top. Keep captions in the safe zone (not top ~250px / bottom ~350px, platform UI).
vertical_from_landscape(){ local out=$1 in=$2
  ffmpeg -v error -y -i "$in" -filter_complex "[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=40:8,eq=brightness=-0.18[bg];[b]scale=-2:1080,crop=1080:1080[fg];[bg][fg]overlay=0:420,format=yuv420p[v]" -map "[v]" -map 0:a? $ENC -c:a aac "$out"; }

# caption <out.mp4> <in.mp4> <text> <t0> <t1> [y=h-220] [size=84]
# drawtext traps: a literal ":" ends the option -> write \: ; an apostrophe ends the quoted text -> use the typographic ’ ; expansion=none makes "%" and "\\" literal (otherwise "100%" = "Stray %" error).
caption(){ local out=$1 in=$2 txt=$3 t0=$4 t1=$5 y=${6:-h-220} sz=${7:-84}
  txt=${txt//:/\\:}; txt=${txt//\'/’}
  ffmpeg -v error -y -i "$in" -vf "drawtext=fontfile=$FONT:expansion=none:text='$txt':fontsize=$sz:fontcolor=white:borderw=4:bordercolor=black@0.9:x=(w-text_w)/2:y=$y:enable='between(t,$t0,$t1)':alpha='if(lt(t,$t0),0,if(lt(t,$t0+0.2),(t-$t0)/0.2,if(lt(t,$t1-0.2),1,max(0,($t1-t)/0.2))))'" -c:v libx264 -crf 19 -preset fast -pix_fmt yuv420p -c:a copy "$out"; }

# concat_clips <out.mp4> <a.mp4> <b.mp4> ...   (all must share codec/size/fps/pix_fmt or -c copy breaks timestamps)
concat_clips(){ local out=$1; shift; : > /tmp/gm_concat.txt; for f in "$@"; do echo "file '$(realpath "$f")'" >> /tmp/gm_concat.txt; done
  ffmpeg -v error -y -f concat -safe 0 -i /tmp/gm_concat.txt -c copy "$out"; }

# mux_audio <out.mp4> <video.mp4> <audio.wav>
mux_audio(){ ffmpeg -v error -y -i "$2" -i "$3" -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest "$1"; }

# loudness_check <file>   -> peaks/LUFS. Reels must not clip (true peak <= -1 dBTP) and sit around -14 LUFS for social. NEVER ship audio you have not measured.
loudness_check(){ ffmpeg -hide_banner -nostats -i "$1" -filter_complex ebur128=peak=true -f null - 2>&1 | grep -E "I:|Peak:|LRA:" | tail -4; ffmpeg -hide_banner -i "$1" -af volumedetect -f null - 2>&1 | grep -E "max_volume|mean_volume"; }

# contact_sheet <video> <out.png> [every_n_seconds=2]  -> one image of the whole video to LOOK at before delivering (Read the png).
contact_sheet(){ local f=$1 out=$2 n=${3:-2}; ffmpeg -v error -y -i "$f" -vf "fps=1/$n,scale=320:-1,tile=6x4" -frames:v 1 "$out"; }

if [ "${1:-}" = selftest ]; then set -e; D=$(mktemp -d); cd "$D"
  ffmpeg -v error -f lavfi -i testsrc=duration=2:size=1280x720:rate=12 f%08d.png
  png_seq_to_clip a.mp4 f%08d.png 0 24 12; still_kenburns b.mp4 f00000005.png 2; concat_clips c.mp4 a.mp4 b.mp4
  ffmpeg -v error -y -f lavfi -i sine=frequency=220:duration=4 t.wav; mux_audio d.mp4 c.mp4 t.wav
  caption e.mp4 d.mp4 "DON'T LOOK: NOW 100%" 0.5 3; vertical_from_landscape v.mp4 e.mp4; contact_sheet e.mp4 s.png 1
  for f in a b c d e v; do printf '%s %s\n' $f "$(ffprobe -v error -show_entries format=duration -of csv=p=0 $f.mp4)"; done; loudness_check d.mp4; echo SELFTEST_OK $D; fi
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
