# Concrete fixes and reusable patterns

## SVG imports and Control minimum size

Symptom: a 64-unit SVG looked soft when shown at 230 pixels. Raising SVG import scale to 8 made it crisp, but exposed a second bug: its 512-pixel minimum size expanded beyond the intended title/ending rectangle.

Cause: TextureRect received the texture and target size while its default expand behavior still kept the texture's minimum dimensions. Assigning IGNORE_SIZE later lowered the minimum without shrinking the already enlarged control.

Correct order:

```gdscript
var logo = TextureRect.new()
logo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
logo.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
logo.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
logo.texture = load("res://assets/branding/logo.svg")
logo.position = target_rect.position
logo.size = target_rect.size
add_child(logo)
```

Preserve source SVG, tune importer scale to actual target pixels, capture both large title and smaller ending displays, and open both. A log that says capture succeeded does not prove layout.

## Windows launch before logging

Symptom: EXE exited immediately; a pack run under the installed Godot editor worked. That did not prove the delivered executable was portable.

Fix in that engine/template version: supply its matching `icudt_godot.dat` next to EXE/PCK. Confirm engine/template version, copy required runtime data, launch the native deliverable from its own directory, read the process exit code and full log. Do not universally prescribe that data file for versions that do not require it.

## Reliable automated walking

A point path used cells just outside an obstacle. The actor arrived a little off center and turned before clearing the edge, then stalled against the collider. Give the planner a clearance margin or account for actor dimensions. Bound each waypoint loop and print actual/target positions when it fails. Test proximity-selected interactables with input events rather than only assigning player positions.

Dependency-aware walkthrough: choose an available uncompleted object whose prerequisite IDs are found; visit gated child/closure after other objects; fail clearly on dependency cycles. Do not assume JSON order already supplies a topological traversal.

## Safe save and test design

Use dedicated QA save names; test flags disable production writes. Write JSON to temporary file, rotate backup, rename atomically, and parse with a JSON object so a corrupt primary can fall back cleanly without noisy global parse errors. A two-process restore test checks restart persistence; a same-instance reload alone does not demonstrate relaunch.

New Game must reset graph completion, selected node, edges and ending choice as well as chapter/object progress. Otherwise a second playthrough can skip the integration puzzle.

## Readability and typography

Choose and embed licensed fonts. In the previous layout, dialogue pages were bounded to roughly 420 characters at 24 px in a 1280x720 viewport, choice text below 70 characters, at most three choices, and long notes used a scroll container. These are that layout's constraints, not universal constants. Inspect longest content at the delivered resolution. Shortening an overflowing graph label to its precise functional term fixed its node fit.

## Audio and finish

Original stereo felt-piano/pad loops used circular reverb tails and measured peak/RMS/seam differences. Activate WAV looping explicitly and crossfade tracks at chapter changes. Stop/release playback on quit. Headless logic runs need not start an audio device; still check imported resources and run graphical builds normally. State exactly whether audio was listened to or only numerically inspected.

Bundle credits and font licenses with the standalone build. Keep source archive/build archive distinct. Compute a final artifact hash after the last export and make all QA claims refer to that artifact. Archive tests are not gameplay tests.
