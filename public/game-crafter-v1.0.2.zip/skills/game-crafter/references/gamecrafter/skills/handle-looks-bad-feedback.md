---
id: handle-looks-bad-feedback
title: "Handling "it looks bad / broken" feedback on a shipped build"
category: testing-qa
when: "User reports the game looks bad, wrong, like an old version, placeholders, missing models/lighting."
related: []
origin: FNAP
---

# Handling "it looks bad / broken" feedback on a shipped build

**When to use:** User reports the game looks bad, wrong, like an old version, placeholders, missing models/lighting.

## Do this

1. Ask for / inspect their screenshots; identify what is missing (placeholder boxes? low renderer? missing textures?).
2. Reproduce on the BUILT pack with the same renderer. Check the on-screen renderer note (Forward+ vs Compatibility fallback changes the whole look).
3. Root-cause by listing what the code resolved: a "role -> real|PLACEHOLDER|missing" wiring report (FNAP `office_wiring` print), `export_probe` output.
4. Fix, rebuild, re-verify, re-deliver; tell them which file to run and what they should see.
5. Do NOT say "you are running an old version" until proven (timestamps, version string in the menu).

## Pitfalls (mistakes seen)

M01 (assistant first blamed stale scripts), M03 renderer fallback.

## Verify

Repro screenshot from pack before fix and after fix, both opened.

## Origin

FNAP. Source notes: process-playbook.md section 4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
