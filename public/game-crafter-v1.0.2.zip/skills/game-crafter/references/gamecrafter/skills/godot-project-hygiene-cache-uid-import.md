---
id: godot-project-hygiene-cache-uid-import
title: "Godot project hygiene - .godot cache, .import/.uid files, harmless warnings"
category: godot-engine
when: "Syncing a Godot project between machines/agents, committing, staging to a PC."
related: []
origin: FNAP
---

# Godot project hygiene - .godot cache, .import/.uid files, harmless warnings

**When to use:** Syncing a Godot project between machines/agents, committing, staging to a PC.

## Do this

- `.godot/` cache (~900 MB for ~600 MB of GLBs; FNAP ~927 MB) is never synced, committed or staged.
- `.import` and `.uid` files are regenerated; sync scripts exclude them (`robocopy ... /XF *.import *.uid`), let Godot regenerate.
- Warning `WARNING: res://scenes/splash.tscn:3 - ext_resource, invalid UID: uid://... - using text path instead` is harmless (stale uid in hand-written/recovered .tscn); delete the `uid=` or let Godot re-save. Import still `EXIT 0`.
- On Windows ARM64 use the arm64 `_console.exe` Godot for headless runs/exports (captures output and exit code).

## Pitfalls (mistakes seen)

staging the cache would blow bridge limits; synced .uid files cause UID conflicts (inference).

## Verify

staged file list contains no `.godot/`, `*.import`, `*.uid`.

## Origin

FNAP. Source notes: G "Import & project hygiene" (lines 12-16); L §2.9 lines 124-125; L §10 line 442.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
