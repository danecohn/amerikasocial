---
id: mistake-hardcoded-absolute-tool-paths
title: "Hard-coded absolute paths (/home/claude/evac, plugin cache dirs) break the factory when moved"
category: mistake
when: "Writing reusable tool scripts or shipping a 'resume' zip."
related: []
origin: Roguelike series
---

# Hard-coded absolute paths (/home/claude/evac, plugin cache dirs) break the factory when moved

**When to use:** Writing reusable tool scripts or shipping a "resume" zip.

## Do this

Resolve paths from `__file__` (`HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = dirname(HERE)`) or an env var (`FACTORY_ROOT`); locate templates by search with a clear error.

## What happened, root cause, fix, prevention

- Symptom: the factory was later found at a different root; gk.py and every spec do `sys.path.insert(0, "/home/claude/evac/_tools")`; release.py/finish.py/pack.py hard-code `/home/claude/evac/build|out`; cover.py hard-codes the icon path; buildgame.py scans `/root/.claude/plugins/synced/*/game-maker/...` for the preset template (SKILL stays None -> crash in write_presets if the plugin is absent); autorun.sh/shot.sh glob the plugin's godot_xvfb.sh.
- Root cause: tools written for one container session.
- Fix: ROOT-relative paths everywhere; vendor the export template and xvfb wrapper into `_tools/`; fail with a message if missing.
- Prevention: run the pipeline from a copy in a different directory as a smoke test.

## Verify

`cp -r factory /tmp/x && cd /tmp/x && python3 _tools/buildgame.py games/g1 --no-music` works.

## Origin

Roguelike series. Source notes: gk.py L5; games/g1_lamp/spec.py L2; release.py L5; finish.py L6, L16, L50; pack.py L8-10; cover.py L40; buildgame.py L19-23; autorun.sh L4; shot.sh L5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
