---
id: godot-movie-maker-capture
title: "Gameplay video via Godot Movie Maker"
category: godot-engine
when: "Trailer/reel footage from the game."
related: []
origin: FNAP
---

# Gameplay video via Godot Movie Maker

**When to use:** Trailer/reel footage from the game.

## Do this

`--write-movie f.png --fixed-fps 12` -> PNG sequence `f00000000.png...` + `f.wav`; game time = frames/fps regardless of wall time; `.avi` gives MJPEG. Example: `godot --path . res://scenes/promo_capture.tscn --write-movie out.avi --fixed-fps 30 -- movie`. Encode with `png_seq_to_clip` (uses `-t`, not `-frames:v`). Clean PNGs after encoding.

## Pitfalls (mistakes seen)

Wrong clip lengths using -frames:v (see ffmpeg skill).

## Verify

ffprobe duration = n/fps.

## Origin

FNAP. Source notes: headless-render-capture/SKILL.md "Video"; templates/promo_capture.fnap_example.gd header.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
