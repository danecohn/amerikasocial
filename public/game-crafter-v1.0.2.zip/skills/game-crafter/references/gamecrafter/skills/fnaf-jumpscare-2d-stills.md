---
id: fnaf-jumpscare-2d-stills
title: "2D jumpscares from single stills (shake/zoom in engine)"
category: pixel-art-2d
when: "Building a 2D/Clickteam/still-image FNAF-like with no animation frames."
related: []
origin: FNAP
---

# 2D jumpscares from single stills (shake/zoom in engine)

**When to use:** Building a 2D/Clickteam/still-image FNAF-like with no animation frames.

## Do this

- One full-screen 1280x720 still per enemy: `jumpscare-remi/dilly/pickle/banshee/golden-pickle.png` plus
  `jumpscare-pickle-power-out.png` (same render re-graded darker/blue).
- "Each jumpscare is one still image. Shake/zoom it in Fusion." Pair with the per-character sting wav.
- Game over card: static + "Game Over" baked in (`card-game-over.png`), optional transparent text overlay 440x100,
  `game-over-static-loop.wav` (5 s loop).

## Pitfalls (mistakes seen)

none.

## Verify

State map lists a jumpscare for every enemy and the power-out.

## Origin

FNAP. Source notes: STATEMAP lines 151-161, 183-184, 244.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
