---
id: dithered-darkness-postfx-shader
title: "Full-screen pixel post-FX shader - Bayer-dithered light radius, vignette, grain, scanlines, hurt, insanity, fade"
category: pixel-art-2d
when: "Horror/lighting mood in a 2D pixel game; need darkness that stays '8-bit' (dithered bands, no smooth gradients)."
related: []
origin: Roguelike series
---

# Full-screen pixel post-FX shader - Bayer-dithered light radius, vignette, grain, scanlines, hurt, insanity, fade

**When to use:** Horror/lighting mood in a 2D pixel game; need darkness that stays "8-bit" (dithered bands, no smooth gradients).

## Do this

```glsl
shader_type canvas_item;
uniform sampler2D screen_tex : hint_screen_texture, filter_nearest, repeat_disable;
uniform vec2 light_pos = vec2(192.0, 108.0); uniform float light_r = 9999.0; uniform float dark_amt = 0.0;
uniform float vignette = 0.35; uniform float grain = 0.05; uniform float hurt = 0.0; uniform float insane = 0.0;
uniform vec3 tint = vec3(1.0); uniform float t = 0.0; uniform float fade = 0.0; uniform float scan = 0.06;
float bayer(vec2 p) { int x = int(mod(p.x,4.0)); int y = int(mod(p.y,4.0));
    float m[16] = float[16](0.,8.,2.,10.,12.,4.,14.,6.,3.,11.,1.,9.,15.,7.,13.,5.); return m[x + y*4] / 16.0; }
float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898,78.233)) + t) * 43758.5453); }
void fragment() {
    vec2 px = floor(UV * vec2(384.0, 216.0)); vec2 uv = UV;
    if (insane > 0.0) { uv.x += sin(UV.y*40.0 + t*3.0)*0.002*insane*6.0; uv.y += sin(UV.x*30.0 + t*2.0)*0.0015*insane*4.0; }
    vec3 c = texture(screen_tex, uv).rgb;
    if (insane > 0.3) { float o = 0.003*insane; c.r = texture(screen_tex, uv+vec2(o,0)).r; c.b = texture(screen_tex, uv-vec2(o,0)).b; }
    c *= tint;
    if (light_r < 9000.0) {
        float k = clamp((distance(px, light_pos) - light_r*0.55) / (light_r*0.45), 0.0, 1.0); k = k*k;
        float q = floor(k*5.0 + bayer(px)) / 5.0;          // 5 dithered steps
        c *= max(1.0 - q*dark_amt, 1.0 - dark_amt);
    }
    float vd = distance(UV, vec2(0.5)) * 1.45; c *= 1.0 - vignette*vd*vd;
    c += (hash(px) - 0.5) * grain;
    c *= 1.0 - scan * step(0.5, fract(px.y * 0.5));       // every other row 6% darker
    c = mix(c, vec3(0.85,0.05,0.08), hurt*0.45);
    c = mix(c, vec3(dot(c, vec3(0.3,0.59,0.11))), insane*0.35);
    c = mix(c, vec3(0.0), fade);
    COLOR = vec4(c, 1.0);
}
```
- Put it on a full-viewport ColorRect inside a CanvasLayer at layer 10 (HUD CanvasLayer at 20 sits above, unaffected). `mouse_filter = IGNORE`.
- Light uses SCREEN pixel coords (light_pos in 384x216 space) - convert player world pos to screen pos each frame. Disable with `light_r = 99999`.
- Per-game knobs from game.json `fx`: vignette 0.4-0.45, grain 0.05-0.06, tint e.g. [0.95,1.0,1.05] (cold) / [1.04,0.98,1.04] (plum).
- Hurt flash: set 1.0 on hit, decays 2.5/s. Insanity drives UV wobble + chromatic split + desaturation (sanity mechanic). Fade used for scene transitions/endings.
- Light resource ("OIL"): radius 130 -> min 48, dark 0.9 (LAST LAMP).

## Pitfalls (mistakes seen)

the dither and scanlines need `px` from `floor(UV * native_res)`; using SCREEN_UV at window resolution would make dither cells tiny and break the 8-bit look. Keep stretch mode "viewport" so the shader runs at 384x216.

## Verify

screenshot_01/03: concentric dithered bands around the player, hard black beyond, faint row scanlines.

## Origin

Roguelike series. Source notes: kit/kit/postfx.gd (all 119 lines); spec.py fx/mechanics.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
