---
id: build-release-sh
title: "build_release.sh (Linux/macOS/cloud zips)"
category: export-release
when: "Building release zips in a Linux/macOS shell."
related: []
origin: FNAP
---

# build_release.sh (Linux/macOS/cloud zips)

**When to use:** Building release zips in a Linux/macOS shell.

## Do this

Usage `build_release.sh <project_dir> <out_dir> <ProductName> [extras_dir]`, env `GODOT=godot PRESETS="Windows Desktop:win:Windows;Linux:lin:Linux;macOS:mac:Mac"` (preset:key:ZipSuffix).
```bash
"$GODOT" --headless --path "$P" --import --quit
IFS=';' read -ra LIST <<< "$PRESETS"
for item in "${LIST[@]}"; do
  IFS=':' read -r preset key suffix <<< "$item"; D="$STAGE/$key/$N"; mkdir -p "$D"
  case "$key" in
    win*) "$GODOT" --headless --path "$P" --export-release "$preset" "$D/$N.exe"; [ -f "$D/$N.exe" ] || { echo "FAIL $preset: exe not produced"; exit 3; };;
    lin*) "$GODOT" --headless --path "$P" --export-release "$preset" "$D/$N.x86_64"; chmod 755 "$D/$N.x86_64";;
    mac*) "$GODOT" --headless --path "$P" --export-release "$preset" "$STAGE/$N-mac.zip"; (cd "$D" && unzip -q "$STAGE/$N-mac.zip");;
  esac
  [ -n "$X" ] && cp -r "$X"/. "$D"/
  rm -f "$OUT/${N}_${suffix}.zip"; (cd "$STAGE/$key" && zip -qry -9 "$OUT/${N}_${suffix}.zip" "$N")
done
```
`zip -y` stores symlinks as links (mac .app), unix zip preserves 755. Note: cloud-built zips >30 MB cannot be pushed to the user's PC via the bridge -> build on the PC instead.

## Pitfalls (mistakes seen)

Exec bits lost; big zips stuck in cloud (see bridge skills).

## Verify

`ls -la $OUT`; zipinfo modes.

## Origin

FNAP. Source notes: scripts/build_release.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
