---
id: beepbox-song-json-format
title: "Write BeepBox song JSON directly (format 9) from Python"
category: audio-music
when: "Generating music data programmatically that beepbox.co can open and edit."
related: []
origin: Roguelike series
---

# Write BeepBox song JSON directly (format 9) from Python

**When to use:** Generating music data programmatically that beepbox.co can open and edit.

## Do this

- Song: `{"format":"BeepBox","version":9,"scale":"expert","key":"D","introBars":0,"loopBars":n,"beatsPerBar":4,"ticksPerBeat":4,"beatsPerMinute":bpm,"layeredInstruments":false,"patternInstruments":false,"channels":[...]}`. 16 ticks per bar.
- Channel: `{"type":"pitch"|"drum","instruments":[inst],"patterns":[{"notes":[...]}],"sequence":[pattern index per bar, 0 = empty],"octaveScrollBar":2 (pitch only)}`.
- Note: `{"pitches":[p,...],"points":[{"tick":t,"pitchBend":0,"volume":v},{"tick":end,"pitchBend":0,"volume":v}]}`; end clipped to 16; skip zero-length.
- Pattern dedupe: key each bar by `json.dumps(notes)`; identical bars reuse the same pattern index (keeps songs small and the URL short).
- Pad all channels to the same bar count with empty bars.
- Pitches are relative to the song key (key set in JSON), C0 = 0; bass base 24, pad 36, lead 48, arp 60, bell 72.
- Instruments: chip `{"type":"chip","volume":70,"wave":"triangle","effects":["reverb"],"reverb":40,"transition":"normal","fadeInSeconds":0.0125,"fadeOutTicks":12}`; add `"transition type"` to effects when transition != normal; FM bell `{"type":"FM","volume":62,"effects":["reverb"],"reverb":75,...,"fadeOutTicks":24}`; drums `{"type":"noise","wave":"retro"}` kick (vol 80, fadeOut 6) and `"white"` hat (vol 70, fadeOut 2); drum pitch 0..11 selects the noise tone (0 heartbeat, 1 kick, 5 snare-ish, 10 hat).
- Chip waves used: "triangle", "sawtooth", "double saw", "1/8 pulse", "1/4 pulse", "rounded"; unison "dissonant"/"shimmer"/"none"; vibrato "delayed".

## Pitfalls (mistakes seen)

none.

## Verify

render_bb.ts loads JSON without throwing; the produced hash link opens in beepbox.co.

## Origin

Roguelike series. Source notes: _tools/bbcompose.py L19-76, L187-199.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
