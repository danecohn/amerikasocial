---
id: data-values-in-resources-checked
title: "Gameplay tuning numbers in .tres, verified by grep + test"
category: gameplay-systems
when: "Spec gives numeric tuning (speeds, timings); QA of AI data."
related: []
origin: FNAP
---

# Gameplay tuning numbers in .tres, verified by grep + test

**When to use:** Spec gives numeric tuning (speeds, timings); QA of AI data.

## Do this

FNAP character speeds m/s in `resources/ai/*.tres`: Pickle 0.8, Remi 0.72, Dilly 0.76, Banshee walk 0.72 / run 3.3, Golden Pickle 0.64. Door sides: right door Pickle+Dilly, left door Remi+Banshee. Remi retreats if flashlight on him ~0.7 s. Banshee sprints from cove; sprint duration = distance / (run_speed*speed_multiplier), not a fixed 6 s. QA does static PASS by grep, then runtime test.

## Pitfalls (mistakes seen)

M14 (fixed sprint timer, lerp to 0.85).

## Verify

grep values; sim script (door_lurker_sim.gd) passes.

## Origin

FNAP. Source notes: BOARD.md lines 23, 30; QA fnap D2.4-D2.5, D4.4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
