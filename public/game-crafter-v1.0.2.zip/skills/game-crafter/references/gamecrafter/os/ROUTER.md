# ROUTER: user intent → workflow → skills
Match what the user wants to a row, open the workflow, then open the skills it lists. Always open the **mistakes** listed for that workflow; they're the traps that already caught a real project.

| The user says / wants… | Workflow |
|---|---|
| "make a game", new idea, new genre, prototype | `workflows/new-game.md` |
| a FNAF-style / night-survival / 3D horror game | `workflows/3d-horror-night-survival.md` |
| an 8-bit / pixel-art / roguelike / retro game, or a series of games fast | `workflows/pixel-roguelike-factory.md` |
| an RPG, open world, quests, dialogue, factions | `workflows/open-world-rpg.md` |
| continue / remaster / finish an existing project | `workflows/continue-or-remaster.md` |
| "it's broken", "looks different from what you showed", placeholders, no textures, black screen | `workflows/fix-a-bug.md` |
| "ship it", "pack it up", zips, Windows/Mac/Linux/ARM64 builds | `workflows/ship-release.md` |
| "get it on my computer", deliver to a folder | `workflows/deliver-to-pc.md` |
| itch page, screenshots, cover, trailer, reel, socials, YouTube | `workflows/promo-kit.md` |
| big job, many parts, "use subagents", a team of AIs, handoff to Cursor | `workflows/multi-agent-production.md` |
| install Godot/Blender, "export template missing", new machine | `skills/check-env-game-tools.md` → `skills/godot-install-export-templates.md` |

## Category shortcuts (when you know the domain)
Open `skills/SKILLS.md` and jump to the category: Core workflow · Planning & design · Project management · Multi-agent · Environment · Godot engine · GDScript patterns · 3D & Blender · Lighting & horror · Pixel art & 2D · Audio & music · UI/UX · Gameplay systems · Enemies & AI · Narrative · RPG systems · Roguelike & procgen · Testing & QA · Export & release · Delivery · Promo · **Mistakes**.

## Always-on skills (every task)
`master-game-loop`, `ask-or-act`, `evidence-rule`, `verify-the-exported-build`, `living-project-docs`, `standing-instructions`, `deliver-and-confirm`, `honest-ship-report`.
