# Template: BUILD_ALL.bat — join split zips + unpack every platform (Windows)
Use when release zips had to be split into parts (e.g. 24 MB pieces because a file bridge or upload limit rejects big files).
Split on Linux/macOS with: `split -b 24M -d -a 3 Game-Windows-x64.zip Game-Windows-x64.zip.part` → `.part000`, `.part001`, …
Ship this file next to the parts. Replace `GAME` with the zip prefix. Save it with CRLF line endings.

```bat
@echo off
setlocal enabledelayedexpansion
rem GAME - rejoins the split zips and unpacks all platform builds. Run inside the DISTRIBUTION folder.
pushd "%~dp0"
for %%P in (Windows-x64 Windows-ARM64 Linux-x64 macOS) do (
  set "Z=GAME-%%P.zip"
  if exist "!Z!.part000" (
    echo Joining !Z! ...
    copy /b "!Z!.part*" "!Z!" >nul
    if errorlevel 1 ( echo FAILED joining !Z! & goto :end )
    if not exist "GAME-%%P" mkdir "GAME-%%P"
    tar -xf "!Z!" -C "GAME-%%P"
    if errorlevel 1 ( echo FAILED unpacking !Z! & goto :end )
    del "!Z!.part*"
    echo Done %%P
  ) else ( echo Skipping %%P - parts not found )
)
echo Finished. The joined .zip files are the ones to upload to itch.io.
:end
popd
pause
```
Notes
- `pushd "%~dp0"` makes it work when double-clicked from anywhere.
- `copy /b a.part*` concatenates in name order — that's why parts are zero-padded (`-a 3`).
- `tar -xf` ships with Windows 10+; no 7-Zip needed.
- Prefer the checksum version below when you can: it refuses to delete parts if the joined zip is corrupt.

# Template: ASSEMBLE_ZIPS.ps1 (checksum-verified join; from the roguelike series)
```powershell
$ErrorActionPreference="Stop"; Set-Location $PSScriptRoot
function Join($name,$sha){ $parts = Get-ChildItem -Filter "$name.0*" | Sort-Object Name
  if(-not $parts){return}; $o=[IO.File]::Create("$PWD\$name")
  foreach($p in $parts){ $b=[IO.File]::ReadAllBytes($p.FullName); $o.Write($b,0,$b.Length) }; $o.Close()
  $h=(Get-FileHash $name -Algorithm SHA256).Hash.ToLower()
  if($h -ne $sha){ Write-Host "CHECKSUM MISMATCH $name" -ForegroundColor Red } else { Write-Host "OK $name"; $parts | Remove-Item } }
Join "Game_Windows_x64.zip"   "<sha256>"
Join "Game_Windows_ARM64.zip" "<sha256>"
Join "Game_Linux.zip"         "<sha256>"
Join "Game_Mac.zip"           "<sha256>"
```
ASSEMBLE_ZIPS.bat wrapper: `powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ASSEMBLE_ZIPS.ps1" & pause`
