---
id: asset-contact-sheet-review
title: "Contact sheet of all generated sprites/tiles/UI for visual QA"
category: pixel-art-2d
when: "After generating procedural art; before screenshots; to let an LLM 'look' at all art in one image."
related: []
origin: Roguelike series
---

# Contact sheet of all generated sprites/tiles/UI for visual QA

**When to use:** After generating procedural art; before screenshots; to let an LLM "look" at all art in one image.

## Do this

- contact.py: rows = enemies x4, player+npcs+hub props x4, bosses x3, each tileset x4, UI (icons, door_icons, heart) x4; sprites bottom-aligned with pad 3 on bg (40,36,52); stacked on (20,18,28). Nearest-neighbour scaling only.
- up.py: quick x3 nearest upscale to `<name>_x.png` for inspecting tiny images.

## Pitfalls (mistakes seen)

none.

## Verify

open the PNG (Read tool) and check every creature reads at gameplay scale.

## Origin

Roguelike series. Source notes: _tools/contact.py, up.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
