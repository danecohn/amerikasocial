---
id: ascii-sprite-maps
title: "ASCII sprite maps for tiny UI sprites (hearts full/half/empty)"
category: pixel-art-2d
when: "Drawing small fixed glyph-like sprites (hearts, cursors, pips) where exact pixel control matters more than shapes."
related: []
origin: Roguelike series
---

# ASCII sprite maps for tiny UI sprites (hearts full/half/empty)

**When to use:** Drawing small fixed glyph-like sprites (hearts, cursors, pips) where exact pixel control matters more than shapes.

## Do this

```python
rows = ["..XX.XX..", ".XXXXXXX.", "XXXXXXXXX", "XXXXXXXXX", ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X...."]  # 9x8 heart
for kind in ("full", "half", "empty"):
    img = new(9, 8)
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch != "X": continue
            px = c if kind == "full" else (c if (kind == "half" and x < 5) else hexc("#2a2230"))
            img.putpixel((x, y), px)
    if kind != "empty":
        img.putpixel((1, 2), light(c, .5)); img.putpixel((2, 1), light(c, .5))   # 2px specular glint top-left
    # then 4-neighbour outline into an 11x10 canvas with #0b0a10
```
- Empty slot colour `#2a2230` (dark plum) instead of transparent, so empty hearts still read on the HUD.
- Half heart split at column 5 (left half filled).
- A dict of ASCII maps (`ICON_SHAPES = {"sword": [...10 rows...]}`) is the natural extension: one char per pixel, '.' transparent, letters map to palette slots. Recommended for any agent without an image model - it is reviewable in plain text.
- HUD use: hearts = ceil(max_hp/2) slots, each slot picks frame `0 if pips>=2 else 1 if pips==1 else 2`, drawn at x = 5 + i*10, y = 3.

## Pitfalls (mistakes seen)

ICON_SHAPES "sword" defined but never used (dead data) - all other icons are drawn with primitives.

## Verify

heart.png 33x10 (3 frames 11x10), 5 colours.

## Origin

Roguelike series. Source notes: _tools/tiles.py lines 358-395; kit/kit/hud.gd lines 92-97.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
