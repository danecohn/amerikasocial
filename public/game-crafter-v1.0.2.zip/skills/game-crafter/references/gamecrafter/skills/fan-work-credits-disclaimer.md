---
id: fan-work-credits-disclaimer
title: "Credits roll with studio attribution and fan-work disclaimer"
category: promo-marketing
when: "Any fan-inspired game (FNAF-like) or any shipped game's credits."
related: []
origin: Pickle's Pickle Shop
---

# Credits roll with studio attribution and fan-work disclaimer

**When to use:** Any fan-inspired game (FNAF-like) or any shipped game's credits.

## Do this

Credits as a data list of [text, size, font-kind] scrolled in a VBox: title, subtitle, "A <Studio> game", "Created, written and built by <Studio>", roles, starring cast, fonts credit, "A fan work inspired by Five Nights at Freddy's. Not affiliated with Scott Cawthon.", closing line, (c) year studio. credits.txt + Soundtrack/ folder go inside every platform zip. AI assistance should be disclosed on itch.io where required (noted in sibling projects).

## Origin

Pickle's Pickle Shop. Source notes: scripts/ui/credits.gd L1-27; transcript summary sec.3 (credits.txt in zips).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
