# Tool: anim_import.gd

**Purpose:** EditorScenePostImport that sets loop modes / names on imported animation clips.

**Usage:** `set as glb import script`

**Skill:** see `skills/clip-manifest-json.md`

**Extract:** save the block below as `anim_import.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
class_name AnimImport
extends RefCounted
## Game Maker template. glTF has no "loop" flag, and the editor's import script does NOT run for models loaded
## at runtime (GLTFDocument / load of a PackedScene still keeps Animation.loop_mode = NONE for many clips).
## Re-apply a policy after instancing: everything loops except the listed one-shots.
## Better: ship a clips.json beside the model (see clip_manifest.gd) and let it override per clip.
const ONE_SHOTS: Array[String] = ["jumpscare", "death", "attack", "hit", "get_up", "sit_down"]   # EDIT per game

static func apply_loops(scene: Node) -> void:
	if scene == null:
		return
	for ap in scene.find_children("*", "AnimationPlayer", true, false):
		for lib_name in ap.get_animation_library_list():
			var lib: AnimationLibrary = ap.get_animation_library(lib_name)
			for anim_name in lib.get_animation_list():
				var a: Animation = lib.get_animation(anim_name)
				a.loop_mode = Animation.LOOP_NONE if String(anim_name) in ONE_SHOTS else Animation.LOOP_LINEAR
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
