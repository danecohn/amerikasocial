---
id: assistant-auto-mode-unreliable-helper
title: "Unreliable AI auto-pilot ("auto mode") with tunable failure, power drain and comedy lines"
category: gameplay-systems
when: "Adding a helper that plays for the player but must never be a sure save."
related: []
origin: Pickle's Pickle Shop
---

# Unreliable AI auto-pilot ("auto mode") with tunable failure, power drain and comedy lines

**When to use:** Adding a helper that plays for the player but must never be a sure save.

## Do this

`AssistantAuto` (RefCounted) shared by the office and a headless sim so numbers match. Tunables in a Resource `.tres` (per night 1..5): extra_usage bars 1; power_base [0.02,0.04,0.07,0.10,0.14] %/s; power_per_hour [0.006..0.028]; check_seconds [14,12,10,8.5,7]; failure_rate [0.25,0.36,0.47,0.58,0.68] clamped 0.12..0.82; false_close_rate [0.08..0.40] clamped 0.04..0.55; idle_alarm 0.045; alarm_power_hit 4; alarm_aggression 8. `decide()` returns {kind, side, close, touch, line_id, line, face}: no threat -> false close / alarm / "all clear" / idle; threat -> on failure wrong_door 35%, open_bad 25%, alarm 20%, misreport 20%; else hold or correct. Threat = character at its door room or in the last 2 path rooms. Toggle with G; props: door motors spin 0.8 s, door lamps emission 3.0, alarm spinner + red emission for 2.4 s + `alarm_apologies.ogg`. Lines are funny and self-deprecating ("I pressed the loud button. It was next to the helpful button.").

## Pitfalls (mistakes seen)

none recorded beyond tuning; a sim (`scripts/dev/auto_mode_sim.gd`) validated survival rates.

## Verify

Run auto_mode_sim headless for each night; check survival distribution not 0% or 100%.

## Origin

Pickle's Pickle Shop. Source notes: scripts/assistant/assistant_auto.gd, assistant_auto_tune.gd, shop_assistant.gd L774-928.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
