# MANIFEST — <GAME TITLE> v<x.y.z>
Generated: <date> · Studio: <studio>

## Deliverables
| File | Platform | Size | SHA256 | Verified how |
|---|---|---|---|---|
| <Game>-Windows-x64.zip | Windows x64 | | | <exe machine type 0x8664; launched? y/n> |
| <Game>-Windows-ARM64.zip | Windows ARM64 | | | <machine type 0xaa64> |
| <Game>-macOS.zip | macOS universal | | | <unsigned: right-click > Open> |
| <Game>-Linux-x64.zip | Linux | | | <launched in cloud + screenshot> |

Each zip contains: the game, `Soundtrack/`, `credits.txt`, `README.txt`.

## Folder map
```
<GAME>/
├── ADVERTISEMENTS/   itch cover 630x500, 5 screenshots, itch.txt, socials.txt, trailer(s)
├── DISTRIBUTION/     platform zips (+ parts and BUILD_ALL.bat if split)
├── DOCS/             GAME_BIBLE.md, soundtrack.txt, KNOWN_GAPS.md
├── PROJECT/          Godot source (zip or folder)
├── MANIFEST.md       this file
├── STATE.md
└── PLAYER_README.txt
```

## Verified / not verified
- Verified: <list with evidence>
- NOT verified: <e.g. not run on real macOS/Windows ARM64 hardware; builds unsigned>

## Not done / known gaps
- <...>
