---
id: fnaf-night-clock-and-ai-ramp
title: "Night clock (12 AM -> 6 AM) and in-night AI ramp"
category: gameplay-systems
when: "Implementing the night timer, hour display, win condition, or making a night harder as it goes."
related: []
origin: FNAP
---

# Night clock (12 AM -> 6 AM) and in-night AI ramp

**When to use:** Implementing the night timer, hour display, win condition, or making a night harder as it goes.

## Do this

- `NightClock`: 6 hours x 86 s/hour = 516 s (~8.6 min) per story night; roguelite shift 3 h x 70 s. Signals
  `hour_changed(hour)` and `night_survived`. `progress()` 0..1 drives the physical clock hands (`Clock_Hand_Hour/Minute`).
- At hours 2, 3, 4 every active non-hallucination animatronic gets `ai_level + 1` (cap 20). Late hours are harder
  without changing the table.
- `--fnap-hour=<sec>` CLI overrides seconds per hour for testing; dev overlay / `debug_skip_hour` key (debug builds only).
- Win: `GameState.complete_night()` advances `highest_night`, after Night 5 sets `story_complete` and
  `brine_run_unlocked` (unlock bonus mode).
- 2D REBUILD clock art: `clock-12-am.png` .. `clock-6-am.png` (220x64) "in play order".

## Pitfalls (mistakes seen)

none recorded.

## Verify

Run `--fnap-hour=2 --fnap-no-save`; confirm `hour_changed` fires 6 times and AI levels increase at 2,3,4 in the
debug overlay; 6 AM goes to the win screen.

## Origin

FNAP. Source notes: REF §2.3 "Night progression", §2.2, §2.14; STATEMAP line 212.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
