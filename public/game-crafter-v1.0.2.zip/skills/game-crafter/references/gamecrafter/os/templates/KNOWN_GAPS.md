# KNOWN GAPS — <GAME TITLE>
Honest list of what is missing, unverified, faked or placeholder. A gap written here is a promise kept; a gap hidden is a bug shipped.

| # | Gap | Player-visible? | Why | Plan |
|---|---|---|---|---|
| 1 | <e.g. Windows ARM64 build not run on real hardware> | no | no device | ask user to test |
