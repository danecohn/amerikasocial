# QA CHECKLIST (evidence-gated) — copy to docs/QA_CHECKLIST.md
Status: TODO / PASS / FAIL, always with evidence (command output or a PNG path you OPENED). Never claim PASS without it.

## A. Global gates
- [ ] A1 `godot --headless --path . --import --quit` exits 0; no parse errors in log
- [ ] A2 boot reaches the first screen (screenshot from the EXPORTED pack: verify_export.sh)
- [ ] A3 `hide_audit.sh` + `lint_export_safety.py`: every hit justified or fixed (no hiding/zeroing/flat-colour "fixes")
- [ ] A4 export probe from the pack: `PROBE_DONE fails=0`
- [ ] A5 save test: write -> quit -> relaunch -> read (PASS, exit 0)
- [ ] A6 version/credits/renderer note correct in the menu
- [ ] A7 palette / content rules / forbidden-asset rules (docs/CONTENT_RULES.md)
- [ ] A8 nothing uploaded/published

## B. Models/assets that must actually SHOW in the built game (not just exist on disk)
- [ ] each required .glb listed in tools/probe_manifest.json loads from the pack
- [ ] screenshot of each key scene from the pack, opened and looked at

## C. Features (one line each, with screenshot/log evidence)
- [ ] ...

## D. Marker/name contract (Blender <-> code)
- [ ] every node name the code looks up exists in the GLB (wiring report shows no "PLACEHOLDER"/"missing")

## E. Packaging
- [ ] zips for each platform exist at the requested folder, new timestamps, sizes sane
- [ ] Linux binary has exec bit inside the zip; mac zip opens; Windows exe runs (user-confirmed if I cannot run it)
- [ ] release log read
