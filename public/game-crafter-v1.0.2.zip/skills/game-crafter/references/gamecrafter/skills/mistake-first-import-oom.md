---
id: mistake-first-import-oom
title: "First import of a big project OOMs / takes forever"
category: mistake
when: "Importing large asset sets on small cloud boxes."
related: []
origin: FNAP
---

# First import of a big project OOMs / takes forever

**When to use:** Importing large asset sets on small cloud boxes.

## Do this

~630 MB of GLBs on 8 GB RAM -> add swapfile (`ensure_swap.sh`, 12 GB used), ONE import process in background with a done-marker (`IMPORT_DONE`); never two imports at once. New files arriving after import started need ONE re-import after IMPORT_DONE.
```bash
nohup sh -c 'godot --headless --path P --import --quit > import.log 2>&1; echo $? > IMPORT_DONE' &
```

## What happened, root cause, fix, prevention

Symptom: OOM/kill. Fix above.

## Verify

IMPORT_DONE contains 0.

## Origin

FNAP. Source notes: mistakes-log.md M30; BOARD.md lines 33-36.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
