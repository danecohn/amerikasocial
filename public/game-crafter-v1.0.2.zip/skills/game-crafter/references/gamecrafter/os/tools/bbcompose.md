# Tool: bbcompose.py

**Purpose:** Composes BeepBox songs (chiptune) as BeepBox URL hashes from mood parameters.

**Usage:** `python3 bbcompose.py <spec>  → hash for render_bb.ts`

**Skill:** see `skills/beepbox-offline-render-node-typescript.md`

**Extract:** save the block below as `bbcompose.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""BeepBox song composer. Forgotten Woods Studios.
Builds BeepBox-format song JSON (the same format beepbox.co imports/exports), renders it with the
REAL BeepBox synth (offline, via bun + render_bb.ts) and writes the beepbox.co link next to the audio.

  from bbcompose import make_song
  make_song(out_dir, "run1", style="chase", key="D", mode="phrygian", bpm=118, bars=32, seed=7)
"""
import json, os, random, subprocess, sys, wave
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODES = {
    "minor": [0, 2, 3, 5, 7, 8, 10], "phrygian": [0, 1, 3, 5, 7, 8, 10], "harmonic": [0, 2, 3, 5, 7, 8, 11],
    "major": [0, 2, 4, 5, 7, 9, 11], "lydian": [0, 2, 4, 6, 7, 9, 11], "dorian": [0, 2, 3, 5, 7, 9, 10],
    "locrian": [0, 1, 3, 5, 6, 8, 10], "mixo": [0, 2, 4, 5, 7, 9, 10], "pent_minor": [0, 3, 5, 7, 10, 3, 5],
}
KEYS = {"C": 0, "C#": 1, "D": 2, "Eb": 3, "E": 4, "F": 5, "F#": 6, "G": 7, "Ab": 8, "A": 9, "Bb": 10, "B": 11}
TPB = 4          # ticks per beat
BPB = 4          # beats per bar
BAR = TPB * BPB  # 16 ticks per bar


def inst(**kw):
    d = {"type": "chip", "volume": 70, "wave": "triangle", "effects": ["reverb"], "reverb": 40,
         "transition": "normal", "fadeInSeconds": 0.0125, "fadeOutTicks": 12}
    d.update(kw)
    if "transition" in d and d["transition"] != "normal" and "transition type" not in d["effects"]:
        d["effects"] = d["effects"] + ["transition type"]
    return d


class Track:
    def __init__(self, name, instrument, drum=False):
        self.name, self.inst, self.drum, self.bars = name, instrument, drum, []

    def add_bar(self, notes):
        """notes: list of (tick, dur, [pitches], vol%)"""
        self.bars.append(sorted(notes, key=lambda n: n[0]))

    def to_json(self):
        pats, seq, idx = [], [], {}
        for b in self.bars:
            key = json.dumps(b)
            if not b:
                seq.append(0)
                continue
            if key not in idx:
                notes = []
                for (t, d, ps, v) in b:
                    t = int(t)
                    d = max(1, int(d))
                    end = min(BAR, t + d)
                    if end <= t:
                        continue
                    notes.append({"pitches": [int(p) for p in ps],
                                  "points": [{"tick": t, "pitchBend": 0, "volume": int(v)},
                                             {"tick": end, "pitchBend": 0, "volume": int(v)}]})
                pats.append({"notes": notes})
                idx[key] = len(pats)
            seq.append(idx[key])
        ch = {"type": "drum" if self.drum else "pitch", "instruments": [self.inst], "patterns": pats, "sequence": seq}
        if not self.drum:
            ch["octaveScrollBar"] = 2
        return ch


def song_json(tracks, key, bpm, intro=0):
    n = max(len(t.bars) for t in tracks)
    for t in tracks:
        while len(t.bars) < n:
            t.bars.append([])
    return {"format": "BeepBox", "version": 9, "scale": "expert", "key": key, "introBars": intro,
            "loopBars": n - intro, "beatsPerBar": BPB, "ticksPerBeat": TPB, "beatsPerMinute": int(bpm),
            "layeredInstruments": False, "patternInstruments": False,
            "channels": [t.to_json() for t in tracks]}


# ---------------------------------------------------------------- composition helpers
def degree_pitch(mode, deg, base):
    """scale degree (may be negative / >6) -> absolute BeepBox pitch (C0 = 0)."""
    oct_, d = divmod(deg, 7)
    return base + oct_ * 12 + MODES[mode][d]


def triad(mode, deg, base, seventh=False):
    ps = [degree_pitch(mode, deg + o, base) for o in (0, 2, 4)]
    if seventh:
        ps.append(degree_pitch(mode, deg + 6, base))
    return ps


PROGS = {
    "dread": [[0, 0, 5, 4], [0, 1, 0, 6], [0, 5, 3, 4], [0, 0, 1, 0]],
    "chase": [[0, 5, 6, 4], [0, 0, 5, 6], [0, 3, 5, 4], [0, 6, 5, 4]],
    "sorrow": [[0, 5, 3, 4], [0, 3, 5, 4], [5, 3, 0, 4], [0, 2, 5, 4]],
    "hope": [[0, 4, 5, 3], [0, 3, 4, 4], [3, 4, 2, 5], [0, 5, 3, 4]],
    "boss": [[0, 1, 0, 6], [0, 0, 5, 6], [0, 1, 5, 4], [0, 6, 1, 0]],
}

RHYTHMS = [  # lead rhythms for one bar: (start, dur)
    [(0, 4), (4, 4), (8, 8)], [(0, 6), (6, 2), (8, 4), (12, 4)], [(0, 2), (2, 2), (4, 4), (8, 8)],
    [(0, 8), (8, 4), (12, 4)], [(2, 2), (4, 6), (10, 2), (12, 4)], [(0, 3), (3, 3), (6, 2), (8, 8)],
    [(0, 16)], [(0, 4), (6, 2), (8, 4), (14, 2)],
]


def lead_bar(rng, mode, chord_deg, base, density, prev):
    """Return notes for a lead bar, walking by step around chord tones."""
    if rng.random() > density:
        return [], prev
    rh = rng.choice(RHYTHMS)
    notes, cur = [], prev
    tones = [chord_deg, chord_deg + 2, chord_deg + 4, chord_deg + 7]
    for i, (s, d) in enumerate(rh):
        if i == 0 or rng.random() < 0.35:
            target = rng.choice(tones)
            cur = target if abs(target - cur) <= 4 else cur + (1 if target > cur else -1) * rng.choice([1, 2])
        else:
            cur += rng.choice([-2, -1, -1, 1, 1, 2])
        cur = max(-3, min(10, cur))
        notes.append((s, d, [degree_pitch(mode, cur, base)], 100 if i == 0 else rng.choice([70, 85, 100])))
    return notes, cur


def drum_bars(style, rng, n, intensity):
    """returns (low_track_bars, high_track_bars) lists of note lists; pitches 0..11 select the noise tone."""
    low, high = [], []
    for b in range(n):
        lo, hi = [], []
        if intensity[b] >= 2:
            if style in ("chase", "boss"):
                for t in (0, 6, 8) if style == "chase" else (0, 3, 6, 8, 11):
                    lo.append((t, 2, [1], 100))
                for t in (4, 12):
                    hi.append((t, 2, [5], 90))
                if intensity[b] >= 3:
                    for t in range(0, 16, 2):
                        hi.append((t, 1, [10], 45))
            else:
                lo.append((0, 2, [1], 100))
                lo.append((8, 2, [1], 80))
                if intensity[b] >= 3:
                    hi.append((4, 2, [5], 70))
                    hi.append((12, 2, [5], 70))
        elif intensity[b] == 1 and style in ("dread", "sorrow", "hope"):
            if b % 2 == 0:
                lo.append((0, 3, [0], 80))   # heartbeat
                lo.append((3, 3, [0], 55))
        low.append(lo)
        high.append(hi)
    return low, high


STYLE = {
    "dread":  dict(pad=("double saw", 38, "dissonant"), lead=("triangle", 70), prog="dread", lead_density=0.55, arp=False, bell=True),
    "chase":  dict(pad=("sawtooth", 26, "shimmer"), lead=("1/8 pulse", 38), prog="chase", lead_density=0.8, arp=True, bell=False),
    "boss":   dict(pad=("sawtooth", 34, "dissonant"), lead=("sawtooth", 40), prog="boss", lead_density=0.9, arp=True, bell=False),
    "sorrow": dict(pad=("triangle", 55, "none"), lead=("triangle", 80), prog="sorrow", lead_density=0.7, arp=False, bell=True),
    "hope":   dict(pad=("triangle", 52, "shimmer"), lead=("rounded", 80), prog="hope", lead_density=0.85, arp=True, bell=True),
}


def build(style, key, mode, bpm, bars, seed):
    rng = random.Random(seed)
    cfg = STYLE[style]
    base_bass, base_pad, base_lead = 12 + KEYS[key] % 12 * 0, 36, 48  # C1.. keep key via song key; pitches are key-relative
    progs = PROGS[cfg["prog"]]
    prog = rng.choice(progs)
    # section plan: intensity per bar 0..3
    inten = []
    for b in range(bars):
        phase = b / bars
        if b < 4:
            v = 0
        elif phase < 0.35:
            v = 1
        elif phase < 0.7:
            v = 2
        elif phase < 0.9:
            v = 3
        else:
            v = 1
        inten.append(v)
    if style in ("chase", "boss"):
        inten = [max(1, v) if b >= 2 else v for b, v in enumerate(inten)]
    pad = Track("pad", inst(wave=cfg["pad"][0], volume=100 - cfg["pad"][1] - 20, unison=cfg["pad"][2], reverb=65,
                            fadeInSeconds=0.2, fadeOutTicks=24, effects=["reverb", "vibrato"], vibrato="delayed"))
    bass = Track("bass", inst(wave="triangle" if style in ("dread", "sorrow", "hope") else "sawtooth", volume=72, reverb=15,
                              fadeOutTicks=6))
    lead = Track("lead", inst(wave=cfg["lead"][0], volume=100 - cfg["lead"][1] - 10, reverb=60, effects=["reverb", "vibrato"],
                              vibrato="delayed", fadeOutTicks=18))
    arp = Track("arp", inst(wave="1/4 pulse", volume=82, reverb=45, fadeOutTicks=4))
    bell = Track("bell", {"type": "FM", "volume": 62, "effects": ["reverb"], "reverb": 75, "transition": "normal",
                          "fadeInSeconds": 0.0, "fadeOutTicks": 24})
    dlow = Track("kick", {"type": "noise", "volume": 80, "wave": "retro", "effects": [], "transition": "normal",
                          "fadeInSeconds": 0.0, "fadeOutTicks": 6}, drum=True)
    dhigh = Track("hat", {"type": "noise", "volume": 70, "wave": "white", "effects": [], "transition": "normal",
                          "fadeInSeconds": 0.0, "fadeOutTicks": 2}, drum=True)
    prev = 4
    dl, dh = drum_bars(style, rng, bars, inten)
    for b in range(bars):
        deg = prog[b % len(prog)]
        v = inten[b]
        # pad
        pad.add_bar([(0, 16, triad(cfg_mode := mode, deg, base_pad, seventh=(style in ("sorrow", "boss"))), 100)] if v >= 0 else [])
        # bass
        r = degree_pitch(mode, deg, 24)
        if v == 0:
            bass.add_bar([(0, 16, [r], 80)])
        elif style in ("chase", "boss"):
            bass.add_bar([(t, 2, [r if t % 4 == 0 else r + (12 if t == 6 else 0)], 100) for t in range(0, 16, 2)])
        else:
            bass.add_bar([(0, 8, [r], 100), (8, 6, [r if v < 2 else r + 7], 85)])
        # lead
        if v >= 1 and b >= 2:
            notes, prev = lead_bar(rng, mode, deg, base_lead, cfg["lead_density"] * (0.6 + 0.2 * v), prev)
            lead.add_bar(notes)
        else:
            lead.add_bar([])
        # arp
        if cfg["arp"] and v >= 2:
            tones = triad(mode, deg, 60)
            step = 2 if style in ("chase", "boss") else 4
            seq = [tones[0], tones[1], tones[2], tones[1]]
            arp.add_bar([(t, step, [seq[(t // step) % 4]], 75) for t in range(0, 16, step)])
        else:
            arp.add_bar([])
        # bell pings
        if cfg["bell"] and v >= 1 and b % 2 == 1:
            tones = triad(mode, deg, 72)
            bell.add_bar([(rng.choice([0, 4, 8, 10]), 6, [rng.choice(tones)], 70)])
        else:
            bell.add_bar([])
    tracks = [pad, bass, lead, arp, bell]
    if style in ("chase", "boss", "dread", "hope", "sorrow"):
        tracks += [dlow, dhigh]
        dlow.bars, dhigh.bars = dl, dh
    return tracks


def render(js, out_wav):
    jp = out_wav[:-4] + ".bb.json"
    json.dump(js, open(jp, "w"))
    r = subprocess.run(["bun", "run", os.path.join(HERE, "render_bb.ts"), jp, out_wav, "seamless"], capture_output=True, text=True, cwd=HERE)
    if r.returncode != 0:
        raise RuntimeError(r.stderr[-800:])
    return r.stdout.strip()


def normalise(path, target_rms_db=-19.0, peak_db=-1.0):
    w = wave.open(path)
    n, ch, sr = w.getnframes(), w.getnchannels(), w.getframerate()
    d = np.frombuffer(w.readframes(n), dtype=np.int16).reshape(-1, ch).astype(np.float64) / 32768
    w.close()
    rms = np.sqrt((d ** 2).mean()) + 1e-9
    g = 10 ** ((target_rms_db) / 20) / rms
    pk = np.abs(d).max() * g
    lim = 10 ** (peak_db / 20)
    if pk > lim:
        g *= lim / pk
    d = np.clip(d * g, -1, 1)
    out = wave.open(path, "wb")
    out.setnchannels(ch); out.setsampwidth(2); out.setframerate(sr)
    out.writeframes((d * 32767).astype(np.int16).tobytes()); out.close()
    return float(np.abs(d).max()), float(np.sqrt((d ** 2).mean())), n / sr


def make_song(out_dir, name, style, key, mode, bpm, bars, seed):
    os.makedirs(out_dir, exist_ok=True)
    tracks = build(style, key, mode, bpm, bars, seed)
    js = song_json(tracks, key, bpm)
    wav = os.path.join(out_dir, name + ".wav")
    msg = render(js, wav)
    pk, rms, dur = normalise(wav)
    hsh = open(wav + ".hash.txt").read().strip()
    os.remove(wav + ".hash.txt")
    return {"name": name, "style": style, "key": key, "mode": mode, "bpm": bpm, "bars": bars, "seconds": round(dur, 1),
            "peak": round(pk, 3), "rms": round(rms, 3), "beepbox_url": "https://www.beepbox.co/#" + hsh}


if __name__ == "__main__":
    print(make_song("/tmp/bbt", "t_dread", "dread", "D", "phrygian", 72, 24, 1))
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
