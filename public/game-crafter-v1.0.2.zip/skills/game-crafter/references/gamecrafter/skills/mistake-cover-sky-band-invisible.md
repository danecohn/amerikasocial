---
id: mistake-cover-sky-band-invisible
title: "Cover "sky band" composited under an opaque layer, so it never shows"
category: mistake
when: "Using Pillow alpha_composite to darken/tint an image."
related: []
origin: Roguelike series
---

# Cover "sky band" composited under an opaque layer, so it never shows

**When to use:** Using Pillow alpha_composite to darken/tint an image.

## What happened, root cause, fix, prevention

- Symptom: the top 62px of the itch cover is flat dark `(6,8,12)`; the intended "darkened blur of the shot top for mood" is absent.
- Root cause: `band = alpha_composite(band, Image.new("RGBA", band.size, (6,8,12,255)))` - the overlay is fully opaque, so the result is just the solid colour.
- Fix: use a translucent overlay, e.g. `(6,8,12,190)`, or `Image.blend(band, solid, 0.75)`; to keep it pixel-art, darken by a palette mapping instead of blur.
- Prevention: when "darkening" with an overlay, alpha must be < 255; preview intermediate layers.
- Detection: count unique colours in the band region (1 colour = bug).

## Verify

band region has many colours after fix.

## Origin

Roguelike series. Source notes: _tools/cover.py lines 13-16; itch_cover_630x500.png (flat top band).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
