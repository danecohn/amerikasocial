# Workflow: 3D open-world RPG
Built from Caesarea (a Fallout-style RPG made by a Blender pass, a Godot pass and an IDE handoff).

1. **Design for AI writers**: `design-bible-for-ai-writers`, `canon-reconciliation-doc`, `content-rule-depict-never-endorse`, `content-rules-file`.
2. **Data-driven story**: `data-driven-story-conversion-pipeline`, `text-only-dialogue-system`, `consequence-ledger-typed-flag-store`, `ledger-condition-effect-language`, `qa-suite-content-cross-reference`.
3. **RPG systems**: `faction-standing-tracks-tiers-caps`, `companion-approval-betrayal-system`, `suspicion-stealth-system`, `time-of-day-curfew-system`, `ending-resolver-gates-guarantee`, `special-skills-perks-traits-levels`, `combat-difficulty-and-item-schema-json`, `economy-dual-currency-rationing`, `save-system-slots-hinges-persist-migration`, `diegetic-radio-manager-bus-chain`, `papers-check-deterministic-minigame`, `hacking-grid-minigame-design`.
4. **World**: `zone-streaming-and-district-template`, `road-graph-astar-travelers`, `procedural-architecture-kit-trim-sheets`, `procedural-material-library-no-missing-files`, `vertex-animated-multimesh-crowd-shader`, `open-world-combat-ai-state-machine`, `interactable-contract-and-interactor-scoring`.
5. **Art pipeline**: `kitslot-placeholder-until-glb-exists`, `parallel-blender-godot-passes-ownership`, `glb-contract-sheet-for-blender-bots`, `measure-glb-aabb-without-blender`, `shared-rig-retarget-and-clip-fallback`, `humanoid-facing-plus-z-convention`.
6. **Team**: `multi-agent-production.md`, `handoff-prompt-for-another-ai`, `windows-arm64-godot-launcher-quirks`.
7. **QA**: `validate-in-scratch-copy`, `run-all-tests-suite-runner`, `static-checks-no-godot`, `headless-screenshot-harness-xvfb`, `known-gaps-honesty-doc`.

Mistakes to read first: the type-inference errors, new scripts not recognised until `--import`, a real model arriving without collision, models over their agreed size, embedded texture bloat, status docs contradicting the builds, and the interrupted 13-agent launch. All are under Mistakes.
