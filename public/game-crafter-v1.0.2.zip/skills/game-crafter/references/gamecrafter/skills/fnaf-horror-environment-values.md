---
id: fnaf-horror-environment-values
title: "Real darkness values for a 3D horror office (environment, flashlight, feed exposure)"
category: 3d-lighting-horror
when: "Setting WorldEnvironment/light values so dark halls are actually dark but cameras stay readable."
related: [fnaf-camera-feed-layer-isolation, mistake-halls-too-bright]
origin: FNAP
---

# Real darkness values for a 3D horror office (environment, flashlight, feed exposure)

**When to use:** Setting WorldEnvironment/light values so dark halls are actually dark but cameras stay readable.

## Do this

- Code-built WorldEnvironment: ambient 0.008 ("so the dark is real"), filmic tonemap, glow 0.25, fog 0.006, exposure 1.0.
- Flashlight SpotLight3D: shadows on, range 16, angle 24, attenuation 2.2.
- Camera feed has its OWN environment: ambient 1.05, exposure 1.65, desaturate 0.55, plus a `DirectionalLight3D`
  "FeedExposure" energy 4.5 limited to the feed layer (fnaf-camera-feed-layer-isolation).
- Eyes are plain lit surfaces (no emissive cheat) so dark halls stay dark; a 0.5 emission shows only on camera feeds.
- Jumpscare adds a local OmniLight "face light".
- Clear color black; `msaa_3d=1`.

## Pitfalls (mistakes seen)

mistake-halls-too-bright (ambient 0.11 -> 0.008).

## Verify

hall_check screenshots: dark state is black, flashlight state shows the actor.

## Origin

FNAP. Source notes: REF §2.2, §2.4, §2.5 EyeRig, §2.6, §1.6, §8.2 #7.

## Related skills

- [fnaf-camera-feed-layer-isolation](fnaf-camera-feed-layer-isolation.md)
- [mistake-halls-too-bright](mistake-halls-too-bright.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
