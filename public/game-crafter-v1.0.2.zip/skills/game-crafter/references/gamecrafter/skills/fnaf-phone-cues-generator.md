---
id: fnaf-phone-cues-generator
title: "Generate subtitle cue times from speech onsets in the call WAV"
category: audio-music
when: "You have recorded call audio and text scripts and need `seconds|text` cues that match."
related: []
origin: FNAP
---

# Generate subtitle cue times from speech onsets in the call WAV

**When to use:** You have recorded call audio and text scripts and need `seconds|text` cues that match.

## Do this

- `tools/make_phone_cues.py` (numpy + wave) detects speech onsets in the wav and assigns subtitle cards to them, writing
  `night-N.cues`. "PARAM (paths, splitter must match game)": the Python card splitter must produce the SAME cards as the
  game's fallback splitter, or cues drift.
- Sketch (rebuild, not quoted):
  ```python
  import wave, numpy as np
  def onsets(path, frame_ms=20, thresh_db=-38, min_gap_s=0.35):
      w = wave.open(path); sr = w.getframerate(); ch = w.getnchannels()
      x = np.frombuffer(w.readframes(w.getnframes()), np.int16).reshape(-1, ch).mean(1) / 32768
      n = int(sr * frame_ms / 1000); fr = x[: len(x) // n * n].reshape(-1, n)
      db = 20 * np.log10(np.sqrt((fr ** 2).mean(1)) + 1e-9)
      voiced = db > thresh_db; out = []; last_off = -1e9
      for i, v in enumerate(voiced):
          t = i * frame_ms / 1000
          if v and (not out or t - last_off >= min_gap_s) and (i == 0 or not voiced[i - 1]): out.append(t)
          if v: last_off = t
      return out
  ```

## Pitfalls (mistakes seen)

splitter mismatch between tool and game -> wrong cards on screen.

## Verify

Play the call in `phone_check`; subtitle changes coincide with speech starts.

## Origin

FNAP. Source notes: REF §2.12, §5.2, §8 table.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
