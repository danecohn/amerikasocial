---
id: mistake-ogv-listing-import-suffix
title: "Splash intro video never found in build"
category: mistake
when: "Finding files by extension at runtime."
related: []
origin: FNAP
---

# Splash intro video never found in build

**When to use:** Finding files by extension at runtime.

## Do this

Apply `packed_name()` to every listed filename BEFORE matching extensions.

## What happened, root cause, fix, prevention

Symptom: splash video missing in build (still open at end; found by lint). Cause: `get_files()` + `.ends_with(".ogv")` fails on `intro.ogv.import`. Fix: packed_name first. Detection: lint_export_safety.

## Verify

Probe loads intro.ogv from pack.

## Origin

FNAP. Source notes: mistakes-log.md M29.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
