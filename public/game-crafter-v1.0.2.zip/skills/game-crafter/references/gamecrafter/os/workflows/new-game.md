# Workflow: new game
**Goal:** a playable, exported vertical slice in the first session, then grow it into a shippable game.

1. **Env**: `check-env-game-tools` (Godot == export templates version; Blender if 3D; Python+Pillow+numpy if pixel; ffmpeg). Missing tools: `godot-install-export-templates`, `install-godot-blender-linux-mac` / `install-godot-blender-windows`, `cloud-swapfile-for-oom`.
2. **Design on one page**: `os/templates/GAME_BIBLE.md` (pillars, loop, scope IN/OUT). Skills: `game-bible-template`, `order-of-work`, `code-built-data-driven-architecture`. Write the user's standing instructions into STATE.md (`standing-instructions`).
3. **Skeleton**: `new-godot-game-recipe` / `new-game-bootstrap`: project.godot, export presets for 4 platforms (`export-presets-four-platforms`), include_filter (`godot-include-filter-raw-data`), autoload state + crash-safe saves (`godot-crash-safe-forward-only-save`), boot → splash → title flow (`studio-boot-splash-flow`, `boot-scene-switcher-with-fade`), settings and pause (`settings-and-pause-menu`).
4. **Vertical slice** (`vertical-slice-first`): one level or night or run, one enemy, win and lose, with real art for one asset of each type, loaded export-safely (`godot-export-safe-asset-loading`, `loud-placeholders`).
5. **Prove it**: `lint-export-safety`, export probe (`export-probe-template`), Xvfb screenshot (`headless-screenshot-harness-xvfb`), and open the image (`evidence-rule`). Add headless tests (`headless-self-test-scene-pattern`) and CLI dev flags (`godot-cli-dev-flags-deterministic-rng`).
6. **Widen** by genre: see the genre workflows.
7. **Docs** every step (`living-project-docs`). **Ship** with `ship-release.md`.

Mistakes to read first: `mistake-exported-build-shows-placeholders`, `mistake-raw-files-not-exported`, `mistake-overwide-multiagent`, `mistake-fix-by-hiding`, `mistake-save-wiped-nonatomic`, `mistake-typed-array-assign`.
