# Template: socials copy (save as ADVERTISEMENTS/socials.txt)
Write one block per platform. Hooks first, no walls of hashtags.
```
X/TWITTER (<= 280 chars): <hook> <link placeholder> #indiegame #horror #pixelart
BLUESKY: <hook, 2 lines>
INSTAGRAM/TIKTOK REEL CAPTION: <hook line>\n<2 lines of tease>\n<CTA: link in bio>\n#indiehorror #pixelart #gamedev #<theme> (max 5)
YOUTUBE TITLE (<= 70 chars): <Game> — <hook> | <genre> 
YOUTUBE DESCRIPTION: <3 lines + link + credits + chapters>
REDDIT (r/IndieGaming, r/horrorgaming — follow each sub's self-promo rules): title + 3 sentence post, no hard sell
DEVLOG POST: what's new, 1 gif/screenshot, what's next
```
Never post anything yourself unless the user asked you to post.
