---
id: deliver-and-confirm
title: "Deliver to the exact folder, then confirm it landed"
category: delivery-pc-bridge
when: "Any time files go to the user's computer, a shared folder or a distribution directory."
related: [split-zip-parts-and-build-all-bat, per-game-delivery-folder-layout, mistake-staged-path-400, mistake-delivered-old-files]
origin: FNAP, Pickle's Pickle Shop, Roguelike series
---

# Deliver and confirm

> **Rule:** A delivery isn't done until you've listed the destination folder and seen the new sizes and timestamps.

## Do this
1. Use the exact path the user named. If they call a folder authoritative ("THE FOLDER"), every delivery goes there.
2. Check the transfer channel's limits before building the payload. Known bridge limits from these projects: about 24–30 MB per file and about 100 MB per call. Anything bigger gets split into zero-padded parts (`split -b 24M -d -a 3`) and shipped with a join script (`BUILD_ALL.bat` / `ASSEMBLE_ZIPS.ps1` with SHA256).
3. A bridge may only accept files from one staging directory (e.g. `/mnt/user-data/outputs/`). Before each commit, confirm the staged file still exists there (`ls`). A missing staged file returns 404, and an oversized one returns 400.
4. Send several commit calls in parallel. Track which parts landed, and finish the whole set before you report.
5. After writing, list the destination: names, sizes and modified times. Sizes must match the source.
6. Never leave a folder mixed (old parts and new parts). If you're interrupted, tell the user exactly which parts are new.
7. Deliver source fixes to the project of record too, not only the build.
8. If the user's computer is unreachable, say so in one line, keep everything staged, and deliver as soon as it reconnects.

## Pitfalls
- **"I need the godot folder on my computer"**: the build reached the PC but the edited source files didn't → always commit the changed source files alongside the build.
- **404 on commit**: the staged folder had been cleaned up → re-stage it, then retry.
- **Old files delivered**: the zip was built before the last fix → rebuild after the final change and compare timestamps.

## Verify
- A listing of the destination with the expected file count, sizes and fresh timestamps.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
