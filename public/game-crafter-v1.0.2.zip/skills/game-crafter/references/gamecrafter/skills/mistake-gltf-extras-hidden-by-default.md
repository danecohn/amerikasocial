---
id: mistake-gltf-extras-hidden-by-default
title: "Mistake - honoring glTF extras `hidden_by_default` hid a mesh that must be visible"
category: mistake
when: "Code reads Blender custom properties (glTF extras) to set visibility."
related: []
origin: FNAP
---

# Mistake - honoring glTF extras `hidden_by_default` hid a mesh that must be visible

**When to use:** Code reads Blender custom properties (glTF extras) to set visibility.

## What happened, root cause, fix, prevention

- Symptom: curtain morph mesh permanently invisible.
- Root cause: custom `_apply_authored_visibility` honoured `hidden_by_default: true` on a mesh that must be shown.
- Fix: skip that rule for nodes that must be visible (allow-list), or fix the extra in Blender.
- Prevention: honour extras deliberately, log every node hidden by extras.
- Detection: hide audit + print list of extras-hidden nodes.

## Verify

node visible in screenshot.

## Origin

FNAP. Source notes: L §2.6 line 109; G line 31.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
