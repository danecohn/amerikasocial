---
id: ledger-condition-effect-language
title: "Writer-notation conditions/effects evaluated with Godot Expression (LedgerExpr)"
category: rpg-systems
when: "Data-driven dialogue/quests/endings need conditions and side effects authored by writers."
related: []
origin: Caesarea
---

# Writer-notation conditions/effects evaluated with Godot Expression (LedgerExpr)

**When to use:** Data-driven dialogue/quests/endings need conditions and side effects authored by writers.

## Do this

- Conditions written like the script: `mara_saved`, `suspicion_level >= 50 AND NOT selene_recruited`, `forum_stand == "defended" OR forum_stand == "rescued"`, `skill("speech") >= 35 AND tier("subura_standing") >= 3`, `one_of(marcellus_status, "dead", "deposed")`. Normalize `AND/OR/NOT`, `≥ ≤ ≠`, unicode minus → Expression syntax. Unknown identifier → **false** + warn once (typo never crashes a scene); validator reports it at authoring time.
- Helpers: `skill(id)`, `special(id)`, `tier(track)`, `has_item(id)`, `quest(id)`, `objective(quest, obj)`, `in_party(id)`, `approval(id)`, `hour()`, `curfew()`, `one_of(value, ...)`.
- Effects one statement each (braces optional): `mara_saved = true`, `suspicion_level += 10`, `suspicion_level = max(suspicion_level - 30, 0)`, verbs `quest_start quest_1_2`, `objective_complete quest_1_1 pass_checkpoint`, `faction_event shelter_exile`, `suspicion 15`, `recruit selene`, `approval rufus -5`, `react report_dissident`, `radio_cue VOX_P8_01`.
- Track keys always routed through FactionManager (caps + tier signals). Unknown verbs re-emitted as `DialogueManager.command_requested(verb, args)` for scene scripts (camera, spawn, play_anim) — stubs may be silent no-ops.
- Cache parsed `Expression`s; clear caches on shutdown (see autoload skill).

## Pitfalls (mistakes seen)

see static-cache crash at quit.

## Verify

unit tests for each operator, unknown ident, each verb.

## Origin

Caesarea. Source notes: design/07 §1; attachment.txt stub list.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
