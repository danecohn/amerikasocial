---
id: <kebab-case-id, same as the file name without .md>
title: <Short human title>
category: <category id from skills/SKILLS.md>
when: <one sentence: the situation that should make an agent open this skill>
related: [<other-skill-id>, <other-skill-id>]
origin: <FNAP | Pickle's Pickle Shop | Caesarea | Roguelike series | GameCrafter>
---

# <Title>

> **Rule:** <the one-line rule an agent must remember even if it reads nothing else>

## When to use
<Triggers: what the user says, what you see in the code, which phase of the project.>

## Do this
1. <Concrete step with exact commands, settings, numbers.>
2. <...>

## Code
```gdscript
# Minimal, copy-ready snippet. Comment the non-obvious lines.
```

## Pitfalls
- **<Symptom the user would see>** → cause: <root cause> → fix: <exact fix>.

## Verify
- <How to prove it worked in the EXPORTED game: command + what output/image you must see.>

## Origin
<One or two lines: which game this came from and what happened.>
