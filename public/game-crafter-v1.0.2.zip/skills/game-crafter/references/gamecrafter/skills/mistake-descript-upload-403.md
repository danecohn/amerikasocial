---
id: mistake-descript-upload-403
title: "Descript upload PUT failed: CONNECT tunnel 403"
category: mistake
when: "Uploading media to Descript from a sandbox."
related: []
origin: FNAP
---

# Descript upload PUT failed: CONNECT tunnel 403

**When to use:** Uploading media to Descript from a sandbox.

## Do this

Sandbox egress proxy allow-list. Don't bypass; `report_upload_status(failed)` for each media id; ask the user to drag files in; delete ghost entries.

## What happened, root cause, fix, prevention

Symptom: 403. Fix above.

## Verify

Project media list.

## Origin

FNAP. Source notes: mistakes-log.md M80.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
