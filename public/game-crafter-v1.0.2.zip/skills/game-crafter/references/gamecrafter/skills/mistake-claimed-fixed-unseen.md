---
id: mistake-claimed-fixed-unseen
title: "Claimed fixed without seeing it"
category: mistake
when: "Any fix report."
related: []
origin: FNAP
---

# Claimed fixed without seeing it

**When to use:** Any fix report.

## Do this

Evidence or it did not happen: open the image/log.

## What happened, root cause, fix, prevention

Symptom: user found it still broken; trust lost. Fix: evidence rule.

## Verify

Evidence path in reply.

## Origin

FNAP. Source notes: mistakes-log.md M90.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
