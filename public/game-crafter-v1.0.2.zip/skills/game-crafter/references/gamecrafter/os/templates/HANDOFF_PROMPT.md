# Template: handoff prompt for another AI (Cursor, Copilot, another chat, a teammate agent)
Write this into `docs/handoff/<TOOL>_PROMPT.md` in the project and keep it current. The receiving AI has no memory of you.

```
You are continuing <GAME> for <STUDIO>. <One paragraph: genre, engine version, language, what exists and works.>
The only credit line anywhere is "<CREDIT LINE>".

## Ownership (do not cross these lines)
- You own: <scenes/scripts/tests/manifests…>
- Another pass owns: <meshes, rigs, animation clips / audio / …>. Do not author, overwrite, delete or "fix" their files.
  If one of their files appears or changes while you work, leave it.
- Placeholders: <e.g. KitSlot instances a GLB when ResourceLoader.exists(path) and builds a visible placeholder only when it is missing — dropping a GLB in needs no scene edit.>

## Paths
- Project of record: <path>   - Working copy: <path>
- Engine exe: <path>  (launcher quirks: <e.g. godot.bat already passes --path; do not pass it again or Godot errors "Invalid project path specified">)

## Rules
1. Read STATE.md, MANIFEST.md, KNOWN_GAPS.md, LOG.md first.
2. Verify in the exported build, not just the editor. Screenshot and look.
3. No fix by hiding, deleting or silencing.
4. Update STATE.md / LOG.md / MANIFEST.md in the same change.
5. Don't upload or publish anything.

## Your task now
<numbered, testable tasks with acceptance criteria>

## Done means
<exact checks: commands to run, what output/screenshot must show>
```
