---
id: mistake-placeholder-collision-only-in-placeholder
title: "Real asset arrived without collision → player fell through the street"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Real asset arrived without collision → player fell through the street

**When to use:** 

## What happened, root cause, fix, prevention

Symptom: `player stands on the street` FAIL after the paving GLB landed. Root cause: the placeholder path created the floor StaticBody; the real-GLB path did not, and the district had no other floor collider. Fix: KitSlot adds a layer-1 StaticBody3D + box CollisionShape3D matching `measured_aabb()` whenever the instanced GLB lacks a StaticBody (no duplicate if it has one; nested kit slots excluded from measurement). Prevention: test both placeholder and real paths; ask the art pass for `-colonly` hulls on architecture; spawn test = `player.is_on_floor()` after 40 physics frames at spawn (0, 0.15, 6).

## Origin

Caesarea. Source notes: godot_import_report.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
