---
id: mistake-capture-oom
title: "OOM killed the capture"
category: mistake
when: "Rendering big scenes on 8 GB RAM."
related: []
origin: FNAP
---

# OOM killed the capture

**When to use:** Rendering big scenes on 8 GB RAM.

## Do this

12 GB swapfile; cap clip length; 1280x720 for clips.

## What happened, root cause, fix, prevention

Symptom: process killed. Cause: 8 GB RAM, 55 MB office + rooms. Fix above.

## Verify

Capture completes.

## Origin

FNAP. Source notes: mistakes-log.md M52.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
