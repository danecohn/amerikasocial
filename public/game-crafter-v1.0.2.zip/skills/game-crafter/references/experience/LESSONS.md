# Lessons from The Rooms We Kept

These lessons were distilled from building and independently checking a seven-chapter 2D narrative game. They extend the supplied GameCrafter pack; they do not bundle the user's private source conversation or project. The original game's theory was credited to Spook Nukem and its development to Forgotten Woods Studios and Amerika LLC. Those are historical credits, not defaults for unrelated work.

## What was actually delivered and checked

The prior game contained 30 interactable cues, 27 optional field notes, original pixel backgrounds and directional character sheets, custom embedded Lora/Vera typography, an original three-part score and rain ambience, joint studio credits and a supplied SVG logo. The independent check reached every cue and the ending, exercised 27 additional resource/gate checks, restored an isolated save in a second process, and opened 12 exported screens. This describes that project's evidence, not proof that future projects pass.

## Design

- Source retrieval is not source completeness: the chat reader initially returned two user messages and unreadable assistant references. The user-supplied full exchange resolved it. Never claim to have adapted unseen text.
- Two linked pathways made the theory playable: sensory prediction and evidence evaluation, alongside affect/bodily awareness and integration. Attention changed cue accessibility; external support changed processing demands; a connection puzzle needed both routes.
- Emotional force came from a child who waited, a mended carpet, an empty chair and lost time. The ending offered care going forward rather than undoing harm. Fiction can be heartbreaking without graphic reenactment or a cure claim.
- Keep evidence status inside optional notes: research finding/context, hypothesis, personal account, metaphor. Audit unverified inherited citations instead of laundering enthusiastic earlier assistant claims into scientific certainty.
- Layer switches, grounding-like visual effects and load meters are simplified game mechanics. Avoid claiming they are treatment, preserved brain anatomy or objective demonstrations of special abilities.

## Production

- Complete project means editable scripts/scenes/data, original assets and generation source, fonts/licenses, export settings and documentation. A compiled build alone does not meet that requirement.
- Keep original art generation deterministic. A base generator can overwrite later polish; document the full order and preserve embedded fonts when regenerating elsewhere.
- Custom fonts must ship as files with licenses, not depend on the developer's system fonts. Literary headings and legible prose can suit pixel-art games better than making all text a tiny terminal face.
- Treat a supplied company logo as an asset with provenance. Keep the SVG unchanged, set import resolution for the largest display size, and check its actual bounds after export.
- Distinguish theory credits from developers. A later user correction to studio ownership must propagate to every visible credit and package document.

## Verification

See [technical notes](TECHNICAL.md). Build evidence around failure cases, actual controls and the exported artifact. Teleporting to cues can validate controller logic while missing walking collisions; use both where justified. Isolate tests and production saves. A final cosmetic fix still changes the pack hash.

Do not overstate automation: no extended human playtest, measured completion time, listening audition, accessibility study or clinical validation was demonstrated by these automated checks. Future games require their own evidence.
