---
id: fnaf-sound-event-checklist
title: "Sound event checklist for a FNAF-like (54 events)"
category: audio-music
when: "Planning or auditing the SFX list of a night-survival game."
related: [mistake-phone-audio-drift-from-script]
origin: FNAP
---

# Sound event checklist for a FNAF-like (54 events)

**When to use:** Planning or auditing the SFX list of a night-survival game.

## Do this

Grouped from the 2D package `07-audio/` (all lower-kebab `.wav`, indexed in `AUDIO-INDEX.csv` with file, length, loop,
use, replaces_original):
- Ambience loops: `office-ambience-loop` (desk fan + fridge compressor + bubbles), `shop-ambience-loop` (empty building
  drone, draft, pipes), `light-buzz-loop` (ballast while a door light is held), `camera-static-loop`,
  `phone-call-static-bed` (30 s), `game-over-static-loop` (5 s), `kitchen-pots-clatter-loop`,
  `power-out-music-box-loop` (24 s).
- Office actions: `door-slam`, `door-open`, `light-switch-click`, `button-denied-buzz`, `camera-flip-up`,
  `camera-flip-down`, `camera-switch-blip`, `camera-static-burst`, `pickle-poster-squeak`.
- Enemy presence: `footsteps-<char>-soft/heavy` (distance-based pairs), `pickle-huff-laugh` (on move),
  `animatronic-garble-1..3` (random at doors/cams), `animatronic-breathing` (someone slipped into the office),
  `brine-cove-hum`, `banshee-run`, `banshee-door-bang`, `golden-pickle-whisper-drone`, `robot-voice-sting` (rare late
  night sting), `door-light-scare-sting` (first light reveal).
- Scares: `jumpscare-<char>` x5.
- Phone: `phone-ring` (3 rings), `phone-pickup-click`, `phone-hangup-click`, `phone-night-1..5`.
- Night flow: `night-start-sting` (reverse swell + low boom + dissonant bell), `power-down`, `power-out-music-box`,
  `6am-chime` (four-note tune then six strikes), `6am-cheer`, `6am-chime-cheer` (pre-mixed).
- Rules from REF: lowercase kebab ids, extension-agnostic lookup; music numbered `NN-name.ogg`; studio theme has a
  seamless loop version ("loop the WAV, not an MP3"). Authoring in BeepBox, share links kept in a README next to assets.
- QA (2D package): every wav in the index, every index row has a wav, every wav has a sound event in the build note.

## Pitfalls (mistakes seen)

mistake-phone-audio-drift-from-script.

## Verify

Index/file/event cross-check script (see fnaf-asset-package-qa).

## Origin

FNAP. Source notes: STATEMAP lines 216-271, 444-446; REF §1.2, §3.5.

---------------------------------------------------------------------------------------------------

## Related skills

- [mistake-phone-audio-drift-from-script](mistake-phone-audio-drift-from-script.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
