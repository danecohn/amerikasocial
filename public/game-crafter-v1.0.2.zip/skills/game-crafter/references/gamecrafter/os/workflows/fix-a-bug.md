# Workflow: fix a bug the user saw
1. **Don't argue, don't theorize** (`handle-looks-bad-feedback`). Quote the symptom into STATE.md.
2. **Search the Mistakes section of SKILLS.md for the symptom.** Most visible bugs already have a skill: placeholders or no textures in the build, invisible jumpscare, pitch-black cameras, too-bright halls, black screen after New Game, save wiped, music stuck ducked, text overflow, T-pose art, typed-array errors.
3. **Reproduce on the exported build** (`verify-the-exported-build`), and screenshot the bug.
4. Find the root cause. Check every system that touches the thing per frame (darkness logic, visibility, layers, HUD), not just the obvious one.
5. Fix without hiding (`never-fix-by-hiding-hide-audit`), without breaking standing instructions (`standing-instructions`).
6. Screenshot after. Check the neighbours (other characters, other rooms, other jumpscares).
7. Write a new `mistake-*` skill if none existed (`os/checklists/new-mistake.md`).
8. Report with before/after evidence (`os/checklists/honest-report.md`).
