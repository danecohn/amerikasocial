---
id: fp-arms-viewmodel-tablet-stow
title: "First-person arms viewmodel: keep lens clear and stow the tablet prop via SkeletonModifier3D"
category: 3d-blender
when: "Animated FP arms glb with a prop bone (tablet) whose rest pose sits in front of the camera."
related: []
origin: Pickle's Pickle Shop
---

# First-person arms viewmodel: keep lens clear and stow the tablet prop via SkeletonModifier3D

**When to use:** Animated FP arms glb with a prop bone (tablet) whose rest pose sits in front of the camera.

## Do this

Constant "stow" tracks get dropped on import, so the rest pose leaves the black tablet glass in front of the lens. A `SkeletonModifier3D` child ("TabletPose") sets bone `prop_tablet` to STOW_POS (0,-0.12,-1.13) scale 0.001 unless the current clip is fp_tablet_idle (HOLD_POS (0,-0.12,-0.48) scale 1) or fp_monitor_up/down (clip drives it). Viewmodel node at z = -0.22 (CLEAR_Z) so shoulders don't clip the lens; force all GeometryInstance3D visible each frame. Camera shake from a `CameraShake` bone: on `skeleton_updated`, camera transform = rest^-1 * pose (in rig space) plus pitch offset for typing. Arms clip state machine by priority: typing -> fp_type; monitor -> fp_tablet_idle; moving -> fp_walk_to_door; holding door -> fp_door_hold; holding breath; stamina < 55 -> fp_pant; else fp_idle; one-shots block until their length elapses.

## Pitfalls (mistakes seen)

Black plate covering the view (tablet rest pose) and shoulders on the lens - both fixed by the above.

## Verify

Screenshot at desk: no black plate; monitor up shows tablet.

## Origin

Pickle's Pickle Shop. Source notes: scripts/player/fp_arms.gd, fp_arms_tablet.gd; office_controller.gd L443-485, L554-608.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
