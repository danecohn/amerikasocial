---
id: blender-lights-vs-godot-and-size
title: "Light units and GLB size management"
category: 3d-lighting-horror
when: "Importing lit scenes; release size too big."
related: []
origin: FNAP
---

# Light units and GLB size management

**When to use:** Importing lit scenes; release size too big.

## Do this

Blender Watts != Godot energy: retune in Godot (fog/ambient interplay). Embedded textures dominate size (rooms 17-23 MB, office 55 MB each); share textures or downsample before shipping. Do not use AI image generation or voxel tricks if the brief forbids them; FNAP title image was a Blender render of the real mesh.

## Pitfalls (mistakes seen)

Lights blown out/too dark after import -> retune.

## Verify

Pack screenshot looks right; zip size.

## Origin

FNAP. Source notes: blender-assets/SKILL.md bullets.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
