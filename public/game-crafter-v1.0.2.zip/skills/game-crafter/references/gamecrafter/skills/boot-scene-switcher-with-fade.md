---
id: boot-scene-switcher-with-fade
title: "Code-only scene switcher with fade overlay (boot.gd)"
category: gdscript-patterns
when: "Building the top-level flow (splash -> title -> hub -> run -> ending) of a Godot game without .tscn per scene."
related: [mistake-black-screen-after-new-game-paused-fade-tween]
origin: Roguelike series
---

# Code-only scene switcher with fade overlay (boot.gd)

**When to use:** Building the top-level flow (splash -> title -> hub -> run -> ending) of a Godot game without .tscn per scene.

## Do this

- main.tscn = one `Node` with boot.gd. boot registers itself (`Game.boot = self`), adds a CanvasLayer layer=100 with a full-screen black ColorRect (`mouse_filter=IGNORE`), then `change_scene(start)` where start = `--scene=` CLI or "splash".
- change_scene: guard `_busy`; fade alpha to 1 in 0.25s; reset `Engine.time_scale = Game.base_scale` and `get_tree().paused = false` (clean state after hitstop/pause); `queue_free` old scene and `await get_tree().process_frame`; `match name` -> `X.new()`; pass `arg` via `if arg != null and "arg" in _cur: _cur.set("arg", arg)`; add_child; fade to 0 in 0.35s.
- CRUCIAL: both fade tweens are `create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)` so they finish even when a dialogue/menu has paused the tree.
- Global `Game.goto(name, arg)` calls `boot.change_scene`.
```gdscript
var t := create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)
t.tween_property(_fade, "color:a", 1.0, 0.25)
await t.finished
Engine.time_scale = Game.base_scale
get_tree().paused = false
```

## Pitfalls (mistakes seen)

see mistake-black-screen-after-new-game-paused-fade-tween.

## Verify

New Game from title on a fresh save shows the hub + intro dialogue (not black). Screenshot `--fresh=1 --scene=title --press=1.2 --shot=...`.

## Origin

Roguelike series. Source notes: kit/kit/boot.gd 10-28, 90-117.

## Related skills

- [mistake-black-screen-after-new-game-paused-fade-tween](mistake-black-screen-after-new-game-paused-fade-tween.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
