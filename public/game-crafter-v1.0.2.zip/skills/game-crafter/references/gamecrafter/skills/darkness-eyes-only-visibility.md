---
id: darkness-eyes-only-visibility
title: "Eyes-only visibility for characters in unlit horror spaces"
category: 3d-lighting-horror
when: "Horror game where characters in dark halls must be invisible except glowing eyes until a light (flashlight, hall light) reveals them."
related: [mistake-invisible-jumpscare-no-animation, mistake-placeholder-capsule-returns-in-build]
origin: Pickle's Pickle Shop
---

# Eyes-only visibility for characters in unlit horror spaces

**When to use:** Horror game where characters in dark halls must be invisible except glowing eyes until a light (flashlight, hall light) reveals them.

## Do this

Each frame per actor: determine `in_hall` (hall rooms or door nooks), side L/R from room id (`_L`/`_R` suffix or CAM_2A/2B = L, CAM_4A/4B = R), `lit = controller.is_hall_lit(side)`, `dark = not lit`, `revealed = controller.is_flashlight_on_actor(self) or lit`. When viewing a hall camera feed of that room, the feed decides: `dark = not hall_lit(cam side); revealed = hall_lit`. `eyes_only = dark and not revealed`. In the two door nooks, eyes are hidden too (pure black) -> `_apply_eyes_only(eyes_only, eyes_only and room in [OFFICE_DOOR_L, OFFICE_DOOR_R])`. Hiding is done by toggling MeshInstance3D.visible by name keywords (iris/eye/sclera/pupil stay). Also `_present_model()` re-puts geometry on render layer 1 each frame (a dark-hall polish set layers to 0, which made meshes un-lightable), skipping meshes on the camera-feed layer (1<<19).

## Pitfalls (mistakes seen)

(a) layers=0 trick made characters impossible to reveal by flashlight -> restore layer 1 each frame. (b) placeholder re-enabled (see mistake-placeholder-capsule-returns-in-build). (c) jumpscare hidden (see mistake-invisible-jumpscare-no-animation). (d) user wanted door rooms "basically pitch black ... you can't see who's there without a light" -> eyes hidden too in door nooks.

## Verify

Screenshots: door nook unlit = black, no eyes; lit = character + hall visible; hall camera unlit = eyes only.

## Origin

Pickle's Pickle Shop. Source notes: animatronic.gd L318-372; transcript summary sec.1, 5.

## Related skills

- [mistake-invisible-jumpscare-no-animation](mistake-invisible-jumpscare-no-animation.md)
- [mistake-placeholder-capsule-returns-in-build](mistake-placeholder-capsule-returns-in-build.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
