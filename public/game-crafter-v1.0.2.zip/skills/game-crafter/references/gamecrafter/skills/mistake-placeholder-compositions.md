---
id: mistake-placeholder-compositions
title: "Descript compositions created as 6-second placeholders"
category: mistake
when: "Creating compositions with media that failed to upload."
related: []
origin: FNAP
---

# Descript compositions created as 6-second placeholders

**When to use:** Creating compositions with media that failed to upload.

## Do this

Have Underlord replace/remove them.

## What happened, root cause, fix, prevention

Symptom: 6 s empty comps. Cause: add_compositions with failed uploads. Fix above.

## Verify

get_project.

## Origin

FNAP. Source notes: mistakes-log.md M82.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
