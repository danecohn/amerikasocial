---
id: mistake-dead-enum-state-and-fixed-timers
title: "Mistake - state machine branch never reached; movement timed with constants"
category: mistake
when: "Writing enemy AI state machines, sprints, lerped motions."
related: []
origin: FNAP
---

# Mistake - state machine branch never reached; movement timed with constants

**When to use:** Writing enemy AI state machines, sprints, lerped motions.

## What happened, root cause, fix, prevention

- Symptom: the `leaning` cove state never occurred; sprint timing wrong; run motion stopped short.
- Root cause: `_banshee_decision` never called `_set_cove_state("leaning")`; `_start_sprint` used a fixed 6.0 s timer although the run is 3.3 m/s over a known distance; `_process_run` lerped to t=0.85 instead of 1.0.
- Fix: add the missing transition; time = distance / speed; lerp to 1.0.
- Prevention: for every enum state, grep that something sets it (`grep -n '_set_state("leaning")'`); time motions from distance/speed, never constants.
- Detection: sim scripts that count state visits (`patrol_sim`), assert each state > 0.

## Verify

sim prints visit counts for all states.

## Origin

FNAP. Source notes: L §2.8 (lines 117-119); G line 46.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
