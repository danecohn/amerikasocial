---
id: code-built-data-driven-architecture
title: "Code-built scenes + data-driven content (architecture that survived a 4-platform release)"
category: planning-design
when: "Starting or structuring a Godot game, especially one AI agents will edit."
related: []
origin: FNAP
---

# Code-built scenes + data-driven content (architecture that survived a 4-platform release)

**When to use:** Starting or structuring a Godot game, especially one AI agents will edit.

## Do this

- Scenes are one root node + a script; UI and 3D are built in `_ready()` (merge-friendly, AI-editable; recovered scenes from FNAP's PCK were exactly this).
- Static `RefCounted` helper classes as string registries: `RoomIds`, `Sfx`, `NodeFinder`, `ModelLoader`, `UiKit`.
- Data: enemy definitions as `Resource` classes (`resources/ai/*.tres`), balance tables as const dicts + `.tres` tuning, text/intents/keywords in JSON (in-game AI terminal), clip loop flags in `clips.json`, subtitles as `.cues`.
- One config dict feeds one gameplay scene: `{title, night, hours, seconds_per_hour, levels{id: ai}, power_max, drain_multiplier, ...}` - story night and roguelite shift both drive the same scene.
- Autoload GameState owns CLI flags, RNG, save, quit, scene switching.
- Folder layout: `scripts/core/`, `scripts/autoload/`, `scripts/dev/` (excluded from export), `tools/` (export probe, shipped), `assets/{models,audio,data,textures}/`, docs outside the Godot folder.

## Pitfalls (mistakes seen)

n/a (positive pattern).

## Verify

new feature = new data entry, not new scene file.

## Origin

FNAP. Source notes: S "Architecture that worked" (lines 17-28); R layout (lines 3-15); L §10 line 445.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
