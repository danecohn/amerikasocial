# Tool: run_all_tests.sh

**Purpose:** Runs every headless test scene and summarizes PASS/FAIL with exit codes.

**Usage:** `bash run_all_tests.sh`

**Skill:** see `skills/static-checks-no-godot.md`

**Extract:** save the block below as `run_all_tests.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Runs tests/test_main.tscn + every tests/*/*_test.tscn, serialized through tools/g.sh.
# Prints a table (suite, passed, failed, exit, seconds, script-errors) and exits non-zero on any failure.
# A suite fails if: exit code != 0, no "RESULT: PASS" line, "RESULT: FAIL", timeout, or any "SCRIPT ERROR"/"Parse Error" in its log.
# Env: T=per-suite timeout seconds (default 240); ONLY="substr" to run matching suites only. Logs: tools/qa/out/logs/<suite>.log
# Machine-readable result: tools/qa/out/tests.tsv (consumed by tools/qa/report.py). Owner: qa (agent 12).
cd "$(dirname "$0")/.."
OUT=tools/qa/out; LOGS=$OUT/logs; mkdir -p "$LOGS"
: > $OUT/tests.tsv
suites=(res://tests/test_main.tscn)
for f in $(ls tests/*/*_test.tscn 2>/dev/null | sort); do suites+=("res://$f"); done
printf "%-44s %7s %7s %5s %6s %7s\n" SUITE PASSED FAILED EXIT SECS SCRERR
rc_all=0
for s in "${suites[@]}"; do
  [ -n "${ONLY:-}" ] && [[ "$s" != *"$ONLY"* ]] && continue
  name=$(echo "${s#res://tests/}" | sed 's#/#_#g; s#\.tscn$##')
  log=$LOGS/$name.log
  t0=$(date +%s)
  T=${T:-240} tools/g.sh --headless --path . "$s" >"$log" 2>&1; rc=$?
  secs=$(( $(date +%s) - t0 ))
  line=$(grep -a "^RESULT:" "$log" | tail -1)
  p=$(echo "$line" | sed -nE 's/.*\(([0-9]+) passed.*/\1/p'); f=$(echo "$line" | sed -nE 's/.*, ([0-9]+) failed.*/\1/p')
  [ -z "$p" ] && p=0; [ -z "$f" ] && f=0
  serr=$(grep -acE "^(SCRIPT ERROR|USER SCRIPT ERROR)|Parse Error" "$log")
  status=ok
  if [ $rc -ne 0 ] || ! echo "$line" | grep -q "RESULT: PASS" || [ "$serr" -gt 0 ]; then status=FAIL; rc_all=1; fi
  [ $rc -eq 124 ] && status=TIMEOUT
  printf "%-44s %7s %7s %5s %6s %7s %s\n" "${s#res://tests/}" "$p" "$f" "$rc" "$secs" "$serr" "$([ $status != ok ] && echo "<-- $status (see $log)")"
  printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n" "${s#res://tests/}" "$p" "$f" "$rc" "$secs" "$serr" "$status" >> $OUT/tests.tsv
done
[ $rc_all -eq 0 ] && echo "ALL SUITES OK" || echo "SOME SUITES FAILED"
exit $rc_all
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
