---
id: fnaf-adaptive-proximity-music
title: "Adaptive stem music driven by enemy proximity (AudioStreamSynchronized)"
category: audio-music
when: "Music should swell per enemy as it gets closer."
related: []
origin: FNAP
---

# Adaptive stem music driven by enemy proximity (AudioStreamSynchronized)

**When to use:** Music should swell per enemy as it gets closer.

## Do this

- `MusicClock` autoload (`proximity_music.gd`): one `AudioStreamSynchronized` with 8 looping stems, each exactly 32 s at
  120 BPM (bed, remi, pickle, dilly, golden_pickle, banshee_tick/march/chase) so clock math is exact.
- Each enemy writes `set_presence(key, 0..1)` every frame from its `danger_level()`; volumes fade at 40 dB/s with
  `gain = a*a*0.7 + a*0.3`. Runner's three stems crossfade equal-power over 0.1 s on the next bar.
- Emits `beat`/`bar`; `on_next_bar(callable)` queue; `music_time()` compensates for
  `AudioServer.get_time_since_last_mix()` and output latency. Falls back to a silent clock if stems are missing.
- `GameState.change_scene` stops the MusicClock.

## Pitfalls (mistakes seen)

none recorded.

## Verify

`audio_check.gd` resolves every stem; debug overlay prints bar/beat.

## Origin

FNAP. Source notes: REF §2.10 MusicClock, §3.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
