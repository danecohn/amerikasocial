---
id: mistake-morph-weights-default-state
title: "Curtain showed all states at once; default state invisible"
category: mistake
when: "Using glTF morph targets / staged meshes for state."
related: []
origin: FNAP
---

# Curtain showed all states at once; default state invisible

**When to use:** Using glTF morph targets / staged meshes for state.

## Do this

Zero all blend shapes on bind; make the default state the visible one; special-case nodes that must be visible; never `return` before registering stage nodes.
```gdscript
for i in mi.get_blend_shape_count(): mi.set_blend_shape_value(i, 0.0)
```

## What happened, root cause, fix, prevention

Symptom: curtain showed Peek+Leaning+Open at once; default invisible. Root cause: glTF morph weights `[1,1,1]`; code hid all stage meshes incl. default; `hidden_by_default` extra honoured on a node that must show. Fix as above. Detection: screenshot of cove; GLB JSON weights.

## Verify

Default closed curtain visible; each state screenshot.

## Origin

FNAP. Source notes: mistakes-log.md M13; BOARD.md line 22.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
