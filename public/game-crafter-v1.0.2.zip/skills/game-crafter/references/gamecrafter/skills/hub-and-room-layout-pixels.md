---
id: hub-and-room-layout-pixels
title: "Room arena metrics and screen layout for a 384x216 roguelike"
category: roguelike-procgen
when: "Laying out a top-down room-based roguelike at low resolution."
related: []
origin: Roguelike series
---

# Room arena metrics and screen layout for a 384x216 roguelike

**When to use:** Laying out a top-down room-based roguelike at low resolution.

## Do this

- Room 24x12 tiles x 16px = 384x192 placed under the 24px HUD (total 216). Rows 0-1 = void+north wall face, row 11 = south wall, columns 0/23 = side walls -> playable 22x9 cells.
- Doors on row 1 at columns [11] / [6,16] / [5,11,17]; door exit trigger when `pos.y < 26` and |x - door_centre| < 11; door icons drawn above doors.
- Obstacle layouts (6 kinds): 4 pillar pairs, centre bar (x 9-14, y 6), two columns (x 8 and 15, y 4-8), 10 random cells, 6 fixed scattered, empty. Keep spawn lane (cols 10-13, bottom 4 rows) and door approaches clear; reject layouts failing BFS connectivity (12 tries).
- Movement: 4-corner box test with half-height (r, r*0.5) for top-down feet collision; axis-separated sliding.

## Pitfalls (mistakes seen)

none recorded.

## Verify

generate 1000 rooms; all connected.

## Origin

Roguelike series. Source notes: kit/kit/room.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
