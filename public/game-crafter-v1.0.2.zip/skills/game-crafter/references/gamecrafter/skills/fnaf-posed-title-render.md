---
id: fnaf-posed-title-render
title: "Posed mascot render for title/menu/poster (Blender CLI)"
category: 3d-blender
when: "Making title art or key art from the game's character GLB."
related: [mistake-t-pose-title-art]
origin: FNAP
---

# Posed mascot render for title/menu/poster (Blender CLI)

**When to use:** Making title art or key art from the game's character GLB.

## Do this

- `pose.py` / `pose_t.py` (transparent + shadow catcher): import GLB into an empty scene, find armature, hide stray
  `Icosphere`, assign action `walk`, `frame_set(--frame)`, BAKE current pose matrices then drop the action so manual bone
  offsets stick, add rotation offsets to `upper_arm.R`/`forearm.R`, rotate armature Z by `--yaw`, Cycles CPU + denoise,
  world `#1B1035`, 60 mm camera placed from body bbox (`H*1.95` back), 3 area lights (amber key 900 W, gold rim 1200 W,
  plum fill 160 W), dark plum floor.
- `blender -b --python pose.py -- --frame 6 --arm <x y z> --fore <x y z> --yaw -20 --samples 24 --w 720 --h 960 --out <png>`;
  `inspect.py` prints bones/actions/mesh dims first.
- Timing: final render ~6 min (17 min transparent) on a Snapdragon ARM64 CPU.
- Brief: "weight on one foot, other foot stepped in, one hand up; not a T-pose".

## Pitfalls (mistakes seen)

mistake-t-pose-title-art.

## Verify

Open the PNG and check pose before using it in menu/poster.

## Origin

FNAP. Source notes: REF §6.2.

---------------------------------------------------------------------------------------------------

## Related skills

- [mistake-t-pose-title-art](mistake-t-pose-title-art.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
