---
id: mistake-pil-pixel-loops
title: "Pure-Python per-pixel gradients slow at 1920 px"
category: mistake
when: "Generating art in Python."
related: []
origin: FNAP
---

# Pure-Python per-pixel gradients slow at 1920 px

**When to use:** Generating art in Python.

## Do this

Use numpy or `Image.linear_gradient`.

## What happened, root cause, fix, prevention

Symptom: slow. Fix above.

## Verify

Timing.

## Origin

FNAP. Source notes: mistakes-log.md M69.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
