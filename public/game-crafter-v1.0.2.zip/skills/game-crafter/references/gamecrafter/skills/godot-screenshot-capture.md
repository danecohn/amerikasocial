---
id: godot-screenshot-capture
title: "Capturing stills in Godot (frame_post_draw + settle times)"
category: godot-engine
when: "Store screenshots, camera feed images, visual verification."
related: []
origin: FNAP
---

# Capturing stills in Godot (frame_post_draw + settle times)

**When to use:** Store screenshots, camera feed images, visual verification.

## Do this

`await RenderingServer.frame_post_draw; get_viewport().get_texture().get_image().save_png(path)`. Wait >= 1 s after any camera/room/light change (2.4 s for flashlight reveals) so lights/TAA settle. Render stills at the FINAL resolution (1920x1080) directly. Generic one-scene screenshotter: `-s shot.gd -- <scene> <out.png> <frames>`. Command: `godot_xvfb.sh -r 1920x1080 -t 300 -l /tmp/shots.log -- --path <proj> res://scenes/promo_capture.tscn -- shots`. Open every PNG (Read) before building art from it.

## Pitfalls (mistakes seen)

Store screenshots soft -> captured 1280x720 and upscaled -> render at 1920x1080. Dark/half-lit shots -> captured before lights/TAA settled -> wait 1-2.4 s.

## Verify

Image size is final res; look at it.

## Origin

FNAP. Source notes: headless-render-capture/SKILL.md "Stills".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
