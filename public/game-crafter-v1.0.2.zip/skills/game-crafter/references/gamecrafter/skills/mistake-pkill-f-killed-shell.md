---
id: mistake-pkill-f-killed-shell
title: "Mistake: `pkill -f godot` killed the controlling shell"
category: mistake
when: "Cleaning up leftover Godot/Xvfb processes."
related: []
origin: FNAP
---

# Mistake: `pkill -f godot` killed the controlling shell

**When to use:** Cleaning up leftover Godot/Xvfb processes.

## Do this

kill_godot.sh:
```bash
pkill -x godot 2>/dev/null; pkill -x Xvfb 2>/dev/null
for p in $(pgrep -f 'Godot_v|/godot ' 2>/dev/null); do [ "$p" != "$$" ] && [ "$p" != "$PPID" ] && kill "$p" 2>/dev/null; done
sleep 1; pgrep -a -x godot || echo "no godot running"
```

## What happened, root cause, fix, prevention

Symptom: the agent's own command shell died mid-session (FNAP). Root cause: `pkill -f godot` matches the full command line of the shell running the pkill (it contains "godot"). Fix/prevention: use `pkill -x` (exact process name) and exclude `$$`/`$PPID`.

## Verify

"no godot running", shell still alive.

## Origin

FNAP. Source notes: headless-render-capture/scripts/kill_godot.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
