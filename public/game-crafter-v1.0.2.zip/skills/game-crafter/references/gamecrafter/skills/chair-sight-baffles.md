---
id: chair-sight-baffles
title: "Sight baffles so a doorway lurker is hidden from the chair but visible from the door"
category: 3d-lighting-horror
when: "Player shouldn't see door lurkers from the seated view; must stand/lean to check."
related: []
origin: Pickle's Pickle Shop
---

# Sight baffles so a doorway lurker is hidden from the chair but visible from the door

**When to use:** Player shouldn't see door lurkers from the seated view; must stand/lean to check.

## Do this

Interior jamb AABBs (mirrored L/R): [(-2.55,0,0.25)-(-1.15,2.65,1.45)] and [(-2.90,0,-1.70)-(-2.20,2.65,-0.90)]; StaticBody3D + BoxShape3D (+ visible mesh only with placeholder office). `blocks_sight(from,to)` uses slab-method ray-AABB test with reach = length - 0.08 so a point embedded in a jamb counts as hidden. Lurk markers pulled to the jamb on the hall side (`Lurk_Door<tag>` at door +0.48 m outward; per-character offsets) facing into the office at (−side*1.6, 1.45). A `seat_sight_test.gd` dev probe samples lurk points from the chair and from PlayerStand_Door*.

## Verify

seat_sight_test prints CHECK PASS (all chair rays blocked, door-stand rays clear).

## Origin

Pickle's Pickle Shop. Source notes: level_builder.gd L309-335, L838-926; STATUS.md "Doorway lurkers... 0.58 m past the office wall"; scripts/dev/seat_sight_test.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
