---
id: mistake-headless-flag-has-no-renderer
title: "Mistake - screenshots from `--headless` are empty/black"
category: mistake
when: "Taking screenshots or video in a cloud container."
related: []
origin: FNAP
---

# Mistake - screenshots from `--headless` are empty/black

**When to use:** Taking screenshots or video in a cloud container.

## What happened, root cause, fix, prevention

- Symptom: black/empty PNGs, or Forward Plus failing to start.
- Root cause: `--headless` uses a dummy renderer (no pixels). Without a Vulkan ICD in the container, Vulkan finds no device.
- Fix: `export VK_ICD_FILENAMES=<path>/vk_swiftshader_icd.json` + `xvfb-run -a -s '-screen 0 1280x720x24' godot --path <proj> --rendering-driver vulkan --resolution 1280x720 res://scenes/x.tscn`.
- Prevention: use `--headless` only for logic checks/import/export; pixels need xvfb+vulkan.
- Detection: image stats (mean ~0) or simply look at it.

## Verify

non-black screenshot that matches the game.

## Origin

FNAP. Source notes: L §5.1 (lines 239-247); G line 20 (M51).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
