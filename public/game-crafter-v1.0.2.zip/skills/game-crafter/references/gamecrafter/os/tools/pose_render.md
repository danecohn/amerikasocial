# Tool: pose_render.py

**Purpose:** Headless Blender: pose an armature on an action frame (no T-pose) and render a Cycles still for title/store art.

**Usage:** `blender -b -P pose_render.py -- <in.glb> <action> <frame> <out.png>`

**Skill:** see `skills/pose-render-character.md`

**Extract:** save the block below as `pose_render.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
"""Render a rigged .glb character in a custom POSE (not the T-pose) with studio lighting - for title screens, posters, store art.
Proven on Five Nights at Pickles (menu art, banners). Cycles CPU, denoised; 720x960 @24 samples took ~6 min on 2 cores, so iterate at low res first.

Usage:
  blender -b --python pose_render.py -- --glb model.glb --out out.png [--action walk] [--frame 6]
      [--bone upper_arm.R 0 0 -60] [--bone forearm.R 0 0 -40] ...   (euler DEGREES added on top of the action's pose; repeatable)
      [--yaw -20] [--samples 24] [--w 720] [--h 960] [--transparent] [--hide Icosphere] [--bg 0.106 0.063 0.208]
      [--key 0.77 0.50 0.125] [--rim 0.96 0.77 0.26] [--fill 0.23 0.13 0.39]
Workflow that worked:
  1. inspect_glb.py to learn bone + action names.   2. Render 360x480 @8 samples with a guess; LOOK at the PNG (Read tool).
  3. Nudge --bone values; repeat 3-6 times.            4. Final at full res / 24-64 samples, in the background (nohup) - it takes minutes.
Gotchas encoded below: bones are QUATERNION by default (set rotation_mode='XYZ' before writing euler); an assigned Action overwrites manual
edits on the next update, so BAKE the sampled pose into matrix_basis and then DROP the action; hide helper meshes with BOTH hide_render and
hide_viewport; --transparent uses a shadow-catcher floor so the subject keeps a grounded contact shadow on alpha."""
import bpy, sys, math, mathutils
A = sys.argv[sys.argv.index("--") + 1:]
def opt(name, default=None, n=1, cast=str):
    if name not in A: return default
    i = A.index(name); v = A[i + 1:i + 1 + n]
    return cast(v[0]) if n == 1 else [cast(x) for x in v]
glb, out = opt("--glb"), opt("--out")
action, frame = opt("--action"), opt("--frame", 1, cast=int)
yaw = opt("--yaw", -20.0, cast=float); samples = opt("--samples", 24, cast=int)
W, H_PX = opt("--w", 720, cast=int), opt("--h", 960, cast=int)
bg = opt("--bg", [0.106, 0.063, 0.208], 3, float); key = opt("--key", [0.77, 0.50, 0.125], 3, float)
rim = opt("--rim", [0.96, 0.77, 0.26], 3, float); fill = opt("--fill", [0.23, 0.13, 0.39], 3, float)
transparent = "--transparent" in A
bones = []
for i, a in enumerate(A):
    if a == "--bone": bones.append((A[i + 1], [float(x) for x in A[i + 2:i + 5]]))
hide = [A[i + 1] for i, a in enumerate(A) if a == "--hide"]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=glb)
for o in bpy.data.objects:
    if o.name in hide: o.hide_render = True; o.hide_viewport = True
arms = [o for o in bpy.data.objects if o.type == 'ARMATURE']
if arms:
    arm = arms[0]; bpy.context.view_layer.objects.active = arm
    if action and action in bpy.data.actions:
        arm.animation_data_create(); arm.animation_data.action = bpy.data.actions[action]
        bpy.context.scene.frame_set(frame); bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode='POSE')
    pb = arm.pose.bones
    mats = {b.name: b.matrix_basis.copy() for b in pb}          # BAKE sampled pose ...
    if arm.animation_data: arm.animation_data.action = None      # ... then DROP the action so manual edits stick
    for b in pb: b.matrix_basis = mats[b.name]
    for name, deg in bones:
        b = pb[name]; b.rotation_mode = 'XYZ'
        b.rotation_euler = [b.rotation_euler[i] + math.radians(deg[i]) for i in range(3)]
    arm.rotation_euler[2] = math.radians(yaw)
    bpy.context.view_layer.update()
sc = bpy.context.scene
sc.render.engine = 'CYCLES'; sc.cycles.samples = samples; sc.cycles.device = 'CPU'; sc.cycles.use_denoising = True
sc.render.resolution_x, sc.render.resolution_y = W, H_PX; sc.render.film_transparent = transparent
w = bpy.data.worlds.new("W"); sc.world = w; w.use_nodes = True       # use_nodes is deprecated in Blender 6 (harmless warning in 5.x)
w.node_tree.nodes["Background"].inputs[0].default_value = (*bg, 1); w.node_tree.nodes["Background"].inputs[1].default_value = 0.45
meshes = [o for o in bpy.data.objects if o.type == 'MESH' and not o.hide_render]
body = max(meshes, key=lambda o: o.dimensions.z)
corners = [body.matrix_world @ mathutils.Vector(c) for c in body.bound_box]
zmin, zmax = min(v.z for v in corners), max(v.z for v in corners); cz = (zmin + zmax) / 2; H = zmax - zmin
cam = bpy.data.objects.new("Cam", bpy.data.cameras.new("Cam")); sc.collection.objects.link(cam); sc.camera = cam
cam.data.lens = 60; cam.location = (0, -H * 1.95, cz + H * 0.02); cam.rotation_euler = (math.radians(90), 0, 0)
def light(name, loc, energy, color):
    d = bpy.data.lights.new(name, 'AREA'); d.energy = energy; d.color = color; d.size = H
    o = bpy.data.objects.new(name, d); o.location = loc; sc.collection.objects.link(o)
    o.rotation_euler = (mathutils.Vector((0, 0, cz)) - mathutils.Vector(loc)).to_track_quat('-Z', 'Y').to_euler()
light("key", (-H * 1.2, -H * 1.6, cz + H * 0.7), 900, key); light("rim", (H * 1.3, H * 0.9, cz + H * 0.6), 1200, rim); light("fill", (H * 0.8, -H * 1.8, cz - H * 0.2), 160, fill)
bpy.ops.mesh.primitive_plane_add(size=20, location=(0, 0, zmin)); fl = bpy.context.object
m = bpy.data.materials.new("fl"); m.use_nodes = True; m.node_tree.nodes["Principled BSDF"].inputs[0].default_value = (0.09, 0.05, 0.17, 1)
m.node_tree.nodes["Principled BSDF"].inputs['Roughness'].default_value = 0.55; fl.data.materials.append(m)
if transparent: fl.is_shadow_catcher = True
sc.render.filepath = out; bpy.ops.render.render(write_still=True)
print("DONE", out)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
