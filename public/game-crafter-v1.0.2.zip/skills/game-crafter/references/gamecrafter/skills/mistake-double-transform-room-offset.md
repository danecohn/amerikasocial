---
id: mistake-double-transform-room-offset
title: "Room placed off the map (transform applied twice)"
category: mistake
when: "Instancing glTF rooms into slots."
related: []
origin: FNAP
---

# Room placed off the map (transform applied twice)

**When to use:** Instancing glTF rooms into slots.

## Do this

Place model transform = slot transform ONCE; glTF root may already carry an offset.

## What happened, root cause, fix, prevention

Symptom: room off map. Root cause: glTF root offset by minus slot; wrapped twice. Fix: single placement. Detection: print global positions.

## Verify

Camera feed screenshot shows room.

## Origin

FNAP. Source notes: mistakes-log.md M21.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
