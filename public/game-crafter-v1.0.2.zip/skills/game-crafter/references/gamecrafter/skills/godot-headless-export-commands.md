---
id: godot-headless-export-commands
title: "Headless export commands (release builds and test packs)"
category: export-release
when: "Building any release or test pack."
related: [godot-install-export-templates, mistake-export-wrong-preset-silent]
origin: FNAP
---

# Headless export commands (release builds and test packs)

**When to use:** Building any release or test pack.

## Source 1: FNAP

### Do this

```
godot --headless --path <proj> --import --quit                         # ALWAYS import first
godot --headless --path <proj> --export-release "Windows Desktop" out/Game.exe
godot --headless --path <proj> --export-release "Linux" out/Game.x86_64
godot --headless --path <proj> --export-release "macOS" out/Game-mac.zip
godot --headless --path <proj> --export-release "Windows ARM64" out/Game.exe
godot --headless --path <proj> --export-pack "Linux" /tmp/test.pck       # for test-running
xvfb-run -a godot --main-pack /tmp/test.pck res://scenes/<scene>.tscn     # run the pack
```
- On Windows ARM64 PC use `Godot_v4.7.2-stable_windows_arm64_console.exe` so output/exit code are capturable (`$LASTEXITCODE`).
- Export templates for the exact version must be installed (godot-install-export-templates).

### Pitfalls (mistakes seen)

wrong preset name silently exits non-zero (mistake-export-wrong-preset-silent).

### Verify

exit code 0 AND output file exists with plausible size AND pack probe passes.

### Origin

FNAP. Source notes: L §3.2 (lines 160-171), §2.1 verify (lines 77-79).

## Source 2: FNAP — Godot CLI export commands

### Do this

```
godot --headless --path <proj> --import --quit                 # always first; background + done-marker for big projects
godot --headless --path <proj> --export-release "Windows Desktop" out/Game.exe
godot --headless --path <proj> --export-release "Linux"          out/Game.x86_64
godot --headless --path <proj> --export-release "macOS"          out/Game-mac.zip   # Godot writes the zip containing the .app
godot --headless --path <proj> --export-release "Windows ARM64"  out/Game.exe       # needs arm64 templates
godot --headless --path <proj> --export-pack "Linux" /tmp/test.pck
godot --main-pack /tmp/test.pck res://tools/export_probe.tscn                        # run FROM the pack
```
On Windows use the `*_console.exe` Godot so stdout and `$LASTEXITCODE` are capturable. On ARM64 PCs use the arm64 console Godot.

### Pitfalls (mistakes seen)

Missing preset / missing templates -> non-zero exit, no file; script must check both.

### Verify

Exit 0 + file exists + size sane.

### Origin

FNAP. Source notes: SKILL.md "Commands".

## Related skills

- [godot-install-export-templates](godot-install-export-templates.md)
- [mistake-export-wrong-preset-silent](mistake-export-wrong-preset-silent.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
