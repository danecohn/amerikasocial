---
id: fnaf-camera-monitor-feed
title: "Security camera monitor: SubViewport feed, low fps, static, map UI"
category: gameplay-systems
when: "Implementing the camera tablet/monitor in 3D."
related: [mistake-room-camera-becomes-current]
origin: FNAP
---

# Security camera monitor: SubViewport feed, low fps, static, map UI

**When to use:** Implementing the camera tablet/monitor in 3D.

## Do this

- Full-screen CanvasLayer (layer 5). A `SubViewport` 640x360 with `own_world_3d = false` (renders the MAIN world).
- `render_target_update_mode` toggled to `UPDATE_ONCE` at `FEED_FPS = 18` (low fps = cheap + creepy). Nearest filter,
  green tint modulate, `static.gdshader` overlay with `intensity = 0.12 + _burst` (`_burst` decays 1.6/s; spikes on
  animatronic move, camera switch, hallucination appearance), REC blink, slow yaw pan `sin(t*0.35)*12 deg`.
- Pose/fov from a `Cam_<short>` Camera3D authored inside each room GLB (fallback `CamSpot_*` marker).
- Map UI: either a code-built button grid (`RoomIds.MAP_LAYOUT`) or hot-spot buttons over a map poster image
  (`POSTER_RECTS` Rect2 per camera, transparent flat styleboxes with hover glow).
- Portrait mode `apply_portrait` resizes viewport to 720x1280 and `keep_aspect = KEEP_WIDTH`.
- Audio: `camera-flip-up.wav` (whoosh + CRT chirp), `camera-flip-down.wav`, `camera-switch-blip.wav`,
  `camera-static-loop.wav`, `camera-static-burst.wav` (when a character moves and the feed scrambles).
- Sketch of the low-fps feed:
  ```gdscript
  const FEED_FPS := 18.0
  var _acc := 0.0
  func _process(delta: float) -> void:
      _acc += delta
      if _acc >= 1.0 / FEED_FPS:
          _acc = 0.0
          feed_viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
      _burst = maxf(0.0, _burst - 1.6 * delta)
      static_mat.set_shader_parameter("intensity", 0.12 + _burst)
      feed_cam.rotation.y = _base_yaw + deg_to_rad(sin(_t * 0.35) * 12.0)
  ```
- `--fnap-bench-monitor=full|room` prints `MONITOR_BENCH mode=... avg_ms=` after 2.5 s (compare isolating one room vs
  rendering the full building).

## Pitfalls (mistakes seen)

mistake-room-camera-becomes-current.

## Verify

`cam_feed_check.tscn` opens the monitor and saves a PNG of every camera feed.

## Origin

FNAP. Source notes: REF §2.4, §5.2, §5.4; STATEMAP audio lines 230-235.

## Related skills

- [mistake-room-camera-becomes-current](mistake-room-camera-becomes-current.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
