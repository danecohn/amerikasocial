---
id: headless-release-check-scene
title: "Release-check / regression scenes that assert real gameplay invariants"
category: testing-qa
when: "Before every build; after any change to lighting, AI, assets."
related: []
origin: Pickle's Pickle Shop
---

# Release-check / regression scenes that assert real gameplay invariants

**When to use:** Before every build; after any change to lighting, AI, assets.

## Do this

`scripts/dev/release_check.gd` (+ .tscn) instantiates the real office.tscn, disables processing, then asserts: all 11 room models load; authored office loads; hall button lights start at energy 0; every Light3D in hall rooms (real and placeholder) is 0; required markers exist (PlayerCamera, Lurk_DoorL/R, AutoConsole, DoorMotor_L/R, DoorLamp_L/R, AlarmLight, AlarmLight_Spinner); curtain grip & morph mesh resolve and blend shapes Peek/Open reach >0.9 on state change; fp arm clips list; physical tablet node; required SFX streams exist; phone calls are 44.1 kHz mono PCM16; GPT Commands panel toggles; unlit doorway -> character geometry not on layer 1, lit -> on layer 1; door approach walks, missed window triggers one jumpscare, closing door blocks Dilly, steady flashlight drives Remi back, closed door can't start an encounter. Uses a stub `EncounterController` class implementing the controller duck-typed API. Prints `RELEASE_CHECK_RESULT checks=N failures=M`, exits 1 on failure. `balance_regression.gd` runs night 5 at `Engine.time_scale = 6.0` checking retreat rooms, regroup pauses and exact bang power costs (Remi 0.3, Banshee 9.2), prints BALANCE_REGRESSION_PASS/FAIL. Note: run as a scene, not `-s`, when autoloads are needed ("-s cannot see the autoloads").

## Verify

exit code 0 and PASS lines.

## Origin

Pickle's Pickle Shop. Source notes: scripts/dev/release_check.gd, balance_regression.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
