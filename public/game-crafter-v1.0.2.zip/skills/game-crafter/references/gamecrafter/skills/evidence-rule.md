---
id: evidence-rule
title: "Evidence or it did not happen"
category: testing-qa
when: "Whenever reporting PASS, fixed, working, or verified."
related: []
origin: FNAP
---

# Evidence or it did not happen

**When to use:** Whenever reporting PASS, fixed, working, or verified.

## Do this

"PASS" requires a command output or an image you opened (with an image-reading tool). Keep evidence images in `docs/evidence/*.png`. QA checklist statuses are TODO / PASS / FAIL, always with an evidence path or command. Agents that "fixed" things by hiding errors made the game go backwards and the user then distrusted everything. Bar used for FNAP: "polished and good"; a boxy placeholder = FAIL.

## Pitfalls (mistakes seen)

M90 claimed fixed without seeing it -> rule: open the image/log. M99 claimed PC build results never read back.

## Verify

Every PASS line in QA_CHECKLIST has a path or a command next to it; the referenced PNG exists and was opened in this session.

## Origin

FNAP. Source notes: process-playbook.md section 2; QA_CHECKLIST.fnap_example.md lines 2-3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
