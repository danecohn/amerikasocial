# Tool: bg_run.sh

**Purpose:** Run a long job in the background with a log and timeout so the agent can poll instead of blocking.

**Usage:** `bash bg_run.sh <name> <timeout_s> <command...>`

**Skill:** see `skills/background-long-jobs-bg-run.md`

**Extract:** save the block below as `bg_run.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Run a long command in the background, poll it, never block a tool call past its timeout (~2 min default, 10 max).
# Usage: bg_run.sh start <name> -- <command...>   -> prints PID, log at /tmp/gm_<name>.log, done marker /tmp/gm_<name>.done (contains exit code)
#        bg_run.sh status <name>                  -> running|done:<rc> + last 5 log lines
#        bg_run.sh wait <name> [max_seconds=100]  -> waits up to N seconds then reports status (call repeatedly; send the user a one-line update between waits)
case "$1" in
 start) n=$2; shift 3; rm -f /tmp/gm_$n.done; nohup bash -c "\"\$@\"; echo \$? > /tmp/gm_$n.done" _ "$@" > /tmp/gm_$n.log 2>&1 & echo "pid $! log /tmp/gm_$n.log";;
 status) n=$2; if [ -f /tmp/gm_$n.done ]; then echo "done:$(cat /tmp/gm_$n.done)"; else echo running; fi; tail -5 /tmp/gm_$n.log;;
 wait) n=$2; m=${3:-100}; for i in $(seq 1 $m); do [ -f /tmp/gm_$n.done ] && break; sleep 1; done; "$0" status $n;;
esac
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
