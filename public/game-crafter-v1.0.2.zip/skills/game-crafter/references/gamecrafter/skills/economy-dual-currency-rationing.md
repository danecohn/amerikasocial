---
id: economy-dual-currency-rationing
title: "Dual currency, rationing and scarcity curve"
category: rpg-systems
when: "Survival/economy layer in an RPG."
related: []
origin: Caesarea
---

# Dual currency, rationing and scarcity curve

**When to use:** Survival/economy layer in an RPG.

## Do this

State coin (denarii) vs black-market caps; exchange 3:1 early → 2:1 → 1:1 as war inflates coin; showing caps at checkpoint +3 suspicion; contraband (`legal: false`) only sold for caps and raises scrutiny. Wages per shift (12 citizen, 9 non-citizen minus surcharge), rent tiers 10/25/60/140 per week. Weekly rations per tier (Grain/Protein/Water/Sweet), need 6/3/10 to stay Fed; short → Hungry (−1 END, −10% AP regen); two weeks → Starving. Ration day every 7th day 06:00; spoil after 2 weeks. Scarcity "matters early and fades later". Caps price ≈ ×3.6 coin price early. Weapon condition: damage ×(0.5 + 0.5×condition); repair max `60 + Repair×0.4`%. Crafting recipe format `{id, station, inputs{item:n}, skill{id:min}, output{item:n}, xp}`; stations: apartment workbench (tier ≥ 2), forge, medical, cookfire.

## Origin

Caesarea. Source notes: design/07 §9, §10.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
