---
id: mistake-mixed-old-new-parts-on-pc
title: "Partial delivery leaves mixed old/new split parts in the user's folder"
category: mistake
when: "Re-delivering a rebuilt split build over an older one."
related: []
origin: Pickle's Pickle Shop
---

# Partial delivery leaves mixed old/new split parts in the user's folder

**When to use:** Re-delivering a rebuilt split build over an older one.

## Do this

During re-delivery, Linux parts 000-015 of the new build were committed, the rest still old; the summary flagged "Until all are done the PC folder has mixed old/new parts". If the session dies mid-way, BUILD_ALL.bat would join a corrupt zip. Prevention: deliver into a fresh subfolder (e.g. DISTRIBUTION_new) or delete old parts first, write a parts manifest (names + sizes + sha256) last, and have the joiner verify the count/hash before unpacking. Resume exactly from a recorded checklist after context compaction.

## Verify

Compare PC listing to the cloud manifest after the final commit.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.7-9; L77-322.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
