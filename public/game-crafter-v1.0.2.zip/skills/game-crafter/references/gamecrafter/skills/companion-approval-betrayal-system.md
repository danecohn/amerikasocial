---
id: companion-approval-betrayal-system
title: "Companions with approval tiers, leave threshold, guaranteed betrayal beat"
category: rpg-systems
when: "Party/companion design."
related: []
origin: Caesarea
---

# Companions with approval tiers, leave threshold, guaranteed betrayal beat

**When to use:** Party/companion design.

## Do this

Up to 5 recruited, 2 active. Approval −100..+100: Hostile ≤ −60, Strained −59..−20, Neutral −19..19, Trusted 20..59, Devoted ≥ 60. Leave at ≤ −60 after a farewell scene. Act IV betrayal: among recruited, not-left companions with approval ≤ −40, the lowest whose betrayal condition holds betrays; if none qualifies an allied NPC betrays (`"ally_npc"`) "so the beat always happens". Per-companion betrayal conditions table. Systemic reaction tags (`react(tag)`, active companions only unless global) with per-companion deltas (e.g. kill_civilian −10/−5/−10/−3/−10/−2); authored scenes write approval directly. Orders: Follow/Wait/Hold/Attack my target/Use ability/Go home. Knocked out on Normal, killable on Hard. Personal quest at Trusted, bond scene at Devoted. Romance never changes ending requirements. API: recruit, set_active, get_active, get_approval, get_tier, change_approval, react, kill, resolve_act4_betrayal; signals companion_recruited/left/died, party_changed, approval_changed, reaction.

## Origin

Caesarea. Source notes: design/07 §12; design/08 §3.6.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
