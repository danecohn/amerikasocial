---
id: fnaf-honest-scope-not-included
title: "Write a "NOT INCLUDED" list with fallbacks for every missing piece"
category: project-management
when: "Delivering a partial package or build; anything the user might assume exists."
related: []
origin: FNAP
---

# Write a "NOT INCLUDED" list with fallbacks for every missing piece

**When to use:** Delivering a partial package or build; anything the user might assume exists.

## Do this

- FNAP REBUILD's list: hallucination flashes (skip random flashes); rare "creepy start" frame (skip frame 16); Night 6/7
  cards, End 2/3 paycheck/termination (skip frames 12-13); Custom Night screen (skip frame 14); loading clock for the
  Wait frame (leave black); monitor raise/lower animation (show/hide the camera layer, optionally fade); camera-switch
  blip frames (flash static ~0.2 s); title-screen stars/credit/version (not made); menu music (use ambience/static loops);
  spinning fan overlay (baked still); frame-by-frame jumpscares (one still each, shake/zoom); End of Demo frame (skip);
  the engine project file itself ("You build and save the .mfa yourself... Nothing in this package is a finished Fusion
  project").
- Plus a "MISSING (referenced but not in the tree)" section: "none - every referenced file exists".
- Each line = what is missing + what the builder should do instead.

## Pitfalls (mistakes seen)

claiming a finished project when only assets were delivered.

## Verify

Every NOT INCLUDED line has a fallback instruction.

## Origin

FNAP. Source notes: STATEMAP lines 280-304.

---------------------------------------------------------------------------------------------------

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
