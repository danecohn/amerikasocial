---
id: mistake-old-studio-name-in-identifiers
title: "Rebranded studio, but bundle identifiers still use the old name"
category: mistake
when: "A studio/company rename; generating bundle IDs."
related: []
origin: Roguelike series
---

# Rebranded studio, but bundle identifiers still use the old name

**When to use:** A studio/company rename; generating bundle IDs.

## Do this

Bundle IDs are permanent once published (macOS saves/keychains, store listings). Decide the reverse-DNS prefix once, store it in one config, and use it everywhere.

## What happened, root cause, fix, prevention

- Symptom: company_name "Forgotten Woods Studios" but `application/bundle_identifier="com.evacstudios.thelastlamp"` / `com.evacstudios.wardseven`.
- Root cause: buildgame.py hard-codes `"com.evacstudios." + slug.replace("_","")`.
- Fix: before first public release switch to the new prefix (e.g. `com.forgottenwoods.<slug>`); after release keep it (changing it orphans saves on macOS). Ask the user which they want.
- Prevention: grep for old brand strings (`evac`, `Eva C`) in generated configs before shipping; keep intentional exceptions (folder name, audio file names) documented.

## Verify

`grep -r evacstudios export_presets.cfg` empty (or intentionally documented).

## Origin

Roguelike series. Source notes: buildgame.py L242; roguelikes/*/export_presets.cfg L46; studio_branding/README.md (intentional old names for folder/audio).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
