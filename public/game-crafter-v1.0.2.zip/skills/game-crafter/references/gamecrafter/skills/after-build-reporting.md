---
id: after-build-reporting
title: "After building: run, document, don't publish"
category: export-release
when: "Right after a successful build."
related: []
origin: FNAP
---

# After building: run, document, don't publish

**When to use:** Right after a successful build.

## Do this

1) Run the built exe if possible (in cloud only Linux build via xvfb); otherwise tell the user exactly what to run and what they should see (FNAP main menu shows `Renderer: forward_plus | <GPU> | vX`). 2) Update docs (CHANGELOG, manifest, handoff) in the same turn. 3) Do not upload/publish unless asked.

## Pitfalls (mistakes seen)

Claiming success without reading logs.

## Verify

user-visible version string matches.

## Origin

FNAP. Source notes: SKILL.md "After building".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
