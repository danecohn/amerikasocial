# Tool: ensure_swap.sh

**Purpose:** Add swap on small cloud boxes so Godot imports / Blender / ffmpeg don't get OOM-killed.

**Usage:** `sudo bash ensure_swap.sh 4G`

**Skill:** see `skills/cloud-swapfile-for-oom.md`

**Extract:** save the block below as `ensure_swap.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Create + enable a swapfile when RAM is tight (first Godot import of ~600MB of GLBs, SwiftShader renders, 8GB boxes OOM).
# Usage: ensure_swap.sh [size_gb=12] [path=/tmp/swapfile]. Safe to re-run. Needs root (containers usually are).
SZ="${1:-12}"; P="${2:-/tmp/swapfile}"
if [ "$(free -g | awk '/Swap:/{print $2}')" -ge "$SZ" ]; then echo "swap already >= ${SZ}GB"; exit 0; fi
if [ ! -f "$P" ]; then fallocate -l "${SZ}G" "$P" 2>/dev/null || dd if=/dev/zero of="$P" bs=1M count=$((SZ*1024)) status=none; fi
chmod 600 "$P"; mkswap "$P" >/dev/null 2>&1; swapon "$P" 2>&1 || { echo "swapon failed (no privilege?). Lower resolution / clip length instead."; exit 1; }
free -h | sed -n '1,3p'
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
