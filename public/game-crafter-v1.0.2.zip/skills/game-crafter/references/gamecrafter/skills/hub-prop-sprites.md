---
id: hub-prop-sprites
title: "Hub prop sprites (shrine 20x34 2-frame, archive 16x18) from material colours"
category: pixel-art-2d
when: "Need interactable furniture (upgrade shrine, lore archive) in a hub."
related: []
origin: Roguelike series
---

# Hub prop sprites (shrine 20x34 2-frame, archive 16x18) from material colours

**When to use:** Need interactable furniture (upgrade shrine, lore archive) in a hub.

## Do this

- `prop_shrine(kind, c1, c2, glow)` kinds: lamp (lantern box with glowing pane flickering `glow` <-> `light(glow,0.2)`), altar (candle rising 1px), brazier (flame polygon height alternates), crystal, tv (screen flicker), chest (sparkle pixels move), bell (clapper swings 1px). All with explicit `#0b0a10` outlines (no finish()).
- `prop_archive(kind, c1, c2)`: book on stand, tape, files (pinned papers), jar - single frame 16x18.
- Altar prop 20x24 uses the first theme's wall face colour so it matches the floor set.

## Pitfalls (mistakes seen)

dead statement `im.alpha_composite(im) if False else None` in prop_shrine.

## Verify

hub_*.png sizes 40x34 (2 frames) and 16x18.

## Origin

Roguelike series. Source notes: _tools/gk.py lines 190-269; tiles.py prop_altar; g1 spec _lamp/_log.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
