---
id: itch-ai-disclosure
title: "Honest generative-AI disclosure for AI-built games"
category: promo-marketing
when: "Publishing any game built with an AI agent on itch.io (or any store with an AI field)."
related: []
origin: Roguelike series
---

# Honest generative-AI disclosure for AI-built games

**When to use:** Publishing any game built with an AI agent on itch.io (or any store with an AI field).

## Do this

- itch.io has a generative-AI disclosure field; answer "Yes".
- Explain what was AI vs procedural: "This game was built with AI assistance: the code and writing were produced with Claude (Anthropic), and the pixel art, tiles, UI sounds and the custom pixel fonts were generated procedurally by scripts. The music is composed in the BeepBox format and rendered with the BeepBox synthesizer."
- Paste-ready short answer: "Code, text and assets were created with AI assistance; art, fonts and sound effects are procedurally generated."
- Reason given to user: "Honest disclosure protects the page from takedowns."
- Same honesty in INDEX: "Disclose AI assistance on itch.io as required."

## Pitfalls (mistakes seen)

none.

## Verify

itch.txt contains the disclosure section.

## Origin

Roguelike series. Source notes: pack.py L103-104; itch.txt L117-118; INDEX.md L16.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
