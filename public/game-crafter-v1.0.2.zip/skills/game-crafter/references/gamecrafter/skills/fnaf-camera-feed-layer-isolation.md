---
id: fnaf-camera-feed-layer-isolation
title: "Dark halls for the player, readable feeds for the monitor (render-layer isolation)"
category: 3d-lighting-horror
when: "The 3D world must look pitch black from the office but security cameras must show the rooms."
related: [mistake-dark-hall-actors-invisible-layers-zero]
origin: FNAP
---

# Dark halls for the player, readable feeds for the monitor (render-layer isolation)

**When to use:** The 3D world must look pitch black from the office but security cameras must show the rooms.

## Do this

- Feed camera `cull_mask = FEED_LAYER (1 << 19)`. On camera select, `_isolate_feed()` walks the room's tree and sets every
  `VisualInstance3D.layers = FEED_LAYER`, ORs the layer into every Light3D `light_cull_mask`, plus the animatronics
  currently in that room. `_restore_feed()` puts original masks back.
- A `DirectionalLight3D` "FeedExposure" (energy 4.5, `light_cull_mask = FEED_LAYER`) follows the feed camera; the feed
  camera has its own `Environment` (ambient 1.05, exposure 1.65, desaturate 0.55) and `CameraAttributesPractical`.
- Player camera removes FEED_LAYER from its cull mask.
- Result: no duplicated geometry, dark halls, readable feeds.
- (quoted)
  ```gdscript
  func _claim(node: Node) -> void:
  	if node is Light3D:
  		var light := node as Light3D
  		_isolated.append({"n": light, "kind": "light", "mask": light.light_cull_mask})
  		light.light_cull_mask = light.light_cull_mask | FEED_LAYER
  	elif node is VisualInstance3D:
  		var vis := node as VisualInstance3D
  		_isolated.append({"n": vis, "kind": "vis", "layers": vis.layers})
  		vis.layers = FEED_LAYER
  	for child in node.get_children():
  		_claim(child)
  ```
- Any per-frame visibility fixer must skip nodes on the feed layer (see mistake-dark-hall-actors-invisible-layers-zero).

## Pitfalls (mistakes seen)

mistake-dark-hall-actors-invisible-layers-zero (layer games done wrong).

## Verify

cam_feed_check PNGs are readable while hall_check "dark" PNG is black.

## Origin

FNAP. Source notes: REF §2.4 "Feed isolation trick", §8.1 D.

## Related skills

- [mistake-dark-hall-actors-invisible-layers-zero](mistake-dark-hall-actors-invisible-layers-zero.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
