# GameCrafter
### An AI game-studio operating system, by Forgotten Woods Studios
*"A Horror Experience Company"*

GameCrafter is a folder of Markdown files. Give it to any LLM agent that has a cloud environment (a shell, Python, file tools) and it can plan, build, verify, ship and market a video game the way a real studio does.

It is not a prompt pack. It holds what an AI agent actually learned shipping these real games for Forgotten Woods Studios:

| Project | What it taught |
|---|---|
| **FNAP / Five Nights at Pickles** | FNAF-style 3D horror in Godot 4 + Blender: office, doors, power, cameras, animatronic AI, phone calls, jumpscares, 4-platform release, promo kit |
| **Pickle's Pickle Shop (FNAP Reimagined)** | the remaster: real darkness, eyes-in-the-dark, hall lights driven by an in-game AI assistant, jumpscare cameras, camera-feed exposure, shipping through a PC bridge |
| **Caesarea** | an open-world 3D RPG built by several AI agents at once: Blender pass, Godot pass, handoff to a coding IDE, design bibles, data-driven quests and dialogue |
| **The Last Lamp, Saint Marrow's, Salt Mine 9, Ward Seven** | an 8-bit horror roguelike series made by a "game factory": procedural pixel art, bitmap fonts, synthesized chiptune music and SFX, one shared engine kit, an automatic test player, 4 games shipped in one day |

Every technique that worked is a skill. **Every mistake that ever reached the user is its own skill too**, so it never happens again: the shipped build full of grey placeholder boxes, the jumpscare with no animation, the camera feeds that were pitch black, the black screen after "New Game", the zips that were too big to deliver, and the rest.

---

## What's inside

```
gamecrafter/
├── README.md            ← you are here (for humans)
├── BOOT.md              ← the agent reads this first: identity, boot sequence, laws
├── skills/
│   ├── SKILLS.md        ← MASTER INDEX: every skill, its trigger, where to start
│   └── *.md             ← one file per skill (techniques + mistakes)
└── os/                  ← the operating system that runs the skills
    ├── ROUTER.md        ← user intent → workflow → skills
    ├── LAWS.md          ← non-negotiable rules (the "never again" list)
    ├── workflows/       ← step-by-step pipelines (new game, ship, promo, fix a bug…)
    ├── checklists/      ← gates you must pass before saying "done"
    ├── templates/       ← GAME_BIBLE, MANIFEST, STATE, itch page, handoff prompt, launchers…
    ├── tools/           ← ready-to-extract scripts (lint, verify, sprite/tile/font/SFX generators…)
    ├── memory/          ← how the agent keeps project state across sessions and other AIs
    └── agents/          ← how to fan work out to subagents, with ready role prompts
```

## How to install it into an AI

1. Upload `gamecrafter.zip` to the AI's cloud environment (or attach the folder) and unzip it.
2. Send this as your first message (or put it in the system prompt):

   > You are running GameCrafter. Read `gamecrafter/BOOT.md` now and follow it for the rest of this conversation. Then help me make my game.

3. Ask for what you want in plain words: *"Make an 8-bit horror roguelike about a lighthouse keeper"*, *"Fix my exported build, the characters are grey capsules"*, *"Ship my Godot project for Windows, Mac and Linux"*, *"Make the itch.io page and a trailer"*.

It works best with an agent that can run a shell (Godot 4 and Blender run headless in the cloud; the install skills cover that). If the agent can also reach your own computer (a desktop bridge), the delivery skills cover that too.

## The toolchain it assumes
- **Godot 4.x** (standard build, GDScript), with matching export templates
- **Blender 4/5** (headless) for 3D models, rigs and animation clips
- **Python 3** with Pillow and numpy for procedural pixel art, fonts and sound
- **Node** for the offline chiptune synth; **ffmpeg** for trailers and audio
- Xvfb plus software rendering for screenshots on a machine with no GPU

None of it costs money. The skills include install steps for Linux, macOS and Windows (x64 and ARM64).

## Ground rules it enforces
- A game is "done" only when the **exported build** has been run and **looked at**, not just the editor.
- No fix may work by hiding, deleting or silencing the problem.
- Every delivery says plainly what was verified and what was not.
- Nothing is uploaded, published or posted unless you ask.

---

**Developed by Forgotten Woods Studios.** GameCrafter v1.0.
Built from real production work on FNAP, Pickle's Pickle Shop, Caesarea and the Forgotten Woods roguelike series.
