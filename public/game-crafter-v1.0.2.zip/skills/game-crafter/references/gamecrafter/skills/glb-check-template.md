---
id: glb-check-template
title: "glb_check.gd - sanity-report every model under a folder"
category: testing-qa
when: "New/re-exported models; before writing code that relies on a model; release check."
related: []
origin: FNAP
---

# glb_check.gd - sanity-report every model under a folder

**When to use:** New/re-exported models; before writing code that relies on a model; release check.

## Do this

- Usage: `godot --headless --path <proj> -s res://scripts/dev/glb_check.gd -- [res://assets/models]`. Recursively scans (packed_name-safe so it also works from a pack), loads each `.glb/.gltf` as PackedScene, instantiates, counts meshes, materials, surfaces without albedo texture, cameras, lights, clips. Prints `OK <file> meshes=.. mats=.. surf_no_albedo=.. cams=.. lights=.. clips=[..]`, `FAIL load <p>`, `  ^ NO MESHES`, final `GLB_CHECK_DONE files=N bad=M`; exit 1 on any bad.
```gdscript
extends SceneTree
func _init() -> void:
    var args := OS.get_cmdline_user_args()
    var root_dir: String = args[0] if args.size() > 0 else "res://assets/models"
    var files: Array[String] = []; _scan(root_dir, files)
    var bad := 0
    for p in files:
        var ps := load(p) as PackedScene
        if ps == null: print("FAIL load ", p); bad += 1; continue
        var n := ps.instantiate()
        # ... count MeshInstance3D / BaseMaterial3D.albedo_texture == null / Camera3D / Light3D / AnimationPlayer clips
        n.free()
    print("GLB_CHECK_DONE files=%d bad=%d" % [files.size(), bad]); quit(1 if bad else 0)
func _scan(dir: String, out: Array[String]) -> void:
    for d in DirAccess.get_directories_at(dir): _scan(dir.path_join(d), out)
    for raw in DirAccess.get_files_at(dir):
        var f := NodeFinder.packed_name(raw)
        if f.get_extension().to_lower() in ["glb", "gltf"] and not out.has(dir.path_join(f)): out.append(dir.path_join(f))
```
- Grep: `godot --headless --path . -s tools/glb_check.gd 2>&1 | grep -E "^(OK|FAIL|GLB|  \^)"`.

## Pitfalls (mistakes seen)

code assumed room GLBs existed that were not there (mistake-assuming-assets-exist).

## Verify

`GLB_CHECK_DONE ... bad=0`.

## Origin

FNAP. Source notes: T/godot_dev/glb_check.gd; L §5.5 line 275.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
