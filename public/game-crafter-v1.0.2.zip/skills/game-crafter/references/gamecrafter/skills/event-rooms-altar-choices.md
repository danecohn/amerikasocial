---
id: event-rooms-altar-choices
title: "Event rooms: altar + one-off narrative choice with stat effects"
category: roguelike-procgen
when: "Adding Slay-the-Spire/Hades-style '?' rooms."
related: []
origin: Roguelike series
---

# Event rooms: altar + one-off narrative choice with stat effects

**When to use:** Adding Slay-the-Spire/Hades-style "?" rooms.

## Do this

- Event room: doors open immediately (player may skip), altar sprite `prop_altar.png` at (192,96) with accent burst; within 24px prompt "[E] INSPECT".
- Pick an unused event (per run `_used_events`) whose `when` passes (e.g. `{"floor": 1}`), else "NOTHING HERE BUT DUST.".
- Event = dialogue scene with a choice; choices carry `fx` lists: `{"do": "mem", "n": 15}`, `heal`, `hurt` (floors at 1 HP), `maxhp`, `dmg` (+/- damage), `light`, `sanity`, `boon` (then offers boon cards with rare_bias 1.0), `rflag`, `spawn` (id, n: converts room into a fight and closes doors).
- Design pattern: each choice is a trade (heal vs max HP, currency vs hurt, light vs boon); 8 events per game, 3-4 floor-gated.
- After use: altar greys out (modulate 0.5), room_n += 1, light +0.1.

## Pitfalls (mistakes seen)

none recorded.

## Verify

`--kind=event --scene=run --press=1.2 --shot=...`.

## Origin

Roguelike series. Source notes: run.gd 278-289, 468-537; content.py EVENTS.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
