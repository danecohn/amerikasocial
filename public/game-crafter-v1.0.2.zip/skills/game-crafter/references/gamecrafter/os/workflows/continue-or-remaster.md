# Workflow: continue, finish or remaster an existing game
1. Find the **project of record** (`canonical-project-folder`, `user-folder-is-source-of-truth`). Read STATE / MANIFEST / KNOWN_GAPS (`os/memory/PROJECT_MEMORY.md`).
2. Diff the user's folder against any working copy. **Their edits win**; merge, then run the parse check (`mistake-user-edited-code-parse-error`).
3. Missing big assets? Copy them from the legacy folder, and rebuild split assets (`large-asset-split-in-source`).
4. Baseline: export as it is now and screenshot it. Then you know what was already broken.
5. Write the user's vision as standing instructions (`standing-instructions`).
6. Work in small verified steps (`master-game-loop`), checking each against the exported build.
7. Ship with `ship-release.md`; deliver the source fixes back to the project of record (`deliver-and-confirm`).
If the source is lost: `recover-project-from-exported-pck`.
