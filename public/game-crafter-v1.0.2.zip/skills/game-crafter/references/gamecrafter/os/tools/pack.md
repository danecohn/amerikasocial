# Tool: pack.py

**Purpose:** Assembles the finished game folder: ADVERTISEMENTS, DOCS, bible, manifest, README, soundtrack.txt.

**Usage:** `python3 pack.py games/gN`

**Skill:** see `skills/per-game-delivery-folder-layout.md`

**Extract:** save the block below as `pack.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""pack.py <games/gN_dir> : assemble the finished game folder (ADVERTISEMENTS docs, bible, manifest, README, soundtrack.txt).
Reads games/gN/meta.py (META dict). Screenshots/cover/zips are produced by other steps into the same out folder."""
import sys, os, json, importlib.util, datetime, glob, shutil
gdir = os.path.abspath(sys.argv[1])
spec = importlib.util.spec_from_file_location("meta", os.path.join(gdir, "meta.py")); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
M = m.META
OUT = f"/home/claude/evac/out/{M['folder']}"
os.makedirs(f"{OUT}/ADVERTISEMENTS", exist_ok=True); os.makedirs(f"{OUT}/DOCS", exist_ok=True)
B = f"/home/claude/evac/build/{M['slug']}"
info = json.load(open(f"{B}/soundtrack_info.json"))
T = M["title"]; URL = f"https://forgottenwoods.itch.io/{M['itch_slug']}"
tags = M["tags"]

itch = f"""ITCH.IO PAGE SETUP - {T}
Studio: Forgotten Woods Studios  (https://forgottenwoods.itch.io)
Fill the boxes on https://itch.io/game/new in this order. Copy/paste exactly.
(Nothing has been uploaded or published. Do it when you are ready. Save as DRAFT first, check the preview, then switch Visibility to Public.)

--------------------------------------------------------------------
TITLE
{T.title() if M.get('title_case') else T}

PROJECT URL (slug)
{URL}
(just the last part: {M['itch_slug']})

SHORT DESCRIPTION OR TAGLINE  (shows under the title in browse pages; keep under ~100 characters)
{M['short']}

CLASSIFICATION
Games

KIND OF PROJECT
Downloadable

RELEASE STATUS
Released

PRICING
Paid  -  ${M['price']}
 - Add a sale: 20% off for the first 7 days (launch discount, ${M['launch_price']}). Itch > Edit game > Pricing > "Start a sale".
 - Leave "Let people pay more" enabled (suggested donation field on) - horror fans do tip.
 - Do NOT make it free; free horror games on itch get downloaded and never bought. Paid + a small launch sale converts better.
 - Optional "Demo" later: upload a second build with only floor 1 for free so people can try it. (Not built; ask me if you want it.)

DESCRIPTION  (paste the block between the lines; itch supports this Markdown-ish formatting in the editor's "Rich text" mode - paste, then fix bold/headings with the toolbar)
--------------------------------------------------------------------
{M['long']}
--------------------------------------------------------------------

GENRE (pick the top 2)
{M['genres']}

TAGS (itch allows 10 - add these, in this order)
{', '.join(tags)}

CUSTOM NOUN
game

UPLOADS  (Upload files - upload ALL FOUR, set the platform tick-box on each)
 - {M['zip_prefix']}_Windows_x64.zip      -> tick "Windows"   (64-bit Intel/AMD PCs)
 - {M['zip_prefix']}_Windows_ARM64.zip    -> tick "Windows"   (Surface/Snapdragon ARM PCs) - name it clearly so ARM owners find it
 - {M['zip_prefix']}_Linux.zip            -> tick "Linux"
 - {M['zip_prefix']}_Mac.zip              -> tick "macOS"
 (If the zips are split into .zip.001 parts, run DISTRIBUTION\\ASSEMBLE_ZIPS.bat first.)
 - Under "Display name" for each file use: "Windows (64-bit)", "Windows (ARM64)", "Linux", "macOS".
 - Tick "This file will be played in the browser": NO (it is a download).

EMBED / FRAMES
Leave blank.

COVER IMAGE
ADVERTISEMENTS\\itch_cover_630x500.png   (630x500, the size itch wants; min 315x250)

SCREENSHOTS  (upload all 5, in this order)
 1. screenshot_01.png   2. screenshot_02.png   3. screenshot_03.png   4. screenshot_04.png   5. screenshot_05.png
 (1920x1080, real in-game captures, pixel-perfect 5x)

GAMEPLAY VIDEO
Leave blank for now. When you record a trailer (see socials.txt), paste the YouTube link here.

COMMUNITY
Comments (recommended - comments boost the itch.io algorithm). Turn OFF Discussion board unless you want to moderate it.

VISIBILITY & ACCESS
Draft while you check it -> then Public.

MORE INFORMATION  (right side column of the edit page)
 - Release date: today's date
 - Author / Developer: Forgotten Woods Studios
 - Average session: {M['session']}
 - Languages: English
 - Inputs: Keyboard, Mouse   (controller is NOT supported yet)
 - Multiplayer: none
 - Links: forgottenwoods.itch.io
 - Accessibility: {M['access']}
 - Player count: Single player

CONTENT WARNING / MATURE CONTENT
Tick "Contains mature content?" is optional. Mention in the description (already included): {M['warnings']}

GENERATIVE AI DISCLOSURE  (itch.io now has a field for this - answer it honestly)
This game was built with AI assistance: the code and writing were produced with Claude (Anthropic), and the pixel art, tiles, UI sounds and the custom pixel fonts were generated procedurally by scripts. The music is composed in the BeepBox format and rendered with the BeepBox synthesizer. Check "Yes" and say: "Code, text and assets were created with AI assistance; art, fonts and sound effects are procedurally generated." Honest disclosure protects the page from takedowns.

--------------------------------------------------------------------
PRICING ADVICE (you said you need to make money)
 - ${M['price']} is the suggested price: roguelikes with real story sell at $3-$8 on itch; $4.99 sits in the impulse-buy zone and still leaves room for a 20-30% sale.
 - First 48 hours matter: post the two reels (socials.txt) the day you publish, then send the link to horror subreddits that allow self-promo days, and horror itch.io jams/tag pages.
 - When you have several games out, bundle them: "Forgotten Woods Collection" - itch Bundles - price at ~30% off the sum. Cross-link every game page in the description footer.
 - I cannot guarantee sales. Revenue depends on how many people see the page; the reels + page quality are the lever.
"""
open(f"{OUT}/ADVERTISEMENTS/itch.txt", "w").write(itch)

soc = f"""SOCIALS - {T}   (Forgotten Woods Studios)
Nothing has been posted. Everything below is ready to paste.

======================================================================
PART 1 - THE TWO REEL POSTS  (Instagram Reels / TikTok / YouTube Shorts - same video, same caption)
======================================================================
Both reels use the vertical 9:16 (1080x1920) cut described in PART 2. Post Reel A on launch day, Reel B 2-3 days later.
Keep to 5 or fewer hashtags (Instagram now limits them; extra ones are ignored or hurt reach).

--- REEL A  (the hook / the premise)  -----------------------------------
CAPTION:
{M['reel_a']}

HASHTAGS: {M['hashtags_a']}
POSTING NOTES: first line is the hook - do not edit it. Put "link in bio" only if your bio link points at {URL}. On TikTok/Shorts say the full link in the pinned comment.

--- REEL B  (the twist / the feeling)  ----------------------------------
CAPTION:
{M['reel_b']}

HASHTAGS: {M['hashtags_b']}
POSTING NOTES: post as a Reel AND share to Stories with the link sticker. Reply to every comment in the first hour.

======================================================================
PART 2 - FUTURE INSTRUCTIONS: VERTICAL REEL AD (9:16, 1080x1920, 20-30 seconds)
======================================================================
You do not need to make this now. When you want paid or organic video, follow this exactly.
1. RECORD: run the game full-screen (it renders 384x216 and scales by whole numbers; use a 1920x1080 window so it is crisp). Record with OBS (Display Capture, 60 fps, MKV -> remux to MP4). Do NOT use window scaling that is not an integer.
2. FRAME: in your editor (Descript works) make a 1080x1920 project. Place the gameplay at 1080 wide (x2.8125 is not integer - instead crop to the middle 384x216 region scaled 5x = 1920x1080, then scale that to 1080x608 and center it), blur+darken a zoomed copy of the same clip behind it to fill the top and bottom. Pixel art can be scaled with "nearest/no smoothing" if the editor offers it.
3. SHOT LIST (seconds):
{M['shots']}
4. TEXT: big bone-white pixel-style text, max 6 words per card, 1.2 s each, upper-left safe area (keep 250 px clear at top and 420 px at bottom: app UI covers them). Suggested cards: {M['cards']}
5. AUDIO: use the game's own soundtrack from the Soundtrack folder (tracks: {M['reel_music']}). Duck music under the first dialogue blips so the talk sounds are audible - they are the hook. End with the Forgotten Woods sting (Eva C Studios\\audio\\eva-c-studios-splash-sting.mp3 - it is the studio sting) for the last 3 seconds over the logo (branding\\forgotten-woods-logo-on-night.png).
6. END CARD (last 3 s): cover art + "{T}" + "forgottenwoods.itch.io" + price.
7. EXPORT: MP4 H.264, 1080x1920, 30 or 60 fps, under 100 MB. Captions burned in (many people watch muted).
8. AD SETTINGS (if you pay for ads): objective = traffic to itch page; audience = interests in roguelikes, horror games, Hades, Undertale, Darkest Dungeon, Cult of the Lamb; countries US/UK/CA/AU first; start at $5/day for 3 days and only keep ads whose cost per click is under $0.30.

======================================================================
PART 3 - FUTURE INSTRUCTIONS: HORIZONTAL REEL / TRAILER AD (16:9, 1920x1080, 30-45 seconds)
======================================================================
Use this on YouTube (trailer, pre-roll), the itch.io "gameplay video" box, Twitter/X and Facebook.
1. Same capture as above, native 1920x1080 (no cropping needed: the game is 16:9 at exactly 5x).
2. STRUCTURE: 0-3 s studio sting + logo (branding\\forgotten-woods-splash-1920x1080.png) -> 3-8 s title card + one line of atmosphere -> 8-30 s four gameplay beats (below) -> 30-38 s review/feature cards -> 38-45 s end card with price and URL.
3. BEATS:
{M['shots_h']}
4. FEATURE CARDS (one per 2.5 s): {M['features_cards']}
5. AUDIO: the title theme under the opening, the boss track under the fight, the "ending" track for the last 10 seconds.
6. YOUTUBE UPLOAD: title "{T} - Official Trailer | Pixel Horror Roguelike", description = first paragraph of the itch description + {URL}, tags = {', '.join(tags[:6])}. Paste the finished YouTube link into the itch.io "Gameplay video" box.
7. THUMBNAIL: ADVERTISEMENTS\\itch_cover_630x500.png scaled to 1280x720 with the title text enlarged.

======================================================================
PART 4 - POSTING SCHEDULE (first 2 weeks)
======================================================================
Day 0 publish + Reel A | Day 2 Reel B | Day 4 vertical ad cut (new gameplay beat) | Day 7 end of launch sale reminder (Story + Reel) | Day 10 behind-the-scenes (how the music/fonts were made) | Day 14 horizontal trailer on YouTube.
"""
open(f"{OUT}/ADVERTISEMENTS/socials.txt", "w").write(soc)

# soundtrack.txt (BeepBox links)
st = f"SOUNDTRACK - {T}\nComposed in the BeepBox format. Open any link at https://www.beepbox.co to edit the song.\nNOTE: the cloud environment I worked in could not reach beepbox.co, so the songs were authored as BeepBox song data and rendered with the real BeepBox synthesizer (MIT source) offline. The links below load the exact songs in the website. Sound effects are procedurally synthesised (not BeepBox).\n\n"
for i in info:
    st += f"{i['name']:<8} {i['key']} {i['mode']:<10} {i['bpm']} BPM  {i['seconds']}s\n{i['beepbox_url']}\n\n"
open(f"{OUT}/DOCS/soundtrack.txt", "w").write(st)

readme = f"""{T}
by Forgotten Woods Studios - a horror experience company
{M['tagline']}

HOW TO RUN
 Windows (x64 or ARM64): unzip, run "{M['product']}.exe". If SmartScreen warns (the game is unsigned): More info > Run anyway.
 Linux: unzip, run ./{M['product']}.x86_64  (needs a normal desktop with OpenGL).
 macOS: unzip, right-click the app > Open the first time (it is unsigned), then Open again.

CONTROLS
{M['controls']}

SAVES
 Progress saves automatically (user data folder of the game). Delete it to start over.

SOUNDTRACK
 The "Soundtrack" folder has all songs (.ogg) and the BeepBox song files (.bb.json). BEEPBOX_LINKS.txt opens each song in the BeepBox editor.

CONTENT NOTES
 {M['warnings']}

(c) Forgotten Woods Studios. https://forgottenwoods.itch.io
"""
open(f"{OUT}/PLAYER_README.txt", "w").write(readme)

# bible + manifest are written by the per-game meta as markdown + auto manifest
bible = M["bible"]
open(f"{OUT}/DOCS/GAME_BIBLE.md", "w").write(bible)
print("docs written", OUT)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
