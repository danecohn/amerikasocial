---
id: fnaf-patrol-movement-ai
title: "Patrol AI: timed rolls against ai_level/20, watched-rules, waypoints"
category: ai-enemies
when: "Implementing FNAF-style room-to-room movement."
related: []
origin: FNAP
---

# Patrol AI: timed rolls against ai_level/20, watched-rules, waypoints

**When to use:** Implementing FNAF-style room-to-room movement.

## Do this

- Every `move_interval * rand(0.75..1.25)` s roll `ai_level/20`; on pass advance one step along `path` (unless
  `moves_only_unwatched` and the room is watched).
- "Watched" = camera monitor open ON that room, OR hall light/flashlight on the door room.
- While the monitor is up there is a 35% chance to "skip a room" (REF wording).
- Movement: snap to waypoint empty `WP_<room>_<Name>` from the room GLB, then a short walk-in tween
  (`dist = clamp(speed*1.5, 0.6, 1.2)`), at the data walk speed. 3D footstep sfx (heavy in halls/doors, soft far away:
  `footsteps-<char>-heavy/soft.wav`). Pickle plays a huff-laugh on move (`laugh_on_move`).
- Camera static burst on any movement (feed scrambles) - a readable tell.
- Sketch:
  ```gdscript
  func _process(delta: float) -> void:
      _move_left -= delta
      if _move_left > 0.0: return
      _move_left = data.move_interval * rng.randf_range(0.75, 1.25)
      if rng.randf() >= ai_level / 20.0: return
      if data.moves_only_unwatched and office.is_room_watched(room): return
      advance()
  ```
- Danger level for music: path progress 0..1; cove 0.9/1.0; office 1.0; +0.3 if the player is watching that room.
- Single-image 2D priority when two share a room (CAM 1B): Remi, then Dilly, then Pickle.

## Pitfalls (mistakes seen)

none in this logic itself; see token guard for walk tweens (`_visual_token`, `_door_token`).

## Verify

`patrol_sim.gd` replays the rules with the real resources.

## Origin

FNAP. Source notes: REF §2.5; STATEMAP line 24.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
