---
id: fnaf-name-contract-node-finder
title: "Blender<->Godot naming contract + normalizing node finder"
category: godot-engine
when: "Code finds nodes in imported GLBs by name."
related: []
origin: FNAP
---

# Blender<->Godot naming contract + normalizing node finder

**When to use:** Code finds nodes in imported GLBs by name.

## Do this

- Office contract names: `PlayerCamera`, `Door_L/R`, `DoorFrame_L/R`, `DoorHousing_L/R`, `DoorMotor_L/R`, `DoorLamp_L/R`,
  `Lever_L/R`|`DoorLever_L/R`, `DoorButton_L/R`, `LightButton_L/R`, `Light_Hall_L/R`, `Hall_Light_L/R`, lights/bulbs,
  `Fan_Blades`, `Clock_Hand_Hour/Minute`, `CRT_Screen`, `Assistant_Keyboard/Speaker/LED`, `FlashlightCharger`,
  `Charger_LED`, `Poster_Map_Real/Fake`, `HallStub_L/R`, `PlayerStand_DoorL/R`, `PlayerLean_DoorL/R`, `GrabBar_L/R`,
  `Lurk_DoorL/R`, `AutoConsole`, `AutoSpeaker`, `AlarmLight`, `AlarmLight_Spinner`.
- Rooms: `Room_<short>.glb` with `Cam_<short>` (Camera3D), `CamSpot_<short>`, `WP_<short>_<Character>` empties,
  `Curtain*`, rare swap nodes. Characters `<id>.glb` with clips, optional `eye.L/eye.R` bones, iris `pupil_shrink`.
- `NodeFinder.normalize(name)`: lowercase, strip trailing Blender duplicate suffix (`.001`/`_001`/`-001`/` 001`),
  `left->l`, `right->r`, keep `[a-z0-9]` -> `Door_Left.001`, `door_l`, `DoorL` all match. `find_by_names(root,
  [aliases])` returns the first ALIAS that matches (ordered preference). Plus `collect` (BFS), `find_lights`,
  `find_animation_player`, `find_mesh`, `resolve_clip`.
- QA hard rule: "office.glb light energies and PlayerCamera must survive any re-export" (compare GLB JSON to original).

## Pitfalls (mistakes seen)

renames in Blender silently break lookups -> `release_check` marker asserts.

## Verify

`release_check.gd`, `tools/glb_check.gd`, `tools/loader_check.gd` (exit code = missing count).

## Origin

FNAP. Source notes: REF §1.2, §3.1, §3.3, §5.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
