---
id: contact-sheet-visual-qa
title: "Contact sheet of all generated art for visual QA (the agent's "eyes")"
category: testing-qa
when: "After any art generation; before building; to review art with an image-reading tool."
related: []
origin: Roguelike series
---

# Contact sheet of all generated art for visual QA (the agent's "eyes")

**When to use:** After any art generation; before building; to review art with an image-reading tool.

## Do this

```python
def sheet(files, k, bg=(40,36,52,255), pad=3):
    ims = [Image.open(f).convert("RGBA") for f in files]
    W = sum(i.width*k + pad for i in ims); H = max(i.height*k for i in ims) + pad*2
    s = Image.new("RGBA", (W, H), bg); x = pad
    for i in ims:
        s.alpha_composite(i.resize((i.width*k, i.height*k), Image.NEAREST), (x, H - pad - i.height*k)); x += i.width*k + pad
    return s
# rows: enemies x4, player+npcs+hub props x4, bosses x3, each tile strip x4, icons+door icons+hearts x4; stacked on (20,18,28)
```
- Background is a mid-dark purple so both dark outlines and black silhouettes remain visible.
- Then READ the PNG with the image viewer and judge silhouettes, palette coherence, outline consistency.

## Pitfalls (mistakes seen)

reviewing art only at 1x or only via colour counts misses unreadable silhouettes; always look at a scaled sheet.

## Verify

sheet ~1933x864 for a full game.

## Origin

Roguelike series. Source notes: _tools/contact.py (all).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
