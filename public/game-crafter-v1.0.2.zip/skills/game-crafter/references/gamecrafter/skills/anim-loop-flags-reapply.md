---
id: anim-loop-flags-reapply
title: "Re-apply animation loop flags after loading glTF (AnimImport)"
category: godot-engine
when: "Imported characters play walk/idle once and freeze; loading glb at runtime."
related: [clip-manifest-json]
origin: FNAP
---

# Re-apply animation loop flags after loading glTF (AnimImport)

**When to use:** Imported characters play walk/idle once and freeze; loading glb at runtime.

## Do this

- glTF has no loop flag; the editor import script does NOT run for models loaded at runtime (GLTFDocument / PackedScene load keeps `loop_mode = NONE` for many clips).
- Policy: everything loops except listed one-shots; better, ship `clips.json` (clip-manifest-json) for per-clip overrides.
```gdscript
class_name AnimImport extends RefCounted
const ONE_SHOTS: Array[String] = ["jumpscare", "death", "attack", "hit", "get_up", "sit_down"]   # EDIT per game
static func apply_loops(scene: Node) -> void:
    if scene == null: return
    for ap in scene.find_children("*", "AnimationPlayer", true, false):
        for lib_name in ap.get_animation_library_list():
            var lib: AnimationLibrary = ap.get_animation_library(lib_name)
            for anim_name in lib.get_animation_list():
                var a: Animation = lib.get_animation(anim_name)
                a.loop_mode = Animation.LOOP_NONE if String(anim_name) in ONE_SHOTS else Animation.LOOP_LINEAR
```

## Pitfalls (mistakes seen)

loop flags lost on import -> idle/walk froze after one cycle.

## Verify

glb_check lists clips; play idle for > clip length in a check scene and assert `is_playing()`.

## Origin

FNAP. Source notes: T/godot_core/anim_import.gd; G line 32; L §4.6 line 228.

## Related skills

- [clip-manifest-json](clip-manifest-json.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
