---
id: hud-minimal-slice
title: "Minimal slice HUD: talk prompt + active quest card + credit corner"
category: ui-ux
when: "First playable slice before full HUD."
related: []
origin: Caesarea
---

# Minimal slice HUD: talk prompt + active quest card + credit corner

**When to use:** First playable slice before full HUD.

## Do this

HUD on the game root (not a full-screen panel): talk prompt (`[E] Papers` near the NPC), active quest title + first open required objective once active ("Curfew — Get past the Porta Subura checkpoint."), studio credit line in a corner (`Game.CREDITS`). Pause (Esc) = centered card with shadow quality and "Save the night"/load slot. End of slice: "Quest complete: Curfew. To be continued." + credit, any key → title. Don't add a health bar if no system exposes player health (honest gap).

## Origin

Caesarea. Source notes: MANIFEST play layer; PLAY.txt; ITCH_PAGE.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
