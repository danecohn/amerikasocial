# Workflow: 3D horror / night survival (FNAF-style)
Built from FNAP and Pickle's Pickle Shop.

1. **Design**: `fnaf-genre-core-loop`, `fnaf-cast-one-rule-per-enemy`, `fnaf-difficulty-curve-tables`, `fnaf-night-config-dict`, `fnaf-story-bible-template`, `fnaf-phone-script-arc`, `fnaf-fact-ledger-per-night`.
2. **Office & controls**: `fnaf-seated-view-edge-pan`, `office-look-seated-and-door-walk`, `fnaf-clickable-area3d`, `fnaf-controls-input-map`, `fnaf-security-door`, `security-door-shutter-rig`, `fnaf-power-system`, `fnaf-power-out-sequence`, `fnaf-stamina-flashlight-lean-breath`, `flashlight-beam-check`.
3. **Darkness (the core of the fear)**: `dark-horror-environment-values`, `office-darkness-environment`, `darkness-eyes-only-visibility`, `door-nook-pitch-black`, `hall-light-system-assistant-controlled`, `fnaf-office-light-states`, `chair-sight-baffles`. Then check with `os/checklists/horror-atmosphere.md`.
4. **Cameras**: `security-camera-feed-subviewport`, `fnaf-camera-monitor-feed`, `camera-feeds-separate-render-layer`, `dark-but-readable-camera-vs-pitch-black-player`, `fnaf-audio-only-camera`.
5. **Enemies**: `fnaf-animatronic-data-resource`, `fnaf-patrol-movement-ai`, `fnaf-door-encounter-mechanic`, `door-approach-lit-encounter`, `fnaf-cove-runner-enemy`, `fnaf-hallucination-enemy`, `fnaf-eye-rig`, `eye-rig-glow-and-look-at`.
6. **Jumpscares**: `fnaf-jumpscare-3d`, `jumpscare-camera-from-model-height`, `hide-hud-during-jumpscare`, `clip-manifest-json` (every character has its jumpscare clip). Test EVERY jumpscare from the exported build, mid-animation.
7. **Story & audio**: `fnaf-phone-call-playback`, `subtitle-cues-measured-from-audio`, `fnaf-voice-lines-tts`, `voice-bank-manifest-lookup`, `fnaf-adaptive-proximity-music`, `fnaf-audio-manager-ducking`, `fnaf-sound-event-checklist`.
8. **In-game AI helper (optional)**: `in-game-ai-assistant-keyword-parser`, `assistant-auto-mode-unreliable-helper`, `fnaf-crt-terminal-in-world`.
9. **Flow**: `fnaf-night-clock-and-ai-ramp`, `win-screen-5-to-6-am`, `fnaf-6am-and-ending`, `fnaf-custom-night`, `fnaf-crash-safe-forward-only-save`.
10. **3D assets**: `blender-godot-node-name-contract`, `glb-contract-sheet-for-blender-bots`, `fnaf-first-person-arms`, `pose-render-character`.
11. **Balance**: `fnaf-balance-sims`, `patrol-sim-balance`.

Mistakes to read first: `mistake-halls-too-bright`, `mistake-dark-hall-actors-invisible-layers-zero`, `mistake-hall-button-lights-under-hidden-parent`, `mistake-death-through-closed-door`, `mistake-frame-hitch-eats-reaction-window`, `mistake-room-camera-becomes-current`, `mistake-unshaded-import-flashlight-cant-light`, plus every Pickle's Pickle Shop jumpscare and darkness mistake listed under Mistakes in SKILLS.md.
