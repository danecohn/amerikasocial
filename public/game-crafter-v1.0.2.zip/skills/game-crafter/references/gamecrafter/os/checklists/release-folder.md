# Release folder check
```
<GAME>/
├── ADVERTISEMENTS/  itch_cover_630x500.png, screenshot_01..05.png, itch.txt, socials.txt, trailer(s)
├── DISTRIBUTION/    <Game>-Windows-x64.zip, -Windows-ARM64.zip, -macOS.zip, -Linux-x64.zip (+ parts + BUILD_ALL.bat + SHA256.txt)
├── DOCS/            GAME_BIBLE.md, soundtrack.txt, KNOWN_GAPS.md
├── PROJECT/         Godot source (zip) — rebuildable
├── MANIFEST.md
├── STATE.md
└── PLAYER_README.txt
```
- [ ] Every zip: game + `Soundtrack/` + `credits.txt` + `README.txt`; `unzip -tq` clean
- [ ] Machine types checked (x64 0x8664, ARM64 0xaa64); Linux exec bit set
- [ ] SHA256.txt matches; join script tested on the parts
- [ ] Unsigned-build instructions in PLAYER_README (SmartScreen / right-click Open)
- [ ] Screenshots are real in-game captures at the game's aspect ratio; cover is 630x500
- [ ] Credit line and studio name are correct everywhere
- [ ] Nothing uploaded
