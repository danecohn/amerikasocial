# Tool: shot.sh

**Purpose:** Native-resolution (384x216) screenshot of a pixel game under Xvfb.

**Usage:** `bash shot.sh <proj> out.png [args]`

**Skill:** see `skills/headless-screenshot-harness-xvfb.md`

**Extract:** save the block below as `shot.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/bin/bash
# usage: shot.sh <proj> <out.png> [extra user args...]   (384x216 native capture)
P=$1; OUT=$2; shift 2
[ -d "$P/.godot" ] || (cd "$P" && timeout 300 godot --headless --path . --import --quit >/dev/null 2>&1)
XV=$(echo /root/.claude/plugins/synced/*/game-maker/skills/headless-render-capture/scripts/godot_xvfb.sh)
bash $XV -r 384x216 -t ${TMO:-240} -l /tmp/shot_$$.log -- --path "$P" --rendering-driver opengl3 -- --shot="$OUT" "$@" >/dev/null 2>&1
grep -E "SHOT_OK|SCRIPT ERROR|ERROR|PLACEHOLDER|WIRING" /tmp/shot_$$.log | head -20
rm -f /tmp/shot_$$.log
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
