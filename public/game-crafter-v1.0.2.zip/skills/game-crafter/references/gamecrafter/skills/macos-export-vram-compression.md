---
id: macos-export-vram-compression
title: "macOS universal export needs both VRAM compression formats enabled"
category: export-release
when: "Adding a macOS preset; first macOS export fails with 'no textures format'."
related: []
origin: FNAP
---

# macOS universal export needs both VRAM compression formats enabled

**When to use:** Adding a macOS preset; first macOS export fails with "no textures format".

## Do this

In project.godot `[rendering] textures/vram_compression/import_s3tc_bptc=true` AND `textures/vram_compression/import_etc2_astc=true` (universal = x86_64 + arm64). L §2.14 additionally mentions macOS preset `texture_format/s3tc_bptc=true` (inference, re-verify). Enabling only one -> export complains about texture format.

## Pitfalls (mistakes seen)

first macOS export failed (M27).

## Verify

`godot --headless --path <proj> --export-release "macOS" out/Game-mac.zip` exits 0 and zip contains `.app`.

## Origin

FNAP. Source notes: G line 41; L §2.14 line 146; R line 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
