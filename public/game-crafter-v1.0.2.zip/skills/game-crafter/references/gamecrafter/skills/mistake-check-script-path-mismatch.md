---
id: mistake-check-script-path-mismatch
title: "Mistake - QA script used a different asset path than the game"
category: mistake
when: "Writing check scripts for assets."
related: []
origin: FNAP
---

# Mistake - QA script used a different asset path than the game

**When to use:** Writing check scripts for assets.

## What happened, root cause, fix, prevention

- Symptom: audio_check reported missing phone audio (or passed) independently of what the game actually loads.
- Root cause: check used `res://assets/audio/phone-night-N.wav`, game used `.../sfx/phone-night-N.wav`.
- Fix: checks call the same resolver/registry function as the game.
- Prevention: no hard-coded paths in checks; import the game's lookup.
- Detection: grep checks for literal `res://` paths.

## Verify

check fails when an asset is removed (negative test).

## Origin

FNAP. Source notes: L §2.12 line 137.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
