---
id: jumpscare-camera-from-model-height
title: "Jumpscare scare-camera framed from the real model height"
category: 3d-lighting-horror
when: "Building a FNAF-style jumpscare with differently-sized characters."
related: []
origin: Pickle's Pickle Shop
---

# Jumpscare scare-camera framed from the real model height

**When to use:** Building a FNAF-style jumpscare with differently-sized characters.

## Do this

Teleport the attacker in front of the player camera, face it toward the camera, then add a dedicated Camera3D as a CHILD of the attacker so animation lunges stay framed. Measure the model's top in actor-local space over all MeshInstance3D AABBs.
```gdscript
func play(a: Animatronic, camera: Camera3D, look: OfficeLook) -> void:
    var cam_xf := camera.global_transform
    var forward := -cam_xf.basis.z; forward.y = 0.0
    forward = forward.normalized() if forward.length() > 0.01 else Vector3.FORWARD
    var pos := cam_xf.origin + forward * 0.75
    pos.y = cam_xf.origin.y - 1.75 + 0.1
    a.jumpscaring = true; a.visible = true; a._apply_eyes_only(false)
    a.global_position = pos
    var cam_flat := Vector3(cam_xf.origin.x, pos.y, cam_xf.origin.z)
    a.look_at(pos + (pos - cam_flat), Vector3.UP, true)   # models face +Z
    var h := _model_height(a); var face_y := h * 0.78
    var dist := clampf(h * 0.62, 0.8, 1.5)
    var face_light := OmniLight3D.new(); face_light.light_energy = 3.5
    face_light.omni_range = 4.0; face_light.position = Vector3(0, face_y, dist * 0.6)
    a.add_child(face_light)
    var sc := Camera3D.new(); sc.name = "JumpscareCamera"; sc.fov = 55.0; sc.near = 0.05
    sc.position = Vector3(0, face_y, dist); a.add_child(sc)
    sc.look_at(a.global_position + Vector3.UP * face_y, Vector3.UP); sc.current = true
    a.play_clip(a.data.jumpscare_clip, false)
    var tw := a.create_tween()
    tw.tween_property(a, "global_position", a.global_position + a.global_transform.basis.z * 0.28, 0.18).set_trans(Tween.TRANS_QUAD)
func _model_height(a) -> float:
    var top := 0.0
    for n in NodeFinder.collect(a.get_node("Model")):
        if n is MeshInstance3D and n.mesh:
            var box = a.global_transform.affine_inverse() * n.global_transform * n.get_aabb()
            top = maxf(top, box.end.y)
    return top if top > 0.3 else 1.7
```
Extras: red flash ColorRect on CanvasLayer 60 (alpha 0->0.35 in 0.05s, ->0 in 0.25s), camera shake = 1.0, SFX `Sfx.jumpscare(id)` +2 dB, music sting -3 dB, duration 1.6 s (2.6 s for hallucination character). After: free scare cam, restore player camera `current = true`, emit `finished`. If no Model node (placeholder), scale-pop 0.85 -> 1.25 with TRANS_BACK.

## Pitfalls (mistakes seen)

Fixed head height 1.75 cut off short characters; models face +Z but `look_at` aims -Z so pass `use_model_front = true` (third arg) or aim away from the camera.

## Verify

Screenshot every character's jumpscare; face centred in top third; model textured.

## Origin

Pickle's Pickle Shop. Source notes: scripts/jumpscare/jumpscare.gd L12-102.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
