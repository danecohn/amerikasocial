---
id: fnaf-crt-terminal-in-world
title: "In-world CRT terminal (SubViewport text on a mesh, animated face, typewriter)"
category: ui-ux
when: "A screen inside the 3D world must show live text/UI."
related: [mistake-subtitle-overflow]
origin: FNAP
---

# In-world CRT terminal (SubViewport text on a mesh, animated face, typewriter)

**When to use:** A screen inside the 3D world must show live text/UI.

## Do this

- Terminal text: `RichTextLabel` (14 lines, `scroll_following`) in a 640x480 `SubViewport` with static shader + scanlines,
  used as `albedo_texture` AND `emission_texture` on the CRT mesh (unshaded, emission 1.4) via `material_override`.
- Left column = animated face: `AnimatedSprite2D` built from `assistant_face/<expr>/NNNN.png` per `manifest.json`
  (canvas 256x192, nearest filter, per-expression fps/frames/loop/hold_frame). 108 frames in 5 expressions
  (idle_smug 36, listening 24, talking 18, glitch 12, apologies 24), opaque RGB with baked scanlines/phosphor bloom,
  12 fps. Copy to the CRT texture only when the frame changed (`_push_face_texture`).
- Typewriter reveal 2 chars/frame; LED mesh pulses with speech; text mirrored as HUD subtitle ("PICKLE-GPT: ...").
- Typing mode locks look, tweens camera to keyboard (FOV 54, pitch -17 deg), plays `fp_type`/`fp_dock`.
- `_team/props.md` contract: "do not set `material_override` on `Screen`" (owner-specific rule; know which mesh owns
  the override).

## Pitfalls (mistakes seen)

mistake-subtitle-overflow (mirroring long terminal text into the HUD).

## Verify

`--fnap-shot-assistant=<phrase>` screenshot flag.

## Origin

FNAP. Source notes: REF §2.11 Presentation, §3.6, §7, §1.7.

## Related skills

- [mistake-subtitle-overflow](mistake-subtitle-overflow.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
