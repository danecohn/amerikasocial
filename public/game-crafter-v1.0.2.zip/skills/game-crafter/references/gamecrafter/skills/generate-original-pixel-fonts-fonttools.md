---
id: generate-original-pixel-fonts-fonttools
title: "Generate original TTF fonts from 5×7 bitmaps with fontTools (when font downloads are blocked)"
category: ui-ux
when: "Need a license-clean UI/terminal font; Google Fonts/npm blocked in the cloud."
related: []
origin: Caesarea
---

# Generate original TTF fonts from 5×7 bitmaps with fontTools (when font downloads are blocked)

**When to use:** Need a license-clean UI/terminal font; Google Fonts/npm blocked in the cloud.

## Do this

Dict of glyph rows ("01110", …) for A–Z, 0–9, punctuation; lowercase mapped to uppercase shapes. UNIT 100 font units per pixel, ascender 7×UNIT (+80), descender 150, advance 6×UNIT (+tracking). Each "1" cell drawn as a square, or an octagon with chamfer for a "carved" look:
```python
fb = FontBuilder(1000, isTTF=True); fb.setupGlyphOrder(order); fb.setupCharacterMap(cmap)
fb.setupGlyf(glyphs); fb.setupHorizontalMetrics(metrics)
fb.setupHorizontalHeader(ascent=ASC+80, descent=-DESC)
fb.setupNameTable({"familyName": family, "styleName": "Regular", "copyright": "Original design. Developed by <Studio>."})
fb.setupOS2(sTypoAscender=ASC+80, sTypoDescender=-DESC, usWinAscent=ASC+80, usWinDescent=DESC); fb.setupPost(); fb.save(path)
```
Two faces from one grid: Terminal (chamfer 0, pad 0, tracking 0) and Carved (chamfer 22, pad 4, tracking 40). Glyph pen: `TTGlyphPen(None)`, moveTo/lineTo/closePath per cell. Alternative: OFL fonts from system packages (Lora, Inter) with a README-fonts.txt licence note; keep font constants swappable in the theme.

## Pitfalls (mistakes seen)

First import of new fonts crashed Godot on Windows writing `.fontdata*.tmp` (access violation) → retry import.

## Origin

Caesarea. Source notes: tools/make_fonts.py; assets/ui/fonts/README-fonts.txt; MANIFEST fonts.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
