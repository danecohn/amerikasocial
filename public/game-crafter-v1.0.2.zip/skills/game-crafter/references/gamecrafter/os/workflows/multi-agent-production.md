# Workflow: multi-agent production
1. Vertical slice first (`vertical-slice-first`). Start with 3–5 roles.
2. Write OWNERS.md and BOARD.md (`template-owners-file`, `template-board-log`, `multi-agent-team-ownership-boundaries`, `interface-contracts-for-parallel-agents`).
3. Art and code in parallel: `parallel-blender-godot-passes-ownership`, `kitslot-placeholder-until-glb-exists`, `glb-contract-sheet-for-blender-bots`.
4. Prompts: `os/agents/SUBAGENTS.md`; handoff to an IDE AI: `handoff-prompt-for-another-ai` + `os/templates/HANDOFF_PROMPT.md`.
5. Changes that cross ownership: `cross-cutting-change-requests`. Merge hazards: `integration-hazard-diverged-trees`.
6. Logs: `append-only-progress-log`, `art-status-files-per-team`.
7. An independent verifier signs off on the exported build.
Mistakes: `mistake-overwide-multiagent`, `mistake-multi-agent-launch-stalled`, the interrupted 13-agent launch, and the key-binding clashes between agents.
