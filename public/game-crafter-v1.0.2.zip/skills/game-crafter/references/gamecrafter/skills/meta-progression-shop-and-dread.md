---
id: meta-progression-shop-and-dread
title: "Permanent upgrades (shrine) bought with run currency + unlockable difficulty tiers"
category: rpg-systems
when: "Adding roguelite meta progression and post-win difficulty."
related: []
origin: Roguelike series
---

# Permanent upgrades (shrine) bought with run currency + unlockable difficulty tiers

**When to use:** Adding roguelite meta progression and post-win difficulty.

## Do this

- Meta defs `{id, name, desc, cost, step, max, effect: {stat, add|mul}}`; price = cost + step*level; list shows "NAME  lv/max", right column price or MAX; disabled (`off`) if maxed or unaffordable (deny sfx). Buying writes save immediately and `refresh_stats()`.
- Standard 8 (gk.meta): hp (+1 heart, 30/+25, max4), dmg (+10%, 25/+25, max5), speed (+5%, 20/+20, max4), ability cd (-8%, 25/+20, max3), currency gain (+10%, 40/+30, max3), luck (60/+50, max2), light radius (+0.3, 35/+30, max3) OR reach (+8, 35/+30, max3), regen (10% heal on clear, 45/+35, max3).
- Currency at run end: `gain = (run mem + (floor_i+1)*4 + (40 if win)) * mem_mul`; added to save memories; runs/deaths/wins/best_floor updated; save written BEFORE any death animation (crash-safe).
- Dread: winning raises `max_dread = max(max_dread, min(5, dread+1))`; descend door shows a "HOW DEEP?" list when max_dread>0; level i: enemy HP x(1+0.25i), spawn budget x(1+0.15i).
- Permadeath of the run: Game.run wiped every run start; only save (meta, currency, flags, fragments, beats) persists.

## Pitfalls (mistakes seen)

none recorded.

## Verify

`--memories=500 --scene=hub` buy all; `--wins=1 --max_dread=3` shows dread menu.

## Origin

Roguelike series. Source notes: hub.gd _shop/_descend; run.gd _end_run; gk.py meta().

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
