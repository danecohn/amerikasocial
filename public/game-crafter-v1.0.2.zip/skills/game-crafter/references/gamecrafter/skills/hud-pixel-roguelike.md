---
id: hud-pixel-roguelike
title: "Pixel HUD: hearts, cooldown pip, resource bar, floor/room label, currency, boon icons, boss bar, banners, toasts"
category: ui-ux
when: "Building a HUD for a 384x216 action game."
related: []
origin: Roguelike series
---

# Pixel HUD: hearts, cooldown pip, resource bar, floor/room label, currency, boon icons, boss bar, banners, toasts

**When to use:** Building a HUD for a 384x216 action game.

## Do this

- CanvasLayer 20; one Control drawing everything in `_draw` (redrawn each frame), 24px top panel with 1px accent line.
- Left: hearts strip 3 frames (full/half/empty) at x 5+10i; ability cooldown bar 40x3 at (5,14) (accent when ready, darkened otherwise); resource bar 60x3 at (5,18) + label.
- Centre: floor name (y11) + sub label darkened (y21). Right: currency icon + number, up to 15 boon icons from right edge.
- Boss bar: 260px wide at y 205-212, black frame, danger colour fill, name above at y 202.
- Banner: title font 30 centred at y 78 (auto-shrinks 30->20->10 to fit W-24), subtitle at y116; fades over last 0.8s. Toast: one line at y 28, fades in last 0.5s.

## Pitfalls (mistakes seen)

none.

## Verify

screenshot in combat and boss.

## Origin

Roguelike series. Source notes: kit/kit/hud.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
