---
id: headless-godot-needs-xvfb-software-vulkan
title: "Render Godot pixels on a GPU-less box (godot_xvfb.sh)"
category: environment-tools
when: "Any screenshot/video/visual check from Godot in a cloud container or CI without GPU/display."
related: []
origin: FNAP
---

# Render Godot pixels on a GPU-less box (godot_xvfb.sh)

**When to use:** Any screenshot/video/visual check from Godot in a cloud container or CI without GPU/display.

## Do this

`godot --headless` uses a DUMMY renderer: screenshots are black/empty. Use Xvfb + software Vulkan ICD + `--rendering-driver vulkan`. ICD search order: `$VK_ICD_FILENAMES`, Playwright Chromium `/opt/pw-browsers/*/chrome-linux/vk_swiftshader_icd.json`, mesa lavapipe `/usr/share/vulkan/icd.d/lvp_icd*.json`; else fall back to `--rendering-driver opengl3` (llvmpipe; works but does not look like Forward+) or `apt install mesa-vulkan-drivers`.
```bash
# godot_xvfb.sh [-r WxH] [-t timeout_s] [-l logfile] -- <godot args...>
RES=1280x720; TMO=600; LOG=""
while getopts "r:t:l:" o; do case $o in r) RES=$OPTARG;; t) TMO=$OPTARG;; l) LOG=$OPTARG;; esac; done; shift $((OPTIND-1)); [ "${1:-}" = "--" ] && shift
ICD="${VK_ICD_FILENAMES:-}"
[ -z "$ICD" ] && ICD=$(ls /opt/pw-browsers/*/chrome-linux/vk_swiftshader_icd.json 2>/dev/null | head -1)
[ -z "$ICD" ] && ICD=$(ls /usr/share/vulkan/icd.d/lvp_icd*.json 2>/dev/null | head -1)
export VK_ICD_FILENAMES="$ICD"
CMD=(timeout "$TMO" xvfb-run -a -s "-screen 0 ${RES}x24" "${GODOT:-godot}" --rendering-driver vulkan --resolution "$RES" "$@")
if [ -n "$LOG" ]; then "${CMD[@]}" >"$LOG" 2>&1; rc=$?; tail -5 "$LOG"; else "${CMD[@]}"; rc=$?; fi
[ $rc -eq 124 ] && echo "TIMED OUT after ${TMO}s - scene never quit()? add get_tree().quit() / --quit-after" >&2
exit $rc
```
Example: `godot_xvfb.sh -r 1280x720 -t 300 -l /tmp/shot.log -- --path ./proj res://scenes/main.tscn -- --gm-quit-after=10`.

## Pitfalls (mistakes seen)

Black screenshots from `--headless` -> dummy renderer -> use wrapper.

## Verify

Open the PNG; non-black, correct content.

## Origin

FNAP. Source notes: headless-render-capture/scripts/godot_xvfb.sh; SKILL.md "Facts".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
