# Tool: inspect_glb.py

**Purpose:** List nodes, meshes, materials, skins and animations inside a .glb (no Blender needed).

**Usage:** `python3 inspect_glb.py model.glb`

**Skill:** see `skills/blender-godot-node-name-contract.md`

**Extract:** save the block below as `inspect_glb.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
"""List armatures/bones/actions/meshes/cameras/lights of a .glb so you can write pose scripts and node-name contracts without guessing.
Usage: blender -b --python inspect_glb.py -- /path/model.glb
Prints lines starting ARM / BONE / ACT / MESH / CAM / LIGHT / EMPTY / SHAPEKEYS / MATS."""
import bpy, sys
path = sys.argv[sys.argv.index("--") + 1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.import_scene.gltf(filepath=path)
for o in bpy.data.objects:
    if o.type == 'ARMATURE':
        print("ARM", o.name, len(o.data.bones), "bones")
        for b in o.data.bones: print("BONE", b.name, [round(x, 2) for x in b.head_local], "->", [round(x, 2) for x in b.tail_local])
    elif o.type == 'MESH':
        print("MESH", o.name, "dims", [round(d, 2) for d in o.dimensions], "mats", [m.name for m in o.data.materials if m])
        if o.data.shape_keys: print("SHAPEKEYS", o.name, [k.name for k in o.data.shape_keys.key_blocks])
    elif o.type == 'CAMERA': print("CAM", o.name, [round(x, 2) for x in o.location], "fov", round(o.data.angle, 3))
    elif o.type == 'LIGHT': print("LIGHT", o.name, o.data.type, "energy", o.data.energy)
    elif o.type == 'EMPTY': print("EMPTY", o.name, [round(x, 2) for x in o.location])
    if o.keys():
        print("EXTRAS", o.name, {k: o[k] for k in o.keys() if not k.startswith("_")})
for a in bpy.data.actions: print("ACT", a.name, "frames", [round(x) for x in a.frame_range])
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
