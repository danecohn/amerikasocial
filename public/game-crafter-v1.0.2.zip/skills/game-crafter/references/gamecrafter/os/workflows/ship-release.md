# Workflow: ship (Windows x64, Windows ARM64, macOS, Linux)
1. Gate: `os/checklists/pre-delivery.md` + `os/checklists/export-verify.md`.
2. Presets: `export-presets-four-platforms`, `export-include-filter-facts`, `macos-export-vram-compression`, `windows-arm64-build`.
3. Export: `godot-headless-export-commands`, `four-platform-export-script` / `build-release-sh` / `build-release-ps1`.
4. Zips: `release-zip-layout-and-exec-bits` (Linux exec bit, the mac .app), each with `Soundtrack/` (`soundtrack-packaging`), credits and README (`player-readme-unsigned-builds`).
5. Check: `verify-exe-architecture` (0x8664 / 0xaa64), `unzip -tq`, size versus the last good build, a screenshot from the exported build.
6. Too big to transfer? `split-zip-parts-and-build-all-bat` / `split-zip-parts-assemble-ps1` + SHA256.
7. Folder: `per-game-delivery-folder-layout`, `os/checklists/release-folder.md`.
8. Deliver: `deliver-to-pc.md`. Never upload to stores unless asked (`never-publish-unless-asked`).
9. Report: `honest-ship-report`, `verified-vs-not-verified-reporting`.
Mistakes: `mistake-zip-exec-bit-lost`, `mistake-macos-export-vram-formats`, `mistake-icon-not-embedded`, `mistake-export-wrong-preset-silent`, `mistake-delivered-old-files`, `mistake-30mb-commit-limit`.
