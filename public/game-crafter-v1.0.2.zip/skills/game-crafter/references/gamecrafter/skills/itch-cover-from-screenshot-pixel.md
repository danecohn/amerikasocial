---
id: itch-cover-from-screenshot-pixel
title: "itch.io cover 630x500 composed at native 210x167 and nearest-scaled x3"
category: promo-marketing
when: "Making store cover art for a pixel game from a real gameplay capture."
related: [mistake-cover-sky-band-invisible]
origin: Roguelike series
---

# itch.io cover 630x500 composed at native 210x167 and nearest-scaled x3

**When to use:** Making store cover art for a pixel game from a real gameplay capture.

## Do this

- Usage: `cover.py <shot 384x216> <title.ttf> <line1> <line2> <tagline> <out.png> [cropx=100] [cropy=40] [title_color=#f2e7c8] [accent=#ff9a3c]`.
- Native canvas 210x167 (x3 = 630x500 exactly). Crop 210x105 of the shot at (cropx,cropy) pasted at y=62; top 62px for the title block on dark `(6,8,12)`.
- Fades: rows 62-75 gradient alpha `(76-y)*14` dark band into the gameplay; bottom rows 150-166 alpha `(y-150)*10`.
- Title lines auto-fit: start size 20, shrink by 1 until `getlength <= 192`, min 8; centred; y=4 then +size+1. Tagline fit to 196 from size 10 at y=49 in accent. Shadow = black copies at (+1,+1),(0,+1),(+1,0) (a 1px drop "extrude").
- Studio icon 16x16 (nearest) at (3,148). Convert RGB, `resize((630,500), NEAREST)`.
- Shipped LAST LAMP cover: "THE LAST / LAMP", tagline "DESCEND. REMEMBER. RELIGHT." in orange, crop shows the beam fight.
- NOTE font sizes like 17-19 from auto-fit break the 10-unit pixel grid (uneven strokes) - prefer stepping 20 -> 10 for pixel fonts.

## Pitfalls (mistakes seen)

see mistake-cover-sky-band-invisible; hard-coded icon path `/home/claude/evac/kit/assets/branding/fw_icon.png`.

## Verify

output 630x500; zoom: all pixels 3x3 blocks.

## Origin

Roguelike series. Source notes: _tools/cover.py (all); THE LAST LAMP/ADVERTISEMENTS/itch_cover_630x500.png.

## Related skills

- [mistake-cover-sky-band-invisible](mistake-cover-sky-band-invisible.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
