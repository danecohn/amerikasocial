---
id: hitstop-shake-fx-juice
title: "Cheap game-feel: hitstop, screen shake, pixel particles, rings, slash arcs, damage numbers"
category: gameplay-systems
when: "Making combat feel good in a 2D pixel game with no particle nodes."
related: []
origin: Roguelike series
---

# Cheap game-feel: hitstop, screen shake, pixel particles, rings, slash arcs, damage numbers

**When to use:** Making combat feel good in a 2D pixel game with no particle nodes.

## Do this

- Hitstop: `Engine.time_scale = 0.08` for 0.035s (0.02 on bosses) via a timer that ignores time scale `create_timer(t, true, false, true)`, then restore `Game.base_scale` (respects --speed); single-flight guard.
- Shake: `Game.shake(a)` keeps the max; decays 14/s; a parent Node2D offset by random +-a rounded to whole pixels; off via settings.
- Fx node (z 50) holds arrays of particles/rings/arcs/texts, updates and `queue_redraw` each frame; particles squares of size 1-2 at floored positions, velocity *0.92 per frame, alpha by life; rings expand 2->max_r; arcs double-stroke (2px + 1px lighter); floating text drifts up 14px/s with 1px black shadow.
- Hit = number popup + blood-coloured burst (per-enemy `blood` hex) + "hit" sfx + hitstop; enemy white flash `Color(2.2,2.2,2.2)` for 0.09s; player hurt flash Color(2,2,2) and red post flash.
- Enemy spawn telegraph ring (0.7s) - fairness.

## Pitfalls (mistakes seen)

none.

## Verify

visual.

## Origin

Roguelike series. Source notes: world.gd hitstop/_process; fx.gd; enemy.gd take_hit.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
