---
id: mistake-concurrent-imports
title: "Mistake - running two Godot processes on one project during import"
category: mistake
when: "Starting a capture/test while an import runs; parallel agents on one project."
related: []
origin: FNAP
---

# Mistake - running two Godot processes on one project during import

**When to use:** Starting a capture/test while an import runs; parallel agents on one project.

## What happened, root cause, fix, prevention

- Symptom: corrupted `.godot` import cache, missing resources, weird load failures.
- Root cause: two concurrent imports / a game run during the first import.
- Fix: kill extra processes, delete `.godot/imported` if corrupted, run one import.
- Prevention: single-owner import, `IMPORT_DONE` sentinel, captures only after it.
- Detection: `pgrep -a godot` before starting.

## Verify

clean single import log ending `EXIT 0`.

## Origin

FNAP. Source notes: L §2.10, §5.7; G line 13.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
