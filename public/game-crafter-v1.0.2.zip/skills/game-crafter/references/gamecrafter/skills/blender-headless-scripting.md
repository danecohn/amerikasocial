---
id: blender-headless-scripting
title: "Run Blender headless with args and sentinels"
category: 3d-blender
when: "Any Blender automation."
related: []
origin: FNAP
---

# Run Blender headless with args and sentinels

**When to use:** Any Blender automation.

## Do this

`blender -b --python script.py -- <args>`; parse `sys.argv[sys.argv.index("--")+1:]`. Start from `bpy.ops.wm.read_factory_settings(use_empty=True)`. Print sentinels (`print("DONE", out)`) and grep logs for `DONE|Error|Traceback` (Blender 5.x spams harmless `use_nodes` DeprecationWarnings; use_nodes deprecated in Blender 6). Address shader sockets BY NAME (`inputs["Base Color"]`, `inputs['Roughness']`), never by index (indices change between versions; M44).

## Pitfalls (mistakes seen)

Socket-index scripts broke across versions -> name lookup.

## Verify

DONE line present.

## Origin

FNAP. Source notes: blender-assets/SKILL.md intro + bullets; make_test_glb.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
