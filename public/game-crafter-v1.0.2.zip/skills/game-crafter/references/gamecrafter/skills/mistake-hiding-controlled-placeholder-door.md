---
id: mistake-hiding-controlled-placeholder-door
title: "Real office load hid the door rigs (placeholder held the controller)"
category: mistake
when: "Swapping placeholder geometry for authored models."
related: []
origin: FNAP
---

# Real office load hid the door rigs (placeholder held the controller)

**When to use:** Swapping placeholder geometry for authored models.

## What happened, root cause, fix, prevention

- Symptom: doors stop working/disappear after the real office GLB loads.
- Root cause: loading the real office hid the placeholder door boxes, and the door rigs (SecurityDoor with state/signals)
  lived on those placeholders.
- Fix: adopt real nodes onto the rig (`adopt_model_node`, `adopt_lever`, `adopt_button`).
- Prevention: "never hide the node you control"; report role resolution in `office_wiring`.

## Verify

door_lurker_sim door motion case passes with the real office.

## Origin

FNAP. Source notes: REF §8.2 #3, §2.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
