# Tool: tiles.py

**Purpose:** Procedural pixel-art tiles, props and UI frames for 8-bit games.

**Usage:** `python3 tiles.py (imported by buildgame.py)`

**Skill:** see `skills/tileset-theme-dict.md`

**Extract:** save the block below as `tiles.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Procedural pixel-art tile / prop / UI generator. Forgotten Woods Studios.
theme dict:
  floor: [c1,c2,c3] hex, fpat: flagstone|planks|tile|dirt|grass|metal|salt|cobble|carpet
  wall:  [top, face, face_dark, hi], wpat: brick|stone|wood|hedge|tile|salt|metal|corn
  block: pillar|crate|statue|rock|desk|pew|bed|tomb|barrel|cage|hay|machine
  decor: list of 4 from: bones|puddle|moss|crack|candle|blood|rubble|flowers|web|paper|salt|glass|ash|petals|chain|toys
  door: wood|iron|arch|gate
  glow: hex (door glow)
"""
import random, math
from PIL import Image, ImageDraw
from sprites import hexc, mix, light, dark, new, D, solid, scale_up

T = 16


def noise(img, rng, colors, density):
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            if rng.random() < density and px[x, y][3] > 0:
                px[x, y] = rng.choice(colors)


def floor_tile(th, seed, variant=0):
    rng = random.Random(seed * 31 + variant)
    c1, c2, c3 = [hexc(c) for c in th["floor"]]
    img = Image.new("RGBA", (T, T), c1)
    d = D(img)
    pat = th.get("fpat", "flagstone")
    if pat == "flagstone":
        d.line((0, 0, 15, 0), fill=c3)
        d.line((0, 0, 0, 15), fill=c3)
        xs = rng.choice([5, 7, 9, 10])
        d.line((xs, 0, xs, 7), fill=c3)
        xs2 = rng.choice([4, 6, 11])
        d.line((xs2, 8, xs2, 15), fill=c3)
        d.line((0, 8, 15, 8), fill=c3)
        d.line((1, 1, 14, 1), fill=light(c1, .08))
        noise(img, rng, [c2, light(c1, .06), dark(c1, .12)], 0.18)
    elif pat == "planks":
        for y in range(0, 16, 4):
            d.line((0, y, 15, y), fill=c3)
            off = rng.choice([3, 6, 9, 12]) if (y // 4) % 2 else rng.choice([2, 7, 13])
            d.line((off, y + 1, off, y + 3), fill=c3)
            d.point((off + 1, y + 2), fill=c2)
        for y in range(16):
            for x in range(16):
                if rng.random() < 0.12:
                    img.putpixel((x, y), rng.choice([c2, dark(c1, .1)]))
    elif pat == "tile":
        for i in range(0, 16, 8):
            d.line((i, 0, i, 15), fill=c3)
            d.line((0, i, 15, i), fill=c3)
        for bx in (0, 8):
            for by in (0, 8):
                if (bx + by) // 8 % 2 == 0:
                    d.rectangle((bx + 1, by + 1, bx + 7, by + 7), fill=c2)
        d.point((rng.randint(1, 14), rng.randint(1, 14)), fill=light(c1, .2))
        noise(img, rng, [dark(c1, .08)], 0.06)
    elif pat == "dirt":
        noise(img, rng, [c2, c3, dark(c1, .1)], 0.35)
        for _ in range(rng.randint(1, 3)):
            x, y = rng.randint(1, 13), rng.randint(1, 13)
            d.rectangle((x, y, x + 1, y), fill=light(c2, .2))
    elif pat == "grass":
        noise(img, rng, [c2, c3], 0.3)
        for _ in range(rng.randint(3, 6)):
            x, y = rng.randint(1, 14), rng.randint(2, 14)
            d.line((x, y, x, y - 2), fill=light(c2, .25))
    elif pat == "metal":
        d.rectangle((0, 0, 15, 15), outline=c3)
        d.line((1, 1, 14, 1), fill=light(c1, .12))
        for (x, y) in ((2, 2), (13, 2), (2, 13), (13, 13)):
            d.point((x, y), fill=c2)
        noise(img, rng, [dark(c1, .08), c2], 0.1)
        if variant == 1:
            d.line((4, 8, 11, 8), fill=c3)
    elif pat == "salt":
        noise(img, rng, [c2, light(c1, .25), c3], 0.28)
        for _ in range(2):
            x, y = rng.randint(1, 13), rng.randint(1, 13)
            d.point((x, y), fill=hexc("#ffffff"))
        d.line((0, 0, 15, 0), fill=c3)
    elif pat == "cobble":
        for (x, y) in ((1, 1), (9, 1), (5, 8), (13, 8), (1, 12)):
            r = 3
            d.ellipse((x - 1, y - 1, x + r + 1, y + r), fill=c2, outline=c3)
        noise(img, rng, [dark(c1, .1)], 0.1)
    elif pat == "carpet":
        d.rectangle((0, 0, 15, 15), fill=c1)
        for y in range(0, 16, 2):
            for x in range((y // 2) % 2, 16, 2):
                img.putpixel((x, y), c2)
        d.line((0, 0, 15, 0), fill=c3)
    return img


def wall_top_tile(th, seed):
    rng = random.Random(seed + 5)
    top = hexc(th["wall"][0])
    img = Image.new("RGBA", (T, T), top)
    noise(img, rng, [dark(top, .15), light(top, .08)], 0.25)
    d = D(img)
    d.line((0, 15, 15, 15), fill=dark(top, .4))
    return img


def wall_face_tile(th, seed):
    rng = random.Random(seed + 9)
    top, face, fdark, hi = [hexc(c) for c in th["wall"]]
    img = Image.new("RGBA", (T, T), face)
    d = D(img)
    pat = th.get("wpat", "brick")
    if pat == "brick":
        for y in range(0, 16, 4):
            d.line((0, y, 15, y), fill=fdark)
            off = 4 if (y // 4) % 2 else 0
            for x in range(off, 16, 8):
                d.line((x, y, x, y + 3), fill=fdark)
    elif pat == "stone":
        for (x, y, w, h) in ((0, 0, 8, 7), (8, 0, 8, 5), (0, 7, 5, 9), (5, 7, 11, 9), (8, 5, 8, 2)):
            d.rectangle((x, y, x + w - 1, y + h - 1), outline=fdark)
    elif pat == "wood":
        for x in range(0, 16, 4):
            d.line((x, 0, x, 15), fill=fdark)
            d.point((x + 2, rng.randint(2, 12)), fill=hi)
    elif pat == "hedge":
        noise(img, rng, [fdark, hi, dark(face, .1)], 0.45)
    elif pat == "corn":
        for x in range(1, 16, 3):
            d.line((x, 15, x + rng.randint(-1, 1), 0), fill=hi if rng.random() < .4 else fdark)
    elif pat == "tile":
        for y in range(0, 16, 5):
            d.line((0, y, 15, y), fill=fdark)
        for x in range(0, 16, 5):
            d.line((x, 0, x, 15), fill=fdark)
        d.rectangle((0, 12, 15, 15), fill=hi)
    elif pat == "salt":
        noise(img, rng, [fdark, hi, light(face, .3)], 0.4)
        d.polygon([(2, 15), (4, 8), (6, 15)], fill=hi)
        d.polygon([(10, 15), (12, 6), (14, 15)], fill=light(face, .2))
    elif pat == "metal":
        d.line((0, 5, 15, 5), fill=fdark)
        d.line((0, 10, 15, 10), fill=fdark)
        for x in (2, 8, 13):
            d.point((x, 3), fill=hi)
            d.point((x, 8), fill=hi)
    noise(img, rng, [fdark], 0.05)
    d.line((0, 0, 15, 0), fill=hi)
    d.line((0, 14, 15, 14), fill=dark(face, .3))
    d.line((0, 15, 15, 15), fill=dark(face, .55))
    return img


def wall_side_tile(th, seed):
    rng = random.Random(seed + 13)
    top, face, fdark, hi = [hexc(c) for c in th["wall"]]
    img = Image.new("RGBA", (T, T), mix(top, face, 0.4))
    noise(img, rng, [dark(top, .15), light(top, .1)], 0.25)
    d = D(img)
    d.line((0, 0, 0, 15), fill=dark(top, .35))
    d.line((15, 0, 15, 15), fill=dark(top, .35))
    return img


def _floor_bg(th, seed):
    return floor_tile(th, seed, 0)


def block_tile(th, seed):
    kind = th.get("block", "pillar")
    img = _floor_bg(th, seed + 1)
    d = D(img)
    ol = hexc("#0b0a10")
    c1, c2, c3 = [hexc(c) for c in th["floor"]]
    wt, wf, wd, wh = [hexc(c) for c in th["wall"]]
    # shadow
    d.ellipse((1, 11, 14, 15), fill=dark(c1, .45))
    if kind == "pillar":
        d.rectangle((4, 4, 11, 14), fill=wf, outline=ol)
        d.rectangle((3, 2, 12, 4), fill=wh, outline=ol)
        d.rectangle((3, 13, 12, 15), fill=wf, outline=ol)
        d.line((6, 5, 6, 12), fill=wh)
        d.line((10, 5, 10, 12), fill=wd)
    elif kind == "crate":
        d.rectangle((2, 4, 13, 14), fill=hexc("#7a5a35"), outline=ol)
        d.line((2, 4, 13, 14), fill=hexc("#5a4126"))
        d.line((13, 4, 2, 14), fill=hexc("#5a4126"))
        d.rectangle((2, 4, 13, 5), fill=hexc("#9a7448"))
    elif kind == "statue":
        d.rectangle((3, 11, 12, 15), fill=wf, outline=ol)
        d.rectangle((5, 5, 10, 11), fill=wh, outline=ol)
        d.ellipse((5, 1, 10, 6), fill=wh, outline=ol)
        d.rectangle((4, 7, 4, 10), fill=wh)
        d.rectangle((11, 7, 11, 10), fill=wh)
        d.point((6, 3), fill=ol)
        d.point((9, 3), fill=ol)
    elif kind == "rock":
        d.polygon([(2, 14), (3, 7), (7, 3), (12, 6), (14, 14)], fill=wf, outline=ol)
        d.polygon([(3, 8), (7, 4), (9, 5), (6, 9)], fill=wh)
        d.line((9, 8, 11, 13), fill=wd)
    elif kind == "desk":
        d.rectangle((1, 6, 14, 9), fill=hexc("#6b4a2e"), outline=ol)
        d.rectangle((2, 9, 3, 14), fill=hexc("#4a3220"), outline=ol)
        d.rectangle((12, 9, 13, 14), fill=hexc("#4a3220"), outline=ol)
        d.rectangle((4, 4, 6, 6), fill=hexc("#d8d0b8"))
    elif kind == "pew":
        d.rectangle((1, 5, 14, 8), fill=hexc("#5c3d26"), outline=ol)
        d.rectangle((1, 9, 14, 12), fill=hexc("#6e4a2e"), outline=ol)
        d.rectangle((1, 13, 2, 15), fill=hexc("#3a2616"))
        d.rectangle((13, 13, 14, 15), fill=hexc("#3a2616"))
    elif kind == "bed":
        d.rectangle((1, 4, 14, 14), fill=hexc("#8a8a96"), outline=ol)
        d.rectangle((2, 5, 6, 8), fill=hexc("#e6e2da"))
        d.rectangle((2, 9, 13, 13), fill=hexc("#b9b4a8"))
    elif kind == "tomb":
        d.rectangle((4, 4, 11, 14), fill=wf, outline=ol)
        d.ellipse((4, 2, 11, 7), fill=wf, outline=ol)
        d.line((7, 6, 8, 6), fill=ol)
        d.line((7, 5, 7, 9), fill=ol)
    elif kind == "barrel":
        d.ellipse((3, 3, 12, 6), fill=hexc("#8a6a42"), outline=ol)
        d.rectangle((3, 5, 12, 13), fill=hexc("#6e5030"), outline=ol)
        d.ellipse((3, 11, 12, 14), fill=hexc("#6e5030"), outline=ol)
        d.line((3, 8, 12, 8), fill=hexc("#3a3a40"))
    elif kind == "cage":
        d.rectangle((2, 3, 13, 14), outline=ol, fill=dark(c1, .3))
        for x in range(4, 13, 3):
            d.line((x, 4, x, 13), fill=hexc("#8a8a90"))
        d.line((2, 3, 13, 3), fill=hexc("#8a8a90"))
    elif kind == "hay":
        d.ellipse((1, 4, 14, 14), fill=hexc("#c9a64a"), outline=ol)
        d.arc((4, 6, 11, 12), 0, 270, fill=hexc("#8a6a28"))
        d.line((2, 9, 14, 9), fill=hexc("#8a6a28"))
    elif kind == "machine":
        d.rectangle((2, 3, 13, 14), fill=hexc("#5a606c"), outline=ol)
        d.rectangle((4, 5, 8, 8), fill=hexc("#1c1c24"))
        d.point((10, 6), fill=hexc("#ff5040"))
        d.point((11, 6), fill=hexc("#50ff70"))
        d.line((3, 11, 12, 11), fill=hexc("#383c46"))
    return img


def door_tile(th, seed, open_):
    top, face, fdark, hi = [hexc(c) for c in th["wall"]]
    img = wall_face_tile(th, seed)
    d = D(img)
    ol = hexc("#0b0a10")
    glow = hexc(th.get("glow", "#ffcc66"))
    kind = th.get("door", "wood")
    if not open_:
        d.rectangle((2, 0, 13, 15), fill=hexc("#3a2a1e") if kind != "iron" else hexc("#3c424c"), outline=ol)
        if kind == "iron" or kind == "gate":
            for x in range(4, 13, 3):
                d.line((x, 1, x, 14), fill=hexc("#6a707a"))
        else:
            for x in range(5, 13, 4):
                d.line((x, 1, x, 14), fill=hexc("#241810"))
        d.rectangle((10, 8, 11, 9), fill=hexc("#c9a64a"))
        d.line((2, 0, 13, 0), fill=hexc("#5a4030") if kind == "wood" else hexc("#7a808a"))
    else:
        d.rectangle((2, 0, 13, 15), fill=hexc("#05040a"), outline=ol)
        for i in range(6):
            d.line((3, 15 - i * 2, 12, 15 - i * 2), fill=mix(hexc("#05040a"), glow, 0.12 + i * 0.1))
        d.rectangle((6, 3, 9, 9), fill=mix(hexc("#05040a"), glow, 0.35))
    return img


def decor_tile(th, kind, seed):
    rng = random.Random(seed)
    img = new(T, T)
    d = D(img)
    if kind == "bones":
        c = hexc("#d8d0b8")
        d.line((3, 10, 10, 7), fill=c)
        d.point((3, 9), fill=c); d.point((11, 6), fill=c)
        d.ellipse((9, 9, 12, 12), fill=c)
        d.point((10, 10), fill=hexc("#0b0a10")); d.point((11, 10), fill=hexc("#0b0a10"))
    elif kind == "puddle":
        c = hexc(th.get("puddle", "#2a4a66"))
        d.ellipse((2, 6, 13, 12), fill=c)
        d.line((4, 8, 7, 8), fill=light(c, .35))
    elif kind == "moss":
        c = hexc("#3a5a30")
        for _ in range(14):
            d.point((rng.randint(1, 14), rng.randint(2, 13)), fill=rng.choice([c, light(c, .2), dark(c, .2)]))
    elif kind == "crack":
        c = hexc("#0b0a10")
        x, y = 3, 3
        for _ in range(9):
            d.point((x, y), fill=c)
            x += rng.choice([0, 1, 1]); y += rng.choice([1, 1, 0])
    elif kind == "candle":
        d.rectangle((6, 9, 8, 13), fill=hexc("#e8e2c8"))
        d.point((7, 8), fill=hexc("#ffcc44")); d.point((7, 7), fill=hexc("#ff9a30"))
        d.line((5, 14, 9, 14), fill=hexc("#4a3a2a"))
    elif kind == "blood":
        c = hexc("#6a0f18")
        d.ellipse((3, 6, 11, 11), fill=c)
        d.point((12, 12), fill=c); d.point((2, 12), fill=c); d.point((13, 5), fill=c)
    elif kind == "rubble":
        for _ in range(6):
            x, y = rng.randint(2, 12), rng.randint(5, 13)
            d.rectangle((x, y, x + rng.randint(1, 2), y + 1), fill=rng.choice([hexc("#6a6a72"), hexc("#4a4a52"), hexc("#8a8a92")]))
    elif kind == "flowers":
        for _ in range(4):
            x, y = rng.randint(2, 13), rng.randint(5, 13)
            d.point((x, y), fill=rng.choice([hexc("#d8d8e8"), hexc("#d8b84a"), hexc("#c85a8a")]))
            d.point((x, y + 1), fill=hexc("#3a5a30"))
    elif kind == "web":
        c = hexc("#c8c8d0")
        d.line((0, 0, 7, 7), fill=c); d.line((0, 0, 7, 0), fill=c); d.line((0, 0, 0, 7), fill=c)
        d.arc((-4, -4, 5, 5), 0, 90, fill=c); d.arc((-8, -8, 8, 8), 0, 90, fill=c)
    elif kind == "paper":
        d.rectangle((4, 7, 8, 11), fill=hexc("#d8d2bc"))
        d.line((5, 8, 7, 8), fill=hexc("#8a8470")); d.line((5, 10, 7, 10), fill=hexc("#8a8470"))
        d.rectangle((9, 5, 12, 8), fill=hexc("#c8c2ac"))
    elif kind == "salt":
        for _ in range(8):
            x, y = rng.randint(2, 13), rng.randint(3, 13)
            d.point((x, y), fill=hexc("#f4f4ff"))
    elif kind == "glass":
        for _ in range(5):
            x, y = rng.randint(2, 13), rng.randint(5, 13)
            d.line((x, y, x + 1, y - 1), fill=hexc("#a8d0e0"))
    elif kind == "ash":
        for _ in range(16):
            d.point((rng.randint(1, 14), rng.randint(3, 14)), fill=rng.choice([hexc("#2a2a2e"), hexc("#3a3a3e"), hexc("#1a1a1e")]))
    elif kind == "petals":
        for _ in range(7):
            d.point((rng.randint(1, 14), rng.randint(3, 14)), fill=rng.choice([hexc("#c8586a"), hexc("#e8a0b0")]))
    elif kind == "chain":
        c = hexc("#6a6a72")
        for i in range(5):
            d.rectangle((7, 2 + i * 2, 8, 3 + i * 2), fill=c if i % 2 == 0 else dark(c, .3))
    elif kind == "toys":
        d.rectangle((4, 9, 7, 12), fill=hexc("#b8503a"), outline=hexc("#0b0a10"))
        d.ellipse((9, 8, 12, 11), fill=hexc("#d8c04a"))
    return img


def build_tiles(th, seed=1):
    cols = 14 + 0
    sheet = Image.new("RGBA", (T * 14, T))
    tiles = [floor_tile(th, seed, 0), floor_tile(th, seed, 1), floor_tile(th, seed, 2), floor_tile(th, seed + 7, 3),
             wall_top_tile(th, seed), wall_face_tile(th, seed), wall_side_tile(th, seed), block_tile(th, seed),
             door_tile(th, seed, False), door_tile(th, seed, True)]
    for k in th.get("decor", ["crack", "bones", "rubble", "paper"])[:4]:
        tiles.append(decor_tile(th, k, seed + len(tiles)))
    for i, t in enumerate(tiles):
        sheet.paste(t, (i * T, 0))
    return sheet


# ------------------------------------------------------------------- UI art
def heart_frames(col="#d02840"):
    c = hexc(col)
    rows = ["..XX.XX..", ".XXXXXXX.", "XXXXXXXXX", "XXXXXXXXX", ".XXXXXXX.", "..XXXXX..", "...XXX...", "....X...."]
    out = []
    for kind in ("full", "half", "empty"):
        img = new(9, 8)
        for y, r in enumerate(rows):
            for x, ch in enumerate(r):
                if ch != "X":
                    continue
                if kind == "full":
                    px = c
                elif kind == "half":
                    px = c if x < 5 else hexc("#2a2230")
                else:
                    px = hexc("#2a2230")
                img.putpixel((x, y), px)
        # highlight
        if kind != "empty":
            img.putpixel((1, 2), light(c, .5)); img.putpixel((2, 1), light(c, .5))
        # outline
        o = new(11, 10); o.paste(img, (1, 1))
        px = o.load(); src = o.copy().load()
        for y in range(10):
            for x in range(11):
                if src[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        xx, yy = x + dx, y + dy
                        if 0 <= xx < 11 and 0 <= yy < 10 and src[xx, yy][3] > 0:
                            px[x, y] = hexc("#0b0a10"); break
        out.append(o)
    return out


ICON_SHAPES = {
    "sword": ["...XX.....", "..XXX.....", ".XXX......", "XXX.......", "XX.X......", "X.XXX.....", "...XXX....", "....XXX...", ".....XXXX.", "......XXX."],
}


def draw_icon(kind, col, acc):
    img = new(10, 10)
    d = D(img)
    c, a = hexc(col), hexc(acc)
    if kind == "heart":
        d.polygon([(1, 3), (3, 1), (5, 3), (7, 1), (9, 3), (9, 5), (5, 9), (1, 5)], fill=c)
    elif kind == "flame":
        d.polygon([(5, 0), (8, 4), (8, 7), (5, 9), (2, 7), (2, 4), (4, 4)], fill=c); d.polygon([(5, 4), (7, 7), (5, 9), (3, 7)], fill=a)
    elif kind == "bolt":
        d.polygon([(6, 0), (2, 5), (5, 5), (3, 9), (8, 3), (5, 3)], fill=c)
    elif kind == "shield":
        d.polygon([(1, 1), (8, 1), (8, 5), (5, 9), (1, 5)], fill=c); d.line((4, 2, 4, 7), fill=a)
    elif kind == "boot":
        d.rectangle((2, 1, 5, 6), fill=c); d.rectangle((2, 6, 8, 8), fill=c); d.line((2, 8, 8, 8), fill=a)
    elif kind == "eye":
        d.ellipse((0, 2, 9, 7), fill=hexc("#e8e0d0")); d.ellipse((3, 3, 6, 6), fill=c); d.point((4, 4), fill=a)
    elif kind == "star":
        d.polygon([(5, 0), (6, 4), (10, 4), (7, 6), (8, 10), (5, 7), (2, 10), (3, 6), (0, 4), (4, 4)], fill=c)
    elif kind == "drop":
        d.polygon([(5, 0), (8, 5), (8, 7), (5, 9), (2, 7), (2, 5)], fill=c); d.point((4, 6), fill=a)
    elif kind == "skull":
        d.ellipse((1, 0, 8, 6), fill=c); d.rectangle((3, 6, 6, 9), fill=c); d.point((3, 3), fill=hexc("#0b0a10")); d.point((6, 3), fill=hexc("#0b0a10"))
    elif kind == "ring":
        d.ellipse((1, 1, 8, 8), outline=c); d.ellipse((2, 2, 7, 7), outline=a)
    elif kind == "arrow":
        d.line((1, 5, 8, 5), fill=c); d.polygon([(9, 5), (6, 2), (6, 8)], fill=c); d.line((1, 3, 3, 5), fill=a); d.line((1, 7, 3, 5), fill=a)
    elif kind == "wave":
        for x in range(10):
            d.point((x, 5 + int(2.5 * math.sin(x * 0.9))), fill=c)
            d.point((x, 3 + int(2.5 * math.sin(x * 0.9))), fill=a)
    elif kind == "key":
        d.ellipse((0, 1, 4, 5), outline=c); d.line((4, 3, 9, 3), fill=c); d.line((7, 3, 7, 5), fill=c); d.line((9, 3, 9, 5), fill=c)
    elif kind == "moon":
        d.ellipse((1, 1, 8, 8), fill=c); d.ellipse((3, 0, 10, 7), fill=hexc("#00000000"))
        px = img.load()
        for y in range(10):
            for x in range(10):
                if (x - 6) ** 2 + (y - 3.5) ** 2 < 14:
                    px[x, y] = (0, 0, 0, 0)
    elif kind == "clock":
        d.ellipse((0, 0, 9, 9), outline=c); d.line((5, 5, 5, 2), fill=a); d.line((5, 5, 7, 6), fill=a)
    elif kind == "hand":
        d.rectangle((2, 4, 7, 8), fill=c)
        for x in (2, 4, 6):
            d.line((x, 4, x, 1), fill=c)
    elif kind == "note":
        d.ellipse((1, 6, 5, 9), fill=c); d.line((5, 7, 5, 1), fill=c); d.line((5, 1, 8, 3), fill=a)
    elif kind == "leaf":
        d.polygon([(1, 8), (2, 3), (7, 1), (8, 6)], fill=c); d.line((1, 8, 7, 2), fill=a)
    elif kind == "gear":
        d.ellipse((2, 2, 7, 7), fill=c); d.ellipse((4, 4, 5, 5), fill=hexc("#0b0a10"))
        for (x, y) in ((4, 0), (4, 8), (0, 4), (8, 4)):
            d.rectangle((x, y, x + 1, y + 1), fill=c)
    elif kind == "plus":
        d.rectangle((4, 1, 5, 8), fill=c); d.rectangle((1, 4, 8, 5), fill=c)
    elif kind == "crown":
        d.polygon([(1, 8), (1, 2), (3, 5), (5, 1), (7, 5), (9, 2), (9, 8)], fill=c)
    elif kind == "feather":
        d.polygon([(8, 0), (2, 6), (1, 9), (4, 8), (9, 3)], fill=c); d.line((1, 9, 7, 2), fill=a)
    elif kind == "bell":
        d.polygon([(5, 0), (8, 6), (9, 8), (1, 8), (2, 6)], fill=c); d.point((5, 9), fill=a)
    elif kind == "web":
        d.line((0, 5, 9, 5), fill=c); d.line((5, 0, 5, 9), fill=c); d.line((1, 1, 8, 8), fill=c); d.line((8, 1, 1, 8), fill=c); d.ellipse((2, 2, 7, 7), outline=a)
    return finish_icon(img)


def finish_icon(img):
    o = new(12, 12)
    o.paste(img, (1, 1))
    px = o.load(); src = o.copy().load()
    for y in range(12):
        for x in range(12):
            if src[x, y][3] == 0:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    xx, yy = x + dx, y + dy
                    if 0 <= xx < 12 and 0 <= yy < 12 and src[xx, yy][3] > 0:
                        px[x, y] = hexc("#0b0a10"); break
    return o


ICON_ORDER = ["heart", "flame", "bolt", "shield", "boot", "eye", "star", "drop", "skull", "ring", "arrow", "wave",
              "key", "moon", "clock", "hand", "note", "leaf", "gear", "plus", "crown", "feather", "bell", "web"]


def build_icons(col, acc):
    s = Image.new("RGBA", (12 * 24, 12))
    for i, k in enumerate(ICON_ORDER):
        s.paste(draw_icon(k, col, acc), (i * 12, 0))
    return s


def build_door_icons(acc, danger):
    """10 frames 16x16: 0 combat,1 boon,2 heal,3 mem,4 event,5 elite,6 boss,7 rest,8 fragment,9 spare"""
    s = Image.new("RGBA", (16 * 10, 16))
    kinds = [("skull", "#c8c0b0"), ("star", "#ffd36a"), ("heart", "#e0304a"), ("drop", acc), ("bell", "#78b8ff"), ("skull", "#ff9a30"),
             ("crown", danger), ("moon", "#a8c0ff"), ("note", "#d8a8ff"), ("ring", "#c8c0b0")]
    for i, (k, c) in enumerate(kinds):
        ic = draw_icon(k, c, "#ffffff")
        bg = new(16, 16)
        d = D(bg)
        d.ellipse((0, 0, 15, 15), fill=(10, 8, 16, 220), outline=hexc(c))
        bg.alpha_composite(ic, (2, 2))
        s.paste(bg, (i * 16, 0))
    return s


def pickup_sheets(acc, mem_col="#f0c860"):
    out = {}
    # memory: small glowing gem 8x8, 3 frames
    m = Image.new("RGBA", (8 * 3, 8))
    for f in range(3):
        im = new(8, 8)
        d = D(im)
        c = hexc(mem_col)
        d.polygon([(4, 0), (7, 3), (4, 7), (1, 3)], fill=c)
        d.line((4, 1, 4, 5), fill=light(c, .5)) if f != 1 else d.line((3, 2, 5, 2), fill=light(c, .6))
        d.point((2, 3 + (f == 2)), fill=hexc("#ffffff"))
        m.paste(finish_icon(im).crop((1, 1, 9, 9)).resize((8, 8)) if False else im, (f * 8, 0))
    out["mem"] = m
    # icon variant for HUD 8x8
    out["mem_icon"] = m.crop((0, 0, 8, 8))
    h = Image.new("RGBA", (11 * 2, 10))
    hf = heart_frames()
    h.paste(hf[0], (0, 0)); h.paste(hf[0].transform((11, 10), Image.AFFINE, (1, 0, 0, 0, 1, -1)), (11, 0))
    out["heart"] = h
    fr = Image.new("RGBA", (12 * 3, 14))
    for f in range(3):
        im = new(12, 14)
        d = D(im)
        c = hexc(acc)
        yb = 2 + (f % 2)
        d.rectangle((3, yb + 1, 8, yb + 9), fill=hexc("#e8e2cc"), outline=hexc("#0b0a10"))
        d.line((4, yb + 3, 7, yb + 3), fill=c); d.line((4, yb + 5, 7, yb + 5), fill=c); d.line((4, yb + 7, 6, yb + 7), fill=c)
        for (x, y) in ((1, yb + 2), (10, yb + 5), (2, yb + 9)):
            d.point((x, y), fill=light(c, .5 if f != 1 else .1))
        fr.paste(im, (f * 12, 0))
    out["fragment"] = fr
    bo = Image.new("RGBA", (14 * 3, 16))
    for f in range(3):
        im = new(14, 16)
        d = D(im)
        c = hexc(acc)
        r = 4 + (f == 1)
        d.ellipse((7 - r, 8 - r, 7 + r, 8 + r), fill=c, outline=hexc("#0b0a10"))
        d.ellipse((5, 6, 8, 9), fill=hexc("#ffffff"))
        for a in range(0, 360, 60):
            x = 7 + int(math.cos(math.radians(a + f * 25)) * 7)
            y = 8 + int(math.sin(math.radians(a + f * 25)) * 7)
            d.point((max(0, min(13, x)), max(0, min(15, y))), fill=light(c, .5))
        bo.paste(im, (f * 14, 0))
    out["boon"] = bo
    return out


def proj_sprites(player_col, enemy_col):
    out = {}
    for name, col in (("proj_player", player_col), ("proj_enemy", enemy_col)):
        im = new(8, 8)
        d = D(im)
        c = hexc(col)
        d.ellipse((1, 1, 6, 6), fill=c, outline=dark(c, .5))
        d.ellipse((2, 2, 4, 4), fill=hexc("#ffffff"))
        out[name] = im
    return out


def prop_altar(acc, wall):
    im = new(20, 24)
    d = D(im)
    ol = hexc("#0b0a10")
    w = hexc(wall)
    d.rectangle((3, 12, 16, 22), fill=dark(w, .1), outline=ol)
    d.rectangle((2, 10, 17, 13), fill=light(w, .1), outline=ol)
    d.rectangle((8, 3, 11, 9), fill=hexc(acc), outline=ol)
    d.point((9, 5), fill=hexc("#ffffff"))
    d.ellipse((7, 1, 12, 5), fill=hexc(acc))
    return im
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
