---
id: interactable-contract-and-interactor-scoring
title: "Interactable contract + Interactor that ranks ray hit and proximity candidates"
category: gdscript-patterns
when: "E-to-interact systems (talk, use, pickup, hold-to-use)."
related: []
origin: Caesarea
---

# Interactable contract + Interactor that ranks ray hit and proximity candidates

**When to use:** E-to-interact systems (talk, use, pickup, hold-to-use).

## Do this

Any node in group `interactable` with `prompt` + `interact(actor)` works; optional `can_interact`, `get_prompt`, `hold_time`, `interact_priority`, `interact_range`, `interaction_point()`, `highlight(on)`, `highlight_root()`. Ready-made `Interactable` (Node3D) kinds USE/TALK/PICKUP; TALK starts `dialogue_id`; PICKUP calls `Game.inventory.add` (or loud PLACEHOLDER warning if inventory missing) and frees the owner; `one_shot`; `condition: Callable`. Interactor: ray from camera center (reach 2.8 m) + proximity scan of the group every 0.1 s (radius 2.2, min facing dot 0.45). Score = `priority*10 + ray_hit 5 + facing 0..3 − distance*0.5` (looked-at beats nearby; priority steps of 10 win). Disabled while dialogue is active. Signals focus_changed(target, prompt), interacted, interact_failed, hold_progress(0..1). `interact_with(target)` for tests/scripted events. Prompt UI: "[" + describe_action("interact") + "] " + prompt (e.g. "[E] Papers").

## Origin

Caesarea. Source notes: Caesarea/game/interaction/interactable.gd, interactor.gd; TEAM.md Interactable contract; MANIFEST play layer.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
