---
id: mistake-30mb-commit-limit
title: "Zips >30 MB can't be committed to PC"
category: mistake
when: "Delivering release zips to user PC."
related: []
origin: FNAP
---

# Zips >30 MB can't be committed to PC

**When to use:** Delivering release zips to user PC.

## Do this

Per-file commit limit 30 MB. Build ON the PC with a `.bat` + `.ps1` (commit the small scripts + sources), user double-clicks, read the log.

## What happened, root cause, fix, prevention

Symptom: commit refused. Fix above.

## Verify

release.log read; folder listed.

## Origin

FNAP. Source notes: mistakes-log.md M71.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
