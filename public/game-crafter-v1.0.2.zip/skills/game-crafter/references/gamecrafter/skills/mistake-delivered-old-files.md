---
id: mistake-delivered-old-files
title: "Delivered" but folder had old files"
category: mistake
when: "After any delivery."
related: []
origin: FNAP
---

# Delivered" but folder had old files

**When to use:** After any delivery.

## Do this

List dir; compare size/mtime against what you produced.

## What happened, root cause, fix, prevention

Symptom: user found old files. Cause: no verification. Fix above.

## Verify

Listing with new mtimes.

## Origin

FNAP. Source notes: mistakes-log.md M77.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
