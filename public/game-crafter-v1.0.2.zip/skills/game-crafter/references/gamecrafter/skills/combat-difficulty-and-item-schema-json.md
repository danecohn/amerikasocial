---
id: combat-difficulty-and-item-schema-json
title: "Difficulty multipliers and item JSON schema as contracts between agents"
category: rpg-systems
when: "Combat/RPG data shared by several agents."
related: []
origin: Caesarea
---

# Difficulty multipliers and item JSON schema as contracts between agents

**When to use:** Combat/RPG data shared by several agents.

## Do this

`data/combat/difficulty.json` levels easy/normal/hard: enemy_damage 0.7/1.0/1.35, enemy_health 0.8/1.0/1.3, perception 0.8/1.0/1.2, spread 1.5/1.0/0.7, reaction 1.4/1.0/0.7 (lower = faster notice), with a `_doc` string explaining each multiplier. Items per category file (`items_weapons/armor/aid/ammo/food/books/components/documents/junk/keys/quest/accessories.json`) `{version, _doc, items{id:{name, category, weight, value_denarii, value_caps, legal, weapon_class, skill, mesh, slot, max_condition, stats{…}, condition_loss_per_use, rail_slots, tags, desc, virtual?}}}`; `_doc` states which `stats` keys are the contract the combat agent reads (melee: damage/attack_speed/reach_m/ap_cost/crit_mult; guns: damage/fire_rate/magazine/ammo/range_m/ap_cost/crit_mult). Virtual items (Fists) flagged `virtual: true`. Also `data/skills/{skills,perks,traits}.json`, `data/combat/{weapons,enemies,factions_combat}.json`, `assets/anim/rig_meta.json` (fps 30, stride/speed per clip, frames, loop) and `combat_clips.json`.

## Origin

Caesarea. Source notes: outputs/Caesarea/data/*, assets/anim/rig_meta.json.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
