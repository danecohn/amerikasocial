# Tool: check_env.sh

**Purpose:** Environment check: Godot + matching export templates, Blender, ffmpeg, Xvfb, Python libs, disk, RAM.

**Usage:** `bash check_env.sh`

**Skill:** see `skills/check-env-game-tools.md`

**Extract:** save the block below as `check_env.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Game Maker: report which game-making tools are present and what is missing.
# Usage: check_env.sh [godot_version]   (default 4.7.2)
# Exit code = number of REQUIRED tools missing (godot, templates, blender, ffmpeg).
GV="${1:-4.7.2}"; miss=0
ok(){ printf '  [ok]   %s\n' "$*"; }
bad(){ printf '  [MISS] %s\n' "$*"; }
warn(){ printf '  [warn] %s\n' "$*"; }
echo "== Game Maker environment check ($(uname -sm))"
GODOT="${GODOT:-$(command -v godot || command -v godot4 || true)}"
if [ -n "$GODOT" ]; then
  v=$("$GODOT" --version 2>/dev/null | head -1); ok "godot: $GODOT -> $v"
  case "$v" in "$GV".*) ;; *) warn "wanted Godot $GV but found $v (export templates must match the editor version EXACTLY)";; esac
else bad "godot not on PATH"; miss=$((miss+1)); fi
TPL_LINUX="$HOME/.local/share/godot/export_templates"; TPL_MAC="$HOME/Library/Application Support/Godot/export_templates"
for d in "$TPL_LINUX" "$TPL_MAC"; do
  if [ -d "$d" ]; then
    found=$(ls "$d" 2>/dev/null | tr '\n' ' ')
    if ls "$d/$GV.stable/version.txt" >/dev/null 2>&1; then ok "export templates $GV.stable in $d ($(ls "$d/$GV.stable" | wc -l) files)"; else bad "no $GV.stable templates in $d (found: ${found:-none})"; miss=$((miss+1)); fi
  fi
done
[ -d "$TPL_LINUX" ] || [ -d "$TPL_MAC" ] || { bad "no export_templates dir at all"; miss=$((miss+1)); }
BL="${BLENDER:-$(command -v blender || true)}"
if [ -n "$BL" ]; then ok "blender: $BL -> $("$BL" --version 2>/dev/null | head -1)"; else bad "blender not on PATH"; miss=$((miss+1)); fi
if command -v ffmpeg >/dev/null; then ok "ffmpeg: $(ffmpeg -version | head -1)"; else bad "ffmpeg missing"; miss=$((miss+1)); fi
command -v xvfb-run >/dev/null && ok "xvfb-run present" || warn "xvfb-run missing (needed only for headless screenshots/video: apt-get install -y xvfb)"
command -v zip >/dev/null && ok "zip present" || warn "zip missing (needed by build_release.sh)"
python3 -c "import PIL; print('  [ok]   Pillow', PIL.__version__)" 2>/dev/null || warn "Pillow missing (pip install --break-system-packages pillow) - needed for store art"
ICD=$(ls /opt/pw-browsers/*/chrome-linux/vk_swiftshader_icd.json 2>/dev/null | head -1)
[ -z "$ICD" ] && ICD=$(ls /usr/share/vulkan/icd.d/*lvp* /usr/share/vulkan/icd.d/*swiftshader* 2>/dev/null | head -1)
[ -n "$ICD" ] && ok "software Vulkan ICD: $ICD" || warn "no software Vulkan ICD found (headless Forward+ screenshots need one: swiftshader json from Playwright chromium, or mesa-vulkan-drivers/lavapipe)"
echo "  cpu cores: $(nproc 2>/dev/null)  ram: $(free -g 2>/dev/null | awk '/Mem:/{print $2" GB"}')  swap: $(free -g 2>/dev/null | awk '/Swap:/{print $2" GB"}')"
echo "  disk free here: $(df -h . | awk 'NR==2{print $4}')"
if [ -n "${HTTPS_PROXY:-}" ]; then echo "  egress proxy active: downloads from non-allowlisted hosts will 403 (see /root/.ccr/README.md); proxy status: curl -sS \"\$HTTPS_PROXY/__agentproxy/status\""; fi
echo "== missing required: $miss"; exit $miss
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
