---
id: blender-godot-node-name-contract
title: "Name contract between Blender models and Godot code (markers, rigs, cameras)"
category: 3d-blender
when: "Authoring or re-exporting .glb models that game code drives; adding markers/cameras/lamps."
related: [mistake-gltf-extras-hidden-by-default]
origin: FNAP
---

# Name contract between Blender models and Godot code (markers, rigs, cameras)

**When to use:** Authoring or re-exporting .glb models that game code drives; adding markers/cameras/lamps.

## Do this

- FNAP contract names that had to survive re-export: `Lurk_DoorL, Lurk_DoorR, Curtain_Grip, AutoConsole, DoorMotor_L/R, DoorLamp_L/R, AlarmLight, AlarmLight_Spinner, PlayerCamera`, security cameras `Cam_<id>`, spots `CamSpot_<id>`; rigs `DoorRig_L/R`.
- Code finds them with NodeFinder normalized names + ordered alias lists; real model first, placeholder second.
- Keep a node-position dump script (`inspect.py`) so misplacements are found, not guessed: door lamp/motor nodes existed in the prop GLB but sat beside the camera (z=0.92/1.42) out of view; moved to z=-0.35 in the GLB.
- Re-exporting a GLB can drop/rename custom nodes (PlayerCamera, markers): diff GLB JSON node lists before/after (QA E13).
- Node `extras` (custom properties) are visible to code; honour them deliberately (see mistake-gltf-extras-hidden-by-default).

## Pitfalls (mistakes seen)

misplaced lamp/motor nodes looked "missing"; renamed nodes broke lookups.

## Verify

inspect dump lists every contract name with sane positions; release_check asserts all contract nodes found.

## Origin

FNAP. Source notes: L §2.6 (lines 106-109), §4.6 line 225; G lines 29-31; S line 21.

## Related skills

- [mistake-gltf-extras-hidden-by-default](mistake-gltf-extras-hidden-by-default.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
