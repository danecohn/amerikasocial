---
id: check-env-game-tools
title: "Environment check (check_env.sh)"
category: environment-tools
when: "Start of any game session; before installing; when a tool seems missing."
related: []
origin: FNAP
---

# Environment check (check_env.sh)

**When to use:** Start of any game session; before installing; when a tool seems missing.

## Do this

`bash check_env.sh [godot_version=4.7.2]` prints [ok]/[MISS]/[warn] for: godot (+ version match warning), export templates in `~/.local/share/godot/export_templates/<v>.stable/version.txt` and the macOS path, blender, ffmpeg, xvfb-run, zip, Pillow, software Vulkan ICD (swiftshader or lvp), cpu cores, RAM, swap, disk free, proxy note (`curl -sS "$HTTPS_PROXY/__agentproxy/status"`). Exit code = number of REQUIRED tools missing (godot, templates, blender, ffmpeg). Reference cloud reality: Godot 4.7.2 at /usr/local/bin/godot, Blender 5.2.2 at /usr/local/bin/blender (`blender -b`), ffmpeg 6.1.1, xvfb, Pillow 12.3, 2 cores, ~7-8 GB RAM, no GPU.

## Pitfalls (mistakes seen)

Template version mismatch -> "no export template".

## Verify

exit 0.

## Origin

FNAP. Source notes: install-godot-blender/scripts/check_env.sh; SKILL.md section 1.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
