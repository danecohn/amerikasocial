---
id: mistake-missing-card-pool-silent-empty
title: "Bonus mode card pool silently empty (resource folder missing)"
category: mistake
when: "Content loaded by directory scan."
related: []
origin: FNAP
---

# Bonus mode card pool silently empty (resource folder missing)

**When to use:** Content loaded by directory scan.

## What happened, root cause, fix, prevention

- Symptom: roguelite has no cards; no error.
- Root cause: `resources/brine/cards/*.tres` absent in the copy; `_load_cards()` silently yields an empty pool.
- Fix: restore the folder; assert pool size > 0 and print an error.
- Prevention: loader checks with exit codes for every scanned content folder.

## Verify

startup log prints card count.

## Origin

FNAP. Source notes: REF caveats, §1.1, §1.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
