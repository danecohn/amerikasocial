---
id: mistake-data-files-not-exported
title: "JSON/CSV/TXT/raw audio/frames missing in the exported game"
category: mistake
when: "Terminal lines, subtitles, faces, voice work in editor but not in the exe."
related: []
origin: FNAP
---

# JSON/CSV/TXT/raw audio/frames missing in the exported game

**When to use:** Terminal lines, subtitles, faces, voice work in editor but not in the exe.

## What happened, root cause, fix, prevention

- Symptom: features driven by data files silently empty in the build.
- Root cause: non-resource files are not exported unless matched by `include_filter`; and `DirAccess` scans return
  `*.import`/`*.remap` names in builds.
- Fix: `include_filter="*.json, *.csv, *.txt, *.cues, assets/audio/voice/*, assets/assistant_face/*, assets/branding/*"`;
  `packed_name()` strip in every scanner (NodeFinder, VoiceBank, assistant audio discovery).
- Prevention: "the #1 export gotcha for data-driven games"; verify features from the exported build.

## Verify

exported build screenshot of terminal + subtitles; loader_check from the pack.

## Origin

FNAP. Source notes: REF §4.1, §3.3 Export lesson, §8.2 #16.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
