---
id: mistake-boss-mixed-pixel-density
title: "Upscaling a sprite before outlining mixes 1px and 2-3px pixels"
category: mistake
when: "Making large sprites by scaling small ones."
related: []
origin: Roguelike series
---

# Upscaling a sprite before outlining mixes 1px and 2-3px pixels

**When to use:** Making large sprites by scaling small ones.

## What happened, root cause, fix, prevention

- Symptom: bosses look "higher resolution" than the rest of the game: chunky 2-3px body pixels with 1px outline, 1px rim light and 1px decorations (THE CHORUS in screenshot_03).
- Root cause: `boss_from` does `scale_up(base,k)` -> `extra()` -> `finish()`, so shading/outline happen after scaling at 1px.
- Fix (pick one style deliberately): (a) strict retro: `finish()` first, then `scale_up` and draw decorations in k-px blocks; (b) modern-retro: draw boss recipes natively at the big size. Do not mix.
- Prevention: decide the "pixel size" rule in the art bible: one art pixel = one canvas pixel for all in-world sprites.

## Verify

zoom contact sheet; outline thickness equals body pixel size.

## Origin

Roguelike series. Source notes: _tools/sprites.py boss_from lines 417-426; screenshot_03.png.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
