---
id: export-preset-filters-pps
title: "Export preset filters and branding settings that shipped"
category: export-release
when: "Writing export_presets.cfg for a code-built Godot game that loads JSON/CSV/TXT data at runtime."
related: []
origin: Pickle's Pickle Shop
---

# Export preset filters and branding settings that shipped

**When to use:** Writing export_presets.cfg for a code-built Godot game that loads JSON/CSV/TXT data at runtime.

## Do this

`export_filter="all_resources"`, `include_filter="*.json, *.csv, *.txt"` (non-resource data must be force-included or FileAccess reads fail in export), `exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, assets/phone-scripts/original/*, assets/phone-scripts/extra/*"`, `binary_format/embed_pck=true`, s3tc_bptc on. Windows: `application/modify_resources=true`, icon png 1024, company/product names, file/product version. macOS: bundle id `com.<studio>.<game>`, min macOS 11.00, codesign 0 (unsigned: tell players right-click > Open). project.godot: `config/use_custom_user_dir=true`, `custom_user_dir_name="<Studio>/<Game>"`, `windows_native_icon=*.ico`, viewport 1920x1080 with window override 1600x900, stretch canvas_items, `import_s3tc_bptc` and `import_etc2_astc` true. Keep export_path empty in the repo; the CLI passes paths.

## Pitfalls (mistakes seen)

User-supplied export_presets.cfg had blank paths and was smaller -> kept the known-good version. Missing .ico files (branding, app_icon) broke the Windows icon -> restored from legacy.

## Verify

`godot --headless --export-release "<preset>" out` succeeds for all; unzip -l shows no dev scripts.

## Origin

Pickle's Pickle Shop. Source notes: /home/claude/base/export_presets.cfg; project.godot; transcript summary sec.3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
