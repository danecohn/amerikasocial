# Tool: clip_manifest.gd

**Purpose:** Required animation clips per character; fails loudly when a clip is missing.

**Usage:** `ClipManifest.check(anim_player, "pickle")`

**Skill:** see `skills/clip-manifest-json.md`

**Extract:** save the block below as `clip_manifest.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
# Game Maker template: tolerant clips.json reader (per-clip loop flags, walk_speed_mps). Comments were lost in the source decompile; see references/godot-gotchas.md
class_name ClipManifest
extends RefCounted











const PATHS: Array[String] = ["res://assets/models/characters/clips.json"]   # json is NOT auto-exported: add "*.json" to every preset include_filter

static var _table: Dictionary = {}
static var _loaded: = false


static func _load() -> void :
	if _loaded:
		return
	_loaded = true
	for path in PATHS:
		if not FileAccess.file_exists(path):
			continue
		var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
		if parsed == null:
			push_warning("ClipManifest: could not parse %s" % path)
			continue
		_ingest(parsed, "")
		return


static func _ingest(node: Variant, owner: String) -> void :
	if node is Array:
		for item in node:
			_ingest(item, owner)
	elif node is Dictionary:
		var d: Dictionary = node
		var clip_name: = String(d.get("name", d.get("clip", "")))
		var who: = String(d.get("character", d.get("file", d.get("model", owner))))
		if clip_name != "" and (d.has("loop") or d.has("length") or d.has("looping")):
			_add(who, clip_name, d)
			return
		for key in d:
			var value: Variant = d[key]
			if key == "clips":
				_ingest(value, owner)
			elif value is Dictionary and ((value as Dictionary).has("loop") or (value as Dictionary).has("length")) and owner != "":
				_add(owner, String(key), value)
			elif value is Dictionary or value is Array:
				var container: = String(key).to_lower() in ["files", "characters", "models", "assets"]
				_ingest(value, owner if container or owner != "" else String(key))


static func _add(who: String, clip_name: String, d: Dictionary) -> void :
	var key: = NodeFinder.normalize(who.get_file().get_basename())
	if not _table.has(key):
		_table[key] = {}
	var loop: Variant = d.get("loop", d.get("looping", null))
	(_table[key] as Dictionary)[clip_name.to_lower()] = {"loop": loop, "length": float(d.get("length", d.get("seconds", 0.0)))}



static func is_looping(character: String, clip: String) -> Variant:
	_load()
	var entry: Dictionary = _table.get(NodeFinder.normalize(character), {})
	var c: Variant = entry.get(clip.to_lower(), null)
	if c == null:

		for k in entry:
			if clip.to_lower().ends_with(String(k)):
				c = entry[k]
				break
	if c == null:
		return null
	return c["loop"]



static func apply(character: String, player: AnimationPlayer) -> void :
	if player == null:
		return
	for anim_name in player.get_animation_list():
		var loop: Variant = is_looping(character, String(anim_name))
		if loop == null:
			continue
		var anim: = player.get_animation(anim_name)
		anim.loop_mode = Animation.LOOP_LINEAR if bool(loop) else Animation.LOOP_NONE


static var _walk_speeds: Dictionary = {}



static func walk_speed(character: String, fallback: float) -> float:
	_load()
	if _walk_speeds.is_empty():
		for path in PATHS:
			if not FileAccess.file_exists(path):
				continue
			var parsed: Variant = JSON.parse_string(FileAccess.get_file_as_string(path))
			if parsed is Dictionary and (parsed as Dictionary).get("files") is Dictionary:
				var files: Dictionary = parsed["files"]
				for f in files:
					if files[f] is Dictionary and (files[f] as Dictionary).has("walk_speed_mps"):
						_walk_speeds[NodeFinder.normalize(String(f).get_basename())] = float(files[f]["walk_speed_mps"])
			_walk_speeds["__loaded"] = 0.0
			break
	return float(_walk_speeds.get(NodeFinder.normalize(character), fallback))
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
