---
id: always-quit-and-timeout-godot
title: "Every Godot run must end (timeout, --quit-after, quit())"
category: mistake
when: "Writing capture scenes or running Godot from tools."
related: []
origin: FNAP
---

# Every Godot run must end (timeout, --quit-after, quit())

**When to use:** Writing capture scenes or running Godot from tools.

## Do this

Always wrap in `timeout`, use `--quit-after` / custom `--gm-quit-after=N`, and end capture scripts with `get_tree().quit()`.

## Pitfalls (mistakes seen)

Symptom: tool call hung until killed. Root cause: scene that never quits. Fix: quit at end of scripted run; wrapper timeout (exit 124 message). Prevention: wrapper always applies timeout.

## Verify

Process exits with 0 before timeout.

## Origin

FNAP. Source notes: headless-render-capture/SKILL.md "Facts"; godot_xvfb.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
