---
id: audio-manager-architecture
title: "Audio system architecture that worked (pool, keyed loops, 3D one-shots, stems, safe ids)"
category: audio-music
when: "Designing a game's AudioManager autoload."
related: [mistake-check-script-path-mismatch]
origin: FNAP
---

# Audio system architecture that worked (pool, keyed loops, 3D one-shots, stems, safe ids)

**When to use:** Designing a game's AudioManager autoload.

## Do this

- SFX player pool; keyed loops (start/stop by key); 3D one-shots at positions; ducking that is always released (`reset_ducks`); adaptive music stems on a beat clock using `AudioStreamSynchronized`; string-id lookup through a static registry (`Sfx`) that warns ONCE per missing id and never crashes.
- Load audio via imported resources + `load()`; check scripts must use the same resolver as the game.
- Keep source ogg for music, wav for sfx; do not re-encode game music without need.
- Measure durations from audio (for subtitles) rather than guessing.

## Pitfalls (mistakes seen)

ducks left on; check-script path mismatch (mistake-check-script-path-mismatch); VoiceBank `DirAccess` scan failing in export.

## Verify

audio_check scene: all ids resolve, duck/reset values, PASS token.

## Origin

FNAP. Source notes: S line 25; L §2.12 (lines 135-139), §6.5 (lines 322-324).

## Related skills

- [mistake-check-script-path-mismatch](mistake-check-script-path-mismatch.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
