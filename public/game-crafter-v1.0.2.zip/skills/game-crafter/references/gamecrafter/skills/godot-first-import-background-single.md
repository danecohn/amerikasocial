---
id: godot-first-import-background-single
title: "Run the first Godot import once, in the background, and wait for it"
category: godot-engine
when: "Fresh clone/checkout, new container, many new assets, before export or capture."
related: [mistake-concurrent-imports]
origin: FNAP
---

# Run the first Godot import once, in the background, and wait for it

**When to use:** Fresh clone/checkout, new container, many new assets, before export or capture.

## Do this

- Fresh import of ~630 MB of GLBs takes many minutes and lots of RAM.
- `cd <proj> && nohup godot --headless --path . --import --quit > import.log 2>&1 &` ; when it finishes `touch IMPORT_DONE`; the log's last line should be `EXIT 0` (wrapper prints it).
- Never two imports at once (corrupts the cache). Don't run the game/captures until `IMPORT_DONE`. Reading/editing code during import is fine.
- Assets added after import started (e.g. wavs that arrived later) need another `--import --quit`.
- Always import before export: `godot --headless --path <proj> --import --quit`.

## Pitfalls (mistakes seen)

see mistake-concurrent-imports.

## Verify

`IMPORT_DONE` exists; `tail -1 import.log` = `EXIT 0`.

## Origin

FNAP. Source notes: L §2.10 (lines 127-129), §5.7 (line 285); G line 13 (M25).

## Related skills

- [mistake-concurrent-imports](mistake-concurrent-imports.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
