---
id: factory-spec-to-game-assembly
title: "Mass-produce a game from a spec (kit copy + generated assets + presets + probe)"
category: core-workflow
when: "You need to build several games of the same genre quickly, or rebuild one game deterministically from a data spec; 'make game N of the series'."
related: [mistake-hardcoded-absolute-tool-paths, mistake-python-hash-nondeterministic-seed]
origin: Roguelike series
---

# Mass-produce a game from a spec (kit copy + generated assets + presets + probe)

**When to use:** You need to build several games of the same genre quickly, or rebuild one game deterministically from a data spec; "make game N of the series".

## Do this

- Architecture: one shared Godot "kit" project (all game code, data-driven), one `games/gN_<name>/` folder per game with `spec.py` (art/audio/fonts description + `GAME` dict), `content.py` (writing: speakers, dialogue, boons, events), `meta.py` (`META` dict: store copy, slugs, prices, bible). Tools in `_tools/`.
- `python3 _tools/buildgame.py games/gN_dir [--no-music]` does, in order:
  1. `load_spec()` via `importlib.util.spec_from_file_location("gspec", gdir/spec.py)`, adds gdir to `sys.path` so the spec can `import content`.
  2. Wipe `build/<slug>/project`, `shutil.copytree(kit, proj)`.
  3. Patch `project.godot`: replace `GAMETITLE` with the title; inject under `[rendering]`: `textures/vram_compression/import_s3tc_bptc=true` and `textures/vram_compression/import_etc2_astc=true` (needed for the universal/ARM macOS export).
  4. Write `game/game.json` = `spec.GAME` (all gameplay content is JSON read by the kit).
  5. `build_art()`: fonts (body.ttf, title.ttf), player/npc/enemy/boss sprite sheets, hub props, pickups, projectiles, altar, heart UI (3 frames 11x10), icons, door icons, one tileset per theme.
  6. Title background 384x216 gradient sky_top->sky_bot + optional `spec.title_scene(bg, draw, sheets, W, H)` hook + vignette(0.5).
  7. Optional `spec.extra_art(proj, sheets)` hook (ending images etc).
  8. Icon: copy studio `kit/assets/branding/fw_icon.png` to `icon.png`.
  9. SFX: `SFX.write(assets/audio/sfx, pitch, grit, seed)` from spec `"sfx": {"pitch":0.9,"grit":1,"seed":3}`.
  10. Music: `render_music()` (BeepBox, see beepbox skills) unless `--no-music`, in which case it re-copies cached `build/<slug>/ogg/*.ogg` (music is the slow step; cache it).
  11. `write_presets()` from the export-preset template.
  12. Probe: walk `assets/` for .png/.ogg/.wav/.ttf -> `tools/probe_manifest.json` {"resources":[res://...], "raw_files":["res://game/game.json"], "dirs":[]}; copy probe.gd/.tscn.
- Then the pipeline is: buildgame.py -> autoplay/verify (autorun.sh, chk.sh, shot.sh) -> screenshots + cover.py -> pack.py (docs/ads) -> release.py (exports+zips) -> finish.py (source zip, MANIFEST, stage to outputs).
- Spec is code (Python), not JSON, so it can hold hooks and call shared helpers (gk.py).

## Pitfalls (mistakes seen)

see mistake-python-hash-nondeterministic-seed, mistake-hardcoded-absolute-tool-paths.

## Verify

`build/<slug>/project` opens headless with no SCRIPT ERROR (chk.sh); probe manifest lists every asset; autoplay run reaches RUN_END.

## Origin

Roguelike series. Source notes: _tools/buildgame.py L1-259; WIP_BIBLE_AND_MANIFEST.md "Resume".

## Related skills

- [mistake-hardcoded-absolute-tool-paths](mistake-hardcoded-absolute-tool-paths.md)
- [mistake-python-hash-nondeterministic-seed](mistake-python-hash-nondeterministic-seed.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
