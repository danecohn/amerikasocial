---
id: interlude-design-hidden-moral-spine
title: "Writing tender horror interludes with an unstated moral spine and flag-driven endings"
category: narrative-dialogue
when: "Designing story minigames that change the ending."
related: []
origin: Pickle's Pickle Shop
---

# Writing tender horror interludes with an unstated moral spine and flag-driven endings

**When to use:** Designing story minigames that change the ending.

## Do this

Five interludes after nights 1-4 + final, each one mechanic with a choice whose meaning is shown by what the player DOES, never stated (no sermonising, no religious words). Flags: gave_bread (stealth carry the OLD loaf past a patrolling light cone), kept_promise_wren (choose a promise you can keep vs a comfort lie), wrote_truth vs burned_ledger (sort receipts, circle discrepancies, compose a letter from 3 fragments), released_jar / jars_released (open or keep voice jars). Final: give each frozen character the item you earned, then answer six bell rings on the beat; endings by count: 0-1 "preserved", 2-3 "shut", all 4 + archive >= 18 docs "golden" (the stranger returns; reuse the final phone line with changed meaning). Earlier flags are acknowledged in later dialogue (`Story.flag("gave_bread")`). Last 20 seconds should land emotionally. Disclose to the user any NEW characters/names you invented that aren't in their bible (Wren, Tobias, surnames) and where to change them (lore.json).

## Verify

Auto-runs with different `--fnap-mini-pick` reach each ending.

## Origin

Pickle's Pickle Shop. Source notes: MANIFEST/MINI_SPEC.md; MANIFEST.md "NEW CHARACTERS I ADDED"; mg_six_oclock.gd header.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
