---
id: fnaf-genre-core-loop
title: "FNAF-style night-survival core loop (office, doors, power, cameras, clock)"
category: planning-design
when: "Starting or pitching any 'survive in a security office until 6 AM' horror game; deciding which systems to build first."
related: [fnaf-cast-one-rule-per-enemy, fnaf-difficulty-curve-tables, mistake-death-through-closed-door]
origin: FNAP
---

# FNAF-style night-survival core loop (office, doors, power, cameras, clock)

**When to use:** Starting or pitching any "survive in a security office until 6 AM" horror game; deciding which systems to build first.

## Do this

- The loop: player is fixed at a desk in an office with a LEFT and RIGHT door that open onto dark halls. A camera monitor
  shows N rooms. Power is finite and NEVER regenerates during the night. A clock runs 12 AM -> 6 AM; reaching 6 AM wins
  the night; an animatronic reaching the office = jumpscare = loss. 5 story nights, then a Custom Night (6) and a bonus mode.
- The tension triangle: information (cameras, door lights, flashlight) costs power; safety (shut doors) costs power;
  power cannot come back. Every action is a trade. Phone line from CALLS N1: "The doors are steel, and they work. They
  also cost power every time, and the power doesn't come back. So don't shut them just because you're nervous."
- FNAP room set (11 cameras), a good template: 1A Show Stage, 1B Dining Area, 1C Brine Cove (the "cove" of the runner),
  2A West Hall, 2B West Hall Corner, 3 Supply Closet, 4A East Hall, 4B East Hall Corner, 5 Backstage, 6 Kitchen
  (audio only, no picture), 7 Restrooms. Plus non-camera nodes `OFFICE_DOOR_L`, `OFFICE_DOOR_R`, `OFFICE`.
- Geography rule: west-side rooms (2A/2B) lead to the LEFT door; east-side (4A/4B) to the RIGHT door. Each enemy is
  assigned a side and the story must state the same side ("Pickle and Dilly come down the east side to the right door,
  Remi and Banshee come down the west side to the left door, and Golden Pickle belongs to no path").
- Each enemy = ONE learnable rule + ONE counter (see fnaf-cast-one-rule-per-enemy). The phone call teaches each rule on
  the night it starts to matter.
- FNAP's own twists on the formula: you cannot see the doorway from the chair (you must stand and walk to the door and
  use hall light or flashlight); stamina for walking/holding; hold-breath; lean; an unreliable in-world AI terminal
  that can operate doors for you (badly); a roguelite bonus mode reusing the same office scene.
- Design rule from BIBLE: "Nothing in the story requires the player to understand the cause of what happens, only to
  survive it."

## Pitfalls (mistakes seen)

see fnaf-difficulty-curve-tables (enemy active before it is introduced) and mistake-death-through-closed-door.

## Verify

Write a one-page "systems sheet": rooms + which door each path ends at, per-enemy rule/counter, power budget
math (fnaf-power-system), night length. Every enemy rule must appear in exactly one phone call on/before its first night.

## Origin

FNAP. Source notes: REF §2 intro, §1.2 (room ids), §2.2-2.5; BIBLE "Rules the Story Keeps"; CALLS N1.

## Related skills

- [fnaf-cast-one-rule-per-enemy](fnaf-cast-one-rule-per-enemy.md)
- [fnaf-difficulty-curve-tables](fnaf-difficulty-curve-tables.md)
- [mistake-death-through-closed-door](mistake-death-through-closed-door.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
