---
id: mistake-<short-name>
title: "Mistake: <what went wrong, in the user's words if possible>"
category: mistake
when: <the symptom or situation that should make an agent open this skill>
related: [<technique-skill-that-prevents-it>]
origin: <game>
---

# Mistake: <title>

> **Never again:** <one-line prevention rule>

## What the user saw
<The symptom exactly as the player/user experienced it. Quote the user if you can.>

## Root cause
<The real technical cause, not the first theory.>

## The fix
<Exact change: files, code, settings. Include the snippet.>

## Prevention
- <Rule or habit that stops this class of bug.>

## Detection
- <A check, grep, lint, probe or screenshot that catches it BEFORE the user does.>

## Origin
<Game and moment it happened.>
