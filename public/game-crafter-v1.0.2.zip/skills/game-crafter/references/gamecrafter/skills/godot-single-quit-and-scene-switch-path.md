---
id: godot-single-quit-and-scene-switch-path
title: "One quit path and one scene-switch path (GameState autoload)"
category: gdscript-patterns
when: "Adding menus, credits, pause, error exits, scene transitions."
related: [mistake-audio-duck-never-released]
origin: FNAP
---

# One quit path and one scene-switch path (GameState autoload)

**When to use:** Adding menus, credits, pause, error exits, scene transitions.

## Do this

- Every quit path (menu, credits, splash, director, office, pause, errors) calls `GameState.quit_game()` (save + quit) - never raw `get_tree().quit()`.
- Every scene change goes through `GameState.change_scene(path)` which stops loops/music and resets audio ducks before `get_tree().change_scene_to_file(path)` ("a cut-off phone call once left music muted in the next scene").
- Close button: `set_auto_accept_quit(false)` + `_notification(NOTIFICATION_WM_CLOSE_REQUEST)` -> `save()` -> `get_tree().quit()`.
- Register: `[autoload] GameState="*res://scripts/autoload/game_state.gd"`.
```gdscript
func quit_game() -> void:
    save(); get_tree().quit()
func change_scene(path: String) -> void:
    AudioManager.stop_all_loops()   # also resets ducks
    get_tree().change_scene_to_file(path)
```

## Pitfalls (mistakes seen)

raw quits bypassed saves; a scene change without stopping a call left buses ducked (mistake-audio-duck-never-released).

## Verify

`grep -rn "get_tree().quit()" scripts/` returns only GameState; save_test passes.

## Origin

FNAP. Source notes: T/godot_core/game_state_template.gd lines 20-21, 73-88; L §2.11; S Non-negotiable 5.

## Related skills

- [mistake-audio-duck-never-released](mistake-audio-duck-never-released.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
