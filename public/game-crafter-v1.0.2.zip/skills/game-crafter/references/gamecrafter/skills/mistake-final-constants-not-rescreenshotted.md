---
id: mistake-final-constants-not-rescreenshotted
title: "Changing tuning values after the last verification screenshot"
category: mistake
when: "Late tweaks to brightness/exposure/balance right before shipping."
related: []
origin: Pickle's Pickle Shop
---

# Changing tuning values after the last verification screenshot

**When to use:** Late tweaks to brightness/exposure/balance right before shipping.

## Do this

Final hall feed values (3.4/0.6 lit, 0.9/0.14 unlit) were changed after the last screenshots (2.6/0.42 vs 1.1/0.2 were the verified ones). The report had to flag it. Prevention: any change to a user-visible constant invalidates its screenshot - re-run the probe (cheap with the shotproj recipe) before packaging, or explicitly list it under "not verified".

## Verify

Screenshot timestamps newer than the last code change of those constants.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.5; L341.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
