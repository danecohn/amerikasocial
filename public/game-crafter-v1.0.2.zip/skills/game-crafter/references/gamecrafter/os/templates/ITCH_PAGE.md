# Template: itch.io page copy (save as ADVERTISEMENTS/itch.txt)
```
TITLE: <Game Title>
TAGLINE (short description, <= 120 chars): <hook in one line>
GENRE: <Action / Adventure / Survival …>   TAGS (max 10): horror, pixel-art, roguelike, 8-bit, retro, atmospheric, singleplayer, short, psychological-horror, <theme>
PRICE: <free / pay what you want / $x>   PLATFORMS: Windows, macOS, Linux
CLASSIFICATION: Game · Release status: Released · Community: comments

--- DESCRIPTION ---
<HOOK PARAGRAPH: second person, present tense, the fear and the place.>

FEATURES
- <feature that sells the fantasy>
- <length: "A 30–45 minute run-based horror game">
- <replay: endings, unlocks>
- Original soundtrack included (Soundtrack folder)

CONTROLS
<table>

DOWNLOADS
- Windows (x64) · Windows (ARM64) · macOS · Linux
- Unsigned builds: Windows SmartScreen > More info > Run anyway · macOS right-click > Open

CONTENT NOTE: <themes: death, grief, blood (pixel), jump scares>
AI DISCLOSURE: <state honestly which parts used generative AI tools, as itch.io requires>

<Studio name> — <studio tagline>
```
Cover image: 630x500 PNG (min 315x250). Screenshots: 5, same aspect as the game (e.g. 1280x720), in-game, no mockups.
