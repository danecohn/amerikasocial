---
id: content-rules-file
title: "Content/story rules file + pre-release grep"
category: narrative-dialogue
when: "Game has a story bible, branding rules, names that must never be shown, allowed voices, forbidden asset types, palette."
related: []
origin: FNAP
---

# Content/story rules file + pre-release grep

**When to use:** Game has a story bible, branding rules, names that must never be shown, allowed voices, forbidden asset types, palette.

## Do this

Write the rules to `docs/CONTENT_RULES.md`. Grep all player-facing strings (scripts, .tres display_name, CSV/JSON line tables, credits, game-over text, lore strings) against it before release. FNAP rules examples: a hidden character's name ("Golden Pickle") is NEVER spoken or shown in UI, never described as "Pickle in gold"; phone calls only by one character (Dale Marsh) - no other "phone call" lines; no AI-generated images, no voxels; palette tokens Night #1B1035, Plum #3A2263, Gold #F5C542, Amber #C48020, Pickle #7ED957, Cream #F4EFE6; pixel art uses nearest-neighbor filtering; lore dates consistent (shop opened 1987; a "1983" label contradicted it). Leaks found by text audit: credits line "and Golden Pickle", game-over text naming the killer, `display_name` in a .tres card, a lore line tying the hidden character to the mascot, unvoiced extra CSV rows. Fix pattern: use "Something"/"???"/"The wrong color", delete stray rows.

## Pitfalls (mistakes seen)

M96 story/content rule leaked into UI text (still outstanding at the end of FNAP).

## Verify

`grep -rniE "<forbidden names>" scripts resources assets/data *.csv` returns 0 hits in player-facing strings.

## Origin

FNAP. Source notes: process-playbook.md section 7; BOARD.md line 35; QA_CHECKLIST.fnap_example.md A4-A7.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
