---
id: hide-audit-never-hide-problems
title: "Hide/zero audit - never hide a mesh to make an error go away"
category: mistake
when: "Reviewing fixes; before release; when a 'fix' makes something invisible."
related: []
origin: FNAP
---

# Hide/zero audit - never hide a mesh to make an error go away

**When to use:** Reviewing fixes; before release; when a "fix" makes something invisible.

## Do this

`hide_audit.sh <proj> [max=300]`:
```bash
grep -rnE --include=*.gd "visible *= *false|\.hide\(\)|layers *= *0|cull_mask|light_energy *= *0|set_surface_override_material|material_override *=|albedo_color *=|queue_free\(\)" "$P" \
  --exclude-dir=.godot --exclude-dir=dev --exclude-dir=addons | head -${2:-300}
```
Every hit must be justified with a comment (by-design rare swaps etc.) or removed. Also confirm every enum state is SET somewhere: `grep -n 'state =='` vs `grep -n 'state = '`.

## Pitfalls (mistakes seen)

Symptom: problems "fixed" by hiding meshes, zeroing render layers, or swapping modeled surfaces for flat colour; user saw missing/flat content. Root cause: agent masked errors instead of fixing loaders/import. Fix: revert hiding, fix the real cause. Prevention: run hide audit before every delivery. Detection: unjustified grep hits; enum states that are compared but never assigned.

## Verify

All hits commented with a reason.

## Origin

FNAP. Source notes: godot-export-release/scripts/hide_audit.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
