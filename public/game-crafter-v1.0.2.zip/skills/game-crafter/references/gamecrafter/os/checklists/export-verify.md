# Export verification (run before every delivery)
1. **Parse/import clean:** `godot --headless --path <proj> --import --quit` → exit 0, no `Parse Error` / `SCRIPT ERROR` in output. (Godot 4.x: check the log text, because the exit code alone can be 0 with script errors.)
2. **Lint:** `python3 lint_export_safety.py <proj>` → 0 errors.
3. **Pack:** `godot --headless --path <proj> --export-pack "Linux" /tmp/check.pck` (or a full `--export-debug`/`--export-release`).
4. **Probe from the pack:** run the export probe scene from inside the pack → `PROBE_DONE fails=0`. (Release templates refuse a scene path on the command line: make a probe copy of the project whose `run/main_scene` is the probe, export it debug, and pass arguments by **environment variables**.)
5. **Screenshot from the pack** under Xvfb (`os/tools/godot_xvfb.md`), `--audio-driver Dummy --rendering-driver opengl3` if Vulkan fails. Take shots of: title, first gameplay, every character/enemy, every jumpscare (mid-animation), every dark area lit and unlit, every camera feed, menus.
6. **Open each PNG and describe it.** Real textured models? Animation mid-pose (not T-pose)? Darkness right? Text readable? No placeholder boxes or capsules?
7. **Executables:** Windows PE machine type `0x8664` (x64) / `0xaa64` (ARM64). Linux binary has the exec bit inside the zip. The mac `.app` zip opens.
8. **Zips:** `unzip -tq` each zip, check its size against the last good build (a big drop means missing assets).
9. Write the results into MANIFEST.md (verified / not verified).
