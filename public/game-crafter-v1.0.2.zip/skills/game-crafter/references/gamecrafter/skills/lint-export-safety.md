---
id: lint-export-safety
title: "Static lint for export-only bugs (lint_export_safety.py)"
category: testing-qa
when: "Before every export/build; after adding any file loading code or new data files."
related: []
origin: FNAP
---

# Static lint for export-only bugs (lint_export_safety.py)

**When to use:** Before every export/build; after adding any file loading code or new data files.

## Do this

`python3 lint_export_safety.py <proj> [--strict]`; exit 1 on any E (or W with --strict). Skips `.godot/` and `addons/`; treats `/dev/`, `*_check.gd`, `/tools/` as dev files (exempt from E rules). Rules:
- E1 `FileAccess.(file_exists|open|get_file_as_string)(...res://....<importable>)` where importable = `glb|gltf|png|jpe?g|webp|svg|ogg|wav|mp3|ogv|tres|tscn|obj|fbx` -> raw file not in PCK.
- E2 `ProjectSettings.globalize_path("res://...")` then reading from disk (editor only). Downgraded to W4 if a `load(`/`ResourceLoader.exists|load`/`load_named(` appears in the 10 lines above (guarded fallback; confirm primary path uses load()).
- E3 `get_files|list_dir_begin|get_files_at` on res:// in a file WITHOUT `packed_name`/`.remap`/`.import` handling -> "add NodeFinder.packed_name() handling; matching extensions like .ogv/.glb/.png fails on 'x.ogv.import' in a build".
- E4 `Image.load_from_file`, `AudioStream*.load_from_file`, `append_from_file` (GLTFDocument) on res:// as primary path.
- W1 data files (`.csv .txt .cues .xml .cfg .md .dat .bin`) referenced by code (filename, relpath or dirname appears in code text) but not matched (fnmatch on relpath or basename) by ANY preset include_filter. Skips `docs/`, `tools/`, README.txt, LICENSE.txt, project.godot. `.json` excluded because it ships raw in 4.7.
- W2 `scripts/dev` exists but no exclude_filter mentioning dev/_check/.py; or no export_presets.cfg.
- W3 hide/zero audit: `visible = false`, `layers = 0`, `cull_mask`, `light_energy = 0`, `set_surface_override_material`, `material_override =` (printed for human justification, first 200).
Ends with `SUMMARY errors=N warnings=N audit_hits=N presets=[...]`. On FNAP it still found 4 spots, e.g. `splash.gd` intro-video search matching `.ogv` on names ending `.ogv.import`.

## Pitfalls (mistakes seen)

Directory scan in splash matched `.ogv` -> in build file is `intro.ogv.import` -> video never found -> strip `.import`/`.remap` (packed_name helper).

## Verify

SUMMARY errors=0; each W3 hit has a justification comment.

## Origin

FNAP. Source notes: godot-export-release/scripts/lint_export_safety.py; SKILL.md "Static lint".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
