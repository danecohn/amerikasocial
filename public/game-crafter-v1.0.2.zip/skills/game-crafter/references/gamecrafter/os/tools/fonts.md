# Tool: fonts.py

**Purpose:** Original 5x7 pixel font generator with several stylings → TTF/bitmap fonts for Godot.

**Usage:** `python3 fonts.py <out_dir>`

**Skill:** see `skills/bitmap-pixel-font-to-ttf.md`

**Extract:** save the block below as `fonts.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Pixel font generator. Forgotten Woods Studios. Original 5x7 glyph drawings, several stylings.
make_font(path, family, body="base|italic|bold|wide|serif", cell="square|chamfer|round|dot|diamond|stitch", chamfer..)
Body fonts are meant for font_size 10 (1 px per cell); display fonts for 20/30/40 (cells visible)."""
import sys, os, random
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen

G = {
"A":["01110","10001","10001","11111","10001","10001","10001"],
"B":["11110","10001","10001","11110","10001","10001","11110"],
"C":["01111","10000","10000","10000","10000","10000","01111"],
"D":["11110","10001","10001","10001","10001","10001","11110"],
"E":["11111","10000","10000","11110","10000","10000","11111"],
"F":["11111","10000","10000","11110","10000","10000","10000"],
"G":["01111","10000","10000","10011","10001","10001","01111"],
"H":["10001","10001","10001","11111","10001","10001","10001"],
"I":["11111","00100","00100","00100","00100","00100","11111"],
"J":["00111","00010","00010","00010","00010","10010","01100"],
"K":["10001","10010","10100","11000","10100","10010","10001"],
"L":["10000","10000","10000","10000","10000","10000","11111"],
"M":["10001","11011","10101","10101","10001","10001","10001"],
"N":["10001","11001","10101","10011","10001","10001","10001"],
"O":["01110","10001","10001","10001","10001","10001","01110"],
"P":["11110","10001","10001","11110","10000","10000","10000"],
"Q":["01110","10001","10001","10001","10101","10010","01101"],
"R":["11110","10001","10001","11110","10100","10010","10001"],
"S":["01111","10000","10000","01110","00001","00001","11110"],
"T":["11111","00100","00100","00100","00100","00100","00100"],
"U":["10001","10001","10001","10001","10001","10001","01110"],
"V":["10001","10001","10001","10001","10001","01010","00100"],
"W":["10001","10001","10001","10101","10101","11011","10001"],
"X":["10001","10001","01010","00100","01010","10001","10001"],
"Y":["10001","10001","01010","00100","00100","00100","00100"],
"Z":["11111","00001","00010","00100","01000","10000","11111"],
"0":["01110","10011","10101","10101","10101","11001","01110"],
"1":["00100","01100","00100","00100","00100","00100","01110"],
"2":["01110","10001","00001","00110","01000","10000","11111"],
"3":["11110","00001","00001","01110","00001","00001","11110"],
"4":["00010","00110","01010","10010","11111","00010","00010"],
"5":["11111","10000","11110","00001","00001","10001","01110"],
"6":["00110","01000","10000","11110","10001","10001","01110"],
"7":["11111","00001","00010","00100","01000","01000","01000"],
"8":["01110","10001","10001","01110","10001","10001","01110"],
"9":["01110","10001","10001","01111","00001","00010","01100"],
".":["00000","00000","00000","00000","00000","01100","01100"],
",":["00000","00000","00000","00000","01100","00100","01000"],
":":["00000","01100","01100","00000","01100","01100","00000"],
";":["00000","01100","01100","00000","01100","00100","01000"],
"!":["00100","00100","00100","00100","00100","00000","00100"],
"?":["01110","10001","00001","00110","00100","00000","00100"],
"'":["00100","00100","01000","00000","00000","00000","00000"],
'"':["01010","01010","10100","00000","00000","00000","00000"],
"-":["00000","00000","00000","11111","00000","00000","00000"],
"+":["00000","00100","00100","11111","00100","00100","00000"],
"/":["00001","00001","00010","00100","01000","10000","10000"],
"(":["00010","00100","01000","01000","01000","00100","00010"],
")":["01000","00100","00010","00010","00010","00100","01000"],
"[":["01110","01000","01000","01000","01000","01000","01110"],
"]":["01110","00010","00010","00010","00010","00010","01110"],
"%":["11001","11010","00010","00100","01000","01011","10011"],
"#":["01010","01010","11111","01010","11111","01010","01010"],
"&":["01100","10010","10100","01000","10101","10010","01101"],
"*":["00000","10101","01110","11111","01110","10101","00000"],
"=":["00000","00000","11111","00000","11111","00000","00000"],
"<":["00010","00100","01000","10000","01000","00100","00010"],
">":["01000","00100","00010","00001","00010","00100","01000"],
"_":["00000","00000","00000","00000","00000","00000","11111"],
"@":["01110","10001","10111","10101","10111","10000","01110"],
"|":["00100","00100","00100","00100","00100","00100","00100"],
" ":["00000"]*7,
}

UNIT = 100
LOW = {"g":["00000","01111","10001","10001","01111","00001","01110"],}

def variant(rows, body):
    rows = [r for r in rows]
    if body == "italic":
        out=[]
        for i,r in enumerate(rows):
            sh = 1 if i < 3 else 0
            out.append(("0"*sh + r)[:5+1].ljust(6,"0"))
        return out
    if body == "bold":
        return [ (r+"0") if False else "".join("1" if (r[i]=="1" or (i>0 and r[i-1]=="1")) else "0" for i in range(5))+("1" if r[4]=="1" else "0") for r in rows]
    if body == "wide":
        return ["".join(c*2 for c in r) for r in rows]
    if body == "serif":
        out=list(rows)
        if rows[0]=="00100" and rows[-1]!="00100": pass
        if rows[0] in ("01110","00100") and rows[6] in ("01110","00100"):
            out[0]="11111" if rows[0]=="00100" else rows[0]; out[6]="11111" if rows[6]=="00100" else rows[6]
        return out
    return rows

def cell(pen, x, y, size, shape, c):
    if shape == "chamfer":
        pts=[(x+c,y),(x+size-c,y),(x+size,y+c),(x+size,y+size-c),(x+size-c,y+size),(x+c,y+size),(x,y+size-c),(x,y+c)]
    elif shape == "round":
        c=size//3
        pts=[(x+c,y),(x+size-c,y),(x+size,y+c),(x+size,y+size-c),(x+size-c,y+size),(x+c,y+size),(x,y+size-c),(x,y+c)]
    elif shape == "diamond":
        h=size//2
        pts=[(x+h,y),(x+size,y+h),(x+h,y+size),(x,y+h)]
    elif shape == "dot":
        s=int(size*0.7); o=(size-s)//2
        pts=[(x+o,y+o),(x+o+s,y+o),(x+o+s,y+o+s),(x+o,y+o+s)]
    elif shape == "stitch":
        s=int(size*0.55); o=(size-s)//2
        pts=[(x+o,y+o),(x+o+s,y+o),(x+o+s,y+o+s),(x+o,y+o+s)]
    else:
        pts=[(x,y),(x+size,y),(x+size,y+size),(x,y+size)]
    pen.moveTo(pts[0])
    for p in pts[1:]: pen.lineTo(p)
    pen.closePath()

def make_font(path, family, body="base", shape="square", chamfer=22, pad=0, tracking=0, drip=0.0, seed=1, skew=0):
    rng = random.Random(seed)
    order=[".notdef"]; names={}
    chars=dict(G)
    for ch in list(chars): names[ch]="space" if ch==" " else "uni%04X"%ord(ch)
    for lo in "abcdefghijklmnopqrstuvwxyz": names[lo]="uni%04X"%ord(lo); chars[lo]=G[lo.upper()]
    for n in sorted(set(names.values())): order.append(n)
    glyphs={}; metrics={}
    maxw=0
    for ch,rows in chars.items():
        rows=variant(rows, body)
        w=len(rows[0]); maxw=max(maxw,w)
        pen=TTGlyphPen(None)
        for r,row in enumerate(rows):
            for ci,c in enumerate(row):
                if c!="1": continue
                y=(6-r)*UNIT; x=ci*UNIT+UNIT//2
                if skew: x+=int(skew*(6-r))
                cell(pen,x-pad,y-pad,UNIT+2*pad,shape,chamfer)
                if drip and r==6 and rng.random()<drip:
                    for k in range(1,rng.randint(2,3)):
                        cell(pen,x,y-k*UNIT,UNIT,"square",0)
        n=names[ch]
        if n not in glyphs:
            glyphs[n]=pen.glyph(); metrics[n]=((w+1)*UNIT+tracking+(UNIT if skew else 0),0)
    glyphs[".notdef"]=TTGlyphPen(None).glyph(); metrics[".notdef"]=(6*UNIT,0)
    fb=FontBuilder(1000,isTTF=True); fb.setupGlyphOrder(order)
    fb.setupCharacterMap({ord(ch):n for ch,n in names.items()})
    fb.setupGlyf(glyphs); fb.setupHorizontalMetrics(metrics)
    ASC=7*UNIT+80; DESC=250 if drip else 150
    fb.setupHorizontalHeader(ascent=ASC,descent=-DESC)
    fb.setupNameTable({"familyName":family,"styleName":"Regular","copyright":"Original design. Forgotten Woods Studios."})
    fb.setupOS2(sTypoAscender=ASC,sTypoDescender=-DESC,usWinAscent=ASC,usWinDescent=DESC)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fb.setupPost(); fb.save(path)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
