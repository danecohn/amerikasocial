---
id: godot-viewport-screenshot-shot-gd
title: "Screenshot any scene from the CLI (shot.gd)"
category: testing-qa
when: "Need visual proof of a scene, store screenshots, before/after evidence."
related: [mistake-headless-flag-has-no-renderer]
origin: FNAP
---

# Screenshot any scene from the CLI (shot.gd)

**When to use:** Need visual proof of a scene, store screenshots, before/after evidence.

## Do this

- Must render: run under xvfb + Vulkan (see godot-headless-render-swiftshader); `--headless` gives no pixels.
- Read pixels only after `await RenderingServer.frame_post_draw`.
- Template `templates/godot_dev/shot.gd`, usage: `godot --path P -s shot.gd -- <scene> <out.png> <frames> [camera_node_name_or_empty] [extra]`
```gdscript
extends SceneTree
var args: PackedStringArray
func _initialize() -> void:
    args = OS.get_cmdline_user_args()
    var scn: PackedScene = load(args[0])
    if scn == null:
        print("SHOT_FAIL load ", args[0]); quit(2); return
    var inst := scn.instantiate()
    root.add_child(inst); current_scene = inst
    _run.call_deferred()
func _run() -> void:
    var frames := int(args[2]) if args.size() > 2 else 90
    for i in frames: await process_frame
    await RenderingServer.frame_post_draw
    var img := root.get_texture().get_image()
    img.save_png(args[1]); print("SHOT_OK ", args[1], " ", img.get_size()); quit(0)
```
- In a game scene: `await RenderingServer.frame_post_draw; get_viewport().get_texture().get_image().save_png(path)`.
- Wait >= 1.0 s after camera/room change (lights, TAA settle); 2.4 s for flashlight reveals.

## Pitfalls (mistakes seen)

empty/black images from `--headless` (mistake-headless-flag-has-no-renderer).

## Verify

`SHOT_OK` printed AND open the PNG and look at it.

## Origin

FNAP. Source notes: T/godot_dev/shot.gd; G line 20; L §5.3 (lines 255-266), §5.5 line 277.

## Related skills

- [mistake-headless-flag-has-no-renderer](mistake-headless-flag-has-no-renderer.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
