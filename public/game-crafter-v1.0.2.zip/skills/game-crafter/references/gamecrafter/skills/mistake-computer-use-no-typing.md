---
id: mistake-computer-use-no-typing
title: "Typing in terminal/Run dialog blocked in computer-use"
category: mistake
when: "Running things on user PC via computer-use."
related: []
origin: FNAP
---

# Typing in terminal/Run dialog blocked in computer-use

**When to use:** Running things on user PC via computer-use.

## Do this

Click-only apps; get File Explorer grant -> double-click a `.bat`; every script writes a transcript log (`Start-Transcript` / `> log 2>&1`).

## What happened, root cause, fix, prevention

Symptom: can't type commands. Fix above.

## Verify

Log file read.

## Origin

FNAP. Source notes: mistakes-log.md M73.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
