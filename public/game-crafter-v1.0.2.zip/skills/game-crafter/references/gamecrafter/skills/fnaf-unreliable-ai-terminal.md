---
id: fnaf-unreliable-ai-terminal
title: "Fake "LLM" in-world terminal: typo-tolerant intent parser + scripted failures"
category: gameplay-systems
when: "Adding a comic/unreliable helper the player can type commands to (doors, cameras, power, time)."
related: []
origin: FNAP
---

# Fake "LLM" in-world terminal: typo-tolerant intent parser + scripted failures

**When to use:** Adding a comic/unreliable helper the player can type commands to (doors, cameras, power, time).

## Do this

- NOT a real LLM. `AssistantBrain.parse(text) -> {intent, side, cam, who}` by keyword scoring with typo tolerance:
  Levenshtein <=1 for words <7 chars, <=2 otherwise; multi-word keywords +1.5; exact word 1.0, near match 0.8; regex for
  `cam 1a`; room and character aliases from JSON; side words (left/west/east...).
- JSON `assets/data/assistant_lines.json`: intents `door_close, door_open, flashlight_on, flashlight_charge, camera,
  where, power, time, music, joke, help`, each with `keywords`, `needs`, `cost` (power % per query), `success[]`, optional
  `not_at_door`/`in_office`; `failures{mishear, wrong_answer, hallucination, refusal, meme}`; `unknown[]`, `boot[]`,
  `thinking[]`; placeholders `{side} {cam} {cam_name} {who} {room} {power} {time} {torch}`.
- `_think`: spend power, spinner + thinking loop 1.5-4 s (x speed), then `_resolve`: `failure_rate = clamp(0.12 +
  0.07*(night-1) + fail_delta, 0.04, 0.85)`. Failure kinds: mishear flips the door side or swaps the camera via the
  poster-swaps lie map; wrong_answer names a room from a FAKE map (`poster-swaps.json`: `when_animatronic_is_in:
  {CAM_x: {reports_cam, reports_name}}`). "help" never fails. On success `_do_action` calls back into the office
  (`assistant_set_door`, `_set_flashlight`, `monitor.select_camera`, `assistant_play_music`).
- Design: the phone voice warns it is "wrong about half the time and very sure about it" and "too slow" for the runner
  - the helper is a trap that costs power and time.
- HUD "GPT Commands" card is generated from `AssistantBrain.command_phrases()` (single source of truth, verified by
  `assistant_check.gd`).
- Offline test hook: `assistant.forced = {"delay":0, "success":true | "failure":kind, "reply":..}` and
  `_on_submit_text()`.

## Pitfalls (mistakes seen)

help list drifting from what the parser accepts -> generate it from the parser.

## Verify

`xvfb-run ... -s tools/assistant_check.gd -- out=/tmp/gpt` parses every command phrase, asserts intent, reports
voice coverage.

## Origin

FNAP. Source notes: REF §2.11, §1.5, §2.9; CALLS N1, N2; BIBLE Tone Notes.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
