---
id: fnaf-first-person-arms
title: "First-person arms viewmodel driving the camera (stand/walk/lean/type clips)"
category: 3d-blender
when: "Adding visible arms and authored camera motion to a seated FP game."
related: [fnaf-runtime-glb-anim-loops]
origin: FNAP
---

# First-person arms viewmodel driving the camera (stand/walk/lean/type clips)

**When to use:** Adding visible arms and authored camera motion to a seated FP game.

## Do this

- `fp_arms.glb` mounted under a `PlayerRig` Node3D that owns the camera. Bone `CameraShake` drives the camera transform
  every skeleton update: `skel.skeleton_updated.connect(_apply_camera_shake)` -> authored camera motion.
- Viewmodel pushed back `CLEAR_Z = -0.22` so shoulders don't sit on the lens.
- `fp_arms_tablet.gd` is a `SkeletonModifier3D` that stows the tablet plate until a tablet clip plays.
- Clip names: `fp_get_up`, `fp_sit_down`, `fp_walk_to_door`, `fp_lean_out_L/R`, `fp_door_yank_*`, `fp_monitor_up/down`,
  `fp_dock/undock`, `fp_type`, `fp_jumpscare_react`, `fp_death`, `fp_flashlight_dies` (one-shots listed in
  fnaf-runtime-glb-anim-loops).

## Pitfalls (mistakes seen)

none.

## Verify

char_check screenshots.

## Origin

FNAP. Source notes: REF §3.3, §3.2, §2.2.

---------------------------------------------------------------------------------------------------

## Related skills

- [fnaf-runtime-glb-anim-loops](fnaf-runtime-glb-anim-loops.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
