# Tool: render_bb.ts

**Purpose:** Renders a BeepBox song hash to WAV offline with the real BeepBox synth (MIT) — works when beepbox.co is unreachable.

**Usage:** `bun run render_bb.ts "<hash>" out.wav seamless`

**Skill:** see `skills/beepbox-offline-render-node-typescript.md`

**Extract:** save the block below as `render_bb.ts` (exact contents) and run it. Adapt paths marked `<...>`.

```typescript
// Renders a BeepBox song (URL hash) to 16-bit stereo WAV with the REAL BeepBox synth
// (https://github.com/johnnesky/beepbox, MIT). Same engine as beepbox.co's export.
// Usage: bun run render_bb.ts "<hash|URL>" out.wav [seamless]
//   seamless: renders two passes and keeps the 2nd, so the reverb tail wraps and the WAV loops cleanly.
import { Song, Synth } from "./bb_out/synth";
import * as fs from "fs";

const [, , input, out, mode] = process.argv;
const seamless = mode === "seamless";
let song: any;
if (input.endsWith(".json")) {
  song = new Song();
  song.fromJsonObject(JSON.parse(fs.readFileSync(input, "utf8")));
  fs.writeFileSync(out + ".hash.txt", song.toBase64String());
} else {
  const hash = input.includes("#") ? input.split("#")[1] : input;
  song = new Song(hash);
}
const synth: any = new Synth(song);
const sr = 44100;
synth.samplesPerSecond = sr;
synth.loopRepeatCount = seamless ? 1 : 0;
synth.isPlayingSong = true;
synth.warmUpSynthesizer(song);
const chunk = 4096;
const L: number[] = [], R: number[] = [];
let guard = 0;
while (synth.playing && guard++ < 100000) {
  const l = new Float32Array(chunk), r = new Float32Array(chunk);
  synth.synthesize(l, r, chunk, true);
  for (let i = 0; i < chunk; i++) { L.push(l[i]); R.push(r[i]); }
}
let start = 0, n = L.length;
if (seamless) { n = Math.floor(L.length / 2); start = n; }
// trim trailing digital silence on non-seamless renders
if (!seamless) { while (n > sr && Math.abs(L[start + n - 1]) < 1e-4 && Math.abs(R[start + n - 1]) < 1e-4) n--; }
const buf = Buffer.alloc(44 + n * 4);
buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 4, 4); buf.write("WAVEfmt ", 8);
buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(2, 22);
buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 4, 28); buf.writeUInt16LE(4, 32); buf.writeUInt16LE(16, 34);
buf.write("data", 36); buf.writeUInt32LE(n * 4, 40);
let o = 44;
for (let i = 0; i < n; i++) {
  const a = Math.max(-1, Math.min(1, L[start + i])), b = Math.max(-1, Math.min(1, R[start + i]));
  buf.writeInt16LE((a * 32767) | 0, o); buf.writeInt16LE((b * 32767) | 0, o + 2); o += 4;
}
fs.writeFileSync(out, buf);
console.log("wrote", out, (n / sr).toFixed(1) + "s", "bars", song.barCount, "loopStart", song.loopStart, "loopLen", song.loopLength);
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
