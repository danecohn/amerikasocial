---
id: faction-standing-tracks-tiers-caps
title: "Faction standing 0–100 with five tiers, gain caps and systemic cross-effects"
category: rpg-systems
when: "RPG reputation system."
related: []
origin: Caesarea
---

# Faction standing 0–100 with five tiers, gain caps and systemic cross-effects

**When to use:** RPG reputation system.

## Do this

- All tracks 0..100, tiers at **0/15/35/60/85**; "high" in gates = 60+ (tier 3). Each tier has a label per faction (Fugitive/Disfavored/Citizen/Trusted/Hero of the Nation; Hated/Distrusted/Known/Friend/Beloved; Suspect/Contact/Ally/Trusted/Sworn …) and unlocks (T2 vendors/gates, T3 contacts/safe houses, T4 unique).
- Starting values come from the background table at character creation; schema default only applies before creation.
- **Caps limit gains only** while a condition holds: standing already above the cap is kept, losses always apply, cap lifts when the condition clears. Example rows `{track, max, when, why}`: caesarea_standing 14 while `civic_status == "fugitive"`; brotherhood_trust 34 while `reported_bos AND brotherhood_depot == ""`; house_favor 34 while `NOT house_restored`.
- Systemic events table `apply_event(event_id, scale)` (authored scene deltas applied exactly as written; this table only for combat/crime/trade/hacking). E.g. `report_dissident`: Caesarea +5, Subura −8, Brotherhood −3, Assembly −5, Exiles −3, Suspicion −5; `shelter_exile`: −5/+2/+2/+2/+8, Susp +8; `kill_civilian`: −5/−10/·/−8/−5, Susp +25; `donate_rations_subura`: Subura +3, Assembly +1, Exiles +1 (pure decency, no cost).
- Council/Senate/Legion flags are authored only (nothing systemic moves them). Derived counts (`legions_loyal_count` from 5 bools) recomputed by the manager.
- API: `get_standing`, `get_tier -> 0..4`, `get_tier_label`, `change(track, delta, source)`, `set_track`, `get_cap`, `apply_event`, signals `standing_changed`, `tier_changed`. Short ids (`"subura"`) accepted.
- Data file `data/factions/factions.json`: `tracks{id:{label,tiers[[min,label]…]}}`, `caps[{track,max,when,why}]`, `events{id:{track:delta}}`.

## Verify

tests for cap holding, cap lifting, loss under cap, tier signal emission.

## Origin

Caesarea. Source notes: design/07 §3; design/08 §3.2, §4.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
