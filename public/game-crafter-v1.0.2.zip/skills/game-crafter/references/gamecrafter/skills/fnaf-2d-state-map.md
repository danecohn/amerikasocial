---
id: fnaf-2d-state-map
title: "State map: enumerate every game state and the exact image that shows it"
category: planning-design
when: "Building a 2D (still-plate) FNAF-like, handing art to an engine builder, or auditing art coverage."
related: [mistake-character-plate-under-shut-door]
origin: FNAP
---

# State map: enumerate every game state and the exact image that shows it

**When to use:** Building a 2D (still-plate) FNAF-like, handing art to an engine builder, or auditing art coverage.

## Do this

- All scene images fixed 1280x720, no panning: every plate shown whole at (0,0).
- Organise by CAMERA (feed image under static/border/name/map overlays), OFFICE (seated plates), RUNNER RUN, JUMPSCARES,
  MENU / NIGHT CARDS / 6 AM / GAME OVER / ENDING, UI OVERLAYS, AUDIO, PHONE SCRIPTS, NOT INCLUDED, MISSING, INVENTORY,
  IMAGE SIZES, QA.
- Per camera list each state as `<state description>   <path>`, e.g. CAM 1A: all present / Remi gone / Dilly gone /
  Pickle alone / empty (no "Pickle gone, others present" because of the leave order). One character per image; if two
  share a room show the highest priority (Remi > Dilly > Pickle).
- Folder layout: `01-characters/` (reference sheets, not shown in game), `02-office/seated/`, `03-cameras/fnaf-states/` +
  `03-cameras/plates/` (one locked empty plate per camera), `04-ui/` (+ `UI-LAYOUT.txt` positions), `05-jumpscares/`,
  `06-menu/`, `07-audio/` (+ `AUDIO-INDEX.csv`), `08-phone-scripts/`, `09-fusion-build/BUILD-NOTE.txt` (event list,
  suggested odds).
- Generated, not hand-written: "Generated from the real files in the tree by gen_statemap.py (it also runs the package
  QA)".
- Inventory example: 303 files (241 images, 62 other); 216 unique images by sha256.

## Pitfalls (mistakes seen)

mistake-character-plate-under-shut-door.

## Verify

The generator reports "referenced files missing: none" and "files not mentioned: none".

## Origin

FNAP. Source notes: STATEMAP entire (lines 1-5, 7-89, 306-328).

## Related skills

- [mistake-character-plate-under-shut-door](mistake-character-plate-under-shut-door.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
