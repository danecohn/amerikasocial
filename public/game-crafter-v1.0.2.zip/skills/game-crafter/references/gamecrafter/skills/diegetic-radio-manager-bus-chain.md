---
id: diegetic-radio-manager-bus-chain
title: "In-world radio (announcer then song) with an engine-side speaker FX bus and 3-layer ducking"
category: audio-music
when: "Diegetic radio/PA/broadcast in a game."
related: []
origin: Caesarea
---

# In-world radio (announcer then song) with an engine-side speaker FX bus and 3-layer ducking

**When to use:** Diegetic radio/PA/broadcast in a game.

## Do this

- Keep voice takes **dry** on disk; apply speaker sound in engine on a bus so the same takes work clean elsewhere. Bus chain `VoxRomae`: HighPass 320 Hz → LowPass 3.6 kHz → EQ6 [−12,−10,−2,+4,+2,−12] → Distortion (overdrive drive 0.18, −3 dB) → Reverb (room 0.18, wet 0.10) → Limiter −1 dB; children `VoxRomaeVoice` (announcer) and `VoxRomaeMusic` (songs −3 dB, compressor side-chained to Voice).
- Generate `default_bus_layout.tres` from code (`tools/make_bus_layout.gd` via `--script`) and also `ensure_buses()` at runtime if the file is missing.
- Ducking: (1) side-chain compression; (2) talk-over tween — song starts `overlap_sec` 0.8 s before voice ends at −10 dB, rises after; (3) gameplay duck −8 dB on whole station while dialogue open.
- Data `vox_romae_playlist.json`: `buses, defaults, songs{id:{title, kind, paths[], optional}}, cues{id:{voice, text, then, overlap_sec?, event?}}, rotations{id:[cue…]}`. Rotations per story state (`act1_curfew`…). Cue without song can emit `cue_event(id, "caesar_address")` for a scene to show text.
- Missing assets: missing song → ONE warning, hold 2 s, move on; missing voice → hold reading time at 14 chars/s so captions/pacing still work. `missing_songs()`, `missing_voices()` for QA.
- In-world speakers: two AudioStreamPlayer3D (unit size 3, max distance 25 m, inverse-square) on the Vox buses, `register_speaker(voice_3d, music_3d)`. Later work: position sync for speakers starting mid-cue + raycast low-pass occlusion.
- Location music loops can be played on the radio's music player for a zone bed.

## Pitfalls (mistakes seen)

in-world speakers mirror from the start of the cue (not synced) — documented as a known gap.

## Origin

Caesarea. Source notes: godot_starter/README Audio; design/07 §17; design/08 §9.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
