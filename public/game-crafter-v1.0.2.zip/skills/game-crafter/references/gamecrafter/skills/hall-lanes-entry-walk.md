---
id: hall-lanes-entry-walk
title: "Fix characters "walking to corners": hall lanes and entry points"
category: ai-enemies
when: "Patrol characters snapping/walking to bad spots on camera."
related: []
origin: Pickle's Pickle Shop
---

# Fix characters "walking to corners": hall lanes and entry points

**When to use:** Patrol characters snapping/walking to bad spots on camera.

## Do this

Baked waypoints parked characters under the camera or against walls. Define HALL_LANES per hall: an `entry` point (end of hall they walk in from) and per-character lane positions in the middle of the hall inside the camera's view; create/move Marker3D `WP_<short>_<Name>` / `WP_<short>_Entry` at runtime and face them toward the camera. `_walk_in()`: start at the entry if > 0.8 m away, else 1.5*speed back along -Z (clamped 0.6..1.2), face travel direction, play move clip, tween to target over `clamp(dist/speed, 0.5, 4.0)` s, then play room clip. Use `_visual_token` to cancel stale callbacks when a newer move happens.

## Pitfalls (mistakes seen)

"walked to corners" bug in the original. Fixed by lanes.

## Verify

Camera screenshots per hall with each character; patrol_sim.

## Origin

Pickle's Pickle Shop. Source notes: level_builder.gd L190-226; animatronic.gd L575-608; MANIFEST.md DONE.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
