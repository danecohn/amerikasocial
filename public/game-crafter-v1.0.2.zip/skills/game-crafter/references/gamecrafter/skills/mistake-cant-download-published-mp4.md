---
id: mistake-cant-download-published-mp4
title: "Couldn't download the published MP4"
category: mistake
when: "Fetching Descript outputs."
related: []
origin: FNAP
---

# Couldn't download the published MP4

**When to use:** Fetching Descript outputs.

## Do this

Media host blocked for sandbox AND PC browser pane; give share + download links; user downloads.

## What happened, root cause, fix, prevention

Symptom: blocked download. Fix above.

## Verify

Links given.

## Origin

FNAP. Source notes: mistakes-log.md M87.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
