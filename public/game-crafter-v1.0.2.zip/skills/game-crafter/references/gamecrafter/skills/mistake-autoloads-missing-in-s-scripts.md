---
id: mistake-autoloads-missing-in-s-scripts
title: "Mistake - autoload singletons are not available in `godot -s` SceneTree scripts"
category: mistake
when: "A `-s` check script references `GameState`, `AudioManager`, etc."
related: []
origin: FNAP
---

# Mistake - autoload singletons are not available in `godot -s` SceneTree scripts

**When to use:** A `-s` check script references `GameState`, `AudioManager`, etc.

## What happened, root cause, fix, prevention

- Symptom: identifier not found / null for autoload globals in a `godot --headless -s check.gd` run.
- Root cause: `-s` SceneTree scripts start before autoloads attach (source: partly inference, re-verify).
- Fix: write the check as a `.tscn` + script and run the scene with `--path` (e.g. `hall_check.tscn`), so autoloads exist.
- Prevention: any check touching game systems = scene-based check; `-s` scripts only for static asset checks (glb_check, loader_check, which use class_name statics).
- Detection: parse errors in check output.

## Verify

check scene prints its PASS token.

## Origin

FNAP. Source notes: L §2.9 line 123; G line 19; S line 34.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
