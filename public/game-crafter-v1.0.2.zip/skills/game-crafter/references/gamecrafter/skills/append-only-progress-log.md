---
id: append-only-progress-log
title: "Append-only LOG.md with timestamped, evidence-bearing entries"
category: project-management
when: "Every step of a long build, especially with multiple agents or risk of interruption."
related: []
origin: Caesarea
---

# Append-only LOG.md with timestamped, evidence-bearing entries

**When to use:** Every step of a long build, especially with multiple agents or risk of interruption.

## Do this

- `docs/handoff/LOG.md`: "Progress log (append-only, newest at bottom)". One bullet per step: `- 2026-10-09 10:25 PT  <Step name>. <what was built>. <what was NOT run, e.g. "Did not run Blender">. --import exit 0. tests/flow/flow_test.tscn PASS 12/0. tests/test_main.tscn PASS 136/0. Not screenshotted. <what is still missing>. Slice is not shippable. No zip.`
- Agents prefix their name: `- 2026-10-09 09:37 characters: copied proxy/v1/legionary GLBs ... (not yet imported)`.
- Log the interruption itself: "Agent launch interrupted by user; agents stopped after writing partial WIP (unverified). Wrote WORKSTREAMS.md + CURSOR_PROMPT.md ... Hand-off to Cursor."
- Each entry restates the full test count, so regressions show as count drops.

## Pitfalls (mistakes seen)

Entries out of chronological order (10:25 then 10:20) when agents append from different clocks — harmless but use one timezone and append, never insert.

## Verify

grep the last entry; its RESULT line must match a fresh run.

## Origin

Caesarea. Source notes: docs/handoff/LOG.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
