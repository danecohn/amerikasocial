---
id: floor-tile-patterns
title: "Nine 16x16 floor pattern algorithms (flagstone, planks, tile, dirt, grass, metal, salt, cobble, carpet)"
category: pixel-art-2d
when: "Need tileable floor textures that do not look like noise soup."
related: []
origin: Roguelike series
---

# Nine 16x16 floor pattern algorithms (flagstone, planks, tile, dirt, grass, metal, salt, cobble, carpet)

**When to use:** Need tileable floor textures that do not look like noise soup.

## Do this

- Start `Image.new("RGBA",(16,16), c1)`; rng = `random.Random(seed*31 + variant)`; `noise(img, rng, colours, density)` replaces each opaque pixel with a random colour from the list with probability density.
- flagstone: grout lines on row 0 and column 0 (so tiles join seamlessly) + row 8; vertical joints at random x in {5,7,9,10} (top half) and {4,6,11} (bottom half); 1px highlight row 1 `light(c1,.08)`; noise [c2, light(c1,.06), dark(c1,.12)] @0.18.
- planks: horizontal seams every 4px; one butt-joint per plank at random offsets (odd rows {3,6,9,12}, even rows {2,7,13}) + nail pixel; 12% speckle [c2, dark(c1,.1)].
- tile: 8px grid lines in c3; checker the (0,0),(8,8) quarters in c2; one random light pixel; noise dark(c1,.08) @0.06.
- dirt: noise [c2,c3,dark] @0.35 + 1-3 light 2x1 pebbles. grass: noise @0.3 + 3-6 vertical 3px blades `light(c2,.25)`.
- metal: c3 border, 1px top highlight, 4 rivets at (2,2),(13,2),(2,13),(13,13); variant 1 adds a seam.
- salt: noise [c2, light(c1,.25), c3] @0.28 + 2 pure-white sparkles + top line.
- cobble: 5 fixed ellipses (c2 fill, c3 outline) at (1,1),(9,1),(5,8),(13,8),(1,12) + dark noise.
- carpet: 1px checker dither `x = (y//2)%2 .. step 2, every other row` in c2 + top line.
- Seamlessness trick: draw the grout only on the TOP and LEFT edges; the neighbour tile's top/left supplies the bottom/right line.
- Variants: room picks floor 0-2 uniformly 90% of the time, variant 3 (different seed) 10% -> breaks repetition.

## Pitfalls (mistakes seen)

noise density > 0.35 on low-contrast palettes turns into TV static at 1x; keep 0.05-0.3 for floors.

## Verify

tile a 24x12 room and look at 1x and 5x; no visible seams, no strong repeating motif.

## Origin

Roguelike series. Source notes: _tools/tiles.py lines 18-97; room.gd line 154.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
