---
id: flashlight-beam-check
title: "Flashlight cone + raycast reveal, battery drain, flicker when low"
category: gameplay-systems
when: "Flashlight mechanic that reveals or repels enemies."
related: []
origin: Pickle's Pickle Shop
---

# Flashlight cone + raycast reveal, battery drain, flicker when low

**When to use:** Flashlight mechanic that reveals or repels enemies.

## Do this

SpotLight3D range 16, angle 18, energy 3.6, shadows, mounted to the fp_arms flashlight bone (`Flashlight_Beam`/`FlashlightMount`). Drain 4.0 %/s on, regen 1.5 %/s off (x2.5 when docked on the charger). Below 20%: energy *= random 0.4..1.0 flicker, 1% chance per frame of `fp_flashlight_shake`; at 0 -> off + `fp_flashlight_dies`. Every 0.15 s `_beam_check`: for visible actors exposed to the beam (position-based rules, e.g. CAM_4B only when leaning) inside cone angle and range, raycast (no areas) to actor+1.2 m; unobstructed -> `on_flashlight_hit()` (flinch, pupil pinprick, stall >=1.1 s, 1.8 s cooldown). `is_flashlight_on_actor()` (used for reveal) requires player at that side's door, door open, monitor down, no power out, within cone and clear ray to actor+1.35 m. Flashlight works only at a door. Props: battery gauge segments (5, emission 2.5 on / darkened 0.85 off), charge ring pulse, lens emission = energy*1.5.

## Verify

probe with lurker posed (`--shot-door=L`), flashlight on, check `is_flashlight_on_actor`.

## Origin

Pickle's Pickle Shop. Source notes: office_controller.gd L21-22, L394-405, L498-549, L1035-1090, L1427-1436.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
