---
id: mistake-cannot-delete-on-pc
title: "Can't delete/rename on the PC"
category: mistake
when: "Need to clean up/rename user files without a PC shell."
related: []
origin: FNAP
---

# Can't delete/rename on the PC

**When to use:** Need to clean up/rename user files without a PC shell.

## Do this

Give exact File Explorer steps or a `.bat` the user runs. Never delete/rename user files you were not asked to.

## What happened, root cause, fix, prevention

Symptom: stale files remain. Fix above.

## Verify

Listing after user action.

## Origin

FNAP. Source notes: mistakes-log.md M78.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
