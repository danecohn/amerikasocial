---
id: fnaf-security-door
title: "Security door state machine (held / latched / jammed, progress-based blocking)"
category: gameplay-systems
when: "Implementing office doors (3D slide door or 2D overlay door)."
related: [mistake-black-cover-cards-in-doorways, mistake-death-through-closed-door, mistake-hiding-controlled-placeholder-door]
origin: FNAP
---

# Security door state machine (held / latched / jammed, progress-based blocking)

**When to use:** Implementing office doors (3D slide door or 2D overlay door).

## Do this

- States: `held` (mouse button held at the door), `latched` (lever click), `jammed` (power out or intruder).
- `progress` 0..1 moves at `close_time 0.55 s` / `open_time 0.9 s`.
- `blocks_entry()` is `progress >= 0.5` (a half-shut door blocks a jumpscare - QA requirement);
  `is_closed()` is `progress >= 0.95`.
- Real GLB: `Door_L/R` leaf translates `-travel*progress` on Y (travel 2.42 m real model / 3.6 m placeholder).
- Door authors missing parts in code (motor can + gearbox + cog + brackets, status lamp, `DoorMouth_*` hall-depth
  spotlight) but a node of the same name in the GLB ALWAYS wins. It also deletes "black cover" cards (QuadMesh or dark
  unshaded BoxMesh) that previous authors put in doorways.
- Rig lives on the placeholder and ADOPTS real nodes: `adopt_model_node`, `adopt_lever`, `adopt_button`.
- Sketch:
  ```gdscript
  class_name SecurityDoor extends Node3D
  const CLOSE_TIME := 0.55
  const OPEN_TIME := 0.9
  var progress := 0.0
  var held := false
  var latched := false
  var jammed := false
  func _process(delta: float) -> void:
      var want := (held or latched) and not jammed
      progress = clampf(progress + (delta / CLOSE_TIME if want else -delta / OPEN_TIME), 0.0, 1.0)
      if leaf: leaf.position.y = _leaf_base_y - travel * progress
  func blocks_entry() -> bool: return progress >= 0.5
  func is_closed() -> bool: return progress >= 0.95
  ```
- Audio: `door-slam.wav` (close), `door-open.wav` (rattling back up), denied buzz with no power.
- HUD status: "LEFT DOOR: LATCHED / HOLDING / OPEN".

## Pitfalls (mistakes seen)

mistake-hiding-controlled-placeholder-door; mistake-black-cover-cards-in-doorways;
mistake-death-through-closed-door.

## Verify

`door_lurker_sim` asserts real door parts present, door motion, half-shut door blocks scare;
`release_check` asserts `DoorMotor/Lamp` markers.

## Origin

FNAP. Source notes: REF §2.3 Door, §2.9, §8.1 E, §8.2 #3.

## Related skills

- [mistake-black-cover-cards-in-doorways](mistake-black-cover-cards-in-doorways.md)
- [mistake-death-through-closed-door](mistake-death-through-closed-door.md)
- [mistake-hiding-controlled-placeholder-door](mistake-hiding-controlled-placeholder-door.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
