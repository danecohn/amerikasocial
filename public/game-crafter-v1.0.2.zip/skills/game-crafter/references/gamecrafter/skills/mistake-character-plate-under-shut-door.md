---
id: mistake-character-plate-under-shut-door
title: "2D: character visible through a shut door (wrong plate under overlay)"
category: mistake
when: "Compositing 2D office plates with door overlays."
related: []
origin: FNAP
---

# 2D: character visible through a shut door (wrong plate under overlay)

**When to use:** Compositing 2D office plates with door overlays.

## What happened, root cause, fix, prevention

- Symptom: a character's jar/limb pokes past the closed door frame.
- Root cause: using the character-in-doorway plate under the door overlay ("Dilly leans past the right door frame, so her
  jar would show").
- Fix: under a shut door use `*-light-empty` (light on) or the empty plate.
- Prevention: state rule in the state map; contact sheet of all combos.

## Verify

render shut-door + occupant combos.

## Origin

FNAP. Source notes: STATEMAP lines 111-121.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
