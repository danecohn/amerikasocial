---
id: game-soundtrack-tracklist-recipe
title: "The 9-track roguelike soundtrack plan (names, styles, keys, tempi)"
category: audio-music
when: "Planning music for a hub-and-floors roguelike or any small game."
related: []
origin: Roguelike series
---

# The 9-track roguelike soundtrack plan (names, styles, keys, tempi)

**When to use:** Planning music for a hub-and-floors roguelike or any small game.

## Do this

- Track tuple `(name, style, key, mode, bpm, bars, seed)`; THE LAST LAMP:
  title sorrow D minor 62 24 | hub sorrow A dorian 70 24 | run1 dread D phrygian 84 32 | run2 chase E minor 104 32 | run3 dread F# locrian 96 32 | run4 chase C harmonic 116 32 | boss boss D phrygian 140 32 | sorrow sorrow G minor 56 24 | ending hope D major 84 32. Seeds 11..19.
- WARD SEVEN (same plan transposed to F#): title F# minor 62, hub C# dorian 70, run1 F# phrygian 84, run2 B minor 108, run3 G locrian 92, run4 E harmonic 120, boss F# phrygian 144, sorrow B minor 54, ending F# major 88. Seeds 41..49.
- Pattern: one home key per game; floors alternate dread/chase and get faster (84 -> ~120 BPM); boss fastest (140-144); sorrow slowest (54-56) for death; ending is the only major-key track. Resulting lengths 54-107 s.
- Each floor in game.json names its music (`"music":"run1"`), bosses `"music":"boss"`.

## Pitfalls (mistakes seen)

none.

## Verify

soundtrack.txt lists 9 tracks with key/BPM/seconds and links.

## Origin

Roguelike series. Source notes: games/g1_lamp/spec.py L129-139; games/g4_ward/spec.py L104-114; DOCS/soundtrack.txt of both games.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
