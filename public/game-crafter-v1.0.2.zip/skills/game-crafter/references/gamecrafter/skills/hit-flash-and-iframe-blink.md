---
id: hit-flash-and-iframe-blink
title: "Sprite hit flash with over-bright modulate and invulnerability blink"
category: pixel-art-2d
when: "Combat feedback on pixel sprites without extra white-frame art."
related: []
origin: Roguelike series
---

# Sprite hit flash with over-bright modulate and invulnerability blink

**When to use:** Combat feedback on pixel sprites without extra white-frame art.

## Do this

- `anim.modulate = Color(2,2,2)` (player) / `Color(2.2,2.2,2.2)` (enemy) while `_flash > 0` -> sprite goes near white (modulate > 1 brightens in Godot canvas).
- i-frames: `Color(1,1,1,0.45)` on alternating 70 ms windows: `int(Time.get_ticks_msec()/70) % 2 == 0`.
- Shield tint `Color(0.6,0.9,1.6)`; exploder warning blink `Color(2.5,1.2,1.2)` at 16 Hz; phantom enemies alpha 0.12 / sine pulse `0.6 + 0.4*sin(t*30)`; death = tween modulate:a -> 0 over 0.25 s.

## Pitfalls (mistakes seen)

none recorded.

## Verify

hit an enemy in a capture: one or two white frames.

## Origin

Roguelike series. Source notes: kit/kit/player.gd 189-191; enemy.gd 120-141, 306.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
