---
id: fnaf-controls-input-map
title: "Input map for a FNAF-like office"
category: ui-ux
when: "Defining project.godot input actions for an office horror game."
related: []
origin: FNAP
---

# Input map for a FNAF-like office

**When to use:** Defining project.godot input actions for an office horror game.

## Do this

- `door_left` (Q, Left), `door_right` (E, Right), `light_left` (A), `light_right` (D), `toggle_monitor` (Space/S/Down),
  `flashlight` (F), `hold_breath` (Shift), `lean` (Z/RMB), `pull_shutter` (LMB), `open_assistant` (T/Tab),
  `pause_menu` (Esc), `debug_overlay` (F-key), `debug_skip_hour`, `debug_drain_power` (debug only, guarded by
  `OS.is_debug_build()`). Auto mode uses a raw `KEY_G` check.
- Mouse alternative: a "CAMERAS" bar at the bottom of the screen opens the monitor on hover (`monitor_bar_hovered`,
  2D: `cam-flip-bar.png` / `cam-flip-bar-hover.png` 480x56).
- A 10 s fading control hint at night start; "How to Play" modal in the main menu.

## Pitfalls (mistakes seen)

Debug keys must be gated by `OS.is_debug_build()` so players can't skip hours in release.

## Verify

Release build: debug keys do nothing.

## Origin

FNAP. Source notes: REF §1.2 input actions, §2.9, §5.4; STATEMAP line 199.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
