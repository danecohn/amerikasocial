---
id: exported-pack-probe
title: "Probe scene that loads every resource from the exported .pck and reports failures"
category: export-release
when: "Proving an exported build contains all assets (avoiding 'works in editor, magenta in export')."
related: []
origin: Roguelike series
---

# Probe scene that loads every resource from the exported .pck and reports failures

**When to use:** Proving an exported build contains all assets (avoiding "works in editor, magenta in export").

## Do this

- `tools/probe.tscn` (Node + `tools/probe.gd`); reads `res://tools/probe_manifest.json` = `{"resources": [res paths], "raw_files": [paths read with FileAccess]}` generated at build time from the asset folders.
- For each resource: `load(p) if ResourceLoader.exists(p) else null`; print `PROBE_FAIL load <p>`; raw files `FileAccess.file_exists` else `PROBE_FAIL raw`. Prints `PROBE renderer=<method>`, `PROBE_COUNT n`, `PROBE_DONE fails=n`; `get_tree().quit(1 if fails else 0)`; missing manifest -> `PROBE_FAIL manifest missing`, exit 2.
- Run it against the exported pack (main pack override with the probe scene as main) - all 4 games: `PROBE_DONE fails=0 (72 resources)`.
- Also launch the exported Linux binary under Xvfb and check log `WIRING ... missing_art=0` + a first-run screenshot.

## Pitfalls (mistakes seen)

Only exported pack testing catches export filter mistakes; editor runs hide them.

## Verify

exit code 0 and `PROBE_DONE fails=0`.

## Origin

Roguelike series. Source notes: _tools/probe.gd, probe.tscn; MANIFEST.md "Exported pack probe: PROBE_DONE fails=0 (72 resources)".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
