# Tool: shot.gd

**Purpose:** Screenshot scene: load a target scene, wait frames, save PNG; args via environment variables.

**Usage:** `SHOT_SCENE=res://x.tscn SHOT_OUT=/tmp/a.png godot --path <proj> res://tools/qa/shot.tscn`

**Skill:** see `skills/headless-screenshot-harness-xvfb.md`

**Extract:** save the block below as `shot.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
extends Node
## QA screenshot + perf probe. Run via tools/qa/shot.sh (xvfb + software Vulkan). Needs autoloads => scene, not -s (M24).
## User args (after --): <scene_res_path> <out.png> [wait_seconds=2.5] [key=value ...]
##   cam=x,y,z,lx,ly,lz  place a fallback Camera3D (only if no current Camera3D exists, or force=1)
##   spawn=Name          for zones: teleport a node named "Player"/group player to Marker3D <Name>
##   fov=70  force=1
## Writes <out.png> and <out.png>.json (nodes, meshes, tris, draw calls, objects, mem, warnings) and prints "SHOT_OK".
var _args: Dictionary = {}

func _ready() -> void:
	call_deferred("_run")

func _run() -> void:
	var ua := OS.get_cmdline_user_args()
	if ua.size() < 2:
		print("SHOT_FAIL usage: <scene> <out.png> [wait]"); get_tree().quit(2); return
	var scene_path := ua[0]; var out := ua[1]
	var wait_s := float(ua[2]) if ua.size() > 2 and ua[2].is_valid_float() else 2.5
	for a in ua:
		if "=" in a: _args[a.get_slice("=", 0)] = a.get_slice("=", 1)
	var t0 := Time.get_ticks_msec()
	var mem0 := OS.get_static_memory_usage()
	var ps := load(scene_path) as PackedScene
	if ps == null:
		print("SHOT_FAIL cannot load ", scene_path); get_tree().quit(3); return
	var inst := ps.instantiate()
	add_child(inst)
	var load_ms := Time.get_ticks_msec() - t0
	await get_tree().process_frame
	if _args.has("spawn"):
		var m := inst.find_child(_args["spawn"], true, false)
		var pl := get_tree().get_first_node_in_group("player")
		if m is Node3D and pl is Node3D:
			(pl as Node3D).global_transform = (m as Node3D).global_transform
	var vp := get_viewport()
	var cam := vp.get_camera_3d()
	if (cam == null and inst is Node3D or inst.find_child("*", true, false) != null and cam == null) or _args.get("force", "0") == "1":
		if _args.has("cam"):
			var c := _args["cam"].split_floats(",")
			var nc := Camera3D.new(); add_child(nc)
			nc.global_position = Vector3(c[0], c[1], c[2]); nc.look_at(Vector3(c[3], c[4], c[5]))
			nc.fov = float(_args.get("fov", 70)); nc.current = true
		elif cam == null:
			print("SHOT_WARN no current Camera3D and no cam= given (3D scene would render the clear colour)")
	var t_end := Time.get_ticks_msec() + int(wait_s * 1000.0)
	while Time.get_ticks_msec() < t_end:
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var img := vp.get_texture().get_image()
	img.save_png(out)
	var info := {
		"scene": scene_path, "load_ms": load_ms, "renderer": RenderingServer.get_video_adapter_name() + " | " + str(RenderingServer.get_current_rendering_method()),
		"nodes": get_tree().get_node_count(),
		"static_mem_mb": snappedf((OS.get_static_memory_usage() - mem0) / 1048576.0, 0.1),
		"static_mem_total_mb": snappedf(OS.get_static_memory_usage() / 1048576.0, 0.1),
		"objects_in_frame": vp.get_render_info(Viewport.RENDER_INFO_TYPE_VISIBLE, Viewport.RENDER_INFO_OBJECTS_IN_FRAME),
		"tris_in_frame": vp.get_render_info(Viewport.RENDER_INFO_TYPE_VISIBLE, Viewport.RENDER_INFO_PRIMITIVES_IN_FRAME),
		"draw_calls": vp.get_render_info(Viewport.RENDER_INFO_TYPE_VISIBLE, Viewport.RENDER_INFO_DRAW_CALLS_IN_FRAME),
		"video_mem_mb": snappedf(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_VIDEO_MEM_USED) / 1048576.0, 0.1),
		"texture_mem_mb": snappedf(RenderingServer.get_rendering_info(RenderingServer.RENDERING_INFO_TEXTURE_MEM_USED) / 1048576.0, 0.1),
	}
	# static scene stats: mesh instances, tris from mesh data, multimesh instances, lights, unique repeated meshes
	var mi := 0; var mm := 0; var mm_inst := 0; var lights := 0; var tris := 0; var shadow_lights := 0
	var mesh_use: Dictionary = {}
	var dup_nonmm: Array = []
	for n in inst.find_children("*", "", true, false):
		if n is MeshInstance3D:
			mi += 1
			var m: Mesh = (n as MeshInstance3D).mesh
			if m != null:
				var key := m.resource_path if m.resource_path != "" else str(m.get_instance_id())
				mesh_use[key] = int(mesh_use.get(key, 0)) + 1
				for s in m.get_surface_count():
					var arrs := m.surface_get_arrays(s) if m is ArrayMesh else []
					if arrs.size() > 0 and arrs[Mesh.ARRAY_INDEX] != null: tris += (arrs[Mesh.ARRAY_INDEX] as PackedInt32Array).size() / 3
					elif arrs.size() > 0 and arrs[Mesh.ARRAY_VERTEX] != null: tris += (arrs[Mesh.ARRAY_VERTEX] as PackedVector3Array).size() / 3
					elif not (m is ArrayMesh): tris += m.get_faces().size() / 3
		elif n is MultiMeshInstance3D:
			mm += 1
			if (n as MultiMeshInstance3D).multimesh: mm_inst += (n as MultiMeshInstance3D).multimesh.instance_count
		elif n is Light3D:
			lights += 1
			if (n as Light3D).shadow_enabled: shadow_lights += 1
	for k in mesh_use:
		if mesh_use[k] >= 20: dup_nonmm.append("%s x%d" % [k, mesh_use[k]])
	info.merge({"mesh_instances": mi, "multimesh_nodes": mm, "multimesh_instances": mm_inst, "lights": lights, "shadow_lights": shadow_lights,
		"static_tris_all_meshes": tris, "repeated_meshes_ge20_non_multimesh": dup_nonmm})
	var f := FileAccess.open(out + ".json", FileAccess.WRITE)
	f.store_string(JSON.stringify(info, " ")); f.close()
	print("SHOT_OK ", out, " ", JSON.stringify(info))
	get_tree().quit(0)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
