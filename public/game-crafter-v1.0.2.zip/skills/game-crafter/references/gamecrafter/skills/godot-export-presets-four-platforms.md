---
id: godot-export-presets-four-platforms
title: "Export presets for Windows x64, macOS universal, Linux, Windows ARM64"
category: export-release
when: "Creating/maintaining export_presets.cfg."
related: []
origin: FNAP
---

# Export presets for Windows x64, macOS universal, Linux, Windows ARM64

**When to use:** Creating/maintaining export_presets.cfg.

## Do this

- 4 presets: `Windows Desktop` (x86_64), `macOS` (universal), `Linux` (x86_64), `Windows ARM64` (`binary_format/architecture="arm64"`, `[preset.3]`, export path `build/windows_arm64/...`).
- `export_filter="all_resources"`.
- `include_filter="*.json, *.csv, *.txt, *.cues, assets/audio/voice/*, assets/assistant_face/*, assets/branding/*"` (+ `tools/probe_manifest.json`).
- `exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, assets/phone-scripts/original/*, assets/phone-scripts/extra/*"` - keeps dev tooling and rejected content out of builds. The export probe in `tools/` is shipped on purpose (tiny).
- Windows: `binary_format/embed_pck=true` (single exe), `debug/export_console_wrapper=1`, metadata `application/company_name`, `product_name`, `file_version`, `icon`; `modify_resources=true` needs `rcedit` - unavailable on Linux/ARM hosts -> icon not embedded (non-fatal, "Window icon embedding may need rcedit").
- macOS: `bundle_identifier="com.<studio>.<game>"`, `min_macos_version="11.00"`, `codesign/codesign=0`, no notarization -> Gatekeeper warning; document "right-click > Open" in the player README. Godot writes the macOS target as a ZIP containing the .app.
- Template: `godot-export-release/templates/export_presets.template.cfg` (sed `__NAME__` placeholders).

## Pitfalls (mistakes seen)

missing include_filter (placeholders), missing ARM64 preset on PC (mistake-presets-commit-not-landing).

## Verify

each preset exports; verify_export.sh on the pack.

## Origin

FNAP. Source notes: L §3.1 (lines 152-158); R line 6, step 1.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
