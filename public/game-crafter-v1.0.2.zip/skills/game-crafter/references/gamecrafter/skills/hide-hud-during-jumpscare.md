---
id: hide-hud-during-jumpscare
title: "Hide HUD/overlays before a jumpscare or cutscene"
category: ui-ux
when: "Any full-screen scripted moment (jumpscare, death, cinematic)."
related: []
origin: Pickle's Pickle Shop
---

# Hide HUD/overlays before a jumpscare or cutscene

**When to use:** Any full-screen scripted moment (jumpscare, death, cinematic).

## Do this

In `trigger_jumpscare`: `if "visible" in hud: hud.visible = false` before calling `jumpscare.play(...)`. Also close camera monitor/terminal. HUD text over the scare cheapens it and can hide the model.

## Pitfalls (mistakes seen)

HUD remained over the jumpscare in shipped build -> user saw HUD + no animation. Prevention: list of overlays to hide in one `_enter_presentation()` helper.

## Verify

Jumpscare screenshot has no HUD elements.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.3 (office_controller.gd `trigger_jumpscare`).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
