---
id: mistake-audio-mix-quiet-clipped
title: "Audio mix quiet or clipped"
category: mistake
when: "Mixing music+SFX in ffmpeg."
related: []
origin: FNAP
---

# Audio mix quiet or clipped

**When to use:** Mixing music+SFX in ffmpeg.

## Do this

`amix=inputs=N:normalize=0`, `alimiter=limit=0.95`, `adelay=ms|ms`, `apad=whole_dur=<s>`; measure with `ebur128`.

## What happened, root cause, fix, prevention

Symptom: quiet/clipped. Cause: amix divides by N; no limiter. Fix above.

## Verify

ebur128 integrated loudness and true peak reported.

## Origin

FNAP. Source notes: mistakes-log.md M65.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
