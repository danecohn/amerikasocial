---
id: honest-manifest-verified-vs-not
title: "MANIFEST.md with explicit Verified / NOT verified lists and file hashes"
category: project-management
when: "Handing over any build to a user."
related: [mistake-docs-contradict-build]
origin: Roguelike series
---

# MANIFEST.md with explicit Verified / NOT verified lists and file hashes

**When to use:** Handing over any build to a user.

## Do this

- Header: studio, build date, engine version, game version.
- Verified: autoplay run end-to-end with no script errors; exported pack probe `PROBE_DONE fails=0 (72 resources)`; export lint 0 errors; Linux export launched under virtual display with `WIRING missing_art=0`; screenshots are real captures.
- NOT verified: Windows x64/ARM64/macOS builds exported but not launched (no such machine); unsigned binaries (instructions); split zips need assembling; beepbox.co unreachable -> music rendered by compiling BeepBox source offline (links open the same songs); SFX numpy not BeepBox; nothing uploaded/published; AI assistance to disclose on itch.io.
- Files table: path, bytes, SHA-256 first 16 hex.

## Pitfalls (mistakes seen)

see mistake-docs-contradict-build (gamepad, font name).

## Verify

hashes recomputed on the PC match.

## Origin

Roguelike series. Source notes: */MANIFEST.md; INDEX.md.

## Related skills

- [mistake-docs-contradict-build](mistake-docs-contradict-build.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
