---
id: mistake-duplicate-room-furniture
title: "Duplicated furniture (code adds props the room GLB already has)"
category: mistake
when: "Code-dressing rooms that may already be dressed in Blender."
related: []
origin: FNAP
---

# Duplicated furniture (code adds props the room GLB already has)

**When to use:** Code-dressing rooms that may already be dressed in Blender.

## What happened, root cause, fix, prevention

- Symptom: doubled arcade machines/props in a room.
- Root cause: `_furnish_rooms()` added prop GLBs unconditionally.
- Fix: only add if `_room_has_named(root, "Arcade")` is false. Owner contract: "do not add a second copy of
  `wall_poster`".
- Prevention: check-before-add for every code-placed prop.

## Verify

cam_feed_check screenshots.

## Origin

FNAP. Source notes: REF §2.7, §7.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
