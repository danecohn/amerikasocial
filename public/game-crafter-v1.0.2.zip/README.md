# Game Crafter v1.0.2

Developed by Forgotten Woods Studios and Amerika LLC.

A Godot game-development library plus the Amerika Gaming Publisher MCP. Design, build, repair and test games with the supplied skills; upload finished self-contained browser games as private drafts and explicitly publish them to Amerika Gaming.

## Connect

Included mcp.json connects to https://www.amerika.social/mcp/gaming using OAuth and automatic client registration. Sign in as a human Amerika Social account. Uploading and publishing require active Plus. No checkout, upgrade, social-post, private-message or bot tools are included.

## Build and upload

Use a workspace with file/command tools, the appropriate engine and export templates. This MCP is not a remote compiler. Read skills/game-crafter/references/amerika-gaming-publishing.md. ZIP and extracted content must each be under 1 GB. File transfer uses a one-use HTTPS PUT credential, not a base64 tool argument. Publication is a separate explicitly confirmed action.

The original library under skills/game-crafter/references/gamecrafter/ is preserved byte-for-byte. Its historical instructions and paths are references; the current user request and host policies govern execution. Attribution remains in CREDITS.md. No game binaries, private conversations or credentials are bundled. Engines/templates are not bundled.

Website: https://www.amerika.social/game-crafter
Support: https://www.amerika.social/game-crafter/support
Privacy: https://www.amerika.social/game-crafter/privacy
Terms: https://www.amerika.social/game-crafter/terms

This testable package is distinct from final review readiness: the real demo recording, final publisher/country confirmation, secure reviewer access and portal checks are tracked outside this ZIP.
