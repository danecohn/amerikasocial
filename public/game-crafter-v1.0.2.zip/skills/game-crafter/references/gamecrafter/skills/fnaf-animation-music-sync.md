---
id: fnaf-animation-music-sync
title: "Lock enemy animation starts to the music bar"
category: audio-music
when: "Adaptive music exists and you want movement/idle loops to land on beats."
related: [fnaf-power-out-sequence]
origin: FNAP
---

# Lock enemy animation starts to the music bar

**When to use:** Adaptive music exists and you want movement/idle loops to land on beats.

## Do this

- `play_clip()` quantizes looping clip starts to the next music bar via `MusicClock.on_next_bar(callable)`;
  `play_clip_now()` is immediate (use for reactions: flinch, jumpscare).
- Music clock emits `beat`/`bar`; `music_time()` compensates with `AudioServer.get_time_since_last_mix()` and output
  latency.
- Power-out sway clip speed-matched to tune length (fnaf-power-out-sequence).

## Pitfalls (mistakes seen)

none.

## Verify

debug overlay shows music bar/beat; clip start times align to bar.

## Origin

FNAP. Source notes: REF §2.5, §2.10.

---------------------------------------------------------------------------------------------------

## Related skills

- [fnaf-power-out-sequence](fnaf-power-out-sequence.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
