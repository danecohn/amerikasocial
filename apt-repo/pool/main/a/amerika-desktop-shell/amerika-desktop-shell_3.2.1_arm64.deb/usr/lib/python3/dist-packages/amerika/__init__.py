"""Amerika OS: shell, settings and the AI system-control layer."""
__version__ = '3.2.1'
