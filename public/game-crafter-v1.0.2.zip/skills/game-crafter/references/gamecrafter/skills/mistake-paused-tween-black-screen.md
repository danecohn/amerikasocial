---
id: mistake-paused-tween-black-screen
title: "Black screen after "New Game" because a fade tween was paused by the dialogue pause"
category: mistake
when: "Using get_tree().paused for dialogue/menus together with screen-fade tweens."
related: []
origin: Roguelike series
---

# Black screen after "New Game" because a fade tween was paused by the dialogue pause

**When to use:** Using get_tree().paused for dialogue/menus together with screen-fade tweens.

## Do this

Tweens/nodes that must run while the tree is paused need `process_mode = PROCESS_MODE_ALWAYS` (node) or `tween.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)`.

## What happened, root cause, fix, prevention

- Symptom (THE LAST LAMP): pressing New Game left the screen black.
- Root cause: the intro dialogue paused the tree, which froze the fade-in tween, so the fade overlay stayed opaque.
- Fix: "fade tweens now run while paused".
- Prevention: autoplay test from a FRESH save (first-run path) plus a screenshot of the first-run intro from the exported build ("the exported Linux build launched and its first-run intro screenshot checked").

## Verify

screenshot ~3 s after New Game is not black (mean brightness check).

## Origin

Roguelike series. Source notes: WIP_BIBLE_AND_MANIFEST.md L4; INDEX.md L14.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
