# The honest report (how every delivery reply ends)
Keep it short and plain. No tool names. No step-by-step recap.

```
<One line: what is done and where it is.>

What changed
- <change in player words>

Verified
- <thing> — how: <exported build screenshot of X / probe 0 fails / zip test / save-reload>

Not verified
- <e.g. not run on real Windows ARM64 or macOS hardware; builds unsigned>
- <e.g. final brightness values not re-screenshotted>

What you need to do (only if anything)
- <e.g. run BUILD_ALL.bat in DISTRIBUTION to join the zip parts>
```
Forbidden phrases: "should work", "probably fine", "I tested it" (without saying how), "done" (with known gaps unmentioned).
If you couldn't do something, say so in one line and give the nearest route that works.
