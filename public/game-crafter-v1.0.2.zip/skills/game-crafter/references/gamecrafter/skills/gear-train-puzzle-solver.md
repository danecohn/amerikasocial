---
id: gear-train-puzzle-solver
title: "Gear-train repair puzzle with mesh/jam analysis and a DFS auto-solver"
category: gameplay-systems
when: "Mechanical puzzle minigames that need validation and hints."
related: []
origin: Pickle's Pickle Shop
---

# Gear-train repair puzzle with mesh/jam analysis and a DFS auto-solver

**When to use:** Mechanical puzzle minigames that need validation and hints.

## Do this

Gears on pegs mesh if centre distance within (r1 + r2) +- TOL 3.5; closer than r1+r2-TOL jams. BFS depth from the key gear; an odd cycle (same-parity neighbours) jams both; output gear direction from depth parity. Spring/key pieces need a rotation; `_power()` returns 0 ok / 1 no spring / 2 spring wrong way / 3 no key / 4 key wrong way. `_solve()` DFS enumerates assignments, picks one that is not jammed, connected and right direction (push_error if none - catches unsolvable stage data). Help: hint after 40 s idle; Oz auto-applies the solution after 150 s (counted as helped, lowers score). test_auto applies the solution.

## Verify

`_solve()` finds >= 1 good assignment for each of 3 stages.

## Origin

Pickle's Pickle Shop. Source notes: scripts/mini/mg_wrens_bench.gd L177-290, L700-712.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
