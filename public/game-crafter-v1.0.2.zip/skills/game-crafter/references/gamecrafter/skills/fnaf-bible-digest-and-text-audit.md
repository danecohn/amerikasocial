---
id: fnaf-bible-digest-and-text-audit
title: "Bible digest for agents + player-facing text audit"
category: narrative-dialogue
when: "Multiple agents/writers touch UI/story text; before release."
related: []
origin: FNAP
---

# Bible digest for agents + player-facing text audit

**When to use:** Multiple agents/writers touch UI/story text; before release.

## Do this

- `BIBLE_DIGEST.md`: one-page distillation of the story docs (tone, mechanics-as-said-by-the-caller, what is never
  explained, audit list for player-facing text) so every agent honours it without reading three docx files.
- Audit (REF §8.2 #17): grep player-facing strings against the bible: hallucination's name never shown; Night 5 end card
  = thanks + studio + social handle; version string present; no "DEMO" text.
- Precedence rule for conflicts: "the bible wins on story, the demo wins on look".
- Game-over killer name map; hallucination shown as "Something".
- 2D package QA also greps names/text for banned words (e.g. the source franchise name "fnaf" only allowed in the one
  required folder name `fnaf-states`).

## Pitfalls (mistakes seen)

name leaks; "DEMO" strings left in release.

## Verify

`grep -ri "<forbidden name>\|demo" <project>/scripts <project>/assets/data` returns nothing player-facing.

## Origin

FNAP. Source notes: REF §7 (BIBLE_DIGEST), §8.2 #17, §2.13; STATEMAP QA lines 437-449.

---------------------------------------------------------------------------------------------------

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
