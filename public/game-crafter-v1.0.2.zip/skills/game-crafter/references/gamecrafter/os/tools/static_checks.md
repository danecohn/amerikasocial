# Tool: static_checks.py

**Purpose:** Project static checks used on Caesarea (parse sanity, forbidden patterns, data references).

**Usage:** `python3 static_checks.py <proj>`

**Skill:** see `skills/static-checks-no-godot.md`

**Extract:** save the block below as `static_checks.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""QA static checks (no Godot needed). Usage: static_checks.py <proj> -> writes tools/qa/out/static.json, prints summary.
 - json: every .json under data/ (and project) parses
 - missing_res: res:// string literals in .gd/.tscn/.tres/.json/.cfg that point to a file that does not exist
   (dynamic paths with %s / + are skipped; .import/.remap-aware: checks the source file)
 - placeholders: push_warning("PLACEHOLDER ...) occurrences
 - todo: TODO/FIXME/STUB counts in game/
 - uid_dupes: duplicate uid:// in .gd.uid files
"""
import os, re, sys, json, glob
proj = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else ".")
SKIP = {".godot", ".git", "addons", "art_source", "build", "_backup", "docs", "design", "tools", "tests", "PAUSED_STATUS.md"}
def walk(exts, skip=SKIP):
    for root, dirs, files in os.walk(proj):
        dirs[:] = [d for d in dirs if d not in skip and not d.startswith(".")]
        for f in files:
            if f.endswith(exts): yield os.path.join(root, f)
rel = lambda p: os.path.relpath(p, proj)
res = {"json_errors": [], "missing_res": [], "placeholders": [], "todo": [], "uid_dupes": []}
for p in walk((".json",), SKIP - {"docs"} | {"docs"}):
    try: json.load(open(p, encoding="utf-8"))
    except Exception as e: res["json_errors"].append(f"{rel(p)}: {e}")
ref_re = re.compile(r'res://[A-Za-z0-9_\-./ ]+\.[A-Za-z0-9]+')
for p in walk((".gd", ".tscn", ".tres", ".json", ".cfg", ".godot")):
    if p.endswith("project.godot"): pass
    txt = open(p, encoding="utf-8", errors="replace").read()
    for i, ln in enumerate(txt.splitlines(), 1):
        s = ln.strip()
        if s.startswith("#"): continue
        for m in ref_re.finditer(ln):
            r = m.group(0)
            if "%s" in ln[m.start():m.end()+3] or ln[m.end():m.end()+2] in (" +", "\"+"): continue
            fp = os.path.join(proj, r[6:])
            if not (os.path.exists(fp) or os.path.exists(fp + ".import")):
                res["missing_res"].append(f"{rel(p)}:{i}: {r}")
for p in walk((".gd",)):
    txt = open(p, encoding="utf-8", errors="replace").read()
    for i, ln in enumerate(txt.splitlines(), 1):
        m = re.search(r'push_warning\(\s*"(PLACEHOLDER[^"]*)', ln)
        if m: res["placeholders"].append(f"{rel(p)}:{i}: {m.group(1)}")
        if re.search(r'\b(TODO|FIXME|STUB|HACK|XXX)\b', ln): res["todo"].append(f"{rel(p)}:{i}: {ln.strip()[:100]}")
uids = {}
for p in glob.glob(os.path.join(proj, "**", "*.uid"), recursive=True):
    if "/.godot/" in p: continue
    u = open(p).read().strip(); uids.setdefault(u, []).append(rel(p))
res["uid_dupes"] = [f"{u}: {v}" for u, v in uids.items() if len(v) > 1]
os.makedirs(os.path.join(proj, "tools/qa/out"), exist_ok=True)
json.dump(res, open(os.path.join(proj, "tools/qa/out/static.json"), "w"), indent=1)
for k, v in res.items(): print(f"static.{k}: {len(v)}")
for k in ("json_errors", "missing_res", "uid_dupes"):
    for l in res[k][:40]: print(f"  {k}: {l}")
sys.exit(1 if res["json_errors"] or res["missing_res"] or res["uid_dupes"] else 0)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
