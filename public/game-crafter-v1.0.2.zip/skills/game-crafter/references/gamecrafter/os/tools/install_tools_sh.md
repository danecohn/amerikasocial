# Tool: install_tools.sh

**Purpose:** Install Godot (standard) + export templates + Blender + ffmpeg + Xvfb on Linux/macOS.

**Usage:** `bash install_tools.sh <godot_version>`

**Skill:** see `skills/godot-install-export-templates.md`

**Extract:** save the block below as `install_tools.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Install Godot (standard, not .NET) + export templates + Blender into $PREFIX on Linux x86_64/arm64 or macOS.
# Idempotent. Usage: install_tools.sh [--godot-only|--blender-only] ; env: GV=4.7.2 BV=5.2.2 PREFIX=/opt/tools
# NOTE: URLs follow the official release naming. If your network proxy blocks them (curl 403),
#       the script says so and prints the manual fallback instead of looping - do not try to bypass the proxy.
set -uo pipefail
GV="${GV:-4.7.2}"; BV="${BV:-5.2.2}"; PREFIX="${PREFIX:-/opt/tools}"; BMAJ="${BV%.*}"
OS=$(uname -s); ARCH=$(uname -m)
mkdir -p "$PREFIX" 2>/dev/null || { PREFIX="$HOME/tools"; mkdir -p "$PREFIX"; }
BIN=/usr/local/bin; [ -w "$BIN" ] || { BIN="$HOME/.local/bin"; mkdir -p "$BIN"; }
fetch(){ # url dest
  echo "-> $1"; local code; code=$(curl -sSL -w '%{http_code}' -o "$2" "$1" 2>/tmp/curl.err) || true
  if [ "$code" != "200" ]; then echo "   FAILED (http $code) $(head -c 200 /tmp/curl.err)"; rm -f "$2"; return 1; fi; }
manual(){ cat <<M
MANUAL FALLBACK (download on a machine with internet, then copy into place):
  Godot $GV standard : https://godotengine.org/download/archive/$GV-stable/   (editor zip + "Export Templates" .tpz)
  Blender $BV        : https://www.blender.org/download/releases/$BMAJ/
Then: unzip the editor, put it on PATH as 'godot'; unzip the .tpz (it is a zip) and move its inner 'templates' folder to
  Linux  ~/.local/share/godot/export_templates/$GV.stable/
  macOS  ~/Library/Application Support/Godot/export_templates/$GV.stable/
  Windows %APPDATA%\\Godot\\export_templates\\$GV.stable\\
(folder name must be exactly <version>.<status>, and contain version.txt)
M
}
install_godot(){
  case "$OS-$ARCH" in
    Linux-x86_64)  G="Godot_v${GV}-stable_linux.x86_64"; ZIP="$G.zip";;
    Linux-aarch64) G="Godot_v${GV}-stable_linux.arm64";  ZIP="$G.zip";;
    Darwin-*)      G="Godot.app"; ZIP="Godot_v${GV}-stable_macos.universal.zip";;
    *) echo "unsupported $OS-$ARCH for godot"; return 1;;
  esac
  BASE="https://github.com/godotengine/godot/releases/download/${GV}-stable"
  mkdir -p "$PREFIX/godot"; cd "$PREFIX/godot" || return 1
  if [ ! -e "$G" ] && [ "$OS" = Linux ]; then fetch "$BASE/$ZIP" "$ZIP" && unzip -oq "$ZIP" && chmod +x "$G"; fi
  if [ "$OS" = Darwin ]; then [ -d /Applications/Godot.app ] || { fetch "$BASE/$ZIP" "$ZIP" && unzip -oq "$ZIP" && mv Godot.app /Applications/; }; G=/Applications/Godot.app/Contents/MacOS/Godot; fi
  [ "$OS" = Linux ] && ln -sf "$PREFIX/godot/$G" "$BIN/godot"; [ "$OS" = Darwin ] && ln -sf "$G" "$BIN/godot"
  TD="$HOME/.local/share/godot/export_templates/$GV.stable"; [ "$OS" = Darwin ] && TD="$HOME/Library/Application Support/Godot/export_templates/$GV.stable"
  if [ ! -f "$TD/version.txt" ]; then
    fetch "$BASE/Godot_v${GV}-stable_export_templates.tpz" tpl.zip && { rm -rf tpl && mkdir tpl && unzip -oq tpl.zip -d tpl && mkdir -p "$TD" && cp -r tpl/templates/* "$TD/" && rm -rf tpl tpl.zip; }
  fi
  command -v godot >/dev/null && godot --version || echo "godot not on PATH (add $BIN)"
  [ -f "$TD/version.txt" ] && echo "templates OK: $TD ($(cat "$TD/version.txt"))" || echo "templates NOT installed"
}
install_blender(){
  case "$OS-$ARCH" in
    Linux-x86_64)  F="blender-${BV}-linux-x64.tar.xz";;
    Linux-aarch64) echo "Blender has no official Linux arm64 build; use 'apt/flatpak' or run on x86_64"; return 1;;
    Darwin-arm64)  F="blender-${BV}-macos-arm64.dmg";;
    Darwin-x86_64) F="blender-${BV}-macos-x64.dmg";;
    *) echo "unsupported $OS-$ARCH for blender"; return 1;;
  esac
  mkdir -p "$PREFIX/blender"; cd "$PREFIX/blender" || return 1
  if [ "$OS" = Linux ] && [ ! -x "$PREFIX/blender/blender" ]; then
    fetch "https://download.blender.org/release/Blender${BMAJ}/$F" "$F" && tar -xf "$F" --strip-components=1 && rm -f "$F"
  elif [ "$OS" = Darwin ]; then echo "macOS: download $F from https://www.blender.org/download/ and drag to Applications, or: brew install --cask blender"; fi
  [ -x "$PREFIX/blender/blender" ] && ln -sf "$PREFIX/blender/blender" "$BIN/blender" && blender --version | head -1
}
mode="${1:-all}"
[ "$mode" != "--blender-only" ] && install_godot
[ "$mode" != "--godot-only" ] && install_blender
command -v xvfb-run >/dev/null || echo "TIP: apt-get install -y xvfb ffmpeg zip   (needed for headless screenshots, video, zips)"
bash "$(dirname "$0")/check_env.sh" "$GV" || { echo; manual; }
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
