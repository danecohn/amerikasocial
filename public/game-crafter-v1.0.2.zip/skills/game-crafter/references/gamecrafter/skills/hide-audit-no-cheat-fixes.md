---
id: hide-audit-no-cheat-fixes
title: "Grep audit for "fixes" that hide problems (visible=false, layers=0, material swaps)"
category: testing-qa
when: "After any bug fix touching visuals; before hand-off."
related: []
origin: Caesarea
---

# Grep audit for "fixes" that hide problems (visible=false, layers=0, material swaps)

**When to use:** After any bug fix touching visuals; before hand-off.

## Do this

`grep -rnE --include=*.gd "visible *= *false|\.hide\(\)|layers *= *0|cull_mask|light_energy *= *0|set_surface_override_material|material_override *=|albedo_color *=|queue_free\(\)" game --exclude-dir=.godot --exclude-dir=dev --exclude-dir=addons`. Every hit must be justified with a comment (by-design swaps) or removed. Also confirm every enum state is SET somewhere (`grep -n 'state ==' / 'state = '`). Hard rule in MANIFEST: "No hiding meshes / silencing warnings as a 'fix'."

## Origin

Caesarea. Source notes: tools/qa/hide_audit.sh, lint.sh, MANIFEST rule 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
