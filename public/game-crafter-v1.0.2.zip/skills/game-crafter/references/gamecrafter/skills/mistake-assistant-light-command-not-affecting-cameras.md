---
id: mistake-assistant-light-command-not-affecting-cameras
title: "Assistant "lights on" didn't light the hall camera feeds"
category: mistake
when: "Any light/power command that should affect multiple views (player view + camera feeds)."
related: []
origin: Pickle's Pickle Shop
---

# Assistant "lights on" didn't light the hall camera feeds

**When to use:** Any light/power command that should affect multiple views (player view + camera feeds).

## Do this

Pickle-GPT door-light commands lit only the rooms next to the doors, not the camera feed rooms. Fix: one entry point `office.assistant_set_hall_lights(side, on)` -> `_set_light` -> `level.set_hall_room_lights(side, on)` which toggles lights for door nook AND hall cam rooms (`var halls: Array = ["CAM_2A","CAM_2B"] if side == "L" else ["CAM_4A","CAM_4B"]`) -> `monitor.refresh_isolation()` so the open feed re-syncs. Empty side = both halls.

## What happened, root cause, fix, prevention

Symptom: "the pickle gpt door light commands don't turn on the lights in the hallway cameras, only next to the rooms. It also has to be able to turn it back off". Fix above + simple commands "lights on"/"lights off". Prevention: map out every view that shows a lit space; one setter updates all.

## Verify

Parse test of commands; screenshot hall cam before/after "lights on" and "lights off".

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.1, 3; shop_assistant.gd hall_lights_on/off.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
