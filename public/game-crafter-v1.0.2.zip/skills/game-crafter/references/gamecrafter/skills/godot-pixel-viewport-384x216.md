---
id: godot-pixel-viewport-384x216
title: "Pixel-perfect 384x216 Godot project settings for 8-bit games"
category: godot-engine
when: "Starting any pixel-art 2D Godot 4 game."
related: []
origin: Roguelike series
---

# Pixel-perfect 384x216 Godot project settings for 8-bit games

**When to use:** Starting any pixel-art 2D Godot 4 game.

## Do this

- project.godot: `window/size/viewport_width=384`, `viewport_height=216`, `window_width_override=1152`, `window_height_override=648` (3x), `window/stretch/mode="viewport"`, `window/stretch/scale_mode="integer"`, `vsync_mode=1`.
- `renderer/rendering_method="gl_compatibility"` (and `.mobile`), `config/features=PackedStringArray("4.7", "GL Compatibility")` -> runs on weak GPUs, software GL (Xvfb/llvmpipe) for headless capture, and ARM64 Windows.
- `textures/canvas_textures/default_texture_filter=0` (nearest), `environment/defaults/default_clear_color=Color(0.02,0.02,0.03,1)`, `boot_splash/show_image=false`, `boot_splash/bg_color=Color(0.02,0.02,0.03,1)` (no Godot logo flash; dark not grey).
- Fonts loaded at runtime made pixel-crisp: `f.antialiasing = TextServer.FONT_ANTIALIASING_NONE; f.hinting = TextServer.HINTING_NONE; f.subpixel_positioning = TextServer.SUBPIXEL_POSITIONING_DISABLED; f.generate_mipmaps = false`. Use sizes 10 (body) and 20/30/40 (title) - multiples of the pixel font's base.
- Pixel snapping by hand: draw particles/rings at `pos.floor()`, shake offset `.round()`.
- Layout grid for 384x216: HUD bar 24px at top (room drawn at y offset 24), room 24x12 tiles of 16px = 384x192.

## Pitfalls (mistakes seen)

none recorded; prevention: never use linear filter or AA fonts for pixel games.

## Verify

screenshot at native 384x216 via `--shot`; text edges have no grey AA pixels.

## Origin

Roguelike series. Source notes: kit/project.godot lines 1-23, 108-113; game.gd _font().

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
