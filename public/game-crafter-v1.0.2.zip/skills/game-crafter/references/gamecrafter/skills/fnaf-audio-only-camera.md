---
id: fnaf-audio-only-camera
title: "Audio-only camera (a feed with no picture; sound tells who is there)"
category: planning-design
when: "Adding a camera that forces listening instead of looking (FNAF kitchen)."
related: []
origin: FNAP
---

# Audio-only camera (a feed with no picture; sound tells who is there)

**When to use:** Adding a camera that forces listening instead of looking (FNAF kitchen).

## Do this

- CAM_6 Kitchen has `FEED_DISABLED`: shows "-CAMERA DISABLED- AUDIO ONLY" while the kitchen pots loop plays at -6 dB
  when watching that camera, -24 dB otherwise.
- 2D: show camera static at full strength + `cam-6-audio-only.png` (460x100) at (410,250); Dilly =
  `kitchen-pots-clatter-loop.wav`.
- Taught by the call (N3): "If you hear pots banging around, that's her in the kitchen. That camera has no picture, so
  the pots are how you know."

## Pitfalls (mistakes seen)

none.

## Verify

Put Dilly in CAM_6, open/close that camera, measure loop volume -6 / -24 dB.

## Origin

FNAP. Source notes: REF §2.4; STATEMAP lines 77-79, 251; CALLS N3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
