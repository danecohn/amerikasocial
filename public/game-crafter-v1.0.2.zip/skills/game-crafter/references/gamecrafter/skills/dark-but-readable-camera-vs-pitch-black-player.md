---
id: dark-but-readable-camera-vs-pitch-black-player
title: "Separate "darkness targets" per view: player view, camera feeds, door nooks"
category: 3d-lighting-horror
when: "Any horror lighting request ('darker', 'too dark', 'pitch black')."
related: []
origin: Pickle's Pickle Shop
---

# Separate "darkness targets" per view: player view, camera feeds, door nooks

**When to use:** Any horror lighting request ("darker", "too dark", "pitch black").

## Do this

User intent decoded over three rounds: halls = very dark for the player (only hall light or flashlight reveals); hall CAMERA FEEDS = dim but with readable detail, bright when the hall light is on; door nooks = pitch black, no eyes, nothing without a light; jumpscares = always fully visible and lit. Implement each as an independent control: player env + material darkening; feed environment + feed-only light (cull mask layer 20); per-room material multipliers; jumpscare override light. Write the targets into the manifest so later passes don't "fix" one by breaking another.

## Verify

Screenshot matrix: {desk, door L/R} x {unlit, lit, flashlight} + {each hall cam} x {unlit, lit} + 5 jumpscares.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.1, 6 (user messages); MANIFEST.md; STATUS.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
