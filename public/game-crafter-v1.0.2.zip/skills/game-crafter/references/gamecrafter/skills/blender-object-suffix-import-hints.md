---
id: blender-object-suffix-import-hints
title: "Blender object suffixes → Godot import types (colonly, convcol, navmesh, occ, SOCKET_)"
category: 3d-blender
when: "Authoring GLBs for Godot with collision/LOD/sockets."
related: []
origin: Caesarea
---

# Blender object suffixes → Godot import types (colonly, convcol, navmesh, occ, SOCKET_)

**When to use:** Authoring GLBs for Godot with collision/LOD/sockets.

## Do this

`_LOD0/_LOD1/_LOD2` visual LODs (file named without suffix contains all); `-col` mesh + trimesh collider; `-convcol` convex; `-colonly` collider only (all architecture: simplified hull `CAE_Arch_<Name>_LOD0-colonly`); `-convcolonly` props; `-navmesh`; `-occ`/`-occonly` occluders (big walls/tiers); `-rigid`; `-noimp`; `-loop`/`-cycle` on actions; `SOCKET_<name>` Empties as attachment points (weapon rails `SOCKET_rail_muzzle/optic/cell`, `SOCKET_grip`, `SOCKET_camera`). Units meters, apply transforms, origin on floor (characters between feet; kit pieces at grid corner; grid 2 m, arches 4 m). Budgets LOD0: hero 60k, NPC 25k, crowd 6k (or 8-direction billboards beyond 40 m), weapon 12k, large arch 30k, prop 0.2–5k; LOD1 ~50%, LOD2 ~20%; textures 2048² heroes, 1024² props, trim sheets for architecture. Modular weapon mods via sockets + item `rail_slots`.

## Origin

Caesarea. Source notes: design/08 §6.1–6.4, §4.3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
