---
id: horror-roguelike-narrative-template
title: "Narrative template for the 4 horror roguelikes (twist, choice, 3 endings)"
category: narrative-dialogue
when: "Writing a story for a short story-driven roguelike (hub + descent), especially a series."
related: []
origin: Roguelike series
---

# Narrative template for the 4 horror roguelikes (twist, choice, 3 endings)

**When to use:** Writing a story for a short story-driven roguelike (hub + descent), especially a series.

## Do this

- Shape that shipped 4 times: protagonist + one loved one + 2-3 hub NPCs who are revealed dead; 4 floors each with a boss who is a facet of the trauma (an authority figure, a voice, the institution/villain, the final boss = the protagonist's own exhaustion: "the minute before you decided to stop trying", "Rest. You've done enough.").
- Death is diegetic (lighthouse/house/refuge "takes you back"); NPCs comment on deaths; logbook/diary fragments (12) reveal the truth piecemeal; reveal at floor 3 sanctuary or after boss 3.
- Final choice after last boss: release/ring/climb/wake (hope) vs stay/sleep (despair). Endings checked in order: TRUE (hope flag + all 12 fragments), HOPE (flag only, with a whispered hint that something was missed), STAY (sad, with "(THIS IS NOT THE ONLY ENDING. ... IS STILL WAITING.)"). Ending entries: `{id, when, music, image, scene, epilogue}`; first matching wins, last is fallback.
- Hub post-game beat after win; archive "all fragments read" beat sets `read_all`.
- Each game re-skins vocabulary through `text` overrides (death title "THE LIGHT FAILS"/"HUSHED"/"OUT OF AIR"/"FLATLINE"; currency EMBERS/BUTTONS/LETTERS/CARDS; dread names STORM I-V / LIGHTS OUT I-V / DAY TWO-SIX / NIGHT TWO-SIX).
- Content notes in store page + README: themes listed, "No gore, no jump-scare screamers".

## Pitfalls (mistakes seen)

Games 3 and 4 reuse lines nearly verbatim from earlier games ("Rest. You've done enough." / "He's the part of you that's tired. Don't be scared of him." / "I've got the kettle on." / "No one has ever said no to me this long.") - templating a series risks players noticing copy-paste; vary signature lines per game.

## Verify

read every ending in a test run via `--flags=choice_release --frags=12 --scene=ending`.

## Origin

Roguelike series. Source notes: games/g1..g4 content.py ENDINGS/BEATS; GAME_BIBLE.md Story sections.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
