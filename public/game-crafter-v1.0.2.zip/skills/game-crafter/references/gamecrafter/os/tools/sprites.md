# Tool: sprites.py

**Purpose:** Procedural pixel-art sprite toolkit: palettes, ASCII sprite maps, outlines, shading, animation frames, sheets.

**Usage:** `python3 sprites.py <spec>  (imported by buildgame.py)`

**Skill:** see `skills/sprite-recipe-grammar.md`

**Extract:** save the block below as `sprites.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Procedural pixel-art sprite toolkit. Forgotten Woods Studios.
Everything is drawn pixel-by-pixel (no anti-aliasing) from compact recipes, then outlined and
shaded with a consistent top-left light so all creatures read as one hand-made set.
"""
import math, random
from PIL import Image, ImageDraw


def hexc(h, a=255):
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)


def mix(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3)) + (255,)


def light(c, t=0.3):
    return mix(c, (255, 255, 255, 255), t)


def dark(c, t=0.35):
    return mix(c, (0, 0, 8, 255), t)


class Pal:
    """palette: base, base2 (secondary), eye (glow), accent, outline"""

    def __init__(self, base, base2=None, eye="#ff3030", accent="#c8c8c8", outline="#0b0a10"):
        self.base = hexc(base)
        self.base2 = hexc(base2) if base2 else dark(self.base, 0.3)
        self.eye = hexc(eye)
        self.accent = hexc(accent)
        self.outline = hexc(outline)


def new(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))


def D(img):
    d = ImageDraw.Draw(img)
    d.fontmode = "1"
    return d


def solid(img):
    """alpha -> 0/255 so no stray translucency"""
    px = img.load()
    for y in range(img.height):
        for x in range(img.width):
            r, g, b, a = px[x, y]
            px[x, y] = (r, g, b, 255 if a >= 128 else 0)
    return img


def finish(img, pal, shade=True, outline=True, lit=0.22, shd=0.28):
    """1px top-left highlight / bottom-right shadow on the fill, then a dark outline."""
    img = solid(img)
    w, h = img.size
    src = img.copy().load()
    out = img.load()

    def a(x, y):
        return 0 <= x < w and 0 <= y < h and src[x, y][3] > 0

    if shade:
        for y in range(h):
            for x in range(w):
                if src[x, y][3] == 0:
                    continue
                c = src[x, y]
                if not a(x, y - 1) or not a(x - 1, y):
                    out[x, y] = light(c, lit)
                elif not a(x, y + 1) or not a(x + 1, y):
                    out[x, y] = dark(c, shd)
    if outline:
        big = new(w + 2, h + 2)
        big.paste(img, (1, 1))
        bp, sp = big.load(), big.copy().load()
        for y in range(h + 2):
            for x in range(w + 2):
                if sp[x, y][3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        xx, yy = x + dx, y + dy
                        if 0 <= xx < w + 2 and 0 <= yy < h + 2 and sp[xx, yy][3] > 0:
                            bp[x, y] = pal.outline
                            break
        return big
    return img


def eyes(img, pts, pal, size=1, pupil=True):
    d = D(img)
    for (x, y) in pts:
        if size == 1:
            d.point((x, y), fill=pal.eye)
        else:
            d.rectangle((x, y, x + size - 1, y + size - 1), fill=hexc("#f4f0e8"))
            if pupil:
                d.point((x + size // 2, y + size // 2), fill=pal.eye if size > 1 else pal.outline)


def glow_eyes(img, pts, pal, size=2):
    d = D(img)
    for (x, y) in pts:
        d.rectangle((x, y, x + size - 1, y + size - 1), fill=pal.eye)
        d.point((x, y), fill=light(pal.eye, 0.6))


def paste_over(dst, src, xy):
    dst.alpha_composite(src, xy)


# ------------------------------------------------------------------ creature recipes
# every recipe: f(pal, frame, rng, **kw) -> Image (before finish). frame 0/1.

def r_ghost(pal, frame, rng, w=16, h=18, arms=True, hollow_eyes=True, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    top = 1
    d.ellipse((1, top, w - 2, top + w - 3), fill=pal.base)
    d.rectangle((1, top + w // 2 - 1, w - 2, h - 4), fill=pal.base)
    # hem
    for x in range(1, w - 1):
        off = 2 if ((x + frame * 2) // 2) % 2 == 0 else 0
        d.line((x, h - 4, x, h - 2 - off), fill=pal.base)
    if arms:
        ay = top + w // 2 + 1 + frame
        d.line((0, ay, 2, ay + 3), fill=pal.base2)
        d.line((w - 1, ay, w - 3, ay + 3), fill=pal.base2)
    # face
    ey = top + w // 3
    for ex in (cx - 4, cx + 2):
        d.rectangle((ex, ey, ex + 1, ey + 2), fill=pal.outline)
        d.point((ex, ey + 1), fill=pal.eye)
    d.rectangle((cx - 1, ey + 5, cx, ey + 7 + frame), fill=pal.outline)
    return img


def r_crawler(pal, frame, rng, w=20, h=14, legs=4, eyes_n=4, **kw):
    img = new(w, h)
    d = D(img)
    cx, cy = w // 2, h // 2
    d.ellipse((cx - 5, cy - 3, cx + 5, cy + 3), fill=pal.base)
    d.ellipse((cx - 3, cy - 4, cx + 3, cy), fill=pal.base2)
    for i in range(legs):
        t = (i + 0.5) / legs
        lx = int(cx - 5 + 10 * t)
        up = (i + frame) % 2
        for sgn in (-1, 1):
            ky = cy + sgn * 3
            fy = cy + sgn * (6 if not up else 5)
            fx = lx + (2 if up else -1) * 1
            d.line((lx, ky, lx + (i - legs / 2), fy), fill=pal.base2)
    for i in range(eyes_n):
        ex = cx - 3 + (i % 2) * 5 + (i // 2)
        ey = cy - 2 + (i // 2) * 2
        d.point((ex, ey), fill=pal.eye)
    d.line((cx - 2, cy + 2, cx + 2, cy + 2), fill=pal.outline)
    return img


def r_blob(pal, frame, rng, w=18, h=16, eyes_n=5, drips=3, **kw):
    img = new(w, h)
    d = D(img)
    r2 = random.Random(kw.get("seed", 1))
    cx, cy = w // 2, h // 2 + 1
    squish = frame
    for _ in range(6):
        rx = r2.randint(3, 5)
        ry = r2.randint(3, 5) - squish
        ox, oy = r2.randint(-3, 3), r2.randint(-2, 2)
        d.ellipse((cx + ox - rx, cy + oy - ry, cx + ox + rx, cy + oy + ry), fill=pal.base if r2.random() < .7 else pal.base2)
    for i in range(drips):
        x = r2.randint(3, w - 4)
        d.line((x, cy + 3, x, cy + 5 + (i + frame) % 3), fill=pal.base)
    pts = []
    for i in range(eyes_n):
        x, y = r2.randint(4, w - 6), r2.randint(3, h - 7)
        d.rectangle((x, y, x + 1, y + 1), fill=hexc("#efe9dc"))
        d.point((x + r2.randint(0, 1), y + r2.randint(0, 1)), fill=pal.eye)
    d.arc((cx - 4, cy + 1, cx + 4, cy + 5), 0, 180, fill=pal.outline)
    return img


def r_brute(pal, frame, rng, w=22, h=24, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    bob = frame
    d.rectangle((cx - 6, 8 + bob, cx + 6, 17 + bob), fill=pal.base)        # torso
    d.rectangle((cx - 3, 3 + bob, cx + 3, 8 + bob), fill=pal.base2)        # head
    d.rectangle((cx - 5, 17, cx - 2, 22 - bob), fill=pal.base2)            # legs
    d.rectangle((cx + 2, 17, cx + 5, 22 - bob * -1), fill=pal.base2)
    d.rectangle((cx - 9, 9 + bob, cx - 7, 20 + bob), fill=pal.base2)       # long arms
    d.rectangle((cx + 7, 9 + bob, cx + 9, 20 + bob), fill=pal.base2)
    d.rectangle((cx - 10, 19 + bob, cx - 6, 22 + bob), fill=pal.base)      # fists
    d.rectangle((cx + 6, 19 + bob, cx + 10, 22 + bob), fill=pal.base)
    d.point((cx - 2, 5 + bob), fill=pal.eye)
    d.point((cx + 2, 5 + bob), fill=pal.eye)
    d.line((cx - 2, 7 + bob, cx + 2, 7 + bob), fill=pal.outline)
    d.line((cx - 4, 11 + bob, cx + 4, 14 + bob), fill=pal.outline)         # scar / stitching
    return img


def r_doll(pal, frame, rng, w=14, h=18, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    tilt = -1 if frame == 0 else 1
    d.ellipse((2 + tilt, 0, w - 3 + tilt, 9), fill=pal.base)          # big head
    d.rectangle((cx - 3, 9, cx + 3, 14), fill=pal.base2)
    d.line((cx - 3, 15, cx - 3, 17 - frame), fill=pal.base2)
    d.line((cx + 3, 15, cx + 3, 16 + frame), fill=pal.base2)
    d.rectangle((cx - 5, 10, cx - 4, 13), fill=pal.base2)
    d.rectangle((cx + 4, 10, cx + 5, 13 - frame), fill=pal.base2)
    for ex in (cx - 4 + tilt, cx + 1 + tilt):
        d.rectangle((ex, 3, ex + 2, 5), fill=hexc("#f2ece0"))
        d.point((ex + 1, 4), fill=pal.eye)
    for x in range(cx - 3 + tilt, cx + 4 + tilt, 2):
        d.line((x, 7, x, 8), fill=pal.outline)      # stitched mouth
    d.line((cx - 3 + tilt, 7, cx + 3 + tilt, 7), fill=pal.outline)
    return img


def r_bat(pal, frame, rng, w=22, h=14, **kw):
    img = new(w, h)
    d = D(img)
    cx, cy = w // 2, h // 2
    up = frame == 0
    d.ellipse((cx - 3, cy - 3, cx + 3, cy + 4), fill=pal.base)
    d.polygon([(cx - 3, cy - 1), (1, 1 if up else cy + 3), (3, cy + 2), (cx - 3, cy + 3)], fill=pal.base2)
    d.polygon([(cx + 3, cy - 1), (w - 2, 1 if up else cy + 3), (w - 4, cy + 2), (cx + 3, cy + 3)], fill=pal.base2)
    d.point((cx - 1, cy - 1), fill=pal.eye)
    d.point((cx + 1, cy - 1), fill=pal.eye)
    d.point((cx - 2, cy - 4), fill=pal.base)
    d.point((cx + 2, cy - 4), fill=pal.base)
    d.line((cx, cy + 2, cx, cy + 3), fill=hexc("#f0f0f0"))
    return img


def r_hand(pal, frame, rng, w=16, h=14, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    d.ellipse((cx - 4, 5, cx + 4, 11), fill=pal.base)
    for i, fx in enumerate((cx - 5, cx - 3, cx - 1, cx + 1, cx + 3)):
        l = 3 + (i % 3) + (frame if i % 2 else 0)
        d.line((fx, 6, fx - 1 + (i - 2) // 2, 6 - l), fill=pal.base)
        d.point((fx - 1 + (i - 2) // 2, 6 - l), fill=pal.base2)
    d.line((cx + 4, 8, cx + 7, 6 + frame), fill=pal.base)
    d.point((cx, 9), fill=pal.eye)    # palm eye
    d.rectangle((cx - 2, 11, cx + 2, 13), fill=pal.base2)
    return img


def r_skull(pal, frame, rng, w=16, h=18, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    d.ellipse((1, 0, w - 2, 11), fill=pal.base)
    d.rectangle((cx - 4, 9, cx + 4, 12), fill=pal.base)
    jaw = 13 + frame * 2
    d.rectangle((cx - 4, jaw, cx + 4, jaw + 2), fill=pal.base2)
    for x in range(cx - 4, cx + 5, 2):
        d.point((x, 12 + frame), fill=pal.outline)
    for ex in (cx - 4, cx + 2):
        d.rectangle((ex, 4, ex + 2, 7), fill=pal.outline)
        d.point((ex + 1, 6), fill=pal.eye)
    d.line((cx, 8, cx, 9), fill=pal.outline)
    return img


def r_worm(pal, frame, rng, w=24, h=12, segs=6, **kw):
    img = new(w, h)
    d = D(img)
    for i in range(segs):
        x = 3 + i * 3
        y = 6 + int(2.2 * math.sin(i * 0.9 + frame * 1.6))
        r = 3 if i not in (0, segs - 1) else (4 if i == 0 else 2)
        d.ellipse((x - r + 1, y - r, x + r, y + r), fill=pal.base if i % 2 == 0 else pal.base2)
    d.point((3, 4 + int(2.2 * math.sin(frame * 1.6))), fill=pal.eye)
    d.point((5, 4 + int(2.2 * math.sin(frame * 1.6))), fill=pal.eye)
    return img


def r_stalker(pal, frame, rng, w=14, h=30, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    sw = frame
    d.ellipse((cx - 3, 0, cx + 3, 7), fill=pal.base)
    d.rectangle((cx - 2, 7, cx + 2, 20), fill=pal.base)
    d.line((cx - 2, 9, cx - 6 + sw, 22), fill=pal.base2)
    d.line((cx + 2, 9, cx + 6 - sw, 22), fill=pal.base2)
    d.line((cx - 1, 20, cx - 3 - sw, 29), fill=pal.base2)
    d.line((cx + 1, 20, cx + 3 + sw, 29), fill=pal.base2)
    d.rectangle((cx - 2, 3, cx - 1, 4), fill=pal.eye)
    d.rectangle((cx + 1, 3, cx + 2, 4), fill=pal.eye)
    d.line((cx - 2, 6, cx + 2, 6), fill=pal.outline)
    return img


def r_mask(pal, frame, rng, w=16, h=18, horns=True, **kw):
    img = new(w, h)
    d = D(img)
    cx = w // 2
    bob = frame
    d.ellipse((2, 2 + bob, w - 3, 15 + bob), fill=pal.base)
    if horns:
        d.polygon([(3, 5 + bob), (1, 0), (6, 3 + bob)], fill=pal.base2)
        d.polygon([(w - 4, 5 + bob), (w - 2, 0), (w - 7, 3 + bob)], fill=pal.base2)
    d.line((4, 7 + bob, 6, 8 + bob), fill=pal.outline)
    d.line((w - 5, 7 + bob, w - 7, 8 + bob), fill=pal.outline)
    d.point((5, 8 + bob), fill=pal.eye)
    d.point((w - 6, 8 + bob), fill=pal.eye)
    d.arc((4, 9 + bob, w - 5, 14 + bob), 0, 180, fill=pal.outline)
    return img


def r_humanoid(pal, frame, rng, w=16, h=20, hair="#3a2a22", cloth=None, skin="#d9b79a", hat=None, held=None, **kw):
    """player / NPC. cloth: pal.base. frame 0..3 walk cycle."""
    img = new(w, h)
    d = D(img)
    cx = w // 2
    cloth = hexc(cloth) if isinstance(cloth, str) else (cloth or pal.base)
    skin = hexc(skin)
    hair = hexc(hair)
    step = [0, 1, 0, -1][frame % 4]
    bob = 1 if frame % 2 == 1 else 0
    # legs
    d.rectangle((cx - 3, 14, cx - 1, 18 + (step if step > 0 else 0)), fill=pal.base2)
    d.rectangle((cx + 1, 14, cx + 3, 18 + (-step if step < 0 else 0)), fill=pal.base2)
    # body
    d.rectangle((cx - 4, 7 + bob, cx + 4, 14 + bob), fill=cloth)
    d.rectangle((cx - 5, 8 + bob, cx - 5, 12 + bob), fill=dark(cloth, .2))
    d.rectangle((cx + 5, 8 + bob, cx + 5, 12 + bob), fill=dark(cloth, .2))
    # head
    d.ellipse((cx - 4, 0 + bob, cx + 4, 8 + bob), fill=skin)
    d.rectangle((cx - 4, 0 + bob, cx + 4, 2 + bob), fill=hair)
    d.rectangle((cx - 4, 1 + bob, cx - 4, 5 + bob), fill=hair)
    d.point((cx - 2, 4 + bob), fill=pal.outline)
    d.point((cx + 2, 4 + bob), fill=pal.outline)
    if hat == "hood":
        d.ellipse((cx - 5, -1 + bob, cx + 5, 7 + bob), fill=cloth)
        d.ellipse((cx - 3, 2 + bob, cx + 3, 7 + bob), fill=skin)
        d.point((cx - 1, 4 + bob), fill=pal.outline)
        d.point((cx + 2, 4 + bob), fill=pal.outline)
    elif hat == "cap":
        d.rectangle((cx - 4, -1 + bob, cx + 4, 2 + bob), fill=pal.accent)
        d.rectangle((cx - 1, 0 + bob, cx + 1, 1 + bob), fill=pal.eye)
    elif hat == "helmet":
        d.ellipse((cx - 5, -1 + bob, cx + 5, 4 + bob), fill=pal.accent)
        d.rectangle((cx - 1, -2 + bob, cx + 1, -1 + bob), fill=hexc("#ffe08a"))
    elif hat == "bow":
        d.polygon([(cx - 3, 0 + bob), (cx - 6, -1 + bob), (cx - 6, 2 + bob)], fill=pal.accent)
        d.polygon([(cx - 3, 0 + bob), (cx, -1 + bob), (cx, 2 + bob)], fill=pal.accent)
    elif hat == "bandage":
        d.rectangle((cx - 4, 0 + bob, cx + 4, 3 + bob), fill=hexc("#e8e2d2"))
        d.line((cx - 4, 2 + bob, cx + 4, 3 + bob), fill=hexc("#b9b09a"))
    elif hat == "crown":
        for x in (cx - 4, cx - 1, cx + 2):
            d.polygon([(x, -1 + bob), (x + 2, -3 + bob), (x + 3, -1 + bob)], fill=pal.accent)
    if held == "lamp":
        d.rectangle((cx + 5, 9 + bob, cx + 7, 12 + bob), fill=hexc("#ffd36a"))
        d.line((cx + 6, 8 + bob, cx + 6, 9 + bob), fill=pal.outline)
    return img


def r_orb(pal, frame, rng, w=12, h=12, **kw):
    img = new(w, h)
    d = D(img)
    r = 4 + frame
    d.ellipse((w // 2 - r, h // 2 - r, w // 2 + r - 1, h // 2 + r - 1), fill=pal.base)
    d.ellipse((w // 2 - 2, h // 2 - 2, w // 2 + 1, h // 2 + 1), fill=pal.eye)
    for a in range(0, 360, 90):
        x = w // 2 + int(math.cos(math.radians(a + frame * 45)) * (r + 1))
        y = h // 2 + int(math.sin(math.radians(a + frame * 45)) * (r + 1))
        d.point((max(0, min(w - 1, x)), max(0, min(h - 1, y))), fill=pal.base2)
    return img


RECIPES = {"ghost": r_ghost, "crawler": r_crawler, "blob": r_blob, "brute": r_brute, "doll": r_doll, "bat": r_bat,
           "hand": r_hand, "skull": r_skull, "worm": r_worm, "stalker": r_stalker, "mask": r_mask,
           "humanoid": r_humanoid, "orb": r_orb}


def make(recipe, pal, frames=2, scale=1, shade=True, seed=1, **kw):
    out = []
    for f in range(frames):
        img = RECIPES[recipe](pal, f, random.Random(seed), seed=seed, **kw)
        img = finish(img, pal, shade=shade)
        if scale > 1:
            img = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
        out.append(img)
    return out


def sheet(frames):
    w = max(f.width for f in frames)
    h = max(f.height for f in frames)
    s = new(w * len(frames), h)
    for i, f in enumerate(frames):
        s.alpha_composite(f, (i * w + (w - f.width) // 2, h - f.height))
    return s, w, h


def scale_up(img, k):
    return img.resize((img.width * k, img.height * k), Image.NEAREST)


def boss_from(recipe, pal, k=2, seed=1, extra=None, **kw):
    """Boss = a creature recipe drawn at 2x then dressed with crown / extra eyes."""
    frames = []
    for f in range(2):
        base = RECIPES[recipe](pal, f, random.Random(seed), seed=seed, **kw)
        base = scale_up(base, k)
        if extra:
            extra(base, pal, f)
        frames.append(finish(base, pal, outline=True))
    return frames


if __name__ == "__main__":
    # contact sheet for eyeballing
    import sys
    pal = Pal("#7a8a9a", "#4c5866", "#ff3a2a", "#c9c2a8")
    row = []
    for r in RECIPES:
        kw = {"hat": "hood"} if r == "humanoid" else {}
        fr = make(r, pal, frames=2 if r != "humanoid" else 4, **kw)
        row.append((r, fr))
    W = sum(max(f.width for f in fr) * len(fr) + 6 for _, fr in row)
    img = Image.new("RGBA", (W, 40), (30, 28, 40, 255))
    x = 2
    for r, fr in row:
        for f in fr:
            img.alpha_composite(f, (x, 4))
            x += f.width
        x += 6
    scale_up(img, 6).save(sys.argv[1] if len(sys.argv) > 1 else "/tmp/sprites_test.png")
    print("ok", img.size)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
