---
id: export-probe-from-pack
title: "Export probe: prove models load from the exported PCK"
category: export-release
when: "Every export."
related: []
origin: Pickle's Pickle Shop
---

# Export probe: prove models load from the exported PCK

**When to use:** Every export.

## Do this

Minimal probe scene: for each required model path (characters under res://assets/models/animated/<id>.glb and office/office.glb) check `ResourceLoader.exists(path)` and `load(path) != null`, print PASS/FAIL per model, `PROBE RESULT: x PASS / y FAIL`, `OVERALL: PASS|FAIL`, quit. Run it from the exported pack (via the shotproj recipe), not the editor. Pair with the export-safety lint (`lint_export_safety.py`, result was 0 errors, 3 warnings) and with screenshots from the export.

## Pitfalls (mistakes seen)

"verified on the Linux export only" - say which platforms were actually run; Windows/ARM64/macOS were never launched; only PE machine types checked (x64 0x8664, ARM64 0xaa64).

## Verify

OVERALL: PASS from the exported binary log.

## Origin

Pickle's Pickle Shop. Source notes: scripts/dev/export_probe.gd; transcript summary sec.2-5; SHIP_NOTES.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
