---
id: bridge-large-file-senduserfile-route
title: "Committing files that stagedPath rejects (SendUserFile fileUuid)"
category: delivery-pc-bridge
when: "Commit returns HTTP 400 on a stagedPath (seen with a 26 MB mp4)."
related: []
origin: FNAP
---

# Committing files that stagedPath rejects (SendUserFile fileUuid)

**When to use:** Commit returns HTTP 400 on a stagedPath (seen with a 26 MB mp4).

## Do this

Call SendUserFile on the file first to get a `file_uuid`, then commit with `{"devicePath": "...", "fileUuid": "..."}`. Files >30 MB can't be committed at all -> build on the PC or ask the user.

## Pitfalls (mistakes seen)

26 MB mp4 rejected with 400 -> use fileUuid route.

## Verify

list folder shows size/mtime.

## Origin

FNAP. Source notes: pc-bridge-delivery/SKILL.md bullet 4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
