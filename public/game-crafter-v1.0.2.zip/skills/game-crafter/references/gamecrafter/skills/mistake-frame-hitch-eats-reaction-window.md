---
id: mistake-frame-hitch-eats-reaction-window
title: "A lag spike kills the player instantly (reaction window consumed by one frame)"
category: mistake
when: "Timed danger windows decrement by delta."
related: []
origin: FNAP
---

# A lag spike kills the player instantly (reaction window consumed by one frame)

**When to use:** Timed danger windows decrement by delta.

## What happened, root cause, fix, prevention

- Symptom: player dies without seeing the approach after a hitch (shader compile, load).
- Root cause: `_approach_left -= delta` with a huge delta.
- Fix: `_approach_left -= minf(delta, 0.1)`.
- Prevention: clamp delta in every player-reaction timer.

## Verify

inject a 1 s stall during an approach; window persists.

## Origin

FNAP. Source notes: REF §2.5, §8.1 E.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
