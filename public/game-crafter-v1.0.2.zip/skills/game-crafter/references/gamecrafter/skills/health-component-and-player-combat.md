---
id: health-component-and-player-combat
title: "Health component + player melee cone / hitscan / reload / regen / respawn"
category: gameplay-systems
when: "Quick action combat layer."
related: []
origin: Caesarea
---

# Health component + player melee cone / hitscan / reload / regen / respawn

**When to use:** Quick action combat layer.

## Do this

`CaeHealth` child node: max_health, `take_damage(amount, source)`, `heal`, `fraction()`, signals damaged/died/healed; parent joins group `damageable`. Player: melee = all damageables within range+0.6 m and within 55° of camera forward (flattened); ranged = ray from camera with spread (`dir + basis.x*rand(±sp) + basis.y*rand(±sp)`), mask world|enemies, tracer ImmediateMesh line 0.06 s (amber for ballistic, blue for energy); fire rate cooldown `1/rate`; auto-reload on empty; reload cooldown 1.2 s; regen 1.5 HP/s after 6 s without damage; red flash ColorRect alpha 0.4 decaying 1.6/s; death → "You fall. Respawning..." 2.5 s → respawn point. Blocked during dialogue and when mouse not captured. Weapon table mirrors items JSON stats.

## Pitfalls (mistakes seen)

Health added with `add_child.call_deferred` + `set.call_deferred("health", 100)` and signals wired in a deferred `_wire` — order-dependent; keep that sequencing or create the node in _ready synchronously.

## Origin

Caesarea. Source notes: game/combat/health.gd, player_combat.gd, weapon_defs.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
