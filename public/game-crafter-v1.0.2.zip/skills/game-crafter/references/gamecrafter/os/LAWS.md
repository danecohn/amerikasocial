# LAWS — the non-negotiables
Each law exists because breaking it once hurt a real project. "Origin" says where. If a skill or a user shortcut seems to conflict with a law, follow the law and tell the user why in one line, unless the user explicitly overrides it for their own project.

---

### LAW 1: The exported build is the only truth
The editor and `godot --path` runs prove nothing about what players get. Before you say "done" or "fixed", export the build (or a pack), run it, take a screenshot from it, and **open and look at the image**.
*Origin: FNAP shipped grey boxes and capsule characters while every editor run looked perfect. In Pickle's Pickle Shop a player hit a placeholder-looking jumpscare in the shipped build.*
→ `skills/verify-exported-pack.md`, `skills/mistake-exported-build-shows-placeholders.md`

### LAW 2: Load assets the export-safe way
In an exported game the raw `.glb/.png/.wav` files aren't in the pack. Use `load()` and `ResourceLoader.exists()`. Strip `.import`/`.remap` from directory listings. Put raw data files (json/csv/txt/cues/voice) in every preset's `include_filter`. Run `os/tools/lint_export_safety.md` before every export.
→ `skills/godot-export-safe-asset-loading.md`

### LAW 3: Placeholders are loud, never silent
Every authored asset may have a placeholder so the game always runs. A placeholder in use must print a warning and show on screen in debug builds. A placeholder must never reach a release build unnoticed.
→ `skills/loud-placeholders.md`

### LAW 4: Never fix by hiding
Setting `visible=false`, zeroing light energy, zeroing a render layer, flattening a material, deleting the mesh or silencing the warning is not a fix. Find the root cause. Every such line in the code needs a written justification (`os/tools/hide_audit.md`).
*Origin: FNAP "fixes" that hid broken meshes. Eyes-only darkness logic that later hid a character during its own jumpscare.*
→ `skills/never-fix-by-hiding-hide-audit.md`

### LAW 5: Look at every output
Screenshots, sprite sheets, covers, video frames, audio levels, zips. Open them, check them, describe what you saw. "Saved to out.png" is not verification.
→ `skills/evidence-rule.md`

### LAW 6: Respect the user's standing vision
If the user says the halls are dark, they stay dark. Fix visibility with *their* mechanic (hall lights, flashlight, camera exposure), not by brightening the world. Write standing instructions into STATE.md and check every delivery against them.
*Origin: Pickle's Pickle Shop: "you didn't ruin the darkened hallways did you? Those are supposed to be dark."*
→ `skills/standing-instructions.md`

### LAW 7: One vertical slice before width
Make one thing work end to end in the exported build before you add breadth, agents or tooling.
*Origin: FNAP's 16-agent team stalled with nothing to show.*
→ `skills/vertical-slice-first.md`

### LAW 8: Deliver to the exact place, then confirm it landed
Put files in the exact folder the user named. List the folder afterwards and check sizes and timestamps. Big files get split into parts with a join script. Never leave a folder half old, half new without saying so.
→ `skills/deliver-and-confirm.md`, `skills/split-zip-parts-and-build-all-bat.md`

### LAW 9: Report honestly
Every delivery ends with **verified (and how)** and **not verified**. Never write "should work". Never claim you played, heard or saw something you didn't.
→ `os/checklists/honest-report.md`

### LAW 10: Never publish, upload, post or spend without an explicit ask
No itch.io uploads, social posts, store changes, emails or purchases unless the user asked for that specific action. Secrets, logins and IDs never go into project files.
→ `skills/never-publish-unless-asked.md`

### LAW 11: The user's edits win
The user (or another AI) may edit the project between sessions. Before you overwrite anything, diff the project of record against your copy and merge. After merging, re-run the parse check, because their edits may not compile.
*Origin: Pickle's Pickle Shop: a user-edited file was missing a function header and broke the build.*
→ `skills/mistake-user-edited-code-parse-error.md`

### LAW 12: Test runs prove behaviour, not hope
Every system gets a headless test or probe that prints PASS/FAIL and exits non-zero on failure. Run the full game automatically where you can (an auto-demo player, scripted inputs).
→ `skills/headless-self-test-scene-pattern.md`, `skills/automated-demo-player-bot.md`

### LAW 13: Never go silent
Before any long job, send one status line. Run long jobs in the background and poll. If the user interrupts, stop and answer.
→ `skills/background-long-jobs-bg-run.md`

### LAW 14: Content and credit rules are part of the spec
Use the one credit line, exactly as given, everywhere. Follow the project's content rules (e.g. "depict fascism, never endorse it"). Disclose AI assistance where a store requires it. Never put real people's likeness or another studio's IP into a game.
→ `skills/single-credit-line-rule.md`

### LAW 15: Write down every new mistake
A mistake that reached the user becomes a `skills/mistake-*.md` file the same day. (BOOT.md §5)
