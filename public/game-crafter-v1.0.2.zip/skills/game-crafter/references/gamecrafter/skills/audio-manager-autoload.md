---
id: audio-manager-autoload
title: "AudioManager autoload: buses, pooled one-shots, keyed loops, ducking, missing-file hooks"
category: audio-music
when: "Any Godot game needing SFX/music/ambience by string id."
related: []
origin: Pickle's Pickle Shop
---

# AudioManager autoload: buses, pooled one-shots, keyed loops, ducking, missing-file hooks

**When to use:** Any Godot game needing SFX/music/ambience by string id.

## Do this

Ensures buses Music/SFX/Ambience exist (add + send to Master). `get_stream(id, dir)` tries `<dir><id>.wav|ogg|mp3` via ResourceLoader, caches, and warns ONCE per missing id ("placeholder hook") so code can reference sounds before they exist. 16-player one-shot pool (steal oldest). `play_sfx_3d` spawns AudioStreamPlayer3D under current_scene (unit_size 4, max_distance 40, queue_free on finish). Keyed loops `play_loop(key, id, db, bus)` (updates volume if already playing) / `stop_loop(key, fade)`; `_force_loop` sets WAV LOOP_FORWARD with loop_end = length*mix_rate, Ogg/MP3 `.loop = true`. Ambience per-id trim table (office -3.6 dB, shop -10.6, default -6). `set_duck(on, -10 dB, 0.35 s)` for hold-breath; separate `set_voice_duck` (-6 dB on Ambience) for dialogue; bus base dB remembered so settings and ducking compose. Sound naming: lowercase kebab ids (`door-slam`, `jumpscare-<id>`, `footsteps-<id>-heavy|soft`, `phone-night-N`), numbered music tracks `01-title-theme` .. `19-permadeath`, character themes. `GameState.change_scene()` always stops loops and the music clock first.

## Verify

Missing-id warnings list in log = sounds still to make.

## Origin

Pickle's Pickle Shop. Source notes: scripts/autoload/audio_manager.gd; scripts/core/sfx.gd; game_state.gd change_scene.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
