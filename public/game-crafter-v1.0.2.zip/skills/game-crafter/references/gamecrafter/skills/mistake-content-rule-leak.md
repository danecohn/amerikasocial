---
id: mistake-content-rule-leak
title: "Story/content rule leaked into UI text"
category: mistake
when: "Before release of a story game."
related: [content-rules-file]
origin: FNAP
---

# Story/content rule leaked into UI text

**When to use:** Before release of a story game.

## Do this

`docs/CONTENT_RULES.md` + grep before release (see content-rules-file).

## What happened, root cause, fix, prevention

Symptom: hidden character name in credits/game-over. Fix above.

## Verify

grep 0 hits.

## Origin

FNAP. Source notes: mistakes-log.md M96; BOARD.md line 35.

## Related skills

- [content-rules-file](content-rules-file.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
