---
id: fnaf-hallucination-enemy
title: "Hallucination enemy (appears on a feed / in the chair, dismissed by raising the monitor)"
category: ai-enemies
when: "Adding a Golden-Freddy-style non-patrolling apparition."
related: [fnaf-bible-digest-and-text-audit]
origin: FNAP
---

# Hallucination enemy (appears on a feed / in the chair, dismissed by raising the monitor)

**When to use:** Adding a Golden-Freddy-style non-patrolling apparition.

## Do this

- Not on any path; `is_hallucination = true` (excluded from the hourly +1 AI ramp).
- 3D logic: while the monitor is up, chance per second `ai*0.0006` (REF writes "x`0.004` on CAM_5": read as a much
  higher per-second chance while watching the back camera CAM_5). He appears on the feed (`golden_state "feed"`);
  when the monitor is lowered he moves into the office chair (`"office"`); 2.2 s later `trigger_jumpscare(golden)`
  unless the monitor is raised again (then `vanish()`). Looped whisper drone + `MusicClock.set_presence("golden_pickle")`.
- 2D REBUILD alternative trigger: a RARE CAM 2B poster swap (`cam-2b-golden-pickle-poster.png`) is the trigger; he
  appears in the office (`office-seated-golden-pickle.png`) when the monitor is lowered. His jumpscare
  ("stare too long") then quits back to the menu.
- Fiction rules (BIBLE): "not a fifth patrol animal and is never described as 'Pickle in gold'... something the
  building produces on very long nights"; "Lifting the monitor makes him go away"; his name is never spoken or shown in
  UI. Game-over screen names him "Something". Jumpscare lasts longer (2.6 s vs 1.6 s).
- Call N4 teaches it: "If it's in the office, lift the monitor. That's all. It goes away. Don't talk to it, and don't look
  at it for long."

## Pitfalls (mistakes seen)

name leak in player-facing strings -> audit (fnaf-bible-digest-and-text-audit).

## Verify

Director moment `golden_pickle`; `force` hooks; grep build strings for the forbidden name.

## Origin

FNAP. Source notes: REF §2.5 Golden Pickle, §2.6, §2.13 (game_over map), §8.2 #17; BIBLE "Golden Pickle"; CALLS N4;
  STATEMAP lines 47, 102, 127, 159.

---------------------------------------------------------------------------------------------------

## Related skills

- [fnaf-bible-digest-and-text-audit](fnaf-bible-digest-and-text-audit.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
