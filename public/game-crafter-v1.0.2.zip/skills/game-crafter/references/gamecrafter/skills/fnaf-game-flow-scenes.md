---
id: fnaf-game-flow-scenes
title: "Game flow: splash -> menu -> night card -> office -> 6 AM / game over"
category: ui-ux
when: "Wiring the scene flow of a night-based horror game."
related: [mistake-splash-video-missing-from-pck]
origin: FNAP
---

# Game flow: splash -> menu -> night card -> office -> 6 AM / game over

**When to use:** Wiring the scene flow of a night-based horror game.

## Do this

- `splash -> main_menu -> night_intro (12:00 AM / "1st Night" card, 3.2 s hold) -> office -> win_screen | game_over`;
  after Night 5 `win_screen` offers Credits; bonus mode unlocks and appears in the menu.
- `GameState.start_night(n)` saves, clamps, clears roguelite `in_shift`, goes to night_intro.
- Splash: try an intro `.ogv` (CLI flag, ProjectSettings `fnap/branding/splash_video`, several folders) else a code
  splash: pixel-art PNG scaled by an INTEGER factor with nearest filter, flash+scale "hit" at 1.0 s, sting wav, window
  icon via `DisplayServer.set_icon`, 4.5 s then fade; any key/click/joypad skips; `--fnap-skip-splash`.
- Main menu: New Game / Continue Night N / How to Play / Bonus mode (if unlocked) / Extras / Credits / Quit; in-menu modal
  help panel (disables menu buttons, Esc closes); version from ProjectSettings; renderer note.
- Extras: bestiary SubViewport with a spotlit animatronic and ABOUT text. Credits: scrolling VBox + live SubViewport 3D
  showcase of the mascot (`showcase` clip).
- 2D REBUILD extras: warning screen card, title bg with 4 twitch frames + transparent logo overlay, newspaper help-wanted
  ad ("The Daily Brine") shown on New Game before Night 1, night cards 1-5, menu selector `>>`, "Continue" + night
  number sprite.
- Every menu calls `GameState.quit_game()` (saves) instead of `get_tree().quit()`.

## Pitfalls (mistakes seen)

mistake-splash-video-missing-from-pck.

## Verify

Boot with no flags; walk the whole flow; `--fnap-autoadvance` for unattended runs.

## Origin

FNAP. Source notes: REF §2.1, §2.13, §2.15; STATEMAP lines 163-185.

## Related skills

- [mistake-splash-video-missing-from-pck](mistake-splash-video-missing-from-pck.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
