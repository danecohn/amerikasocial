---
id: export-include-filter-facts
title: "What Godot 4.7 exports raw vs imported (include_filter rules)"
category: export-release
when: "Adding data files (csv/txt/json/cues/xml/cfg) or raw-scanned asset folders; writing export presets."
related: []
origin: FNAP
---

# What Godot 4.7 exports raw vs imported (include_filter rules)

**When to use:** Adding data files (csv/txt/json/cues/xml/cfg) or raw-scanned asset folders; writing export presets.

## Do this

Measured in Godot 4.7.2 with EMPTY include_filter and `export_filter="all_resources"`: `.json` ships raw (resource type); `.csv` is IMPORTED as a Translation (only `x.csv.import` listed, raw bytes gone, `load()` returns Translation not text); `.txt .cues .md .cfg .xml .dat .bin` are NOT exported at all; `.png .glb .wav .ogg` are imported (only `.import` names visible). Standard include_filter: `"*.txt, *.csv, *.cues, *.xml, *.cfg, <raw-scanned dirs>/*, tools/probe_manifest.json"` (FNAP: `assets/audio/voice/*, assets/branding/*`). Standard exclude_filter: `"_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"` (dev scenes can't ship).

## Pitfalls (mistakes seen)

Phone-call subtitles (`.cues`/`.txt`) and data missing in build -> not in include_filter -> add globs. Filters differed between presets (copy/paste) -> "works on Windows, missing on Mac" -> keep filters IDENTICAL in every preset.

## Verify

lint W1 clean; probe manifest raw-file checks pass from pack.

## Origin

FNAP. Source notes: SKILL.md "Presets"; export_presets.template.cfg header.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
