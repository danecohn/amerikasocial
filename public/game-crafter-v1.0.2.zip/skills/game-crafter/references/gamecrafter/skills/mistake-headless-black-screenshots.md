---
id: mistake-headless-black-screenshots
title: "Screenshots from `--headless` are black"
category: mistake
when: "Capturing images from Godot."
related: []
origin: FNAP
---

# Screenshots from `--headless` are black

**When to use:** Capturing images from Godot.

## Do this

`--headless` uses dummy renderer; use xvfb + software Vulkan for any pixels.

## What happened, root cause, fix, prevention

Symptom: black PNGs. Fix above.

## Verify

Open PNG.

## Origin

FNAP. Source notes: mistakes-log.md M51.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
