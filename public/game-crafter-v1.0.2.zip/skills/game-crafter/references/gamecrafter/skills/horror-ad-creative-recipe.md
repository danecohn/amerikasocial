---
id: horror-ad-creative-recipe
title: "Horror/arcade ad creative structure"
category: promo-marketing
when: "Writing a trailer brief (for ffmpeg or Descript)."
related: []
origin: FNAP
---

# Horror/arcade ad creative structure

**When to use:** Writing a trailer brief (for ffmpeg or Descript).

## Do this

Cold open within 2 s (hard cut, glitch/white flash 0-0.3 s, boom, title slam) -> build with quick cuts on the music, flicker, punch-in zooms, red/amber grade, vignette, grain -> kinetic lines ("THEY'RE ALWAYS WATCHING", "SURVIVE 5 NIGHTS") -> 0.3 s near-silence -> jumpscare + stinger -> end card + CTA ("PLAY FREE ON ITCH.IO"), 0.5 s fade. Colours #000000 #C8102E #FF9A1F #FFFFFF. Keep titles off busy artwork. Vertical safe zones top 250/bottom 350 px.

## Pitfalls (mistakes seen)

n/a

## Verify

user review.

## Origin

FNAP. Source notes: game-promo-pipeline/SKILL.md "Creative recipe".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
