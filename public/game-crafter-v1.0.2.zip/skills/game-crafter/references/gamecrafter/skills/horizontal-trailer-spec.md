---
id: horizontal-trailer-spec
title: "16:9 trailer (30-45 s) structure + YouTube upload + thumbnail"
category: promo-marketing
when: "Making a YouTube trailer / itch gameplay video for a small game."
related: []
origin: Roguelike series
---

# 16:9 trailer (30-45 s) structure + YouTube upload + thumbnail

**When to use:** Making a YouTube trailer / itch gameplay video for a small game.

## Do this

- Capture native 1920x1080 (game is 16:9 at exactly 5x, no crop).
- Structure: 0-3 s studio sting + splash logo (forgotten-woods-splash-1920x1080.png) -> 3-8 s title card + one line of atmosphere -> 8-30 s four gameplay beats -> 30-38 s feature cards -> 38-45 s end card with price and URL.
- Beats: (a) floor-1 combat with the resource bar shrinking, (b) a boon pick (shows the build side), (c) a named boss fight with boss bar and a dialogue line, (d) the last stair/door then cut to black - never show endings (spoilers).
- Feature cards (2.5 s each): "4 FLOORS. 4 BOSSES." / "18 RELICS" / "8 UPGRADES" / "3 ENDINGS" / "ORIGINAL SOUNDTRACK" / "WINDOWS - MAC - LINUX".
- Audio: title theme under opening, boss track under fight, "ending" track for last 10 s.
- YouTube: title "<TITLE> - Official Trailer | Pixel Horror Roguelike"; description = first paragraph of itch description + page URL; tags = first 6 itch tags; paste the YouTube link into itch "Gameplay video".
- Thumbnail: cover 630x500 scaled to 1280x720 with enlarged title.
- Posting schedule (2 weeks): Day 0 publish + Reel A | Day 2 Reel B | Day 4 vertical ad cut | Day 7 end-of-sale reminder (Story + Reel) | Day 10 behind-the-scenes (how the music/fonts were made) | Day 14 horizontal trailer on YouTube.

## Pitfalls (mistakes seen)

none.

## Verify

no ending footage in the cut; URL and price correct.

## Origin

Roguelike series. Source notes: pack.py L152-168; socials.txt PART 3-4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
