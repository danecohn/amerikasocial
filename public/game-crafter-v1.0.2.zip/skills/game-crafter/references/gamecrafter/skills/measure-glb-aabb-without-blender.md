---
id: measure-glb-aabb-without-blender
title: "Measure a GLB's bounds/sockets with pure Python (glTF accessor min/max)"
category: 3d-blender
when: "Blender is unavailable (cloud) and you must QA GLBs against a size contract."
related: []
origin: Caesarea
---

# Measure a GLB's bounds/sockets with pure Python (glTF accessor min/max)

**When to use:** Blender is unavailable (cloud) and you must QA GLBs against a size contract.

## Do this

- Parse GLB: 12-byte header, chunk 0 JSON. For every node with a mesh, take each primitive's POSITION accessor `min`/`max` (required by glTF spec), transform the 8 corners by the node's world matrix (TRS or matrix, accumulated through parents), union → scene AABB. Empties named `SOCKET_*` → report their translation.
- Pass rule used: min, max and size on each axis within 5% of the contracted length of that axis.
- Also hash files (SHA-256) to confirm two trees (PC project and work copy) hold identical files; recheck sizes at the end if files are still being written.
- Report embedded images (bufferView, empty uri) vs external URIs; materials using `baseColorFactor` only.

## Pitfalls (mistakes seen)

Measuring while another bot is still exporting: re-read sizes at the end ("Banner, raider, three weapons and Mara were rewritten during the pass; sizes rechecked").

## Verify

Compare to Godot `measured_aabb()` test results.

## Origin

Caesarea. Source notes: glb_report.md header.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
