---
id: game-spec-module-contract
title: "What a per-game spec/content/meta module must expose"
category: planning-design
when: "Starting a new game in a spec-driven factory; writing spec.py/meta.py."
related: []
origin: Roguelike series
---

# What a per-game spec/content/meta module must expose

**When to use:** Starting a new game in a spec-driven factory; writing spec.py/meta.py.

## Do this

- `spec.py`: `SPEC = {"slug", "title": {"name","sky_top","sky_bot"}, "font_name", "fonts": {"body": dict(body="base", shape="square"), "title": dict(body="bold", shape="chamfer", chamfer=24, pad=4, tracking=40)}, "pal", "accent_hex", "mem_col", "heart_col", "icon_col", "proj_col", "eproj_col", "danger_hex", "seed", "sfx": {"pitch","grit","seed"}, "player": {"recipe":"humanoid","pal":Pal(...),"frames":4,"kw":{...}}, "npcs": {...}, "enemies": {...}, "bosses": {...}, "props": {name: fn}, "tiles": {theme: {...}}, "music": [(name, style, key, mode, bpm, bars, seed), ...]}`, plus `GAME` dict and optional hooks `title_scene`, `extra_art`.
- Creature entry flags: `kid: True` (crop rows 11-14 to make a shorter humanoid), `alpha: 0.85` (ghost transparency), `scale`, `frames`, `seed`, `kw`.
- `meta.py`: `META = {"folder","slug","itch_slug","title","product","zip_prefix","tagline","short","price","launch_price","session","genres","tags"(10),"access","warnings","controls","long","reel_a","hashtags_a","reel_b","hashtags_b","shots","cards","reel_music","shots_h","features_cards","bible", "title_case"?}` - every store/social text is data, templated by pack.py.
- Naming: slug `the_last_lamp` (files/exe), itch slug `the-last-lamp`, product `The Last Lamp` (exe/app display name), zip prefix `The_Last_Lamp`, folder `THE LAST LAMP`.

## Pitfalls (mistakes seen)

none specific.

## Verify

buildgame.py and pack.py run without KeyError.

## Origin

Roguelike series. Source notes: games/g1_lamp/spec.py L9-30, 129-139; games/g1_lamp/meta.py keys; pack.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
