---
id: mistake-ducking-left-on-after-death
title: "Music/ambience stays muted in the next scene (duck not released)"
category: mistake
when: "Audio is quiet after dying during a phone call / voice line."
related: []
origin: FNAP
---

# Music/ambience stays muted in the next scene (duck not released)

**When to use:** Audio is quiet after dying during a phone call / voice line.

## What happened, root cause, fix, prevention

- Symptom: after a death or scene change mid-call, Music/Ambience stayed ducked in the next scene.
- Root cause: the duck was only released on normal call end.
- Fix: `stop_all_loops() -> reset_ducks()`; `PhoneCall._exit_tree` restores ducks; token-guard awaits.
- Prevention: release every duck/lock on ALL exit paths (scene change, death, exit_tree).

## Verify

die mid-call, check bus volumes in the menu.

## Origin

FNAP. Source notes: REF §8.2 #10, §2.10, §8.1 I.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
