---
id: mistake-hall-cameras-pitch-black
title: "Hall camera feeds too dark to read"
category: mistake
when: "Tuning camera feed exposure in a dark horror map."
related: []
origin: Pickle's Pickle Shop
---

# Hall camera feeds too dark to read

**When to use:** Tuning camera feed exposure in a dark horror map.

## Do this

Camera feeds have their own exposure separate from the player view. In `camera_monitor.gd _sync_feed_exposure`: hall cams (CAM_2A/2B left, CAM_4A/4B right) use `energy = 3.4 if hall_on else 0.9`, `ambient = 0.6 if hall_on else 0.14`. Earlier values 0.01/0.005 made the feeds pitch black. Intermediate tested values 2.6/0.42 lit vs 1.1/0.2 unlit were screenshotted and OK.

## What happened, root cause, fix, prevention

Symptom: user: "hallway cameras ... you need to be able to see some detail it shouldn't be so dark it's pitch black, except for outside the doors". Root causes: (1) energy 0.01/ambient 0.005; (2) feed not refreshed when lights toggled; (3) a typed-array runtime error aborted the light function. Fix: retune; `_set_light` calls `monitor.refresh_isolation()` after `level.set_hall_room_lights`; fix array typing. Prevention: "dark" for horror means dim-but-readable on cameras; only spaces the user names are pitch black. Re-screenshot after every constant change (final values 3.4/0.6 and 0.9/0.14 were NOT re-screenshotted - flagged to user).

## Verify

Screenshot each hall cam lit and unlit; check mean luminance > threshold unlit and noticeably higher lit.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.1, 3, 4, 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
