---
id: godot-frame-animator-feet-origin
title: "Minimal Godot sprite animator with bottom-centre (feet) origin"
category: pixel-art-2d
when: "Animating strip sheets for top-down characters that y-sort by feet."
related: []
origin: Roguelike series
---

# Minimal Godot sprite animator with bottom-centre (feet) origin

**When to use:** Animating strip sheets for top-down characters that y-sort by feet.

## Do this

```gdscript
class_name Anim extends Sprite2D
var frames: Array = []; var fps := 6.0; var _t := 0.0; var playing := true
func setup(path: String, n: int, speed := 6.0) -> Anim:
    frames = Art.frames(path, n); fps = speed; texture = frames[0]; centered = true
    var h := float((frames[0] as Texture2D).get_height())
    offset = Vector2(0, -h * 0.5)          # node position = feet
    return self
func _process(delta: float) -> void:
    if playing and frames.size() > 1:
        _t += delta * fps; texture = frames[int(_t) % frames.size()]
```
- Player uses 8 fps and stops on frame 0 when idle; enemies 6 fps (data `fps`). Facing via `flip_h`. Y-sort: `actors.y_sort_enabled = true` and `z_index = int(position.y)`.
- Drop shadow: shared 12x5 ellipse texture, `Color(0,0,0,0.45)`, at (0,-1), z -1; scaled `Vector2(radius/5,1)` for enemies.

## Pitfalls (mistakes seen)

centred sprites with ODD width/height land on half pixels (offset -9.5) - can shimmer/blur when not snapped. Prevention: keep frame sizes even, or `offset = Vector2(0, -floor(h/2))`, or enable 2D pixel snapping.

## Verify

stand sprite on a tile line; feet touch the line at all frames.

## Origin

Roguelike series. Source notes: kit/kit/anim.gd; player.gd lines 46-70, 179-189; enemy.gd lines 50-56, 162, 170.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
