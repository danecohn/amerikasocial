---
id: descript-import-media
title: "Getting media into Descript via MCP"
category: promo-marketing
when: "User asks for a Descript project/edit."
related: []
origin: FNAP
---

# Getting media into Descript via MCP

**When to use:** User asks for a Descript project/edit.

## Do this

`import_media(project_name, add_media={name:{content_type,file_size}}, add_compositions=[{name,width,height,clips:[{media}]}])` -> `upload_urls` (presigned PUT, valid ~3 h), `job_id`, `project_id`, `project_url` (show it). PUT: `curl -X PUT -H "Content-Type: application/octet-stream" --data-binary @file "<upload_url>"` (size must match). Test reachability first (sandbox storage host returned `CONNECT tunnel failed, response 403`); don't bypass proxy. If PUT fails: `report_upload_status(job_id, media_id, "failed", detail)` for EACH media key so the job doesn't hang (newer schema also lets you pass the attachment in `files` so the server fetches it); tell the user to drag files from <folder> into the project; ghost entries without extension (`type: other`) remain -> tell them to delete. Keep upload URLs in the command; don't reference a temp file you never wrote. Compositions created from failed uploads are 6-second placeholders: have Underlord replace them with real clips.

## Pitfalls (mistakes seen)

Hung jobs after failed PUT -> report status per media key.

## Verify

get_project shows media.

## Origin

FNAP. Source notes: references/descript-playbook.md "Getting media in".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
