# <GAME TITLE> — Game Bible
Studio: <studio name> · Engine: Godot <x.y.z> · Genre: <genre> · Target: Windows x64 / Windows ARM64 / macOS / Linux
Status: <concept | slice | alpha | beta | shipped> · Last updated: <date> by <agent/person>

## 1. One-line pitch
<"A <genre> where you <verb> in <place> while <threat>.">

## 2. Pillars (3 max) — every feature must serve one
1. <e.g. Darkness is the enemy: you can't see who's there without light>
2. <...>
3. <...>

## 3. Player fantasy & core loop
- Moment to moment: <what the hands do>
- Session loop: <a night / a run / a quest>
- Meta loop: <unlocks, story, endings>

## 4. Controls
| Action | Keyboard/Mouse | Gamepad |
|---|---|---|

## 5. World, story & tone
- Setting: <...>
- Story in 5 beats: <...>
- What the player can learn (and when): <...>
- Endings: <...>
- Content rules: <what we depict, what we never endorse, age rating target>

## 6. Characters / enemies
| Name | Role | Behavior / AI | Visual notes | Audio |
|---|---|---|---|---|

## 7. Systems
<One subsection per system: rules, numbers, data file it lives in.>

## 8. Art direction
- Style: <3D low-poly horror / 8-bit pixel art 320x180 / ...>
- Palette: <hex list or named palette>
- Lighting rules: <e.g. halls pitch black unless lit>
- UI style & font: <...>

## 9. Audio direction
- Music: <style, tracks list, BPM/key>
- SFX: <list>
- Voice: <lines, subtitles>

## 10. Difficulty & progression
<Curve per night/floor/act with numbers.>

## 11. Scope (what's IN / OUT for v1)
- IN: <...>
- OUT: <...>

## 12. Credits
<The one credit line, exactly as it must appear.>
