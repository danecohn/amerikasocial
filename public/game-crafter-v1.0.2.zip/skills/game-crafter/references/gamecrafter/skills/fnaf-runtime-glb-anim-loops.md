---
id: fnaf-runtime-glb-anim-loops
title: "Re-apply animation loop policy to runtime-loaded GLBs"
category: godot-engine
when: "GLB animations loop wrongly (or don't loop) in game."
related: []
origin: FNAP
---

# Re-apply animation loop policy to runtime-loaded GLBs

**When to use:** GLB animations loop wrongly (or don't loop) in game.

## Do this

- Godot's editor import script does not run for `GLTFDocument.generate_scene` at runtime, and the importer loses Blender
loop flags. `FnapAnimImport.apply_loops(scene)`: every clip loops EXCEPT one-shots: `jumpscare, door_retreat,
light_flinch, serve, appear, fp_door_yank_*, fp_monitor_up/down, fp_lean_out_*, fp_dock/undock, fp_get_up,
fp_sit_down, fp_jumpscare_react, fp_death, fp_flashlight_dies`. Then `ClipManifest.apply(character, player)` overrides
from `clips.json` (`clips`, `walk_speed_mps`). Play helpers also set `loop_mode` per call.

## Pitfalls (mistakes seen)

trusting `Animation.loop_mode` from the GLB.

## Verify

char_check prints each clip's loop mode.

## Origin

FNAP. Source notes: REF §3.2, §8.1 J.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
