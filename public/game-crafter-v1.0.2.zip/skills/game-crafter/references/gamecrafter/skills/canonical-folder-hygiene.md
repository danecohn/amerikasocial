---
id: canonical-folder-hygiene
title: "Canonical project folder rules"
category: project-management
when: "User defines folder layout on their PC (e.g. 'the Godot folder contains ONLY the project')."
related: []
origin: FNAP
---

# Canonical project folder rules

**When to use:** User defines folder layout on their PC (e.g. "the Godot folder contains ONLY the project").

## Do this

Godot folder holds only the project; docs/tools/art/DISTRIBUTION live beside it. Stray docs are MOVED by a script (not deleted). Deliver to the EXACT path requested (user: "No, I want the zips IN that folder, find a way"). Verify with a listing; say where it landed in plain words (no internal paths unless asked). Generic layout: `<Game>\Godot\`, `<Game>\docs\`, `<Game>\tools\` (scripts + logs), `<Game>\art\`, `<Game>\DISTRIBUTION\` (+ `_inputs` extras).

## Pitfalls (mistakes seen)

Delivering next to rather than into the requested folder -> user rejected.

## Verify

listing of exact folder.

## Origin

FNAP. Source notes: pc-bridge-delivery/SKILL.md bullets 7-8; make_release example.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
