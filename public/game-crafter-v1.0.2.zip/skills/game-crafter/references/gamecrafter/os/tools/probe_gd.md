# Tool: probe.gd

**Purpose:** Minimal probe used by the factory to boot a game in the exported build and log.

**Usage:** `godot --main-pack ... `

**Skill:** see `skills/export-probe-template.md`

**Extract:** save the block below as `probe.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
extends Node
func _ready() -> void:
	var fails := 0
	var m: Variant = JSON.parse_string(FileAccess.get_file_as_string("res://tools/probe_manifest.json")) if FileAccess.file_exists("res://tools/probe_manifest.json") else null
	if m == null:
		print("PROBE_FAIL manifest missing"); get_tree().quit(2); return
	print("PROBE renderer=", RenderingServer.get_current_rendering_method())
	for p in m.get("resources", []):
		var res: Resource = load(p) if ResourceLoader.exists(p) else null
		if res == null:
			print("PROBE_FAIL load ", p); fails += 1
	for p in m.get("raw_files", []):
		if not FileAccess.file_exists(p):
			print("PROBE_FAIL raw ", p); fails += 1
	print("PROBE_COUNT ", m.get("resources", []).size())
	print("PROBE_DONE fails=", fails)
	get_tree().quit(1 if fails else 0)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
