---
id: mistake-dead-generated-icon
title: "Generated per-game icon thrown away (dead code) - every game ships the studio icon"
category: mistake
when: "Reviewing asset pipelines."
related: []
origin: Roguelike series
---

# Generated per-game icon thrown away (dead code) - every game ships the studio icon

**When to use:** Reviewing asset pipelines.

## Do this

Decide explicitly: studio icon (brand consistency) or per-game icon (store recognisability); remove the unused path.

## What happened, root cause, fix, prevention

- Symptom: buildgame.py composes a 64x64 icon from the player sprite (`ic`), never saves it, then copies `fw_icon.png` as icon.png; `title_bg(..., big=False)` and `k = 1` also unused.
- Root cause: changed decision mid-way, leftover code.
- Fix: delete or save as `assets/ui/game_icon.png` for itch/desktop use.

## Verify

grep for unused variables (pyflakes).

## Origin

Roguelike series. Source notes: buildgame.py L128-131, L228-233.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
