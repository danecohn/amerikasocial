# Template: BOARD.md — shared team board for multi-agent work
One file every agent appends to. Timestamped, prefixed with the role. Never rewrite someone else's line.

```
[HH:MM] LEAD: <milestone / signal, e.g. READY_CODE: scripts+scenes+GLBs in <path>; import next>
[HH:MM] <ROLE>(<n>): started; owning <files>. Will not touch <files> without asking <owner>.
[HH:MM] <ROLE>(<n>): REQUEST #<owner>: need <function/asset> — fallback if absent: <...>
[HH:MM] QA(<n>): <check> PASS/FAIL — evidence: <command output or PNG path that was OPENED>
[HH:MM] MAIN: USER REQUIREMENTS ADDED — (1) ... (2) ...  ← copy every new user requirement here immediately
[HH:MM] MAIN: team stalled (no live agents) — continuing solo from <point>
```
Signals used: READY_CODE, READY_ASSETS, IMPORT_DONE, EXPORT_DONE, QA_BASELINE, BLOCKED(<why>), HANDOFF(<to>).
Rule from FNAP: a 16-agent team stalled within an hour with nothing to show. Start with 3–5 roles, one vertical slice, then widen.
