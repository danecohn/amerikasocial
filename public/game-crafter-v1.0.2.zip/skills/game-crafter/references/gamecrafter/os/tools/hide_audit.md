# Tool: hide_audit.sh

**Purpose:** Greps for 'fixes' that hide problems (visible=false, energy=0, layer zeroing, flat materials) so each can be justified.

**Usage:** `bash hide_audit.sh <proj>/scripts`

**Skill:** see `skills/never-fix-by-hiding-hide-audit.md`

**Extract:** save the block below as `hide_audit.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Grep audit for "fixes" that hide problems instead of solving them. Every hit must be justified (by-design rare swaps etc).
# Rule learned the hard way: NEVER hide meshes, zero render layers, or swap modeled surfaces for flat color to make an error go away.
P="${1:-.}"
grep -rnE --include=*.gd "visible *= *false|\.hide\(\)|layers *= *0|cull_mask|light_energy *= *0|set_surface_override_material|material_override *=|albedo_color *=|queue_free\(\)" "$P" \
  --exclude-dir=.godot --exclude-dir=dev --exclude-dir=addons | head -${2:-300}
echo "-- justify each hit (comment why) or remove it. Also confirm every enum state is SET somewhere: grep -n 'state ==' and grep -n 'state = ' "
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
