---
id: interface-contracts-for-parallel-agents
title: "Freeze contracts (zone, interactable, NPC, damage, inventory, save, input, buses, facing, tests) before agents start"
category: multi-agent
when: "Before parallel agents code against each other. - knowledge (Caesarea TEAM.md contracts, reusable verbatim):   - Zone scene `game/scenes/zones/<zone_id>.tscn`: root Node3D with `const ZONE_ID := '<zone_id>'`; child `Marker3D` `PlayerSpawn` + optional `Spawn_<name>`; optional `ZoneExit_<target>` Area3D with meta `target_zone`, `target_spawn`; NavigationRegion3D for pathing; lighting via kit/env presets.   - Interactable: node in group `interactable` with `var prompt: String` and `func interact(actor: Node) -> void`; optional `can_interact(actor) -> bool`; UI shows '[E] ' + prompt.   - NPC: `CharacterFactory.spawn(npc_id, parent, xform) -> Node3D`; data `data/npcs/<id>.json`; talking via `DialogueManager.start(dialogue_id)`.   - Damage: `take_damage(amount: float, source: Node, kind: String)`, signal `died`, group `damageable`, faction via meta `faction`.   - Inventory: `Game.inventory` with `add/remove/count/equip`, signal `changed`.   - Save: SaveManager serializes ledger+quest+faction+inventory+player transform+zone id; stateful nodes join group `saveable` and implement `save_state() -> Dictionary` / `load_state(d)`.   - Input actions (defined in code by `InputSetup.ensure_actions()`): move_forward/back/left/right, sprint, jump, crouch, interact, attack, aim, reload, toggle_camera, pause, inventory, journal, map, quick_save, quick_load.   - Audio buses: Master, Music, SFX, UI, VoxRomae*.   - Facing: +Z forward in Godot (assets face -Y in Blender).   - Tests: each area adds `tests/<area>/<area>_test.tscn` printing `RESULT: PASS (n passed, 0 failed)` or `RESULT: FAIL` and calling `get_tree().quit(code)`.   - Placeholders must be LOUD: visible stand-in + `push_warning('PLACEHOLDER: ...')`, listed in the agent file.   - Kit agent froze its public API in `game/world/kit/README.md` first, before implementation."
related: []
origin: Caesarea
---

# Freeze contracts (zone, interactable, NPC, damage, inventory, save, input, buses, facing, tests) before agents start

**When to use:** Before parallel agents code against each other. - knowledge (Caesarea TEAM.md contracts, reusable verbatim):   - Zone scene `game/scenes/zones/<zone_id>.tscn`: root Node3D with `const ZONE_ID := "<zone_id>"`; child `Marker3D` `PlayerSpawn` + optional `Spawn_<name>`; optional `ZoneExit_<target>` Area3D with meta `target_zone`, `target_spawn`; NavigationRegion3D for pathing; lighting via kit/env presets.   - Interactable: node in group `interactable` with `var prompt: String` and `func interact(actor: Node) -> void`; optional `can_interact(actor) -> bool`; UI shows "[E] " + prompt.   - NPC: `CharacterFactory.spawn(npc_id, parent, xform) -> Node3D`; data `data/npcs/<id>.json`; talking via `DialogueManager.start(dialogue_id)`.   - Damage: `take_damage(amount: float, source: Node, kind: String)`, signal `died`, group `damageable`, faction via meta `faction`.   - Inventory: `Game.inventory` with `add/remove/count/equip`, signal `changed`.   - Save: SaveManager serializes ledger+quest+faction+inventory+player transform+zone id; stateful nodes join group `saveable` and implement `save_state() -> Dictionary` / `load_state(d)`.   - Input actions (defined in code by `InputSetup.ensure_actions()`): move_forward/back/left/right, sprint, jump, crouch, interact, attack, aim, reload, toggle_camera, pause, inventory, journal, map, quick_save, quick_load.   - Audio buses: Master, Music, SFX, UI, VoxRomae*.   - Facing: +Z forward in Godot (assets face -Y in Blender).   - Tests: each area adds `tests/<area>/<area>_test.tscn` printing `RESULT: PASS (n passed, 0 failed)` or `RESULT: FAIL` and calling `get_tree().quit(code)`.   - Placeholders must be LOUD: visible stand-in + `push_warning("PLACEHOLDER: ...")`, listed in the agent file.   - Kit agent froze its public API in `game/world/kit/README.md` first, before implementation.

## Pitfalls (mistakes seen)

Contract changes made silently break other agents; rule: write to requests/ + LOG.

## Verify

a contract test per area (flow_test checks spawn marker, exits, player on floor).

## Origin

Caesarea. Source notes: TEAM.md "Contracts", LOG 09:37 kit entry.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
