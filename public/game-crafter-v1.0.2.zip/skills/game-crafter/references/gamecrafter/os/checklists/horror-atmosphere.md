# Horror atmosphere check (dark games)
- [ ] Dark areas are actually dark in the **exported** build (screenshot unlit vs lit, side by side).
- [ ] Threat readability: where the design says "you can't see who's there without light", nothing is visible unlit — no glowing eyes either, unless that's the intended tell.
- [ ] Light sources the player controls (hall lights, flashlight, lamp) visibly change the scene AND every camera feed that sees that area.
- [ ] Camera feeds show readable detail (not pure black) except where black is the design.
- [ ] Every jumpscare: the real model, real textures, the jumpscare animation playing, face framed, HUD hidden, sound plays, then the death/game-over flow.
- [ ] No darkness/visibility logic hides the character during its own jumpscare (jumpscaring flag overrides it).
- [ ] Audio: ambience loops without clicks, stingers aren't clipped, proximity music works.
- [ ] Brightness/gamma setting exists and doesn't break the intended darkness.
