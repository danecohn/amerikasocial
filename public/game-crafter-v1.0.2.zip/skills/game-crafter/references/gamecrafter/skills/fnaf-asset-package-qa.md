---
id: fnaf-asset-package-qa
title: "Asset package QA generator (inventory, duplicates, references, banned names)"
category: testing-qa
when: "Delivering an art/audio package to a builder (human or another tool), or before zipping assets."
related: []
origin: FNAP
---

# Asset package QA generator (inventory, duplicates, references, banned names)

**When to use:** Delivering an art/audio package to a builder (human or another tool), or before zipping assets.

## Do this

- `gen_statemap.py` generates the state map from the real tree AND runs QA:
  - banned names in file/folder names; source-franchise name only in the one required folder (`fnaf-states`);
  - zero-byte files; temp/provisional/old/"occupied" leftovers; empty folders; unreadable images;
  - banned names inside text files; generated STATE-MAP/BUILD-NOTE checked for banned names;
  - wavs missing from `AUDIO-INDEX.csv`; index rows with no wav; wavs with no sound event in BUILD-NOTE;
  - referenced files missing; files not mentioned in STATE-MAP or BUILD-NOTE.
- Duplicate accounting: sha256 every image; list intentional byte-identical groups with a WHY line (e.g. "plates/ keeps
  one locked empty plate per camera", "door/light art is symmetric", "last frame of the 5->6 roll = the 6 AM hold card").
- Near-copies: report max pixel difference (e.g. baked door-shut plates differ by 30-47/255 from plate+overlay) and %
  pixels differing for rare swaps (0.2%-12.1%).
- Image size table grouped by size with transparency noted.
- Sketch:
  ```python
  import hashlib, pathlib, collections
  from PIL import Image, ImageChops
  root = pathlib.Path(".")
  groups = collections.defaultdict(list)
  for p in root.rglob("*.png"):
      groups[hashlib.sha256(p.read_bytes()).hexdigest()].append(p)
  dups = {h: ps for h, ps in groups.items() if len(ps) > 1}
  def maxdiff(a, b):
      return max(ImageChops.difference(Image.open(a).convert("RGB"), Image.open(b).convert("RGB")).getextrema(), key=lambda e: e[1])[1]
  zero = [p for p in root.rglob("*") if p.is_file() and p.stat().st_size == 0]
  ```

## Pitfalls (mistakes seen)

undocumented duplicates look like mistakes to the next person; document why.

## Verify

QA section prints "none" for every check.

## Origin

FNAP. Source notes: STATEMAP lines 2-3, 306-397, 434-449.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
