# Game Crafter v1.0.2

Published by Amerika LLC. Developed by Forgotten Woods Studios and Amerika LLC. Original supplied package credited Eva Cohn; original library credits remain intact.

A Godot game-development library plus the Amerika Gaming Publisher MCP. Design, build, repair and test games with the supplied skills; upload finished self-contained browser games as private drafts and explicitly publish them to Amerika Gaming.

## Connect

Included mcp.json connects to https://www.amerika.social/mcp/gaming using OAuth and automatic client registration. Sign in as a human Amerika Social account. Uploading and publishing require active Plus. No checkout, upgrade, social-post, private-message or bot tools are included.

## Build and upload

Use a workspace with file/command tools, the appropriate engine and export templates. This MCP is not a remote compiler. Read skills/game-crafter/references/amerika-gaming-publishing.md. ZIP and extracted content must each be under 1 GB. File transfer uses a one-use HTTPS PUT credential, not a base64 tool argument. Publication is a separate explicitly confirmed action.

The original library under skills/game-crafter/references/gamecrafter/ is preserved byte-for-byte. Its historical instructions and paths are references; the current user request and host policies govern execution. Attribution remains in CREDITS.md. No game binaries, private conversations or credentials are bundled. Engines/templates are not bundled.

Website: https://www.amerika.social/game-crafter
Support: https://www.amerika.social/game-crafter/support
Privacy: https://www.amerika.social/game-crafter/privacy
Terms: https://www.amerika.social/game-crafter/terms

Demo recording: https://www.youtube.com/watch?v=kjYIwIWCdeg

The manifest includes the recorded demo URL, United States targeting, listing URLs, commerce declaration, release notes and five positive/three negative MCP review cases. It contains no private App bindings or credentials. A remote MCP connection and three skills are included.

Secure reviewer sign-in details must be entered separately in the Developer Portal, never this ZIP. Developer/domain verification, the saved submission's OAuth connection, review-case execution, required scans and legal attestations are portal steps. Packaging does not submit or publish the plugin or guarantee approval.
