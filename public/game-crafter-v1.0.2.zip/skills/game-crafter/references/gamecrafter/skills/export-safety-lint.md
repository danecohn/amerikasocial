---
id: export-safety-lint
title: "Static lint for bugs that only appear in EXPORTED Godot builds"
category: export-release
when: "Before every export; in CI. - knowledge (tools/qa/lint_export_safety.py): E1 `FileAccess.file_exists/open` on a res:// importable asset (glb/png/wav/...) — raw file not in PCK; E2 `ProjectSettings.globalize_path('res://...')` then reading from disk; E3 DirAccess listing on res:// without `.import`/`.remap` handling (in a build `x.ogv` appears as `x.ogv.import`); E4 `Image.load_from_file`/`AudioStream*.load_from_file`/`GLTFDocument.append_from_file` as primary path; W1 non-JSON data files (csv/txt/cfg/cues/xml/md) referenced by code but not in any preset include_filter (json ships raw in 4.7; csv is imported as Translation — raw bytes gone); W2 no exclude_filter for dev folders; W3 hiding/zeroing code for audit; W4 globalize_path after a guarded load() (likely fallback, verify). 'Guarded' = a `load(`/`ResourceLoader.exists` within the previous 10 lines. Dev paths (tests/, tools/, dev/, *_check.gd) exempt. Exit 1 on any E (or W with --strict).   - Pattern for export-safe assets: `if ResourceLoader.exists(path): t = load(path)` else `push_warning('PLACEHOLDER: ...')` (TrimMaterials._tex)."
related: []
origin: Caesarea
---

# Static lint for bugs that only appear in EXPORTED Godot builds

**When to use:** Before every export; in CI. - knowledge (tools/qa/lint_export_safety.py): E1 `FileAccess.file_exists/open` on a res:// importable asset (glb/png/wav/...) — raw file not in PCK; E2 `ProjectSettings.globalize_path("res://...")` then reading from disk; E3 DirAccess listing on res:// without `.import`/`.remap` handling (in a build `x.ogv` appears as `x.ogv.import`); E4 `Image.load_from_file`/`AudioStream*.load_from_file`/`GLTFDocument.append_from_file` as primary path; W1 non-JSON data files (csv/txt/cfg/cues/xml/md) referenced by code but not in any preset include_filter (json ships raw in 4.7; csv is imported as Translation — raw bytes gone); W2 no exclude_filter for dev folders; W3 hiding/zeroing code for audit; W4 globalize_path after a guarded load() (likely fallback, verify). "Guarded" = a `load(`/`ResourceLoader.exists` within the previous 10 lines. Dev paths (tests/, tools/, dev/, *_check.gd) exempt. Exit 1 on any E (or W with --strict).   - Pattern for export-safe assets: `if ResourceLoader.exists(path): t = load(path)` else `push_warning("PLACEHOLDER: ...")` (TrimMaterials._tex).

## Origin

Caesarea. Source notes: tools/qa/lint_export_safety.py; trim_materials.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
