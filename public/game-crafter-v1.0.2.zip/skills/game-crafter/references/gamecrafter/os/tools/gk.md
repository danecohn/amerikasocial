# Tool: gk.py

**Purpose:** Game-authoring helpers used by every game spec (dialogue, rooms, enemies, items, story beats).

**Usage:** `import gk in a game spec`

**Skill:** see `skills/game-spec-module-contract.md`

**Extract:** save the block below as `gk.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
"""gk.py - game-authoring helpers shared by every game spec/content file. Forgotten Woods Studios.
Dialogue builders, standard boon/meta tables (renamed per game), enemy/boss builders with phase presets,
hub prop drawers, and hero title scenes. Keeps each game file focused on writing and art direction."""
import sys, math, random
sys.path.insert(0, "/home/claude/evac/_tools")
from PIL import Image, ImageDraw
from sprites import Pal, hexc, new, D, scale_up, mix, light, dark


# ------------------------------------------------------------------ dialogue helpers
def L(w, t, m=None, **kw):
    d = {"w": w, "t": t}
    if m:
        d["m"] = m
    d.update(kw)
    return d


def N(t, m=None, **kw):
    return L("", t, m, **kw)


def CMD(c, **kw):
    d = {"cmd": c}
    d.update(kw)
    return d


def CH(*choices, w="", t=""):
    return {"w": w, "t": t, "c": list(choices)}


def C(t, say=None, set=None, fx=None):
    d = {"t": t}
    if say:
        d["say"] = say
    if set:
        d["set"] = set
    if fx:
        d["fx"] = fx
    return d


def beat(id, trigger, scene, when=None, set=None, repeat=False):
    b = {"id": id, "trigger": trigger, "scene": scene}
    if when:
        b["when"] = when
    if set:
        b["set"] = set
    if repeat:
        b["repeat"] = True
    return b


def ev(id, scene, when=None):
    e = {"id": id, "scene": scene}
    if when:
        e["when"] = when
    return e


def speaker(name, color, sprite="", frames=2, hz=200, wave=1, ms=50, var=0.05):
    return {"name": name, "color": color, "sprite": sprite, "frames": frames, "blip": {"hz": hz, "wave": wave, "ms": ms, "var": var}}


def death_beats(add, lines):
    """lines: list of (id, deaths_needed, [scene lines]) -> adds death beats + generic fallback."""
    for did, n, sc in lines:
        add(beat(did, "death", sc, when={"deaths": n}))
    add(beat("d_generic", "death", [N("YOU WAKE.")], when={}, repeat=True))


# ------------------------------------------------------------------ boons / meta
# id: (rarity, max, stat, op, value, icon, template)
_BOON_BASE = {
    "dmg": ("common", 4, "damage", "mul", 0.2, 1, "DAMAGE +20%."),
    "rate": ("common", 3, "rate", "mul", 0.2, 2, "ATTACKS 20% FASTER."),
    "speed": ("common", 3, "speed", "mul", 0.1, 4, "MOVE 10% FASTER."),
    "hp": ("common", 3, "hp", "add", 2, 0, "+1 HEART."),
    "block": ("rare", 3, "block", "add", 0.12, 3, "12% CHANCE TO BLOCK A HIT."),
    "wind": ("rare", 2, "heal_now", "add", 3, 19, "HEAL 3 NOW. +1 HEART."),
    "drain": ("rare", 3, "lifesteal", "add", 0.12, 8, "12% CHANCE TO HEAL ON KILL."),
    "luck": ("rare", 2, "luck", "add", 1, 6, "RARER GIFTS APPEAR."),
    "crit": ("rare", 3, "crit", "add", 0.15, 13, "15% CHANCE FOR DOUBLE DAMAGE."),
    "dashcd": ("common", 3, "ability_cd", "mul", -0.3, 14, "ABILITY RECOVERS 30% FASTER."),
    "mem": ("common", 3, "mem_mul", "add", 0.25, 12, "EARN 25% MORE CURRENCY."),
    "knock": ("common", 2, "knock", "add", 100, 22, "HITS KNOCK ENEMIES FARTHER."),
    "regen": ("rare", 3, "regen", "add", 0.3, 11, "30% CHANCE TO HEAL ON ROOM CLEAR."),
    "reach": ("common", 3, "range", "add", 20, 5, "ATTACK REACHES 20 FARTHER."),
    "multi": ("rare", 2, "proj_count", "add", 1, 15, "+1 PROJECTILE."),
    "pierce": ("rare", 2, "pierce", "add", 1, 16, "SHOTS PIERCE +1 ENEMY."),
    "aoe": ("common", 3, "aoe_bonus", "add", 10, 17, "BLASTS 10 WIDER."),
    "res": ("common", 3, "light", "add", 0.4, 7, "LIGHT RADIUS WIDENS."),
    "resdrain": ("common", 2, "light_regen", "add", 0.35, 18, "LIGHT BURNS 35% SLOWER."),
    "epic_dmg": ("epic", 1, "damage", "mul", 0.6, 9, "DAMAGE +60%. LOSE 1 HEART."),
    "epic_hp": ("epic", 1, "hp", "add", 4, 20, "+2 HEARTS."),
}
_WEAPON_IDS = {
    "melee": ["reach"], "nova": ["reach"], "beam": ["reach"],
    "shoot": ["multi", "pierce"], "throw": ["aoe", "reach"],
}


def boons(weapon, lex, resource=None):
    """lex: id -> (NAME, optional desc override). Returns the boon list (~16-19)."""
    ids = ["dmg", "rate", "speed", "hp", "block", "wind", "drain", "luck", "crit", "dashcd", "mem", "knock", "regen", "epic_dmg", "epic_hp"]
    ids += _WEAPON_IDS.get(weapon, [])
    if resource == "light":
        ids += ["res", "resdrain"]
    out = []
    for i in ids:
        rar, mx, stat, op, val, icon, desc = _BOON_BASE[i]
        name, *rest = lex.get(i, (i.upper(),))
        if rest:
            desc = rest[0]
        b = {"id": i, "name": name, "desc": desc, "icon": icon, "rarity": rar, "max": mx, "effect": {"stat": stat, op: val}}
        if i == "epic_dmg":
            b["effect2"] = {"stat": "hp", "add": -2}
        if i == "wind":
            b["effect2"] = {"stat": "hp", "add": 2}
        out.append(b)
    return out


def meta(lex, currency="MEMORIES", weapon="melee", resource=None):
    base = [
        ("m_hp", "hp", "START WITH +1 HEART.", 30, 25, 4, "hp", "add", 2),
        ("m_dmg", "dmg", "DAMAGE +10%.", 25, 25, 5, "damage", "mul", 0.1),
        ("m_speed", "speed", "MOVE 5% FASTER.", 20, 20, 4, "speed", "mul", 0.05),
        ("m_cd", "cd", "ABILITY RECOVERS 8% FASTER.", 25, 20, 3, "ability_cd", "mul", -0.08),
        ("m_mem", "mem", "EARN 10%% MORE %s." % currency, 40, 30, 3, "mem_mul", "add", 0.1),
        ("m_luck", "luck", "RARER GIFTS APPEAR.", 60, 50, 2, "luck", "add", 1),
    ]
    if resource == "light":
        base.append(("m_light", "light", "LIGHT RADIUS WIDENS.", 35, 30, 3, "light", "add", 0.3))
    else:
        base.append(("m_reach", "reach", "ATTACK REACHES 8 FARTHER.", 35, 30, 3, "range", "add", 8))
    base.append(("m_regen", "regen", "10% CHANCE TO HEAL ON ROOM CLEAR.", 45, 35, 3, "regen", "add", 0.1))
    out = []
    for id_, key, desc, cost, step, mx, stat, op, val in base:
        out.append({"id": id_, "name": lex[key], "desc": desc, "cost": cost, "step": step, "max": mx, "effect": {"stat": stat, op: val}})
    return out


# ------------------------------------------------------------------ enemies / bosses
def E(name, ai, hp, speed, dmg=1, size=7, cost=3.0, mem=2, **kw):
    d = {"name": name, "hp": hp, "speed": speed, "damage": dmg, "ai": ai, "size": size, "cost": cost, "mem": mem}
    d.update(kw)
    return d


def phases(style, summon=("", ""), hp_scale=1.0):
    """Preset 3-phase attack scripts. summon = (enemy_id_a, enemy_id_b)."""
    a, b = summon
    S = {
        "gunner": [
            {"at": 1.0, "gap": 1.3, "patterns": [{"type": "aimed", "n": 3, "spread": 0.3, "speed": 90}, {"type": "ring", "n": 10, "speed": 60}] + ([{"type": "summon", "enemy": a, "n": 2}] if a else [])},
            {"at": 0.6, "gap": 1.0, "patterns": [{"type": "aimed", "n": 5, "spread": 0.25, "speed": 100}, {"type": "charge"}, {"type": "ring", "n": 14, "speed": 62}, {"type": "slam", "r": 56}]},
            {"at": 0.3, "gap": 0.8, "patterns": [{"type": "spiral", "dur": 3.0}, {"type": "aimed", "n": 5, "speed": 115}, {"type": "charge"}, {"type": "ring", "n": 18, "speed": 66}]}],
        "caster": [
            {"at": 1.0, "gap": 1.2, "patterns": [{"type": "rain", "dur": 3.0, "rate": 0.2}, {"type": "aimed", "n": 3, "speed": 85, "homing": 1.2}] + ([{"type": "summon", "enemy": a, "n": 3}] if a else [])},
            {"at": 0.6, "gap": 1.0, "patterns": [{"type": "ring", "n": 16, "speed": 58}, {"type": "teleport"}, {"type": "aimed", "n": 5, "speed": 95, "homing": 1.5}, {"type": "slam", "r": 62}]},
            {"at": 0.3, "gap": 0.8, "patterns": [{"type": "spiral", "dur": 3.5, "turn": 2.8}, {"type": "rain", "dur": 3.0, "rate": 0.14}, {"type": "teleport"}, {"type": "ring", "n": 20, "speed": 64}]}],
        "brute": [
            {"at": 1.0, "gap": 1.4, "patterns": [{"type": "charge"}, {"type": "slam", "r": 60}, {"type": "aimed", "n": 3, "speed": 80}] + ([{"type": "summon", "enemy": a, "n": 2}] if a else [])},
            {"at": 0.6, "gap": 1.1, "patterns": [{"type": "charge"}, {"type": "slam", "r": 70}, {"type": "ring", "n": 14, "speed": 60}, {"type": "charge"}]},
            {"at": 0.3, "gap": 0.9, "patterns": [{"type": "charge"}, {"type": "slam", "r": 76}, {"type": "ring", "n": 20, "speed": 66}, {"type": "spiral", "dur": 3.0}]}],
        "swarm": [
            {"at": 1.0, "gap": 1.4, "patterns": [{"type": "ring", "n": 14, "speed": 55}, {"type": "aimed", "n": 5, "speed": 85}] + ([{"type": "summon", "enemy": a, "n": 3}] if a else []) + [{"type": "slam", "r": 70}]},
            {"at": 0.6, "gap": 1.1, "patterns": [{"type": "rain", "dur": 3.5, "rate": 0.14}, {"type": "ring", "n": 18, "speed": 60}] + ([{"type": "summon", "enemy": b or a, "n": 2}] if (b or a) else []) + [{"type": "spiral", "dur": 3.0}]},
            {"at": 0.3, "gap": 0.9, "patterns": [{"type": "spiral", "dur": 4.0, "rate": 0.09}, {"type": "slam", "r": 76}, {"type": "ring", "n": 22, "speed": 66}, {"type": "rain", "dur": 3.0, "rate": 0.1}]}],
        "trickster": [
            {"at": 1.0, "gap": 1.0, "patterns": [{"type": "aimed", "n": 3, "speed": 105, "homing": 1.0}, {"type": "teleport"}, {"type": "ring", "n": 12, "speed": 65}, {"type": "charge"}]},
            {"at": 0.65, "gap": 0.8, "patterns": [{"type": "spiral", "dur": 3.0}, {"type": "teleport"}, {"type": "aimed", "n": 5, "speed": 115}, {"type": "rain", "dur": 3.0, "rate": 0.14}, {"type": "slam", "r": 62}]},
            {"at": 0.3, "gap": 0.65, "patterns": [{"type": "ring", "n": 22, "speed": 70}, {"type": "teleport"}, {"type": "spiral", "dur": 3.5, "rate": 0.09, "turn": 3.0}, {"type": "charge"}, {"type": "aimed", "n": 7, "speed": 120, "spread": 0.2}]}],
    }
    return S[style]


def BOSS(name, title, hp, style, size=12, speed=28, mem=30, keep=75, summon=("", ""), lines=None, music="boss", **kw):
    """lines: [[phase2 lines], [phase3 lines]] each a list of dialogue dicts"""
    d = {"name": name, "title": title, "hp": hp, "speed": speed, "size": size, "damage": 1, "mem": mem, "keep": keep, "music": music,
         "phases": phases(style, summon)}
    if lines:
        d["phase_lines"] = lines
    d.update(kw)
    return d


# ------------------------------------------------------------------ hub props (shrine / archive sprites)
def prop_shrine(kind, c1, c2, glow):
    """returns fn() -> 2 frames (20x34)."""
    def make():
        out = []
        for f in range(2):
            im = new(20, 34)
            d = D(im)
            o = hexc("#0b0a10")
            if kind == "lamp":
                d.rectangle((6, 22, 13, 32), fill=hexc(c2), outline=o)
                d.rectangle((3, 30, 16, 33), fill=hexc(c1), outline=o)
                d.rectangle((4, 8, 15, 22), fill=hexc(c1), outline=o)
                d.rectangle((6, 10, 13, 20), fill=hexc(glow) if f == 0 else light(hexc(glow), 0.2))
                d.polygon([(3, 8), (10, 1), (16, 8)], fill=hexc(c2), outline=o)
            elif kind == "altar":
                d.rectangle((2, 20, 17, 32), fill=hexc(c1), outline=o)
                d.rectangle((0, 30, 19, 33), fill=hexc(c2), outline=o)
                d.rectangle((5, 12, 14, 20), fill=hexc(c2), outline=o)
                d.rectangle((9, 4 + f, 10, 12), fill=hexc("#f0e6c0"))
                d.rectangle((8, 2 + f, 11, 5 + f), fill=hexc(glow))
            elif kind == "brazier":
                d.polygon([(3, 18), (16, 18), (13, 30), (6, 30)], fill=hexc(c1), outline=o)
                d.rectangle((8, 30, 11, 33), fill=hexc(c2), outline=o)
                d.polygon([(5, 18), (10, 4 + f * 2), (15, 18)], fill=hexc(glow))
                d.polygon([(8, 18), (10, 9 + f), (12, 18)], fill=light(hexc(glow), 0.5))
            elif kind == "crystal":
                d.polygon([(10, 2), (16, 14), (13, 30), (7, 30), (4, 14)], fill=hexc(c1), outline=o)
                d.polygon([(10, 4), (14, 14), (11, 28), (10, 28)], fill=hexc(glow) if f == 0 else light(hexc(glow), 0.3))
                d.rectangle((3, 30, 16, 33), fill=hexc(c2), outline=o)
            elif kind == "tv":
                d.rectangle((2, 8, 17, 26), fill=hexc(c2), outline=o)
                d.rectangle((4, 10, 15, 24), fill=hexc(glow) if f == 0 else light(hexc(glow), 0.25))
                d.line((6, 8, 3, 2), fill=hexc(c1))
                d.line((13, 8, 16, 2), fill=hexc(c1))
                d.rectangle((6, 26, 13, 32), fill=hexc(c1), outline=o)
            elif kind == "chest":
                d.rectangle((1, 16, 18, 31), fill=hexc(c1), outline=o)
                d.rectangle((0, 12, 19, 18), fill=hexc(c2), outline=o)
                d.rectangle((8, 16, 11, 21), fill=hexc("#e8d080"), outline=o)
                d.point((5 + f * 8, 8 - f), fill=hexc(glow))
                d.point((12 - f * 6, 5 + f), fill=hexc(glow))
                d.point((9, 2 + f * 2), fill=hexc("#ffffff"))
            elif kind == "bell":
                d.polygon([(5, 10), (14, 10), (17, 26), (2, 26)], fill=hexc(c1), outline=o)
                d.rectangle((9, 4, 10, 10), fill=hexc(c2))
                d.rectangle((8 + f, 26, 11 + f, 30), fill=hexc(c2), outline=o)
                d.rectangle((1, 30, 18, 33), fill=hexc(c2), outline=o)
            im.alpha_composite(im) if False else None
            out.append(im)
        return out
    return make


def prop_archive(kind, c1, c2):
    def make():
        im = new(16, 18)
        d = D(im)
        o = hexc("#0b0a10")
        if kind == "book":
            d.rectangle((6, 10, 9, 17), fill=hexc(c2), outline=o)
            d.rectangle((1, 5, 14, 11), fill=hexc(c1), outline=o)
            d.rectangle((2, 6, 13, 10), fill=hexc("#e8dcb8"))
            d.line((8, 6, 8, 10), fill=hexc("#8a7a58"))
        elif kind == "tape":
            d.rectangle((2, 5, 13, 15), fill=hexc(c1), outline=o)
            d.ellipse((4, 7, 7, 10), fill=hexc("#e8e8e8"), outline=o)
            d.ellipse((8, 7, 11, 10), fill=hexc("#e8e8e8"), outline=o)
            d.rectangle((4, 12, 11, 14), fill=hexc(c2))
        elif kind == "files":
            d.rectangle((2, 4, 13, 16), fill=hexc(c1), outline=o)
            for y in (6, 9, 12):
                d.line((3, y, 12, y), fill=hexc(c2))
            d.rectangle((6, 2, 9, 4), fill=hexc(c2), outline=o)
        elif kind == "jar":
            d.rectangle((4, 4, 11, 16), fill=hexc(c1), outline=o)
            d.rectangle((5, 2, 10, 4), fill=hexc(c2), outline=o)
            d.rectangle((5, 8, 10, 15), fill=hexc(c2))
        return [im]
    return make


# ------------------------------------------------------------------ hero title scenes
def title_scene_factory(kind, c1="#1a2430", c2="#0c1016", glow="#ffcf6b", seed=5, enemies=("enemy_a", "enemy_b", "enemy_c"), player_x=60, dy=0):
    """returns title_scene(img, d, sheets, W, H). kinds: house, tower, hall, church, field, road, tent, cave, water"""
    def scene(img, d, sheets, W, H):
        rng = random.Random(seed)
        for _ in range(70):
            x, y = rng.randint(0, W - 1), rng.randint(0, int(H * 0.6))
            d.point((x, y), fill=rng.choice([(120, 140, 170, 255), (200, 210, 230, 255), (80, 100, 130, 255)]))
        ground = hexc(c2)
        mid, hi = hexc(c1), mix(hexc(c1), (255, 255, 255, 255), 0.12)
        gl = hexc(glow)
        cx = 292
        d.rectangle((0, int(H * 0.8), W, H), fill=ground)
        lay = Image.new('RGBA', (W, H), (0, 0, 0, 0))
        d2 = ImageDraw.Draw(lay)
        if kind == "house":
            d2.polygon([(cx - 56, 150), (cx - 56, 90), (cx, 56), (cx + 56, 90), (cx + 56, 150)], fill=mid)
            d2.rectangle((cx - 56, 90, cx + 56, 150), fill=mid)
            d2.polygon([(cx - 62, 92), (cx, 52), (cx + 62, 92)], fill=hi)
            for wx in (cx - 40, cx - 14, cx + 18, cx + 42):
                for wy in (100, 124):
                    d2.rectangle((wx - 5, wy, wx + 5, wy + 12), fill=gl if rng.random() < 0.3 else ground)
            d2.rectangle((cx - 7, 130, cx + 7, 150), fill=ground)
            d2.rectangle((cx - 4, 60, cx + 4, 72), fill=gl)
        elif kind == "tower":
            d2.polygon([(cx - 14, 150), (cx - 9, 58), (cx + 9, 58), (cx + 14, 150)], fill=mid)
            d2.rectangle((cx - 12, 46, cx + 12, 58), fill=hi)
            d2.polygon([(cx - 14, 46), (cx, 30), (cx + 14, 46)], fill=hi)
            d2.rectangle((cx - 4, 50, cx + 4, 56), fill=gl)
            d2.polygon([(cx - 60, 150), (cx - 30, 134), (cx + 36, 140), (cx + 70, 150)], fill=mid)
        elif kind == "hall":
            d2.rectangle((cx - 70, 80, cx + 70, 150), fill=mid)
            d2.rectangle((cx - 70, 74, cx + 70, 80), fill=hi)
            for wx in range(cx - 60, cx + 61, 20):
                d2.rectangle((wx - 4, 94, wx + 4, 116), fill=gl if rng.random() < 0.35 else ground)
            d2.rectangle((cx - 8, 124, cx + 8, 150), fill=ground)
            d2.rectangle((cx + 40, 40, cx + 52, 74), fill=mid)
        elif kind == "church":
            d2.rectangle((cx - 40, 96, cx + 40, 150), fill=mid)
            d2.polygon([(cx - 44, 96), (cx, 66), (cx + 44, 96)], fill=hi)
            d2.rectangle((cx - 8, 40, cx + 8, 96), fill=mid)
            d2.polygon([(cx - 10, 40), (cx, 20), (cx + 10, 40)], fill=hi)
            d2.line((cx, 8, cx, 22), fill=hi)
            d2.line((cx - 4, 13, cx + 4, 13), fill=hi)
            d2.ellipse((cx - 10, 108, cx + 10, 128), fill=gl)
            d2.rectangle((cx - 6, 130, cx + 6, 150), fill=ground)
        elif kind == "field":
            for i in range(0, W, 5):
                h = rng.randint(14, 40)
                d2.line((i, int(H * 0.8), i + rng.randint(-2, 2), int(H * 0.8) - h), fill=mid)
            d2.rectangle((cx - 4, 86, cx + 4, 150), fill=hi)
            d2.line((cx - 30, 100, cx + 30, 100), fill=hi)
            d2.ellipse((cx - 8, 80, cx + 8, 96), fill=mid)
            d2.rectangle((cx - 3, 87, cx - 1, 89), fill=gl)
            d2.rectangle((cx + 1, 87, cx + 3, 89), fill=gl)
        elif kind == "road":
            d2.polygon([(cx - 90, H), (cx - 4, 120), (cx + 4, 120), (cx + 90, H)], fill=mid)
            for k in range(5):
                y = 128 + k * 16
                d2.rectangle((cx - 1, y, cx + 1, y + 6), fill=gl)
            d2.rectangle((cx - 40, 76, cx + 40, 108), fill=hi)
            d2.rectangle((cx - 34, 82, cx - 8, 96), fill=gl)
            d2.rectangle((cx + 8, 82, cx + 34, 96), fill=gl)
            d2.ellipse((cx - 36, 104, cx - 26, 114), fill=ground)
            d2.ellipse((cx + 26, 104, cx + 36, 114), fill=ground)
        elif kind == "tent":
            d2.polygon([(cx - 60, 150), (cx, 70), (cx + 60, 150)], fill=mid)
            for i in range(-60, 61, 20):
                d2.polygon([(cx + i, 150), (cx + i + 10, 150), (cx, 70)], fill=hi)
            d2.line((cx, 70, cx, 50), fill=hi)
            d2.polygon([(cx, 50), (cx + 14, 55), (cx, 60)], fill=gl)
            d2.polygon([(cx - 14, 150), (cx, 118), (cx + 14, 150)], fill=ground)
        elif kind == "cave":
            d2.polygon([(cx - 90, 150), (cx - 60, 90), (cx - 20, 64), (cx + 30, 70), (cx + 70, 100), (cx + 90, 150)], fill=mid)
            d2.polygon([(cx - 26, 150), (cx - 18, 108), (cx + 4, 98), (cx + 24, 112), (cx + 30, 150)], fill=ground)
            for i in range(6):
                x = cx - 20 + i * 8
                d2.polygon([(x, 98 + (i % 2)), (x + 3, 98), (x + 1, 108 + (i % 3) * 3)], fill=hi)
            d2.rectangle((cx - 2, 126, cx + 2, 130), fill=gl)
        else:  # water
            d2.polygon([(cx - 70, 150), (cx - 40, 120), (cx + 40, 118), (cx + 70, 150)], fill=mid)
            d2.rectangle((cx - 4, 70, cx + 4, 120), fill=hi)
            d2.rectangle((cx - 4, 64, cx + 4, 70), fill=gl)
        img.alpha_composite(lay, (0, dy))
        # glow halo
        glo = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        gd = ImageDraw.Draw(glo)
        pl = scale_up(sheets["player"][0], 4)
        img.alpha_composite(pl, (player_x, H - pl.height - 6))
        gx, gy = player_x + int(pl.width * 0.85), H - int(pl.height * 0.5) - 6
        for r in range(60, 4, -3):
            gd.ellipse((gx - r, gy - r, gx + r, gy + r), fill=(*gl[:3], int(2 + (60 - r) * 0.45)))
        img.alpha_composite(glo)
        for i, name in enumerate(enemies):
            if name not in sheets:
                continue
            fr = scale_up(sheets[name][0], 2)
            fr = fr.point(lambda v: int(v * 0.4) if v < 250 else v)
            img.alpha_composite(fr, (222 + i * 26, H - fr.height - 8 - (i % 2) * 5))
    return scene


# ------------------------------------------------------------------ game assembly
DEFAULT_TEXT = {
    "controls_hint": "WASD: MOVE   ARROWS OR MOUSE: ATTACK   SPACE: ABILITY",
    "room_clear": "ROOM CLEAR.", "dark_bites": "THE DARK BITES.", "death_title": "YOU FALL",
    "boon_title": "CHOOSE A GIFT", "boon_sub": "CHOOSE ONE", "inspect": "[E] INSPECT",
    "hub_hint": "WALK TO THINGS AND PRESS [E].", "descend": "DESCEND", "fragment_found": "ARCHIVE",
    "abandon": "GIVE UP THE RUN", "stat_floor": "FLOOR", "stat_kills": "SLAIN", "new_game": "NEW GAME", "continue": "CONTINUE",
}


def make_game(**kw):
    g = {"version": "1.0.0", "fx": {"vignette": 0.4, "grain": 0.05, "tint": [1.0, 1.0, 1.0]},
         "dread_names": ["THE FIRST NIGHT", "DREAD I", "DREAD II", "DREAD III", "DREAD IV", "DREAD V"]}
    g.update(kw)
    t = dict(DEFAULT_TEXT)
    t.update(kw.get("text", {}))
    g["text"] = t
    return g
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
