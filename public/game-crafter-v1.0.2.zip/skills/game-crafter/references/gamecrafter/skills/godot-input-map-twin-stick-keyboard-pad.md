---
id: godot-input-map-twin-stick-keyboard-pad
title: "Input map for twin-stick roguelike (keyboard, mouse, gamepad)"
category: godot-engine
when: "Defining input actions in project.godot for a top-down action game."
related: []
origin: Roguelike series
---

# Input map for twin-stick roguelike (keyboard, mouse, gamepad)

**When to use:** Defining input actions in project.godot for a top-down action game.

## Do this

- Actions: move_left/right/up/down = WASD physical keys (65,68,87,83) + joypad axis 0/1; aim_left/right/up/down = arrow keys (4194319,4194321,4194320,4194322) + right stick axes 2/3; attack = mouse button 1 + J (74) + right trigger axis 5; ability = Space (32) + mouse button 2 + pad button 0; interact = E (69) + Enter (4194309) + pad button 3; confirm = pad button 0; pause = Esc (4194305) + pad button 6 (Start). Deadzone 0.3.
- Use `physical_keycode` so layouts (AZERTY) still map by position.
- Menus accept move_* AND ui_* AND interact/ui_accept/confirm so keyboard, pad and arrows all navigate.
- F11 toggles fullscreen globally in boot.gd `_unhandled_input` (keycode KEY_F11).

## Pitfalls (mistakes seen)

none recorded.

## Verify

play with pad and keyboard; menus respond to both.

## Origin

Roguelike series. Source notes: kit/project.godot [input]; boot.gd _unhandled_input; menus.gd _process.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
