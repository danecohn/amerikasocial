---
id: mistake-music-stays-ducked
title: "Music stayed ducked after call cut by death/scene change"
category: mistake
when: "Audio ducking."
related: []
origin: FNAP
---

# Music stayed ducked after call cut by death/scene change

**When to use:** Audio ducking.

## Do this

`reset_ducks()` in `stop_all_loops()` and `_exit_tree`.

## What happened, root cause, fix, prevention

Symptom: music quiet forever after a death mid-call. Root cause: duck released only on normal call end. Fix: reset on every stop path. Detection: audio_check script.

## Verify

Bus volume restored after interrupt test.

## Origin

FNAP. Source notes: mistakes-log.md M17; BOARD.md line 25.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
