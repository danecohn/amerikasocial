---
id: fnaf-night-config-dict
title: "One office scene, many nights: drive everything from a config dictionary"
category: gameplay-systems
when: "Implementing nights, custom night, challenge modes or a roguelite mode on top of one office scene."
related: []
origin: FNAP
---

# One office scene, many nights: drive everything from a config dictionary

**When to use:** Implementing nights, custom night, challenge modes or a roguelite mode on top of one office scene.

## Do this

- `OfficeController._ready` builds `config = BrineRun.shift_config() if BrineRun.in_shift else _story_config()` then
  `_apply_config()`. One scene serves story nights AND roguelite shifts.
- Story night shape (sketch from REF §2.2):
  ```gdscript
  func _story_config() -> Dictionary:
      var n := GameState.night
      return {
          "title": "Night %d" % n, "night": n,
          "hours": 6,
          "seconds_per_hour": float(GameState.cli.get("hour", 86)),   # --fnap-hour=<sec>
          "levels": {"pickle": ai("pickle"), "remi": ai("remi"), ...},  # GameState.ai_for(id)
          "power_max": 100.0,
          "drain_multiplier": 1.0 + 0.08 * (n - 1),
          "phone": n <= 5,
          "music_track": ...,
      }
  ```
- Roguelite shift returns the SAME shape (hours 3, 70 s/hour, deck modifiers applied).
- Optional keys the office honours: `stamina_multiplier, door_speed, auto_close, door_cams, flicker_cams, banshee_speed,
  assistant_fail_delta, assistant_speed, assistant_hallucinate, dark_office, golden_forced, music`.
- Order of `_ready` (copy it): seed rng -> pick config -> `_build_environment()` -> `LevelBuilder.build()` ->
  `_build_systems()` (Power, Stamina, NightClock, OfficeLook, HUD, CameraMonitor, PhoneCall, DebugOverlay, Jumpscare as
  child nodes, signals wired) -> `_wire_office()` (find nodes by name, adopt door rigs, clickable areas) ->
  `_spawn_animatronics()` -> `_build_assistant()` -> `_apply_config()` -> `_start_night()`.

## Pitfalls (mistakes seen)

none recorded; the pattern avoided a second office scene for the bonus mode.

## Verify

Boot `--fnap-night=N` for N=1..6 and a roguelite shift; debug overlay shows the expected AI levels/drain.

## Origin

FNAP. Source notes: REF §2.2, §1.5, §2.14.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
