---
id: glb-json-chunk-diff
title: "Diff a GLB's JSON chunk before/after re-export"
category: 3d-blender
when: "Re-exporting any existing GLB that code depends on."
related: []
origin: FNAP
---

# Diff a GLB's JSON chunk before/after re-export

**When to use:** Re-exporting any existing GLB that code depends on.

## Do this

GLB = 12-byte header (magic `glTF`, version, length) then chunk (uint32 length, uint32 type `JSON`) containing JSON. Read with python: `struct.unpack('<III', f.read(12)); clen, ctype = struct.unpack('<II', f.read(8)); j = json.loads(f.read(clen))`; compare `nodes[].name`, `extensions.KHR_lights_punctual.lights[].intensity`, cameras. (Technique named in source; snippet is the standard GLB layout.)

## Pitfalls (mistakes seen)

Lost nodes/changed light energies after re-export.

## Verify

Diff shows no missing contract names.

## Origin

FNAP. Source notes: blender-assets/SKILL.md bullet "Re-exporting a GLB".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
