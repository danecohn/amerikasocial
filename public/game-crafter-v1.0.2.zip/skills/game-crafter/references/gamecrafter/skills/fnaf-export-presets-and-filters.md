---
id: fnaf-export-presets-and-filters
title: "Four-platform export presets with include/exclude filters for data-driven games"
category: export-release
when: "Exporting a Godot game that loads JSON/CSV/TXT/raw audio/frames at runtime."
related: [mistake-data-files-not-exported, mistake-splash-video-missing-from-pck]
origin: FNAP
---

# Four-platform export presets with include/exclude filters for data-driven games

**When to use:** Exporting a Godot game that loads JSON/CSV/TXT/raw audio/frames at runtime.

## Do this

- `export_filter="all_resources"`; `include_filter="*.json, *.csv, *.txt, *.cues, assets/audio/voice/*,
  assets/assistant_face/*, assets/branding/*"`; `exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log,
  assets/phone-scripts/original/*, assets/phone-scripts/extra/*"` (dev .tscn under scripts/dev are therefore not
  shippable).
- `script_export_mode=2` (binary tokens), `encrypt_pck=false`, `binary_format/embed_pck=true`.
- Windows x86_64: `application/modify_resources=true` (icon, company, product, `file_version=1.0.0.0`, copyright; needs
  `rcedit`, may be unavailable in Linux containers), `export_console_wrapper=1`, `texture_format/s3tc_bptc=true`.
- macOS: `architecture="universal"`, bundle id `com.<studio>.<game>`, `min_macos_version 11.00`, category Games, no
  codesign; output `.zip` containing the `.app`; requires VRAM s3tc_bptc or etc2_astc in project settings.
- Linux x86_64 `.x86_64`. Windows ARM64 = its own preset (`binary_format/architecture="arm64"`) + ARM64 templates.
- Commands: `godot --headless --path <proj> --import --quit`; `godot --headless --path <proj> --export-release
  "Windows Desktop" out/<Game>.exe` (and "Linux", "macOS" -> `-mac.zip`, "Windows ARM64"). Templates at
  `~/.local/share/godot/export_templates/<ver>.stable` must match the editor exactly.
- Export-safe directory scans (quoted):
  ```gdscript
  ## In an exported build res:// lists "office.glb.import" / "office.glb.remap" instead of "office.glb".
  static func packed_name(file: String) -> String:
  	if file.ends_with(".import") or file.ends_with(".remap"):
  		return file.get_basename()
  	return file
  ```
- Size reality: models ~606 MB (rooms 394 MB), audio ~95 MB; zips 0.4-0.8 GB (PCK compresses JPG/PNG poorly); JPG for big
  room surfaces to cut size.

## Pitfalls (mistakes seen)

mistake-data-files-not-exported; mistake-splash-video-missing-from-pck.

## Verify

Run the exported build with a screenshot flag; confirm voice/face/phone subtitles work from the PCK.

## Origin

FNAP. Source notes: REF §4.1, §4.2, §3.3, §3.4, §8.1 A, §1.1.

## Related skills

- [mistake-data-files-not-exported](mistake-data-files-not-exported.md)
- [mistake-splash-video-missing-from-pck](mistake-splash-video-missing-from-pck.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
