---
id: extras-character-viewer
title: "Extras gallery: rotate through the real 3D characters with descriptions that teach mechanics"
category: ui-ux
when: "Adding an extras/bestiary screen."
related: []
origin: Pickle's Pickle Shop
---

# Extras gallery: rotate through the real 3D characters with descriptions that teach mechanics

**When to use:** Adding an extras/bestiary screen.

## Do this

SubViewportContainer with its own stage; instance an `Animatronic` per entry and play its showcase clip (`play_showcase()` falls back to idle). Descriptions double as tutorials ("He only moves when nobody is looking. He comes down the east hall to the right door."; "If it is in the office, lift the monitor."). Debug overlay (F-key action) prints controller `debug_text()` every 0.2 s: power, usage, stamina, torch, music bar/beat, each character's AI level/room/aggression/banging/cove state, FPS, monitor cam, location.

## Origin

Pickle's Pickle Shop. Source notes: scripts/ui/extras.gd L1-25; debug_overlay.gd; office_controller.gd debug_text.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
