# Tool: model_loader.gd

**Purpose:** Export-safe GLB loading with a LOUD placeholder fallback.

**Usage:** `ModelLoader.load_model(path)`

**Skill:** see `skills/loud-placeholders.md`

**Extract:** save the block below as `model_loader.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
class_name ModelLoader
extends RefCounted
## Game Maker template. Load a model by name from SEARCH_DIRS.
## Order: (1) res:// via load() so it works in editor AND exported builds,
##        (2) fallback: read a loose .glb from disk with GLTFDocument (hot-drop assets without reimport; dev only).
## NEVER use FileAccess.file_exists()/globalize_path() on res:// assets as the primary path: in an export the
## raw .glb is not in the PCK, those checks fail, and the game silently falls back to placeholders.
const SEARCH_DIRS: Array[String] = [
	"res://assets/models/characters",
	"res://assets/models/environment",
	"res://assets/models/props",
]
const LIVE_DIRS: Array[String] = []   # optional absolute folders for live-dev (e.g. "/workspace/game/models")

static func load_named(stems: Array) -> Node3D:
	for dir in SEARCH_DIRS:
		var path := NodeFinder.find_resource_file(dir, stems)
		if path == "":
			continue
		var packed := load(path) as PackedScene
		if packed:
			var inst := packed.instantiate() as Node3D
			AnimImport.apply_loops(inst)
			return inst
		push_warning("ModelLoader: %s exists but did not load as PackedScene (import failed?)" % path)
	for dir in LIVE_DIRS:
		var f := _find_in_dir(dir, stems)
		if f != "":
			return load_external_glb(f)
	push_warning("ModelLoader: no model for %s - caller should fall back LOUDLY, never silently" % [stems])
	return null

static func load_external_glb(path: String) -> Node3D:
	var doc := GLTFDocument.new()
	var state := GLTFState.new()
	var err := doc.append_from_file(path, state)
	if err != OK:
		push_warning("ModelLoader: could not read %s (%s)" % [path, error_string(err)])
		return null
	var scene := doc.generate_scene(state) as Node3D
	AnimImport.apply_loops(scene)
	return scene

static func _find_in_dir(dir: String, stems: Array) -> String:
	var wanted: Array[String] = []
	for s in stems:
		wanted.append(NodeFinder.normalize(str(s)))
	var da := DirAccess.open(dir)
	if da == null:
		return ""
	for raw in da.get_files():
		var file := NodeFinder.packed_name(raw)   # harmless for loose disk folders, required if this ever scans res://
		var ext := file.get_extension().to_lower()
		if (ext == "glb" or ext == "gltf") and wanted.has(NodeFinder.normalize(file.get_basename())):
			return dir.path_join(file)
	return ""
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
