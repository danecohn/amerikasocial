---
id: auto-manifest-with-hashes
title: "Auto-generated MANIFEST.md: verified / NOT verified / file table with sizes and hashes"
category: project-management
when: "Finishing any deliverable folder."
related: [mistake-templated-verification-claims]
origin: Roguelike series
---

# Auto-generated MANIFEST.md: verified / NOT verified / file table with sizes and hashes

**When to use:** Finishing any deliverable folder.

## Do this

- Header: `# MANIFEST - <TITLE>` / `Studio: ... | Built <date> | Engine Godot <ver> | Version 1.0.0`.
- `## Verified` (only what was actually run: autoplay full run, probe fails=0 with count, export lint 0 errors, Linux export launched under virtual display showing real art `WIRING missing_art=0`, screenshots are real captures native 384x216 nearest x5 to 1920x1080).
- `## NOT verified (be aware)`: platforms exported but not launched (Windows x64/ARM64, macOS - "the same pack runs on all four; only the platform runtime differs"), unsigned binaries and how to open them, split zips need ASSEMBLE_ZIPS.bat, beepbox.co unreachable provenance, no gamepad, nothing uploaded/published.
- `## Files` table: walk the output dir, `| relpath | bytes | sha256[:16] |`, sorted, excluding MANIFEST.md itself.
- Stage to outputs: `shutil.rmtree(dst); shutil.copytree(OUT, dst)`; print file count and MB.

## Pitfalls (mistakes seen)

the Verified section is a hard-coded string in finish.py, identical for all 4 games, including a wrong resource count - see mistake-templated-verification-claims.

## Verify

recompute one hash from the table; counts in Verified match logs.

## Origin

Roguelike series. Source notes: _tools/finish.py L23-53; all four MANIFEST.md.

## Related skills

- [mistake-templated-verification-claims](mistake-templated-verification-claims.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
