---
id: godot-music-crossfade-and-sfx-pool
title: "AudioKit: two-player music crossfade + 10-voice SFX pool (GDScript)"
category: godot-engine
when: "Building the audio layer of a Godot 4 game."
related: []
origin: Roguelike series
---

# AudioKit: two-player music crossfade + 10-voice SFX pool (GDScript)

**When to use:** Building the audio layer of a Godot 4 game.

## Do this

- Node with `process_mode = PROCESS_MODE_ALWAYS` (music keeps playing in pause menus), two AudioStreamPlayers A/B for music and 10 for SFX; created in `_ready()` by code.
- `play_music(name, fade := 1.2)`: ignore if same track; "" = stop; load `res://assets/audio/music/%s.ogg`; set `loop` on AudioStreamOggVorbis except stings; new player starts at -60 dB and tweens to `linear_to_db(max(0.0001, music_vol))` while old tweens to -60 then stops (parallel tween, `chain().tween_callback(old.stop)`); kill previous tween first.
- `play_sfx(name, vol, pitch)`: first non-playing pool voice; pitch jitter `* rng.randf_range(0.96, 1.04)` so repeats do not sound robotic.
- Cache streams in a Dictionary; missing file -> `push_warning` + `print("PLACEHOLDER missing audio: ...")` so automated logs catch it (instead of silent failure).
- Skip playing when `DisplayServer.get_name() == "headless"` (no audio device in CI; avoids errors/spam).
- Volumes stored linear 0..1, converted with `linear_to_db(maxf(0.0001, v))` (never pass 0).
- Instantiated by the Game autoload (`audio = AudioKit.new()`), not a separate autoload.

## Pitfalls (mistakes seen)

none recorded.

## Verify

grep logs for "PLACEHOLDER missing audio" = 0; switching floors crossfades.

## Origin

Roguelike series. Source notes: kit/kit/audio_kit.gd L1-95; kit/kit/game.gd L14-47.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
