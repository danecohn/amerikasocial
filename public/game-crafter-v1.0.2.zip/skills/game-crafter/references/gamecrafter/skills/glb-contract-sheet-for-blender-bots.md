---
id: glb-contract-sheet-for-blender-bots
title: "Writing a Blender-team request with exact paths, origins, sizes, sockets, clip names and budgets"
category: 3d-blender
when: "Commissioning 3D assets from another agent/tool (Cursor+Blender, a Blender subagent) for a Godot game."
related: []
origin: Caesarea
---

# Writing a Blender-team request with exact paths, origins, sizes, sockets, clip names and budgets

**When to use:** Commissioning 3D assets from another agent/tool (Cursor+Blender, a Blender subagent) for a Godot game.

## Do this

- Header rules: original assets only (no rips); GLB glTF 2.0 +Y up; Blender -Y front → Godot +Z front; never rotate to fix facing; exact path per file; one GLB per path; never delete/replace another bot's GLB; keep .blend in `art_source/`; don't touch `design/`, `game/`, `tests/`, `.godot/`; verify with `godot --headless --import` 0 errors; measured AABB within 5%.
- Team split example (23 bots): street kit (1-3), wasteland architecture (4-6), settlement props (7-8), scatter (9-10), humanoids (11-12), creatures (13-14), armed enemies (15-16), weapons (17-18), hero wrist-computer asset (19), animation (20-21), textures/UV/AABB QA (22), integrator who runs import + tests and owns the manifest (23).
- Contract rows: `CAE_Arch_SuburaInsula_Facade.glb corner 8x13x3`, `..._Corner 3x13x3`, `CAE_Arch_RomaPaving_Tile corner 4x0.2x4 top y=0`, `RomaCurb 4x0.15x0.6`, `PortaSubura_Gate 12x9x2 opening x 2..10 SOCKET_Barrier`, `CheckpointBarrier hinge arm +X 7.6x0.12x0.16`, `GuardBooth base_center 2.5x2.8x2.5`, `VoxSpeaker 0.28x4.0x0.28 SOCKET_Speaker`, `ArgusCamera wall mount +Z 0.28x0.22x0.46`, `StreetLamp 0.28x4.5x0.28 SOCKET_Light`, `ForumArch corner 14x16x6`; wasteland buildings corner (RuralHouse 6x4x5, Villa 22x7x16, Watchtower 4x11x4, WallSegment 8x5x1 tiles end to end, FortGate 10x7x2 opening centered 4 m); props base_center (Windmill 6x14x6 with separate `Blades` node for rotation; Campfire with SOCKET_Light).
- Scatter: one mesh, one material, < 600 tris so the game can MultiMesh thousands. Humanoids: 56-bone proxy rig, LOD0 < 12k tris, height 1.8 m. Creatures: own rigs + listed clips (Idle, Walk, Run, Attack_*, Hit, Death). Weapons: origin at the grip. Clip names `CAE_Anim_*`.
- Delivery order follows the New Game path: street + civilians first, then settlements, combat, the story-beat hero asset early, scatter last.
- QA bot writes `glb_report.md`: measured scene AABB from glTF POSITION accessor min/max transformed by nodes (no Blender needed); "A file not on disk is missing, not a failure"; compare SHA-256 across trees; list sockets found and translations; report trims embedded vs referenced.
- Integrator: "If a test fails because a GLB's AABB mismatches, report the path and measured vs expected; do not weaken the contract."

## Pitfalls (mistakes seen)

A GLB's hinge cap exceeded contract by 0.042 m → test fail; fixed in source .blend. Character name mismatch (`CAE_Char_Legionary_LOD0_skinned.glb` in `assets/characters` vs contract `assets/chars/CAE_Char_Legionary.glb`) left two folders (`characters/` vs `chars/`) — pick one folder name in the contract and stick to it. Civic GLBs embedded 5 trim sheets each (7-15 MB per building) instead of referencing the shared trim folder — specify "reference trims by URI / share materials" if size matters.

## Verify

glb_report pass table; godot import exit 0; AABB tests pass.

## Origin

Caesarea. Source notes: docs/handoff/CURSOR_MODEL_REQUEST.md, glb_report.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
