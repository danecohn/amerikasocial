---
id: automated-demo-player-bot
title: "Built-in automated demo/test player that plays a full roguelike run to the ending"
category: testing-qa
when: "You need to prove a whole game is winnable/crash-free in a headless cloud box, capture gameplay screenshots/footage, or regression-test after a kit change."
related: [mistake-demo-bot-ignores-dormant-enemies, mistake-demo-bot-stuck-on-obstacles, mistake-thrown-weapon-landing-on-cursor-vs-target]
origin: Roguelike series
---

# Built-in automated demo/test player that plays a full roguelike run to the ending

**When to use:** You need to prove a whole game is winnable/crash-free in a headless cloud box, capture gameplay screenshots/footage, or regression-test after a kit change.

## Do this

- Flags (Godot user args after `--`): `--demo=1 --auto=1 --god=1 --skipevent=1 --press=1.2` is the proven "full winning run" combo used for all 4 games. Each one is independent:
  - `--demo=1`: Player.demo = true (bot drives movement/aim/ability inside player.gd); hub `_intro` auto-activates the descend door 1.5s after the intro.
  - `--auto=1`: Dialogue `_pressed()` returns true every 25 frames (`Engine.get_process_frames() % 25 == 0`); Menus press OK every 30 frames (boon cards, lists, pages). `--auto=last` makes list menus select the LAST item (e.g. reach "BACK", or test the second choice).
  - `--god=1`: `player.hurt()` returns immediately (still dies never) - lets the bot survive bosses.
  - `--skipevent=1`: bot ignores event altars and walks to door 0.
  - `--press=1.2`: boot `_presser` injects `InputEventAction` press/release of `interact` (or `--act=<action>`) every 1.2s using pause-proof timers `create_timer(gap, true, false, true)` -> advances splash/title/death screen/choices that wait for input.
  - `--loot=1`: bot walks to non-heart pickups before taking the door. `--dbg=1`: prints alive/pending/wave every 120 frames.
- Bot movement (player.gd `_process` when demo): default target = ellipse patrol `c=(192,96)`, `ang=t*0.6`, `want = c + (cos(ang)*90, sin(ang)*36)`. If state is clear/boss_clear/rest (or event with skipevent/altar used) -> `want = room.door_pos(0) + (0,-2)`. In combat/boss: find nearest live non-`fake` enemy; if farther than 80px, `want = enemy + (pos-enemy).normalized()*60` (walk to within 60px -> wakes dormant ambushers and reaches turrets). Event: walk to altar+(0,12) and call `_interact_altar()` within 14px.
- Bot aim: always at nearest live non-fake enemy chest (`pos + (0,-6)`), fire only if one exists; stores `aim_dist` for thrown weapons. Ability every 4s (`fmod(t,4) < 0.12`).
- `mv = (want - position).limit_length(1.0)` if farther than 4px.
- Un-stick (see mistake skill): every 1.2s compare position to last; if moved <3px and no waypoint active, pick random waypoint `(randf_range(60,324), randf_range(60,170))` for 1.6s.
- Log markers to grep: `ROOM floor=.. n=.. kind=.. reward=.. doors=..`, `BOSS_DEFEATED <id>`, `RUN_END win=true floor=3`, `SCRIPT ERROR`, `PLACEHOLDER`.
- Combine with `--speed=N` (Engine.time_scale, base_scale restored after hitstop/scene change) to shorten wall-clock time, and `--seed=N` for reproducible runs.

## Pitfalls (mistakes seen)

see mistake-demo-bot-stuck-on-obstacles, mistake-demo-bot-ignores-dormant-enemies, mistake-thrown-weapon-landing-on-cursor-vs-target.

## Verify

`bash _tools/autorun.sh <proj> 900 --demo=1 --auto=1 --god=1 --skipevent=1 --press=1.2` shows ROOM lines for 4 floors, 4 BOSS_DEFEATED, `RUN_END win=True`, no SCRIPT ERROR. MANIFEST then states "Full autoplay run (hub -> 4 floors -> 4 bosses -> win -> ending -> hub -> new run) completed with no script errors".

## Origin

Roguelike series. Source notes: player.gd 32-39, 112-151, 163-173; boot.gd 25-46; dialogue.gd 82-88; menus.gd 93-96; hub.gd 67-70; WIP_BIBLE_AND_MANIFEST.md Game 2; MANIFEST.md "Verified".

## Related skills

- [mistake-demo-bot-ignores-dormant-enemies](mistake-demo-bot-ignores-dormant-enemies.md)
- [mistake-demo-bot-stuck-on-obstacles](mistake-demo-bot-stuck-on-obstacles.md)
- [mistake-thrown-weapon-landing-on-cursor-vs-target](mistake-thrown-weapon-landing-on-cursor-vs-target.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
