---
id: fnaf-qa-checklist-evidence
title: "Evidence-gated QA checklist + regression grep audit"
category: testing-qa
when: "Before claiming a build works; after multiple agents edited the project."
related: [mistake-hide-mesh-to-silence-errors, mistake-qa-pass-without-evidence]
origin: FNAP
---

# Evidence-gated QA checklist + regression grep audit

**When to use:** Before claiming a build works; after multiple agents edited the project.

## Do this

- Sections: A global gates (import exits 0; boot reaches splash then posed title; grep for regressions: `visible = false`,
  `layers = 0`, `cull_mask`, `set_surface_override_material`, flat `albedo_color` substitution, `queue_free` of loaded GLB
  meshes - each hit justified or FAIL; no AI images/voxels; palette; nearest filtering; credits/version; Godot version
  pinned; nothing published), B restored-regression items, C models that must actually SHOW (not just exist on disk),
  D numbered feature list with screenshots as evidence, E marker names present in GLB/scripts, F packaging.
- Rule: "Never claim PASS without a command output or a PNG I opened with Read." Status TODO/PASS/FAIL + evidence path.
- Grep: `grep -rnE "visible = false|layers = 0|cull_mask|set_surface_override_material|albedo_color|queue_free" scripts/`

## Pitfalls (mistakes seen)

mistake-hide-mesh-to-silence-errors; mistake-qa-pass-without-evidence.

## Verify

Every checklist row has an evidence path.

## Origin

FNAP. Source notes: REF §5.3.

## Related skills

- [mistake-hide-mesh-to-silence-errors](mistake-hide-mesh-to-silence-errors.md)
- [mistake-qa-pass-without-evidence](mistake-qa-pass-without-evidence.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
