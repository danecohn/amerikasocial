---
id: mistake-hid-placeholder-that-rig-lived-on
title: "Door rigs broke after the real office loaded"
category: mistake
when: "Swapping placeholders for real models where rigs/scripts reference nodes."
related: []
origin: FNAP
---

# Door rigs broke after the real office loaded

**When to use:** Swapping placeholders for real models where rigs/scripts reference nodes.

## Do this

Rigs adopt real nodes (`adopt_model_node`); never hide the node you control.

## What happened, root cause, fix, prevention

Symptom: door rigs broke after real office loaded. Root cause: code hid ALL placeholder meshes including shutter boxes the door rig lived on. Fix: rigs adopt real nodes; look up on real model first, placeholder second; keep a "role -> real/PLACEHOLDER/missing" wiring report. Prevention: hide a placeholder only after its role is adopted by a real node. Detection: `office_wiring` print.

## Verify

Wiring report all "real"; doors animate in pack screenshot.

## Origin

FNAP. Source notes: mistakes-log.md M06.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
