---
id: dialogue-dsl-python-helpers
title: "Tiny Python DSL for writing dialogue/beats/events as data"
category: narrative-dialogue
when: "Authoring lots of game dialogue in Python that compiles to JSON for a Godot dialogue runner."
related: []
origin: Roguelike series
---

# Tiny Python DSL for writing dialogue/beats/events as data

**When to use:** Authoring lots of game dialogue in Python that compiles to JSON for a Godot dialogue runner.

## Do this

```python
def L(w, t, m=None, **kw): d={"w":w,"t":t}; (d.__setitem__("m",m) if m else None); d.update(kw); return d  # line: who, text, mood
def N(t, m=None, **kw): return L("", t, m, **kw)          # narrator
def CMD(c, **kw): d={"cmd":c}; d.update(kw); return d     # command step
def CH(*choices, w="", t=""): return {"w":w,"t":t,"c":list(choices)}
def C(t, say=None, set=None, fx=None): ...                 # one choice: text, reply lines, flags, fx
def beat(id, trigger, scene, when=None, set=None, repeat=False): ...  # story beat
def ev(id, scene, when=None): ...                          # random event
def speaker(name, color, sprite="", frames=2, hz=200, wave=1, ms=50, var=0.05):
    return {"name":name,"color":color,"sprite":sprite,"frames":frames,"blip":{"hz":hz,"wave":wave,"ms":ms,"var":var}}
def death_beats(add, lines):  # [(id, deaths_needed, [lines])] + generic fallback
    for did,n,sc in lines: add(beat(did,"death",sc,when={"deaths":n}))
    add(beat("d_generic","death",[N("YOU WAKE.")],when={},repeat=True))
```
- Moods used in text: `"m": "shout" | "whisper"`; `^` inside text = a pause marker (e.g. "You carry it well. ^Too well.").
- Always add a repeatable generic fallback beat so every trigger has something to say.

## Pitfalls (mistakes seen)

none.

## Verify

game.json loads; every death count has a beat.

## Origin

Roguelike series. Source notes: _tools/gk.py L10-70; spec.py phase_lines.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
