---
id: fnaf-custom-night
title: "Custom Night (Night 6) with per-enemy 0-20 sliders"
category: gameplay-systems
when: "Adding a post-story challenge night."
related: []
origin: FNAP
---

# Custom Night (Night 6) with per-enemy 0-20 sliders

**When to use:** Adding a post-story challenge night.

## Do this

- Night 6 = Custom Night; `custom_ai` per character 0-20; default table row N6 16,18,18,19,10 (pickle, remi, dilly,
  banshee, golden). Same `_story_config` shape; `phone: false` (n > 5).
- 2D REBUILD explicitly did NOT make Custom Night art (screen, portraits, AI arrows, READY button) - plan these assets if
  you want it.

## Pitfalls (mistakes seen)

none.

## Verify

`--fnap-night=6` boots with custom values.

## Origin

FNAP. Source notes: REF §2.3, §1.5; STATEMAP lines 287-289.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
