---
id: door-nook-pitch-black
title: "Make the rooms outside office doors pitch black unless lit"
category: 3d-lighting-horror
when: "User asks 'darker', 'pitch black', 'can't see who's there without a light'."
related: []
origin: Pickle's Pickle Shop
---

# Make the rooms outside office doors pitch black unless lit

**When to use:** User asks "darker", "pitch black", "can't see who's there without a light".

## Do this

`_darken_door_nooks()` in level_builder: for tag in ["L","R"], find `Room_OFFICE_DOOR_<tag>` on the map, multiply every material albedo by `Color(0.1, 0.1, 0.11)`, disable emission, skip Light3D nodes. Call it from both `keep_halls_dark()` and `_darken_halls()` so re-applied after any rebuild. Hall rooms use a milder multiplier `Color(0.75, 0.75, 0.78)` plus near-zero ambient. Combine with eyes hidden in nooks (eye energy 0, eye meshes hidden). Light comes only from the hall light (Pickle-GPT) or flashlight.

## Pitfalls (mistakes seen)

First pass left nooks visible enough to see the lurker; user complained. Prevention: confirm darkness targets per space with the user (halls = dark but readable on camera; door nooks = pitch black) and screenshot both unlit and lit.

## Verify

Screenshot from desk toward each doorway: unlit = black (no silhouette, no eyes); lit = lurker visible.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.1, 3; level_builder.gd `_darken_door_nooks`.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
