---
id: mistake-concurrent-godot-imports
title: "Two Godot processes on one project corrupt import cache"
category: mistake
when: "Multiple agents or background jobs touching one project."
related: []
origin: FNAP
---

# Two Godot processes on one project corrupt import cache

**When to use:** Multiple agents or background jobs touching one project.

## Do this

Single instance; `IMPORT_DONE` marker; others wait.

## What happened, root cause, fix, prevention

Symptom: broken .godot/imported. Fix above; delete `.godot/imported` and re-import once if corrupted.

## Verify

One godot PID.

## Origin

FNAP. Source notes: mistakes-log.md M58; process-playbook 3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
