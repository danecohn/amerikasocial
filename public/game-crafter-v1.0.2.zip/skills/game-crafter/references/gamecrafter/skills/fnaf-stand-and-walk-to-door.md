---
id: fnaf-stand-and-walk-to-door
title: "Dark doorways you must physically go to (hall light / flashlight reveal)"
category: planning-design
when: "You want doors to be scarier than FNAF's button-from-chair: the player must leave the chair to check a doorway."
related: [fnaf-camera-feed-layer-isolation, mistake-dark-hall-actors-invisible-layers-zero, mistake-hall-button-lights-under-hidden-parent, mistake-halls-too-bright]
origin: FNAP
---

# Dark doorways you must physically go to (hall light / flashlight reveal)

**When to use:** You want doors to be scarier than FNAF's button-from-chair: the player must leave the chair to check a doorway.

## Do this

- Rule (CALLS N1): "You can't see the doorways from the chair. If you want to know who's standing there, you get up, you
  walk to the door, and you turn on the hall light or the flashlight. Then you decide."
- Implementation: `OfficeLook.go_to("door_l")` runs phases `stand -> walk (route: aisle, mid, doorway) -> at_door`, and
  back `return_walk -> sit`; emits `locomotion(state)` which drives first-person arm clips (`fp_get_up`,
  `fp_walk_to_door`, `fp_lean_out_L` ...). Walking costs stamina (`stamina.sprinting`).
- Hall rooms (CAM_2A/2B/4A/4B) and `Light_Hall_L/R` start at `light_energy 0`. Only the flashlight (SpotLight3D,
  shadows on, range 16, angle 24, attenuation 2.2) or the A/D hall-light buttons reveal a hall. The office "full" light
  state never re-lights halls (`keep_halls_dark()`).
- Camera feeds have their own exposure, so the dark halls don't break monitoring (fnaf-camera-feed-layer-isolation).
- Story foreshadowing: the job ad says "must be able to stand up quickly" (BIBLE) - a mechanic hinted in fiction.
- 2D REBUILD simplification: seated plates with door lights; "Only one door light is on at a time (switching one on
  switches the other off)".

## Pitfalls (mistakes seen)

mistake-dark-hall-actors-invisible-layers-zero; mistake-hall-button-lights-under-hidden-parent;
mistake-halls-too-bright.

## Verify

`hall_check.tscn` dumps hall structure and screenshots dark / flashlight / hall-light states;
`seat_sight_test.gd` proves nothing in the doorway is visible from the chair.

## Origin

FNAP. Source notes: REF §2.2, §2.3, §5.2; CALLS N1; BIBLE "Why the Player Took the Night Shift"; STATEMAP lines 122-123.

## Related skills

- [fnaf-camera-feed-layer-isolation](fnaf-camera-feed-layer-isolation.md)
- [mistake-dark-hall-actors-invisible-layers-zero](mistake-dark-hall-actors-invisible-layers-zero.md)
- [mistake-hall-button-lights-under-hidden-parent](mistake-hall-button-lights-under-hidden-parent.md)
- [mistake-halls-too-bright](mistake-halls-too-bright.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
