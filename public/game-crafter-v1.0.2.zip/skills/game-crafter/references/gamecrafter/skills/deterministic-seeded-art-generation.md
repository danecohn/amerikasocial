---
id: deterministic-seeded-art-generation
title: "Seed every random choice so art regenerates identically"
category: pixel-art-2d
when: "Any procedural art; required for reproducible builds and stable diffs."
related: [mistake-python-hash-nondeterministic-tiles]
origin: Roguelike series
---

# Seed every random choice so art regenerates identically

**When to use:** Any procedural art; required for reproducible builds and stable diffs.

## Do this

- Each generator constructs its own `random.Random(seed ...)` (floor `seed*31 + variant`, wall top `seed+5`, face `seed+9`, side `seed+13`, block floor `seed+1`, decor `seed + len(tiles)`, title stars `Random(5)`/`Random(7)`); never use the global `random` module state.
- Game-wide seed in SPEC (`"seed": 11/21/31/41`) offsets tiles per game so the same theme dict in two games still differs.

## Pitfalls (mistakes seen)

see mistake-python-hash-nondeterministic-tiles.

## Verify

build twice, `sha256sum assets/**/*.png` identical.

## Origin

Roguelike series. Source notes: _tools/tiles.py; buildgame.py line 124.

## Related skills

- [mistake-python-hash-nondeterministic-tiles](mistake-python-hash-nondeterministic-tiles.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
