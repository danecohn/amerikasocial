---
id: fnaf-power-system
title: "Power system (usage bars, drain formula, budget math)"
category: gameplay-systems
when: "Implementing or tuning the non-regenerating power meter."
related: []
origin: FNAP
---

# Power system (usage bars, drain formula, budget math)

**When to use:** Implementing or tuning the non-regenerating power meter.

## Do this

- `rate (%/s) = 0.1 * usage_bars * drain_multiplier + bonus_drain`.
- `usage_bars = 1 + doors_latched + lights_on (hall light, flashlight) + monitor_up + auto_extra` (HUD shows 1-5 bars).
- Runner bangs subtract instantly: `power_drain_per_bang + bang_escalation*(bangs-1)` percent (per-enemy data).
- Emits `power_depleted` ONCE. Office lights auto-drop to `lamp` state below 20% power; `dark` on power-out.
- Terminal queries also cost power (`cost` per intent); auto mode adds an extra usage bar + percent/sec base + per-hour.
- Budget math (derived): 1 bar = 0.1%/s -> 100% lasts 1000 s > 516 s night (idle survives); constant 2 bars = 500 s <
  516 s (sustained extra usage kills you just before 6 AM on N1). N5 (x1.32): idle 1 bar lasts ~757 s. Tune so idle
  survives and any sustained extra device does not.
- Sketch:
  ```gdscript
  class_name PowerSystem extends Node
  signal power_depleted
  var power := 100.0
  var drain_multiplier := 1.0
  var bonus_drain := 0.0
  var _dead := false
  func usage_bars() -> int:
      return 1 + doors_latched + lights_on + int(monitor_up) + auto_extra
  func _process(delta: float) -> void:
      if _dead: return
      power -= (0.1 * usage_bars() * drain_multiplier + bonus_drain) * delta
      if power <= 0.0:
          power = 0.0
          _dead = true
          power_depleted.emit()
  func bang(bangs: int, per_bang: float, escalation: float) -> void:
      power = maxf(0.0, power - (per_bang + escalation * (bangs - 1)))
  ```
- 2D REBUILD: pressing dead buttons plays `button-denied-buzz.wav`; panels switch to `panel-*-dead.png`.

## Pitfalls (mistakes seen)

none logged; but HUD must reflect bars exactly (single source).

## Verify

Debug overlay power readout over a timed run equals formula; `--fnap-debug-print=<sec>`.

## Origin

FNAP. Source notes: REF §2.3 Power, §2.2 light states, §2.11; STATEMAP lines 126, 229.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
