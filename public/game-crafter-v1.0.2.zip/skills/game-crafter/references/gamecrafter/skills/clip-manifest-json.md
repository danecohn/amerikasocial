---
id: clip-manifest-json
title: "clips.json manifest for per-clip loop flags and walk speeds (ClipManifest)"
category: gdscript-patterns
when: "Characters have many clips with mixed loop/one-shot behaviour; movement speed must match the walk animation."
related: [gameplay-logic-preemptive-rules]
origin: FNAP
---

# clips.json manifest for per-clip loop flags and walk speeds (ClipManifest)

**When to use:** Characters have many clips with mixed loop/one-shot behaviour; movement speed must match the walk animation.

## Do this

- Ship `res://assets/models/characters/clips.json` beside the models (keep `*.json` in include_filter). Tolerant reader accepts arrays or dicts with keys `name|clip`, `character|file|model`, `loop|looping`, `length|seconds`, nested under `clips`, `files`, `characters`, `models`, `assets`; per-file `walk_speed_mps`.
- Lookup keys normalized with `NodeFinder.normalize(file basename)`; clip match exact (lowercase) or suffix match (`Armature|walk` ends with `walk`).
- API: `ClipManifest.is_looping(character, clip) -> Variant(null|bool)`, `ClipManifest.apply(character, player)`, `ClipManifest.walk_speed(character, fallback)`.
```gdscript
static func apply(character: String, player: AnimationPlayer) -> void:
    if player == null: return
    for anim_name in player.get_animation_list():
        var loop: Variant = is_looping(character, String(anim_name))
        if loop == null: continue
        player.get_animation(anim_name).loop_mode = Animation.LOOP_LINEAR if bool(loop) else Animation.LOOP_NONE
```
- Example shape: `{"files": {"pickle.glb": {"walk_speed_mps": 1.4, "clips": {"walk": {"loop": true, "length": 1.0}, "jumpscare": {"loop": false}}}}}` (illustrative).
- Use walk_speed to time movement = distance / speed (see gameplay-logic-preemptive-rules).
- Note: template file had its comments lost in a decompile (blank lines 5-14); behaviour intact.

## Pitfalls (mistakes seen)

animation looping wrong after import; fixed-time sprints didn't match speed.

## Verify

print `is_looping` for each clip; a check that clip loop_mode matches manifest.

## Origin

FNAP. Source notes: T/godot_core/clip_manifest.gd; S Architecture bullet 2 (line 20); L §4.6 line 228.

## Related skills

- [gameplay-logic-preemptive-rules](gameplay-logic-preemptive-rules.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
