# Tool: release.py

**Purpose:** Exports 4 platforms, builds zips with soundtrack + README, splits big zips into parts with SHA256.

**Usage:** `python3 release.py <slug> <Product Name> <out_dir>`

**Skill:** see `skills/export-presets-four-platforms.md`

**Extract:** save the block below as `release.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""release.py <slug> <Product Name> <out_dir> : export 4 platforms, build zips (+soundtrack+README), split >29MB parts."""
import sys, os, subprocess, shutil, zipfile, hashlib, stat, glob
slug, product, out = sys.argv[1], sys.argv[2], sys.argv[3]
B = f"/home/claude/evac/build/{slug}"; P = f"{B}/project"; X = f"{B}/exports"
SK=os.environ.get("SKIP_EXPORT")
if not SK: shutil.rmtree(X, ignore_errors=True); os.makedirs(X)
pn = product.replace(" ", "_")
jobs = [("Windows Desktop", f"{X}/win64/{slug}.exe", "Windows_x64"), ("Windows ARM64", f"{X}/winarm/{slug}.exe", "Windows_ARM64"),
        ("Linux", f"{X}/linux/{slug}.x86_64", "Linux"), ("macOS", f"{X}/mac/{slug}-mac.zip", "Mac")]
subprocess.run(["godot","--headless","--path",P,"--import","--quit"],capture_output=True,timeout=300)
for preset, path, tag in jobs:
    if SK: continue
    os.makedirs(os.path.dirname(path), exist_ok=True)
    r = subprocess.run(["godot","--headless","--path",P,"--export-release",preset,path],capture_output=True,text=True,timeout=500)
    ok = os.path.exists(path)
    print(preset, "rc", r.returncode, "ok" if ok else "MISSING", os.path.getsize(path) if ok else 0)
    if not ok: print(r.stdout[-800:], r.stderr[-800:]); sys.exit(1)
dist = f"{out}/DISTRIBUTION"; shutil.rmtree(dist, ignore_errors=True); os.makedirs(dist)
readme = open(f"{out}/PLAYER_README.txt").read() if os.path.exists(f"{out}/PLAYER_README.txt") else product
import json
st = f"{B}/soundtrack_pkg"; shutil.rmtree(st, ignore_errors=True); os.makedirs(st)
for f in glob.glob(f"{B}/ogg/*.ogg"): shutil.copy(f, st)
for f in glob.glob(f"{B}/soundtrack/*.bb.json"): shutil.copy(f, st)
info = json.load(open(f"{B}/soundtrack_info.json"))
open(f"{st}/BEEPBOX_LINKS.txt","w").write("SOUNDTRACK - composed in the BeepBox synthesizer (beepbox.co). Paste any link below into a browser to open and edit the song.\n\n"+"".join(f"{i['name']}  ({i['key']} {i['mode']}, {i['bpm']} BPM, {i['seconds']}s)\n{i['beepbox_url']}\n\n" for i in info))
def add_extras(z, top):
    z.writestr(f"{top}/README.txt", readme)
    for f in sorted(glob.glob(f"{st}/*")):
        z.write(f, f"{top}/Soundtrack/{os.path.basename(f)}")
def mk(tag, files, mode_exec=()):
    zp = f"{dist}/{pn}_{tag}.zip"
    with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        top = product
        for src, arc in files:
            zi = zipfile.ZipInfo(f"{top}/{arc}", date_time=(2026,10,9,0,0,0)); zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = ((0o755 if arc in mode_exec else 0o644) | stat.S_IFREG) << 16
            z.writestr(zi, open(src,"rb").read())
        add_extras(z, top)
    return zp
zips = []
zips.append(mk("Windows_x64", [(f"{X}/win64/{slug}.exe", f"{product}.exe")]))
zips.append(mk("Windows_ARM64", [(f"{X}/winarm/{slug}.exe", f"{product}.exe")]))
zips.append(mk("Linux", [(f"{X}/linux/{slug}.x86_64", f"{product}.x86_64")], mode_exec={f"{product}.x86_64"}))
# mac: keep Godot zip, append extras
mz = f"{dist}/{pn}_Mac.zip"; shutil.copy(f"{X}/mac/{slug}-mac.zip", mz)
with zipfile.ZipFile(mz, "a", zipfile.ZIP_DEFLATED) as z: add_extras(z, product)
zips.append(mz)
LIM = 20_000_000
sums = []
for zp in zips:
    sz = os.path.getsize(zp); h = hashlib.sha256(open(zp,"rb").read()).hexdigest(); sums.append((os.path.basename(zp), h, sz))
    print(os.path.basename(zp), sz)
    if sz > LIM:
        data = open(zp,"rb").read(); os.remove(zp)
        for i in range(0, len(data), LIM):
            open(f"{zp}.{i//LIM+1:03d}","wb").write(data[i:i+LIM])
bat = ["@echo off","rem Joins the split zip parts in this folder into the finished zips (checks SHA-256). Double-click to run.","powershell -NoProfile -ExecutionPolicy Bypass -File \"%~dp0ASSEMBLE_ZIPS.ps1\"","pause"]
ps = ['$ErrorActionPreference="Stop"','Set-Location $PSScriptRoot']
for n,h,sz in sums:
    ps += [f'$parts = Get-ChildItem -Filter "{n}.0*" | Sort-Object Name',
           f'if ($parts) {{ $o=[IO.File]::Create("$PWD\\{n}"); foreach($p in $parts){{ $b=[IO.File]::ReadAllBytes($p.FullName); $o.Write($b,0,$b.Length) }}; $o.Close();',
           f'  $h=(Get-FileHash "{n}" -Algorithm SHA256).Hash.ToLower(); if($h -ne "{h}"){{ Write-Host "CHECKSUM MISMATCH {n}" -ForegroundColor Red }} else {{ Write-Host "OK {n}"; $parts | Remove-Item }} }}']
if any(sz>LIM for _,_,sz in sums):
    open(f"{dist}/ASSEMBLE_ZIPS.bat","w",newline="\r\n").write("\r\n".join(bat)+"\r\n")
    open(f"{dist}/ASSEMBLE_ZIPS.ps1","w",newline="\r\n").write("\r\n".join(ps)+"\r\n")
open(f"{dist}/SHA256.txt","w").write("".join(f"{h}  {n}\n" for n,h,_ in sums))
print("done")
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
