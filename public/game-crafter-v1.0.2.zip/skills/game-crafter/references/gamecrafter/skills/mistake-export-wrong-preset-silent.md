---
id: mistake-export-wrong-preset-silent
title: "Mistake - export with a missing/wrong preset name produced nothing"
category: mistake
when: "Scripted exports, especially on the user's PC."
related: []
origin: FNAP
---

# Mistake - export with a missing/wrong preset name produced nothing

**When to use:** Scripted exports, especially on the user's PC.

## What happened, root cause, fix, prevention

- Symptom: ARM64 build script "ran" but no exe appeared.
- Root cause: preset name wrong/missing (the PC's export_presets.cfg lacked `[preset.3]`), Godot exits non-zero quietly.
- Fix: check `$LASTEXITCODE` and that the exe exists: `if (-not (Test-Path $exe)) { throw "exe not produced" }`.
- Prevention: build scripts assert output existence; list presets before exporting (`grep '^name=' export_presets.cfg`).
- Detection: read the build log.

## Verify

exe present with new timestamp.

## Origin

FNAP. Source notes: L §3.2 lines 170-171, §7.4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
