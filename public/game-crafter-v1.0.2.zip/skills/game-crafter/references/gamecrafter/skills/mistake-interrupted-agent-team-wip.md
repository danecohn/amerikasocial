---
id: mistake-interrupted-agent-team-wip
title: "Interrupted parallel agent launch leaves unverified WIP — recover by baseline re-run"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Interrupted parallel agent launch leaves unverified WIP — recover by baseline re-run

**When to use:** 

## What happened, root cause, fix, prevention

Symptom: user interrupted a 13-agent launch ~10 min in (usage nearly exhausted); partial files appeared across kit, ui, combat, characters, player, rpg, colosseum/city stubs; no agent reported; tests not re-run after edits. Root cause: launching many agents at once with little budget; no gate between "agent writes" and "integrator verifies". Fix: next pass (Cursor) re-ran `--import` + test_main first, fixed the two type-inference compile errors and missing class cache, restored project.godot settings agents had changed (`config/version`, `import_s3tc_bptc`, `import_etc2_astc`), got PASS 130/0, and only then continued. Prevention: (1) baseline test line recorded before agents start; (2) agents must update their agent file "before you finish and after every major step"; (3) integrator re-runs all suites before accepting; (4) with limited budget, run fewer agents sequentially; (5) treat everything since the last verified baseline as WIP in the MANIFEST.

## Origin

Caesarea. Source notes: LOG 09:45, 10:00; MANIFEST "STATE AT HAND-OFF".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
