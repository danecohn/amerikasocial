# Tool: node_finder.gd

**Purpose:** Name-based node lookup helpers + packed_name() for export-safe directory listings.

**Usage:** `autoload or static class NodeFinder`

**Skill:** see `skills/godot-export-safe-asset-loading.md`

**Extract:** save the block below as `node_finder.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
class_name NodeFinder
extends RefCounted
## Game Maker template (proven in Five Nights at Pickles).
## Find nodes / animation clips / model files BY NORMALIZED NAME so Blender re-exports
## ("Door_Left.001", "door_l", "DoorL") never break the code, and so lookups behave the
## same in the editor and in an EXPORTED build (see packed_name).

## "Door_Left.001" -> "doorl". Lowercase, drop Blender duplicate suffix (.001 _001 -001 " 001"),
## left->l, right->r, keep only [a-z0-9].
static func normalize(raw: String) -> String:
	var s := raw.to_lower()
	var rx := RegEx.create_from_string("[._ -]\\d{3}$")
	s = rx.sub(s, "")
	s = s.replace("left", "l").replace("right", "r")
	var out := ""
	for c in s:
		if (c >= "a" and c <= "z") or (c >= "0" and c <= "9"):
			out += c
	return out

## First node matching ANY alias; aliases are tried in order (put the preferred name first).
static func find_by_names(root: Node, names: Array) -> Node:
	if root == null:
		return null
	var wanted: Array[String] = []
	for n in names:
		wanted.append(normalize(str(n)))
	var all_nodes := collect(root)
	for w in wanted:
		for node in all_nodes:
			if normalize(node.name) == w:
				return node
	return null

## Breadth-first list of root and every descendant.
static func collect(root: Node) -> Array[Node]:
	var result: Array[Node] = []
	if root == null:
		return result
	var queue: Array[Node] = [root]
	while not queue.is_empty():
		var n: Node = queue.pop_front()
		result.append(n)
		queue.append_array(n.get_children())
	return result

static func find_lights(root: Node) -> Array[Light3D]:
	var lights: Array[Light3D] = []
	for n in collect(root):
		if n is Light3D:
			lights.append(n)
	return lights

static func find_animation_player(root: Node) -> AnimationPlayer:
	for n in collect(root):
		if n is AnimationPlayer:
			return n
	return null

static func find_mesh(root: Node) -> MeshInstance3D:
	for n in collect(root):
		if n is MeshInstance3D:
			return n
	return null

## Resolve a clip name tolerant of glTF prefixes: "walk" matches "walk", "Armature|walk", "x_walk", "lib/walk".
static func resolve_clip(player: AnimationPlayer, clip: String) -> String:
	if player == null:
		return ""
	if player.has_animation(clip):
		return clip
	var want := clip.to_lower()
	for anim_name in player.get_animation_list():
		var lower := String(anim_name).to_lower()
		if lower == want or lower.ends_with("|" + want) or lower.ends_with("_" + want) or lower.ends_with("/" + want):
			return anim_name
	return ""

## Find a model/scene file in a res:// folder by normalized stem. EXPORT-SAFE: uses packed_name().
static func find_resource_file(dir: String, stems: Array, extensions: Array = ["glb", "gltf", "tscn", "scn"]) -> String:
	var da := DirAccess.open(dir)
	if da == null:
		return ""
	var wanted: Array[String] = []
	for s in stems:
		wanted.append(normalize(str(s)))
	for raw in da.get_files():
		var file := packed_name(raw)
		if not extensions.has(file.get_extension().to_lower()):
			continue
		if wanted.has(normalize(file.get_basename())):
			return dir.path_join(file)
	return ""

static func list_model_files(dir: String) -> Array[String]:
	var files: Array[String] = []
	var da := DirAccess.open(dir)
	if da == null:
		return files
	for raw in da.get_files():
		var file := packed_name(raw)
		if ["glb", "gltf"].has(file.get_extension().to_lower()) and not files.has(dir.path_join(file)):
			files.append(dir.path_join(file))
	files.sort()
	return files

## THE EXPORT BUG: in a shipped build, DirAccess.get_files("res://...") returns
## "office.glb.import" / "office.glb.remap" instead of "office.glb" (the raw file is not in the PCK).
## Always pass directory listings through this, then load() the stripped path - never FileAccess it.
static func packed_name(file: String) -> String:
	if file.ends_with(".import") or file.ends_with(".remap"):
		return file.get_basename()
	return file
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
