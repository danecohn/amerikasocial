---
id: fnaf-stamina-flashlight-lean-breath
title: "Stamina, flashlight battery, lean and hold-breath (player-side resources)"
category: gameplay-systems
when: "Adding body/resource mechanics beyond power to a FNAF-like."
related: []
origin: FNAP
---

# Stamina, flashlight battery, lean and hold-breath (player-side resources)

**When to use:** Adding body/resource mechanics beyond power to a FNAF-like.

## Do this

- Stamina (`stamina_system.gd`): regen 8/s; costs sprint 22/s, yank (hold the shutter) 14/s, hold breath 30/s;
  `EXHAUSTED_THRESHOLD 25`; `speed_factor()` slows movement. Below 55% the player pants (looped breathing, volume lerps
  -22..-4 dB) and nearby animatronics gain `aggression`; look shake scales with exhaustion; HUD vignette shader blurs
  edges (`vignette.gdshader`).
- Flashlight: usable only at a door; drains 4/s, regens 1.5/s (x2.5 when docked at the desk charger); below 20%
  flickers. Charger LED red/green/pulse, battery gauge mesh lit by surface index `ceil(battery/20)`, charge ring pulse,
  lens emission.
- Hold breath (Shift, at a door): ducks Music/Ambience; bangers give up after 1 bang instead of 2-3.
- Lean (Z / RMB): tweens `player_rig` to `PlayerLean_Door*` marker (60% when arms exist), plays `fp_lean_out_L/R`,
  exposes a corner camera room (CAM_4B) to the beam only while leaning.

## Pitfalls (mistakes seen)

none recorded.

## Verify

Debug overlay shows stamina/aggression; sim of a sprint/hold shows exhaustion < 25 slows walk.

## Origin

FNAP. Source notes: REF §2.3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
