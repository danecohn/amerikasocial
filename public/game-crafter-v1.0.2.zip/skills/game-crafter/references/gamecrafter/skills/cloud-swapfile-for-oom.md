---
id: cloud-swapfile-for-oom
title: "Add swap in the cloud container before big imports/renders"
category: environment-tools
when: "First import of large GLBs or SwiftShader rendering on ~8 GB RAM; OOM kills."
related: []
origin: FNAP
---

# Add swap in the cloud container before big imports/renders

**When to use:** First import of large GLBs or SwiftShader rendering on ~8 GB RAM; OOM kills.

## Do this

```bash
fallocate -l 12G /tmp/swapfile && chmod 600 /tmp/swapfile && mkswap /tmp/swapfile && swapon /tmp/swapfile
```
(exact commands are the standard recipe, inferred). FNAP: 8 GB RAM was not enough with the 55 MB office + rooms loaded -> OOM; 12 GB swap fixed it. It is gone on a fresh container - recreate.
- Constraints: 2 cores, ~7-8 GB RAM, no GPU -> Cycles CPU only, Godot software Vulkan; plan time budgets.

## Pitfalls (mistakes seen)

OOM during import/render.

## Verify

`swapon --show`; `free -h`.

## Origin

FNAP. Source notes: L §1.1 line 23-27, §1.4, §5.2 line 250.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
