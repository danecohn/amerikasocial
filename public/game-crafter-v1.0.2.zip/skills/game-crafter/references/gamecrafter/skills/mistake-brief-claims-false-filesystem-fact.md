---
id: mistake-brief-claims-false-filesystem-fact
title: "Brief said art_source/.gdignore exists; it didn't → Godot imported art sources"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Brief said art_source/.gdignore exists; it didn't → Godot imported art sources

**When to use:** 

## What happened, root cause, fix, prevention

Symptom: stale `.import` files under art_source, duplicate assets imported. Root cause: assumed `.gdignore`. Fix: `touch art_source/.gdignore` (zero bytes) — also used for `design/` (holds a reference copy of the starter code) and `_retired/` (retired voxel scripts). Prevention: verify every brief claim (`ls -la`) and put `.gdignore` in any folder holding source art, reference code copies or retired code.

## Origin

Caesarea. Source notes: requests/characters.md; PAUSED_STATUS Done.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
