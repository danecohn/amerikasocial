---
id: godot-include-filter-raw-data
title: "What actually ships in a Godot 4.7 export, and the include_filter you need"
category: export-release
when: "The game reads any non-resource file (txt, cues, csv, xml, cfg, md, dat, bin, raw ogg/png/wav, ogv) at runtime; writing/maintaining export_presets.cfg."
related: [mistake-exported-build-shows-placeholders]
origin: FNAP
---

# What actually ships in a Godot 4.7 export, and the include_filter you need

**When to use:** The game reads any non-resource file (txt, cues, csv, xml, cfg, md, dat, bin, raw ogg/png/wav, ogv) at runtime; writing/maintaining export_presets.cfg.

## Do this

- Measured in Godot 4.7.2 with an EMPTY include_filter and `export_filter="all_resources"`:
  - `.json` ships raw (it is a resource type in 4.7) - FileAccess can read it.
  - `.csv` is imported as a Translation: only `x.csv.import` is listed, raw bytes are gone, `load()` returns a Translation, not text.
  - `.txt .cues .md .cfg .xml .dat .bin` are NOT exported at all.
  - `.png .glb .wav .ogg` are imported (only `.import` names visible).
- FNAP's include_filter (put in EVERY preset): `include_filter="*.json, *.csv, *.txt, *.cues, assets/audio/voice/*, assets/assistant_face/*, assets/branding/*"`. Template presets already carry `*.json` etc. and `tools/probe_manifest.json`.
- Keep `*.json` in include_filter anyway (belt and braces; the probe template says so) - one template comment (clip_manifest.gd) still claims json is "NOT auto-exported", which is outdated for 4.7.2 but harmless if you include it.
- Missing `*.cues` -> phone calls had no subtitles in the export. Voice bank needed `LINES.csv` in include_filter. Splash intro video `res://assets/branding/eva_c_studios_intro.ogv` missing from PCK printed `[splash] static logo splash (no intro video found)` (non-fatal fallback).
- CSV caution (inference, re-verify): if a .csv must be read as text, set its import to "Keep File" or include it and prove with the export probe that `FileAccess.file_exists` is true in the pack.

## Pitfalls (mistakes seen)

phone subtitles and voice lines silently missing in the export because raw data wasn't included (see mistake-exported-build-shows-placeholders).

## Verify

Add each raw file to `probe_manifest.json` `raw_files`; probe from the pack prints `PROBE_OK raw <path>`; a missing one prints `PROBE_FAIL raw <path>  <- add to include_filter`. Negative test (new-godot-game-recipe step 6) proves the gate bites.

## Origin

FNAP. Source notes: G line 6 (measured table); L §2.1 fix 4 (line 70-71), L §2.12 (line 138), L §10 line 443; S Non-negotiable 1; T/godot_dev/export_probe.gd line 6; T/godot_core/clip_manifest.gd line 15.

## Related skills

- [mistake-exported-build-shows-placeholders](mistake-exported-build-shows-placeholders.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
