# Tool: glb_check.gd

**Purpose:** Checks that every node name the code expects exists in each GLB (the Blender↔code name contract).

**Usage:** `godot --headless --path <proj> res://dev/glb_check.tscn`

**Skill:** see `skills/blender-godot-node-name-contract.md`

**Extract:** save the block below as `glb_check.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
extends SceneTree
## Game Maker: sanity-report every .glb/.gltf under a folder (meshes, materials, albedo textures, cameras, lights, clips).
## usage: godot --headless --path <proj> -s res://scripts/dev/glb_check.gd -- [res://assets/models]
## Fails (exit 1) on any model that does not load or has zero meshes. Works from the editor tree AND from a pack (uses packed_name).
func _init() -> void:
	var args := OS.get_cmdline_user_args()
	var root_dir: String = args[0] if args.size() > 0 else "res://assets/models"
	var files: Array[String] = []
	_scan(root_dir, files)
	var bad := 0
	for p in files:
		var ps := load(p) as PackedScene
		if ps == null:
			print("FAIL load ", p); bad += 1; continue
		var n := ps.instantiate()
		var meshes := 0; var mats := {}; var untextured := 0; var cams := 0; var lights := 0
		var clips: Array = []
		for c in NodeFinder.collect(n):
			if c is MeshInstance3D:
				meshes += 1
				var m := (c as MeshInstance3D).mesh
				if m:
					for s in m.get_surface_count():
						var mat := (c as MeshInstance3D).get_active_material(s)
						if mat is BaseMaterial3D:
							mats[mat.resource_name] = true
							if mat.albedo_texture == null: untextured += 1
			elif c is Camera3D: cams += 1
			elif c is Light3D: lights += 1
			elif c is AnimationPlayer:
				for a in (c as AnimationPlayer).get_animation_list(): clips.append(String(a))
		print("OK %s meshes=%d mats=%d surf_no_albedo=%d cams=%d lights=%d clips=%s" % [p.get_file(), meshes, mats.size(), untextured, cams, lights, clips])
		if meshes == 0: bad += 1; print("  ^ NO MESHES")
		n.free()
	print("GLB_CHECK_DONE files=%d bad=%d" % [files.size(), bad])
	quit(1 if bad else 0)
func _scan(dir: String, out: Array[String]) -> void:
	for d in DirAccess.get_directories_at(dir): _scan(dir.path_join(d), out)
	for raw in DirAccess.get_files_at(dir):
		var f := NodeFinder.packed_name(raw)
		if f.get_extension().to_lower() in ["glb", "gltf"] and not out.has(dir.path_join(f)): out.append(dir.path_join(f))
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
