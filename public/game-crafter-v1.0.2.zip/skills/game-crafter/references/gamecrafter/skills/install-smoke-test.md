---
id: install-smoke-test
title: "Installed" means an export actually ran"
category: environment-tools
when: "After installing tools."
related: []
origin: FNAP
---

# Installed" means an export actually ran

**When to use:** After installing tools.

## Do this

Run end-to-end `verify_export.sh` on a tiny project (new-game recipe). Also Python deps in Debian containers: `pip install --break-system-packages pillow numpy`. Blender: always `blender -b`; 5.x prints harmless `use_nodes` DeprecationWarnings. Software Vulkan ICD needed for headless screenshots (Playwright swiftshader or mesa-vulkan-drivers).

## Pitfalls (mistakes seen)

Declaring install done without an export.

## Verify

verify_export.sh exit 0.

## Origin

FNAP. Source notes: install-godot-blender/SKILL.md rules 6-8; install-guide.md "Verify".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
