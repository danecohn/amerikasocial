# Workflow: promo kit (itch.io, trailer, reels, socials)
1. Capture: `scripted-promo-capture-scene`, `director-trailer-capture`, `native-screenshot-capture-and-upscale`, `taa-settle-before-screenshots`. 5 real in-game screenshots.
2. Store art: `itch-cover-630x500-from-screenshot` / `itch-cover-from-screenshot-pixel`, `pillow-store-art-generator`, `studio-brand-pixel-identity`.
3. Copy: `itch-page-copy`, `itch-long-description-template`, `itch-tags-genres-selection`, `itch-pricing-launch-strategy`, `itch-ai-disclosure`, `youtube-copy-rules`, `socials-two-reel-captions` (templates in `os/templates/ITCH_PAGE.md`, `SOCIALS.md`).
4. Video: `horizontal-trailer-spec`, `vertical-reel-ad-spec`, `vertical-reel-from-landscape`, `reel-assembly-segments`, `reel-audio-mix-from-game-sounds`, `ffmpeg-recipe-library`, `ffmpeg-drawtext-captions`, `horror-ad-creative-recipe`.
5. Optional editing service: `descript-import-media`, `descript-directing-underlord`, `descript-jobs-and-publish`.
6. Look at every frame and listen to every mix (`evidence-rule`). Write caveats (`promo-honest-caveats`). Post nothing (`never-publish-unless-asked`).
Mistakes: the ffmpeg drawtext, tile, zoompan, audio-mix and vertical-crop mistakes, plus the Descript mistakes (all under Mistakes).
