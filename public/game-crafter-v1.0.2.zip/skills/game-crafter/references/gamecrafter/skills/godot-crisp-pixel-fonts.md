---
id: godot-crisp-pixel-fonts
title: "Godot 4 settings for crisp pixel fonts (no AA, no hinting, no subpixel)"
category: godot-engine
when: "Loading TTF pixel fonts in Godot; text looks blurry or uneven."
related: []
origin: Roguelike series
---

# Godot 4 settings for crisp pixel fonts (no AA, no hinting, no subpixel)

**When to use:** Loading TTF pixel fonts in Godot; text looks blurry or uneven.

## Do this

```gdscript
func _font(path: String) -> FontFile:
    var f: FontFile = load(path) as FontFile if ResourceLoader.exists(path) else null
    if f == null: push_warning("PLACEHOLDER font missing: " + path); return null
    f.antialiasing = TextServer.FONT_ANTIALIASING_NONE
    f.hinting = TextServer.HINTING_NONE
    f.subpixel_positioning = TextServer.SUBPIXEL_POSITIONING_DISABLED
    f.generate_mipmaps = false
    return f
func label(text, size := 10, color := Color.WHITE, title := false) -> Label:
    var l := Label.new(); l.text = text
    l.add_theme_font_override("font", font_title if title else font_body)
    l.add_theme_font_size_override("font_size", size)          # multiples of 10 only
    l.add_theme_color_override("font_color", color)
    l.add_theme_constant_override("line_spacing", 2)
    l.add_theme_constant_override("outline_size", 0)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE; return l
```
- Drop shadows are a second label/string offset by (1,1) (body) or (2,2) (title) in black, never font outlines.
- Pillow side: `d.fontmode = "1"` for aliased text in generated images; shadow offset `size_px//10 + 1`.

## Pitfalls (mistakes seen)

font sizes not multiple of the font's cell unit (e.g. 15) produce uneven pixel widths - always 10/20/30/40 for a 100-unit cell / 1000 UPM font.

## Verify

zoomed screenshot: every glyph stroke is exactly N whole pixels.

## Origin

Roguelike series. Source notes: kit/kit/game.gd lines 53-88; fx.gd lines 78-81; title.gd 33-38; buildgame.py render_text.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
