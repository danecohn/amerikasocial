---
id: mistake-phone-audio-drift-from-script
title: "Recorded/described phone audio doesn't match the current script"
category: mistake
when: "Story scripts are revised after audio was made or described."
related: []
origin: FNAP
---

# Recorded/described phone audio doesn't match the current script

**When to use:** Story scripts are revised after audio was made or described.

## What happened, root cause, fix, prevention

- Symptom (observed across sources): the 2D package's AUDIO list describes calls from a different script ("Night 1:
  welcome, legal message"; "Night 2: Remi left / Dilly right"; "Night 3: hint about the gold Pickle suit Backstage";
  "Night 4: phone guy cornered; banging, music box"; "Night 5: reversed, warped, garbled voice") while the current call
  scripts have Night 5 as clear speech and different content; written durations (105/80/70/55/30 s) differ from recorded
  (108.05/67.95/54.29/41.49/21.52 s).
- Root cause: audio/descriptions made from an earlier script, not regenerated.
- Fix: one source of truth (`night-N.txt`) -> regenerate/re-record wav -> regenerate `.cues` from the real wav; update
  AUDIO-INDEX descriptions.
- Prevention: cue generator + subtitle check per night; bible digest audit includes audio descriptions.

## Verify

phone_check subtitles match spoken words.

## Origin

FNAP. Source notes: STATEMAP lines 258-262; CALLS; REF §3.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
