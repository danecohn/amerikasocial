---
id: ending-resolver-gates-guarantee
title: "EndingResolver: gate expressions, two-endings guarantee, hidden collapse, priority"
category: rpg-systems
when: "Multiple endings driven by flags."
related: []
origin: Caesarea
---

# EndingResolver: gate expressions, two-endings guarantee, hidden collapse, priority

**When to use:** Multiple endings driven by flags.

## Do this

Each ending's gate = list of ledger expressions (ALL must hold), stored as exact expressions in code; `explain(id)` returns unmet ones for a debug overlay. Hub lists only eligible endings (`get_hub_options()`), one ending always available. **Two-endings guarantee**: if no main gate holds, offer the player's alliance ending with thresholds waived (variant `fragile`), else a fallback, so the player always has a real alternative. Variants chosen by ordered rules (pact → puppet; leverage → puppet; merciful > ruthless → reformer; else tyrant). **Hidden collapse** state from act ≥ 4 if ANY trigger (≥3 failed missions, war abandoned, stalled > 21 days without key, city fell, explicit walk-away). Priority: `collapse → act5_failed → chosen ending if eligible → otherwise default ending` (last fallback only catches scripting bugs; logs warning). Resolve writes `final_choice`, key holder, `ending_id`, `ending_variant`, emits `ending_resolved`. Epilogue cards `{ending, order, still, text, if}`, text matching the ending script word for word.

## Pitfalls (mistakes seen)

Ambiguous bible wording ("both" vs "or") → doc follows the detailed section and lists it as an open question; thresholds kept as single constants so the owner can change one number.

## Verify

tests assert ineligible choice is refused (`'surrender_to_state' chosen but E1 is not eligible`).

## Origin

Caesarea. Source notes: design/07 §15, §19; godot_import_report test warnings.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
