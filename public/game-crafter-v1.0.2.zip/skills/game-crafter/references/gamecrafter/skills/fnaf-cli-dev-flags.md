---
id: fnaf-cli-dev-flags
title: "CLI dev/QA flags parsed in the state autoload"
category: testing-qa
when: "You need to jump to a night, screenshot, auto-quit, or capture without touching the menu."
related: [mistake-dev-run-overwrites-player-save]
origin: FNAP
---

# CLI dev/QA flags parsed in the state autoload

**When to use:** You need to jump to a night, screenshot, auto-quit, or capture without touching the menu.

## Do this

- Parse `OS.get_cmdline_user_args()` (everything after `--`). `--fnap-foo=bar` -> `cli["foo"]="bar"`; bare `--capture`,
  `--aspect`, `--seed`, `--cues` also accepted.
- Flags: `night`, `skip-intro`, `skip-splash`, `no-save`, `quit-after=<sec>`, `hour=<sec per hour>`,
  `screenshot=<png>`, `shot-door=L|R`, `shot-pan`, `shot-frames`, `shot-assistant=<phrase>`, `shot-monitor=CAM_x`,
  `shot-credits`, `quit-on-shot`, `debug-print=<sec>`, `bench-monitor=full|room`, `brine-test`, `splash-video=<path>`,
  `office`, `autoadvance`, `capture=<moment>`, `seed`, `aspect=vertical`, `cues=<sheet#track>`, `cues-audio`.
- Dev switch never saves (quoted):
  ```gdscript
  func _dev_switch_active() -> bool:
  	return capture != "" or cli.has("no-save") or cli.has("night") or cli.has("screenshot")
  func save() -> void:
  	if _dev_switch_active():
  		return          # dev flags must never overwrite the player's real save
  ```
- Example: `godot --headless --path . -- --fnap-night=3 --fnap-quit-after=8 --fnap-no-save`.

## Pitfalls (mistakes seen)

mistake-dev-run-overwrites-player-save.

## Verify

Run with `--fnap-night=5`, check save file mtime unchanged.

## Origin

FNAP. Source notes: REF §1.7, §5.1.

## Related skills

- [mistake-dev-run-overwrites-player-save](mistake-dev-run-overwrites-player-save.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
