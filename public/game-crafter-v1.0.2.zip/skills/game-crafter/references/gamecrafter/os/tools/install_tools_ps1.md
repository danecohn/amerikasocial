# Tool: install_tools.ps1

**Purpose:** Install Godot + templates on Windows x64/ARM64.

**Usage:** `powershell -ExecutionPolicy Bypass -File install_tools.ps1`

**Skill:** see `skills/godot-install-export-templates.md`

**Extract:** save the block below as `install_tools.ps1` (exact contents) and run it. Adapt paths marked `<...>`.

```powershell
<# Game Maker: install Godot (standard) + export templates + Blender on Windows (x64 or ARM64).
   Usage:  powershell -NoProfile -ExecutionPolicy Bypass -File install_tools.ps1 [-GodotVersion 4.7.2] [-BlenderVersion 5.2.2] [-Prefix C:\GameTools]
   Picks the NATIVE build for the CPU (ARM64 PCs run ARM64 Godot/Blender fast; x64 builds run under emulation).
   Writes a transcript to install_tools.log next to this script so a remote agent can read the result back. #>
param([string]$GodotVersion="4.7.2",[string]$BlenderVersion="5.2.2",[string]$Prefix="$env:USERPROFILE\GameTools")
$ErrorActionPreference="Stop"; $ProgressPreference="SilentlyContinue"
Start-Transcript -Path (Join-Path $PSScriptRoot "install_tools.log") -Force | Out-Null
try {
  $arm = ($env:PROCESSOR_ARCHITECTURE -eq "ARM64") -or ($env:PROCESSOR_ARCHITEW6432 -eq "ARM64")
  $gsuffix = if ($arm) {"windows_arm64"} else {"win64"}; $barch = if ($arm) {"windows-arm64"} else {"windows-x64"}
  New-Item -ItemType Directory -Force $Prefix | Out-Null
  $base = "https://github.com/godotengine/godot/releases/download/$GodotVersion-stable"
  $gz = Join-Path $Prefix "godot-$GodotVersion.zip"; $gd = Join-Path $Prefix "godot-$GodotVersion-$gsuffix"
  if (-not (Test-Path $gd)) {
    Invoke-WebRequest "$base/Godot_v$GodotVersion-stable_$gsuffix.exe.zip" -OutFile $gz
    Expand-Archive $gz $gd -Force; Remove-Item $gz
  }
  $tpz = Join-Path $Prefix "templates.zip"; $td = Join-Path $env:APPDATA "Godot\export_templates\$GodotVersion.stable"
  if (-not (Test-Path (Join-Path $td "version.txt"))) {
    Invoke-WebRequest "$base/Godot_v$GodotVersion-stable_export_templates.tpz" -OutFile $tpz
    $tmp = Join-Path $Prefix "tpl"; Expand-Archive $tpz $tmp -Force
    New-Item -ItemType Directory -Force $td | Out-Null; Copy-Item (Join-Path $tmp "templates\*") $td -Recurse -Force
    Remove-Item -Recurse -Force $tmp, $tpz
  }
  $bmaj = ($BlenderVersion -split '\.')[0..1] -join '.'
  $bd = Join-Path $Prefix "blender-$BlenderVersion-$barch"
  if (-not (Test-Path $bd)) {
    $bz = Join-Path $Prefix "blender.zip"
    Invoke-WebRequest "https://download.blender.org/release/Blender$bmaj/blender-$BlenderVersion-$barch.zip" -OutFile $bz
    Expand-Archive $bz $Prefix -Force; Remove-Item $bz
  }
  Write-Host "GODOT: $(Get-ChildItem $gd -Filter *console.exe | Select-Object -First 1 -Expand FullName)"
  Write-Host "TEMPLATES: $td  version.txt=$(Get-Content (Join-Path $td 'version.txt'))"
  Write-Host "BLENDER: $(Get-ChildItem $Prefix -Recurse -Filter blender.exe | Select-Object -First 1 -Expand FullName)"
  Write-Host "INSTALL_DONE"
} catch { Write-Host "FAILED: $_"; Write-Host "Fallback: winget install GodotEngine.GodotEngine ; winget install BlenderFoundation.Blender (these install the x64 build) - export templates still need the .tpz from godotengine.org" }
Stop-Transcript | Out-Null
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
