---
id: honest-verification-language
title: "Write status lines that cannot be mistaken for "done"
category: core-workflow
when: "Every report, LOG line, agent file, final message."
related: []
origin: Caesarea
---

# Write status lines that cannot be mistaken for "done

**When to use:** Every report, LOG line, agent file, final message.

## Do this

Template per step: what was built; what was NOT run ("Did not run Blender", "Did not run bld_shell_WIP.py (never executed; no blend or glb)"); exact test lines; "Not screenshotted"; what is still placeholder ("People are capsule stand-ins", "labeled stand-ins", "not claimed as sculpture"); "Slice is not shippable. No zip." Distinguish "PLACEHOLDER, not a canon change". State what was checked vs assumed (packs contain X; not launched on Linux/macOS). Agent files have "Not verified: everything" when true. Final report lists: files changed, what you refused to overwrite and why, assets noticed but not touched, test line, manifest paths updated, canon guesses.

## Origin

Caesarea. Source notes: LOG.md; MANIFEST; agents/*.md; attachment.txt Report back.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
