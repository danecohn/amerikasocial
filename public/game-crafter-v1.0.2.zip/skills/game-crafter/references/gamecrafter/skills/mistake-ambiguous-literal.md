---
id: mistake-ambiguous-literal
title: "Ambiguous short instruction answered literally ("already there")"
category: mistake
when: "Short/ambiguous user instruction."
related: []
origin: FNAP
---

# Ambiguous short instruction answered literally ("already there")

**When to use:** Short/ambiguous user instruction.

## Do this

Restate the goal from the previous turn; ask one question.

## What happened, root cause, fix, prevention

Symptom: user frustrated. Fix above.

## Verify

Interpretation stated.

## Origin

FNAP. Source notes: mistakes-log.md M95.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
