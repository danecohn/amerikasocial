---
id: enemy-ai-archetypes-data-driven
title: "Enemy AI archetypes chosen by data (chase, shoot, turret, burst, charge, orbit, wander, summon, ambush, exploder)"
category: ai-enemies
when: "Building many enemy types for an action roguelike from a small code base."
related: []
origin: Roguelike series
---

# Enemy AI archetypes chosen by data (chase, shoot, turret, burst, charge, orbit, wander, summon, ambush, exploder)

**When to use:** Building many enemy types for an action roguelike from a small code base.

## Do this

- One Enemy class; `def.ai` selects behaviour; params in data: hp, speed, size (radius), cd, keep (preferred distance), damage (contact), proj_speed, proj_dmg, shots, ring, homing, summon, max_minions, mass, flying, faces_left, sprite, frames, fps, mem (currency drop), cost (spawn budget), blood (hex), fake.
- Spawn: HP = hp * run hp_mul; first-cd randomized x0.6-1.2; random strafe sign and orbit phase so packs desync.
- Separation steering: neighbours closer than 11px push `d/l*(11-l)*4`.
- chase: straight at target. shoot/burst: hold `keep` (80) distance band (+12/-16) with 0.5 strafe, flip strafe at 0.4%/frame, fire when cd elapsed and dist<190 (cd*0.85..1.15); burst fires a `ring` (8) of bullets; turret stands still.
- charge: approach at 0.55 speed; within 150 -> "wind" 0.7s (shake sprite +-1px, sfx warn) -> "dash" 0.5s at speed*4.2 -> "recover" 0.9s.
- orbit: circle player at `keep` (54) with speed*1.4 cap, periodic 0.4s lunge at speed*4.
- wander: random direction changes; 55% chance to dash 0.28s at speed*3.4 roughly toward player.
- summon: kite away to keep 110; spawn `summon` id if alive count < max_minions (4) every cd 4.
- ambush: hidden (alpha 0.12, no contact damage) until player within keep (52) or hit; then chases at 1.7x for 3s; re-hides if far (>90) after timer.
- exploder: rush at 1.25x; within 20px start 0.6s fuse (flashing), explode r=28 with def damage.
- Common: knockback `kb += v / max(0.6, mass)` decays lerp 8/s (bosses take 10%); stun zeroes velocity; flying enemies ignore walls but clamp to room bounds; contact damage if within radius+player radius; small 2px HP bar shown 2s after hit; death: burst, ring, fade 0.25s, `world.on_enemy_died` (drops `mem` pickups, 7% + luck*3% heart).
- Enemies target `world.target_for(self)` so decoys work.

## Pitfalls (mistakes seen)

Hidden ambushers never approach -> demo bot that stands off at range never wakes them; see demo-player skill ("walks to dormant enemies").

## Verify

spawn each archetype in a test room (`--floor`, `--kind`) and screenshot.

## Origin

Roguelike series. Source notes: kit/kit/enemy.gd 38-335.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
