---
id: mistake-commit-not-landing-mtime
title: "File commit "not landing" / script produced no exe"
category: mistake
when: "Re-committing changed files to PC."
related: []
origin: FNAP
---

# File commit "not landing" / script produced no exe

**When to use:** Re-committing changed files to PC.

## Do this

mtime guard (`expectedMtimeMs`) or stale file; re-commit with force, verify via `device_list_dir` / stage it back and diff.

## What happened, root cause, fix, prevention

Symptom: old presets on PC; ARM64 script made no exe (reconstructed). Fix above.

## Verify

Staged-back content matches.

## Origin

FNAP. Source notes: mistakes-log.md M72.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
