# Tool: lint_export_safety.py

**Purpose:** Static lint that catches code which works in the editor but breaks in an exported build (raw res:// file APIs, globalize_path, DirAccess listings without packed_name, data files missing from include_filter).

**Usage:** `python3 lint_export_safety.py <godot_project_dir>   # exit 1 on errors`

**Skill:** see `skills/godot-export-safe-asset-loading.md`

**Extract:** save the block below as `lint_export_safety.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""Game Maker: static lint for the bug class that only appears in EXPORTED Godot builds.
Usage: lint_export_safety.py <godot_project_dir> [--strict]
Flags (E = error, W = warning):
  E1  FileAccess.file_exists/open on a res:// path of an importable asset (glb/png/jpg/ogg/wav/...): raw file is not in the PCK
  E2  ProjectSettings.globalize_path("res://...") then reading it from disk (works in editor only)
  E3  DirAccess get_files/list_dir_begin on res:// WITHOUT packed_name()/.import/.remap handling in the same file
  E4  Image.load_from_file / AudioStreamOggVorbis.load_from_file / GLTFDocument.append_from_file used as the PRIMARY path on res://
  W1  data files (csv/txt/cfg/cues/xml/md/dat/bin; json ships raw) present in the project but not covered by ANY preset include_filter, while code references them
  W2  presets missing exclude_filter for dev folders (scripts/dev, *_check.gd, *.py)
  W3  hiding/zeroing code (visible=false, layers=0, cull_mask, light_energy=0, set_surface_override_material): print for human audit
  W4  globalize_path used but a load() precedes it (likely a guarded fallback; confirm)
Exit code 1 if any E found (or W with --strict).
"""
import os, re, sys, fnmatch, configparser, glob
proj = sys.argv[1] if len(sys.argv) > 1 else "."
strict = "--strict" in sys.argv
IMPORTABLE = r"(glb|gltf|png|jpe?g|webp|svg|ogg|wav|mp3|ogv|tres|tscn|obj|fbx)"
gd_files = [p for p in glob.glob(os.path.join(proj, "**", "*.gd"), recursive=True) if "/.godot/" not in p and "/addons/" not in p]
errs, warns, audit = [], [], []
def rel(p): return os.path.relpath(p, proj)
for p in gd_files:
    try: src = open(p, encoding="utf-8", errors="replace").read()
    except Exception: continue
    is_dev = "/dev/" in p or p.endswith("_check.gd") or "/tools/" in p
    lines = src.splitlines()
    has_packed = "packed_name" in src or ".remap" in src or ".import" in src
    def guarded(i):   # a load()/ResourceLoader.exists() in the 10 lines above => this line is probably a dev/disk FALLBACK, not the primary path
        ctx = "\n".join(lines[max(0, i-11):i-1])
        return bool(re.search(r"\bload\(|ResourceLoader\.(exists|load)|load_named\(", ctx))
    for i, ln in enumerate(lines, 1):
        s = ln.strip()
        if s.startswith("#"): continue
        if re.search(r"FileAccess\.(file_exists|open|get_file_as_string)\([^)]*res://[^)]*\." + IMPORTABLE + r"\b", s):
            if not is_dev: errs.append((p, i, "E1", s))
        if ("globalize_path" in s) and not is_dev and ("res://" in s or "path" in s):
            (warns if guarded(i) else errs).append((p, i, "E2" if not guarded(i) else "W4", s + ("   (guarded fallback after load()? verify primary path uses load())" if guarded(i) else "")))
        if re.search(r"(Image\.load_from_file|AudioStream\w*\.load_from_file|append_from_file)\(", s) and "res://" in s and not is_dev:
            errs.append((p, i, "E4", s))
        if re.search(r"(get_files|list_dir_begin|get_files_at)", s) and not has_packed and not is_dev:
            errs.append((p, i, "E3", s + "   <- add NodeFinder.packed_name() handling (.import/.remap); matching extensions like .ogv/.glb/.png fails on 'x.ogv.import' in a build"))
        if re.search(r"(\bvisible\s*=\s*false|\blayers\s*=\s*0\b|cull_mask|light_energy\s*=\s*0\b|set_surface_override_material|material_override\s*=)", s):
            audit.append((p, i, "W3", s))
# presets
cfg_path = os.path.join(proj, "export_presets.cfg")
inc_globs, exc_globs, presets = [], [], []
if os.path.exists(cfg_path):
    txt = open(cfg_path, encoding="utf-8", errors="replace").read()
    for m in re.finditer(r'^name="([^"]+)"', txt, re.M): presets.append(m.group(1))
    for m in re.finditer(r'^include_filter="([^"]*)"', txt, re.M): inc_globs += [g.strip() for g in m.group(1).split(",") if g.strip()]
    for m in re.finditer(r'^exclude_filter="([^"]*)"', txt, re.M): exc_globs += [g.strip() for g in m.group(1).split(",") if g.strip()]
    if not any("dev" in g or "_check" in g or g.endswith(".py") for g in exc_globs) and os.path.isdir(os.path.join(proj, "scripts", "dev")):
        warns.append((cfg_path, 0, "W2", "scripts/dev exists but no exclude_filter for it (dev scenes/scripts would ship)"))
else:
    warns.append((cfg_path, 0, "W2", "no export_presets.cfg found"))
DATA = (".json", ".csv", ".txt", ".cfg", ".cues", ".xml", ".md", ".dat", ".bin", ".wav", ".ogg", ".png", ".ogv")
code_text = "\n".join(open(p, encoding="utf-8", errors="replace").read() for p in gd_files)
for root, dirs, files in os.walk(proj):
    dirs[:] = [d for d in dirs if d not in (".godot", ".git", "addons", "build", "_backup")]
    for f in files:
        if not f.lower().endswith((".csv", ".txt", ".cues", ".xml", ".cfg", ".md", ".dat", ".bin")): continue   # .json ships by itself in 4.7 (it is a resource type); these do not (csv is imported as a Translation: raw bytes gone)
        rp = rel(os.path.join(root, f)).replace(os.sep, "/")
        if rp.startswith(("docs/", "tools/")) or f in ("README.txt", "LICENSE.txt", "project.godot"): continue
        covered = any(fnmatch.fnmatch(rp, g) or fnmatch.fnmatch(f, g) for g in inc_globs)
        referenced = f in code_text or rp in code_text or os.path.dirname(rp) and (os.path.dirname(rp) in code_text)
        if referenced and not covered:
            warns.append((os.path.join(proj, rp), 0, "W1", f"data file referenced by code but not matched by any include_filter (raw files are NOT exported unless included; it will be missing in the build)"))
for kind, items in (("ERROR", errs), ("WARN", warns)):
    for p, i, code, s in items: print(f"{kind} {code} {rel(p)}:{i}: {s}")
if audit:
    print(f"\nHIDE/ZERO AUDIT ({len(audit)} hits) - justify each (rare swaps / by-design only; never hide a mesh or zero a layer to make an error go away):")
    for p, i, code, s in audit[:200]: print(f"  {rel(p)}:{i}: {s}")
print(f"\nSUMMARY errors={len(errs)} warnings={len(warns)} audit_hits={len(audit)} presets={presets}")
sys.exit(1 if errs or (strict and warns) else 0)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
