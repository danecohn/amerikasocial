---
id: mistake-concat-copy-timestamps
title: "concat `-c copy` gives odd timestamps"
category: mistake
when: "Joining video segments."
related: []
origin: FNAP
---

# concat `-c copy` gives odd timestamps

**When to use:** Joining video segments.

## Do this

Encode every segment identically (30 fps, yuv420p, same size/codec) before concat.

## What happened, root cause, fix, prevention

Symptom: stutter/odd durations. Fix above.

## Verify

ffprobe each segment identical.

## Origin

FNAP. Source notes: mistakes-log.md M63.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
