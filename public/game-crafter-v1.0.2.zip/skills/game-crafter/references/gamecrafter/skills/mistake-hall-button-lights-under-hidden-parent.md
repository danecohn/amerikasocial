---
id: mistake-hall-button-lights-under-hidden-parent
title: "Hall lights never turn on (lights parented under a node hidden later)"
category: mistake
when: "A light toggles in code but nothing lights up after real models load."
related: []
origin: FNAP
---

# Hall lights never turn on (lights parented under a node hidden later)

**When to use:** A light toggles in code but nothing lights up after real models load.

## What happened, root cause, fix, prevention

- Symptom: pressing the hall-light button does nothing visible once the real halls load.
- Root cause: hall button lights lived under `HallStub_*`, which is hidden once real halls load (hidden parent hides
  child lights).
- Fix: `_detach_hall_button_lights()` reparents them to the office root.
- Prevention: never parent functional lights/controls under placeholder nodes that get hidden; `release_check` asserts
  hall lights exist and start at energy 0.

## Verify

hall_check "hall-light" screenshot is lit.

## Origin

FNAP. Source notes: REF §8.2 #2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
