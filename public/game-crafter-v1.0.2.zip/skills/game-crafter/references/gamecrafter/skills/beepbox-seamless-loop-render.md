---
id: beepbox-seamless-loop-render
title: "Make a looping game-music WAV with a clean reverb wrap"
category: audio-music
when: "Rendering background music that must loop with no click/gap."
related: []
origin: Roguelike series
---

# Make a looping game-music WAV with a clean reverb wrap

**When to use:** Rendering background music that must loop with no click/gap.

## Do this

- Render the song twice (`loopRepeatCount = 1`) and keep only the SECOND half: `n = floor(L.length/2); start = n`. The reverb/release tail of pass 1 is already sounding at the start of pass 2, so the loop point is seamless.
- Do not trim silence on seamless renders. Song JSON sets `introBars: 0`, `loopBars: total bars`.
- In Godot set `AudioStreamOggVorbis.loop = true` for everything except one-shot stings (`sting_death`, `sting_win`).

## Pitfalls (mistakes seen)

none recorded.

## Verify

track durations equal bars*4 beats*60/bpm (e.g. 24 bars @62 BPM = 92.9 s; 32 bars @140 = 54.9 s; matches soundtrack.txt), and looping playback has no audible tick.

## Origin

Roguelike series. Source notes: render_bb.ts L4-4, L22, L33-36; soundtrack.txt durations; audio_kit.gd L61-62.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
