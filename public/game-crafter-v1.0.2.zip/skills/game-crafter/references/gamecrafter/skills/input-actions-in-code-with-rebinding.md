---
id: input-actions-in-code-with-rebinding
title: "InputSetup — register all actions in code (keyboard+gamepad), rebinding + JSON persistence"
category: gdscript-patterns
when: "Any game needing an input map without editing project.godot; settings rebinding."
related: []
origin: Caesarea
---

# InputSetup — register all actions in code (keyboard+gamepad), rebinding + JSON persistence

**When to use:** Any game needing an input map without editing project.godot; settings rebinding.

## Do this

`InputSetup.ensure_actions(force=false)` idempotent (adds missing actions with deadzone 0.2; fills defaults only when an action has no events — keeps user rebinds); call from Game._ready(). JSON-safe descriptors `{"t":"key","code":KEY_W}` (physical keycode), `{"t":"mouse","button":...}`, `{"t":"joy_button","button":...}`, `{"t":"joy_axis","axis":...,"value":±1}`. Rebind replaces events of the SAME DEVICE CLASS (keyboard/mouse vs gamepad); `add=true` appends; `find_conflicts(event)`, `reset_defaults(action="")`, `serialise()/deserialise()`, `describe_action()` for prompts ("[E] Talk"). ACTION_INFO `[action, label, group]` drives the settings screen. Aliases mirror legacy names (`toggle_view` → `toggle_camera`). Defaults: WASD + left stick, Shift/L3 sprint, Space/A jump, C or Ctrl/B crouch, Q/Z lean, right stick look, V/R3 toggle camera, X swap shoulder, E/Y interact, LMB/RT attack, RMB/LT aim, R/X reload, Esc/Start pause, Tab inventory, J journal, M map, F5/F9 quick save/load.
- mistakes (observed in code, not documented): key collisions between agents — `Q` is lean_left in InputSetup but weapon-cycle in PlayerCombat (hard-coded KEY_Q); `Tab` is inventory in InputSetup and Pip-Boy toggle in PipBoy (KEY_TAB). Root cause: agents hard-coding keycodes instead of using actions. Prevention: gameplay code reads `Input.is_action_*` only; run `find_conflicts` in a test over all hard-coded keys.

## Origin

Caesarea. Source notes: Caesarea/game/interaction/input_setup.gd; game/combat/player_combat.gd; game/ui/pipboy.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
