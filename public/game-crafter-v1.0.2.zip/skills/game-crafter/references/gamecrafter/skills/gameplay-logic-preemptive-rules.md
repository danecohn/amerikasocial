---
id: gameplay-logic-preemptive-rules
title: "Gameplay-logic rules that pre-empt FNAF-style bugs (timers, doors, fairness, balance)"
category: gameplay-systems
when: "Building survival-horror mechanics: doors, power, reaction windows, jumpscares, hallucinations, enemy balance."
related: [await-cancellation-tokens, mistake-dead-enum-state-and-fixed-timers]
origin: FNAP
---

# Gameplay-logic rules that pre-empt FNAF-style bugs (timers, doors, fairness, balance)

**When to use:** Building survival-horror mechanics: doors, power, reaction windows, jumpscares, hallucinations, enemy balance.

## Do this

- Every enum state must be set somewhere.
- Reaction windows decrement by `minf(delta, 0.1)` (clamped delta: a hitch can't eat the whole window).
- Motion time = distance / speed.
- Doors block at `progress >= 0.5`.
- Audio ducks always released.
- Awaits tokenised (await-cancellation-tokens).
- Unfair-death guards: `refuse_closed_door()`; never allow a jumpscare while a valid block is up.
- Hallucination/fake entities: separate flag + own path; never recolour another enemy to fake one.
- Balance by simulation (`patrol_sim.gd`, `balance_regression`, `door_lurker_sim`, `seat_sight_test`), measure instead of guessing.
- One config dict feeds one gameplay scene (story night vs roguelite shift): `{title, night, hours, seconds_per_hour, levels{id: ai}, power_max, drain_multiplier, ...}`.

## Pitfalls (mistakes seen)

dead branches and fixed timers (mistake-dead-enum-state-and-fixed-timers).

## Verify

sims run headless with exit codes; regression thresholds.

## Origin

FNAP. Source notes: G "Gameplay-logic bugs" (lines 45-49); S lines 20, 23, 27-28.

## Related skills

- [await-cancellation-tokens](await-cancellation-tokens.md)
- [mistake-dead-enum-state-and-fixed-timers](mistake-dead-enum-state-and-fixed-timers.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
