---
id: mistake-frames-v-after-fps-filter
title: "ffmpeg clip length wrong with `-frames:v N"
category: mistake
when: "Cutting clips with ffmpeg."
related: []
origin: FNAP
---

# ffmpeg clip length wrong with `-frames:v N

**When to use:** Cutting clips with ffmpeg.

## Do this

Use `-t seconds` (= frames / source fps); `-frames:v` counts OUTPUT frames after `fps=30` filter.

## What happened, root cause, fix, prevention

Symptom: wrong duration. Fix above.

## Verify

ffprobe duration.

## Origin

FNAP. Source notes: mistakes-log.md M60.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
