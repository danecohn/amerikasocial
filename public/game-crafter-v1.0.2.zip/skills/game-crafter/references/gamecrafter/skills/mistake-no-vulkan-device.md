---
id: mistake-no-vulkan-device
title: "Vulkan finds no device in cloud; Forward+ can't start"
category: mistake
when: "Rendering Godot in a GPU-less container."
related: []
origin: FNAP
---

# Vulkan finds no device in cloud; Forward+ can't start

**When to use:** Rendering Godot in a GPU-less container.

## Do this

`VK_ICD_FILENAMES=<swiftshader json from Playwright chromium>` + `xvfb-run -a` + `--rendering-driver vulkan` (wrapper `godot_xvfb.sh`). Alternative proven: `xvfb-run -a -s '-screen 0 1280x720x24' godot --path <proj> --rendering-driver vulkan --resolution 1280x720` with llvmpipe (opengl3 also works). Screenshot: `await RenderingServer.frame_post_draw; get_viewport().get_texture().get_image().save_png(p)`.

## What happened, root cause, fix, prevention

Symptom: no device. Cause: no GPU/ICD. Fix above.

## Verify

PNG non-black.

## Origin

FNAP. Source notes: mistakes-log.md M50; BOARD.md line 2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
