---
id: fnaf-voice-lines-tts
title: "Generated voice lines for a machine character (edge-tts, consistent settings)"
category: audio-music
when: "Voicing a robotic/AI character with many short lines."
related: []
origin: FNAP
---

# Generated voice lines for a machine character (edge-tts, consistent settings)

**When to use:** Voicing a robotic/AI character with many short lines.

## Do this

- 76 lines, one en-US "Jenny" voice via `edge-tts`, rate +4%, pitch +2 Hz. Rule: regenerate with the SAME settings so
  "the computer stays one machine".
- Placeholders (`{side}`) are spoken as neutral words ("that", "they") because one file serves all fill-ins while the
  on-screen text fills real values.
- File naming `<intent>.<kind>.<n>.ogg` (e.g. `intents.door_close.success.2.ogg`, `auto.alarm.0.ogg`,
  `failures.meme.3.ogg`); `LINES.csv` (`id,text,speaker,status`).
- `VoiceBank` resolves by id, `_glitch` variant, or exact text; loads unimported oggs with
  `AudioStreamOggVorbis.load_from_file`. Glitchy variants when night >= 4.
- Missing clip -> short garble fallback.
- Phone voice was a human-style recorded voice, separate from the machine voice.

## Pitfalls (mistakes seen)

mixing voice settings across batches makes one machine sound like several.

## Verify

`assistant_check.gd` reports voice coverage per line id.

## Origin

FNAP. Source notes: REF §2.10 Voice generation, §2.11 Voice playback, §1.2.

---------------------------------------------------------------------------------------------------

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
