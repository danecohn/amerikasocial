---
id: animation-loop-policy-runtime
title: "Animation loop policy applied at runtime (imports from GLTFDocument skip editor import scripts)"
category: godot-engine
when: "Characters' clips should loop or play once; models may be loaded through GLTFDocument at runtime."
related: []
origin: Pickle's Pickle Shop
---

# Animation loop policy applied at runtime (imports from GLTFDocument skip editor import scripts)

**When to use:** Characters' clips should loop or play once; models may be loaded through GLTFDocument at runtime.

## Do this

Editor import scripts don't run on `GLTFDocument.generate_scene`, so apply a runtime policy: list ONE_SHOTS (jumpscare, door_retreat, light_flinch, serve, appear, fp_door_yank_L/R, fp_monitor_up/down, fp_lean_out_L/R, fp_dock, fp_undock, fp_get_up, fp_sit_down, fp_jumpscare_react, fp_death, fp_flashlight_dies) -> LOOP_NONE, everything else LOOP_LINEAR, over every AnimationLibrary. Then a data manifest `clips.json` (per character: clip -> {loop, length}, plus `walk_speed_mps`) overrides per clip (`ClipManifest.apply(id, anim_player)`, `is_looping()`, `walk_speed()`). Per-play: `play_clip_now()` sets loop_mode then plays immediately; looping ambient clips start on the next music bar via `MusicClock.on_next_bar` so idle motions sync with the soundtrack. Idle fallbacks list when `idle` is missing.

## Pitfalls (mistakes seen)

User saw no jumpscare animation; verification step afterwards confirmed every character (pickle, remi, dilly, banshee, golden_pickle) and fp_arms contain all required clips: idle, walk, jumpscare, door_peek, door_bang, door_retreat, listen, light_flinch, showcase + per-character specials (sing, powerout_sway, play_bass, serve, cove_hide, cove_peek, run, slump, appear) and arms (fp_idle, fp_run, door yanks, pant, hold breath, monitor up/down, lean L/R, flashlight shake, dock/undock).

## Verify

Script that loads every character GLB and asserts the required clip list via resolve_clip; prints missing.

## Origin

Pickle's Pickle Shop. Source notes: scripts/core/fnap_anim_import.gd, clip_manifest.gd, animatronic.gd L259-272, L404-422; STATE.md clips list; transcript summary sec.3 "Verified facts".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
