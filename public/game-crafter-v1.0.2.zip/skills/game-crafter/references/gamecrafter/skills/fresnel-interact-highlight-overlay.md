---
id: fresnel-interact-highlight-overlay
title: "Focus highlight via shared material_overlay fresnel shader built in code"
category: godot-engine
when: "Highlighting the focused interactable without assets."
related: []
origin: Caesarea
---

# Focus highlight via shared material_overlay fresnel shader built in code

**When to use:** Highlighting the focused interactable without assets.

## Do this

```glsl
shader_type spatial;
render_mode blend_add, unshaded, cull_back, depth_draw_never;
uniform vec4 glow_color : source_color = vec4(1.0, 0.78, 0.25, 1.0);
uniform float strength = 1.8;
void fragment() {
    float f = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 2.0);
    float pulse = 0.85 + 0.15 * sin(TIME * 4.0);
    float a = clamp(f * strength + 0.14, 0.0, 1.0) * pulse;
    ALBEDO = glow_color.rgb * a; ALPHA = a;
}
```
One cached ShaderMaterial (render_priority 10) applied as `material_overlay` to up to 48 MeshInstance3D under the root; previous overlay stored in meta `_interact_hl_prev` and restored on off (doesn't destroy the original material — not a "hide/swap" fix).

## Origin

Caesarea. Source notes: Caesarea/game/interaction/interact_highlight.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
