---
id: mistake-demo-player-gaps
title: "Automated demo player failures found while verifying games 2-3"
category: mistake
when: "Building an autoplay/demo bot to verify full runs of action games."
related: []
origin: Roguelike series
---

# Automated demo player failures found while verifying games 2-3

**When to use:** Building an autoplay/demo bot to verify full runs of action games.

## Do this

A verification bot must (1) aim thrown weapons at the target position, (2) seek out idle/dormant enemies, (3) detect being stuck and steer away.

## What happened, root cause, fix, prevention

- SAINT MARROW'S: thrown weapon did not land on the target/cursor -> fixed so throws land where aimed; demo stood still when enemies were dormant -> demo now walks to dormant enemies (rooms never cleared otherwise).
- SALT MINE 9: demo player got stuck on obstacles -> kit fix: demo un-sticks itself (detect low displacement over time, then sidestep/random direction).
- Prevention: fix bot problems in the shared kit so later games inherit them; always verify with `--demo=1 --auto=1 --god=1 --skipevent=1 --press=1.2` to a RUN_END win.

## Verify

autoplay log reaches RUN_END for every game in the series.

## Origin

Roguelike series. Source notes: WIP_BIBLE_AND_MANIFEST.md L7, L10.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
