---
id: bitmap-pixel-font-to-ttf
title: "Original 5x7 pixel font table compiled to TTF with fontTools (licence-free)"
category: pixel-art-2d
when: "Need a custom pixel font (no licence issues) usable by Godot Labels and Pillow text."
related: []
origin: Roguelike series
---

# Original 5x7 pixel font table compiled to TTF with fontTools (licence-free)

**When to use:** Need a custom pixel font (no licence issues) usable by Godot Labels and Pillow text.

## Do this

- Glyph table: dict char -> 7 strings of 5 '0'/'1' (A-Z, 0-9, `. , : ; ! ? ' " - + / ( ) [ ] % # & * = < > _ @ |` and space). Lowercase maps to the uppercase drawings (all-caps game UI).
- Each '1' becomes a closed contour (square or styled cell) of UNIT=100 font units; UPM 1000 -> at font_size 10 one cell = exactly 1 screen pixel; at 20/30/40 cells are 2/3/4 px.
```python
y = (6 - r) * UNIT; x = ci * UNIT + UNIT // 2            # row 6 sits on the baseline; half-cell left bearing
cell(pen, x - pad, y - pad, UNIT + 2*pad, shape, chamfer)
advance = (w + 1) * UNIT + tracking + (UNIT if skew else 0)   # 1 cell letter-spacing
fb = FontBuilder(1000, isTTF=True); fb.setupGlyphOrder(order); fb.setupCharacterMap({ord(ch): name})
fb.setupGlyf(glyphs); fb.setupHorizontalMetrics(metrics)
ASC = 7*UNIT + 80; DESC = 250 if drip else 150
fb.setupHorizontalHeader(ascent=ASC, descent=-DESC)
fb.setupNameTable({"familyName": family, "styleName": "Regular", "copyright": "Original design. ..."})
fb.setupOS2(sTypoAscender=ASC, sTypoDescender=-DESC, usWinAscent=ASC, usWinDescent=DESC); fb.setupPost(); fb.save(path)
```
- Glyph names `uniXXXX` (space = "space"), `.notdef` empty with advance 600. Glyph order must include every name.
- Body variants: base; italic (shift top 3 rows right 1 cell, width 6); bold (OR each pixel with its left neighbour, width 6); wide (each column doubled, width 10); serif (I/T-like glyphs get full-width top/bottom bars). Cell shapes: square, chamfer (octagon, `c` units cut), round (c = size//3), diamond, dot (70% square), stitch (55% square). Extras: `pad` (cells overlap -> blockier display font), `tracking`, `skew` (italic slant in units per row), `drip` (random 1-2 cell drips under bottom-row pixels).
- Shipped pairs: LAST LAMP "Lamplight" body base/square + title bold/chamfer 24, pad 4, tracking 40; SAINT MARROW'S "Hush" body base/round + title wide/round pad 4 tracking 20; SALT MINE 9 "Rivet" = same as Lamp; WARD SEVEN "Chart" body base/square + title wide/chamfer 24 pad 4 tracking 30.
- Sizes used in Godot: body 10 everywhere; title 20/30/40 (title screen 40 for 1 line, 30 for 2 lines; banners shrink 30->20->10 until width <= W-24).

## Pitfalls (mistakes seen)

- `LOW = {"g": ...}` lowercase g defined but never used; lowercase is uppercase. Fine for all-caps UI, but dialogue with lowercase shows caps - write all UI text uppercase on purpose.
- Dead code in `variant()` ("serif" first `if ... pass`, bold `if False`). Harmless; clean when porting.
- Missing glyphs (e.g. accented letters, curly quotes, em dash) render as empty .notdef -> keep content ASCII or add glyphs.

## Verify

`ImageFont.truetype(body.ttf, 10).getlength("A") == 6`; render a pangram at size 10 with Pillow fontmode "1" and check crisp single-pixel strokes.

## Origin

Roguelike series. Source notes: _tools/fonts.py (all 152 lines); games/*/spec.py "fonts"; title.gd lines 26-40; hud.gd banner().

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
