---
id: known-gaps-honesty-doc
title: "docs/KNOWN_GAPS.md and itch page copy that state exactly what is placeholder"
category: promo-marketing
when: "Packaging any WIP/vertical slice; writing store copy."
related: []
origin: Caesarea
---

# docs/KNOWN_GAPS.md and itch page copy that state exactly what is placeholder

**When to use:** Packaging any WIP/vertical slice; writing store copy.

## Do this

- Open with: "This is a work-in-progress slice of <Game>, not a finished game."
- List plainly: which characters are proxies, which assets are stand-ins (labeled in-game), missing systems ("Combat, items, and skills are data only. There is no health bar."), missing audio beds, unplayed cutscenes, acts not in the build, non-functional buttons ("The title Settings button does nothing"), platform caveats ("Linux zip was packed on Windows, so after unzip the binary may need `chmod +x`"; "not launched as shipped games on Linux or macOS"), "Nothing was uploaded."
- ITCH_PAGE.md draft: Short description ("A work-in-progress slice of a 3D Roman wasteland RPG. Not a finished game."), About, What you can do, What you should not expect (same gaps), Controls table, Downloads (zip names, chmod note), Credits (single studio line). "Read KNOWN_GAPS.md before treating any screenshot as a finished scene."

## Pitfalls (mistakes seen)

Claiming finished scenes from screenshots; mitigated by explicit gaps.

## Verify

Every gap item corresponds to a MANIFEST "not done" line.

## Origin

Caesarea. Source notes: docs/KNOWN_GAPS.md, docs/ITCH_PAGE.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
