# Tool: build_release.sh

**Purpose:** Export all platform presets and zip them with correct executable bits (Linux/macOS).

**Usage:** `bash build_release.sh <project_dir> <out_dir> <GameName>`

**Skill:** see `skills/export-presets-four-platforms.md`

**Extract:** save the block below as `build_release.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Build per-platform release zips headless (Linux/macOS host or cloud container). Exec bits preserved (chmod 755 + zip -y).
# Usage: build_release.sh <project_dir> <out_dir> <ProductName> [extras_dir]
#   env: GODOT=godot  PRESETS="Windows Desktop:win:Windows;Linux:lin:Linux;macOS:mac:Mac"  (preset:key:ZipSuffix)
# extras_dir (optional) is copied into every zip (README.txt, credits.txt, Soundtrack/ ...).
# NOTE the 30 MB-per-file PC-bridge limit: big zips built in a cloud container cannot be pushed to the user's PC; build ON the PC (build_release.ps1).
set -euo pipefail
P="${1:?project}"; OUT="${2:?out dir}"; N="${3:?ProductName}"; X="${4:-}"; GODOT="${GODOT:-godot}"
PRESETS="${PRESETS:-Windows Desktop:win:Windows;Linux:lin:Linux;macOS:mac:Mac}"
STAGE="$(mktemp -d)"; mkdir -p "$OUT"
"$GODOT" --headless --path "$P" --import --quit
IFS=';' read -ra LIST <<< "$PRESETS"
for item in "${LIST[@]}"; do
  IFS=':' read -r preset key suffix <<< "$item"; D="$STAGE/$key/$N"; mkdir -p "$D"
  case "$key" in
    win*) "$GODOT" --headless --path "$P" --export-release "$preset" "$D/$N.exe"; [ -f "$D/$N.exe" ] || { echo "FAIL $preset: exe not produced"; exit 3; };;
    lin*) "$GODOT" --headless --path "$P" --export-release "$preset" "$D/$N.x86_64"; chmod 755 "$D/$N.x86_64";;
    mac*) "$GODOT" --headless --path "$P" --export-release "$preset" "$STAGE/$N-mac.zip"; (cd "$D" && unzip -q "$STAGE/$N-mac.zip");;
  esac
  [ -n "$X" ] && cp -r "$X"/. "$D"/
  rm -f "$OUT/${N}_${suffix}.zip"; (cd "$STAGE/$key" && zip -qry -9 "$OUT/${N}_${suffix}.zip" "$N")
done
ls -la "$OUT"; rm -rf "$STAGE"
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
