---
id: camera-feeds-separate-render-layer
title: "Security-camera feeds on their own render layer with their own light/exposure"
category: 3d-lighting-horror
when: "Building in-game monitors/camera feeds while the player view must stay dark."
related: []
origin: FNAP
---

# Security-camera feeds on their own render layer with their own light/exposure

**When to use:** Building in-game monitors/camera feeds while the player view must stay dark.

## Do this

- Put feed-only lights on a separate render layer (`light.layers` / camera `cull_mask`), render feeds with a SubViewport camera that has its own Environment/exposure so feeds are readable while the player's view stays dark.
- Camera nodes in models named `Cam_<id>`, spots `CamSpot_<id>`.
- Overlay the feed with the CRT static shader (crt-static-overlay-shader).
- Full algorithm lives in `references/fnap-project-reference.md` sec 2.4 (not part of this harvest).
- Exception to the hide audit: `cull_mask`/layers used deliberately for feeds must be justified in the audit.

## Pitfalls (mistakes seen)

global brightening to make feeds readable also lit the halls (M12).

## Verify

screenshot of a feed (readable) and of the hall from the office (dark) in the same build.

## Origin

FNAP. Source notes: S line 24; G line 39 (M12); L §2.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
