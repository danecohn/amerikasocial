---
id: fnaf-rare-swaps
title: "Rare camera swaps / easter eggs (posters, newspapers, "IT'S ME")"
category: gameplay-systems
when: "Adding rare visual variants to camera rooms for replay creepiness and lore drip."
related: [mistake-curtain-morph-all-weights-one]
origin: FNAP
---

# Rare camera swaps / easter eggs (posters, newspapers, "IT'S ME")

**When to use:** Adding rare visual variants to camera rooms for replay creepiness and lore drip.

## Do this

- 3D: `PosterSwaps.SWAPS` const: cam -> list of `{id, rare[], normal[]}`. 6% per camera roll, ONE roll per camera, split
  into equal bands per variant so at most one shows. `on_camera()` resets then applies; reset on monitor lower and on
  camera change. Swaps are nodes baked into room GLBs, hidden by default (`AUTHORED_HIDDEN` list + node extra
  `hidden_by_default`). Emits `swapped(id)` -> poster squeak. `force(id)` is the test hook.
- 2D: "roll once each time the player switches to the camera, only when the room would show its empty image".
- FNAP swap list: 1C "IT'S ME" sign; 2B poster easter egg and Golden Pickle poster (doubles as hallucination trigger);
  4A "IT'S ME" on the wall, posters swapped for crying-kids drawings; 4B newspaper clippings 1-4 (lore drip);
  5 heads staring at the camera; 5 Remi face filling the lens (rare stare).
- Rare-swap images reuse the room's empty plate with one detail changed (0.2%-12.1% of pixels differ) - cheap to make.

## Pitfalls (mistakes seen)

Hidden-by-default nodes must be special-cased if they are not swaps (see mistake-curtain-morph-all-weights-one:
the `Curtain` mesh shipped `hidden_by_default` but must be visible).

## Verify

`tools/poster_swaps_test.gd` renders normal + forced-swap screenshots per case.

## Origin

FNAP. Source notes: REF §2.8, §2.7; STATEMAP lines 31, 46-47, 58-59, 65-68, 73, 75, 87-88, 387-397.

---------------------------------------------------------------------------------------------------

## Related skills

- [mistake-curtain-morph-all-weights-one](mistake-curtain-morph-all-weights-one.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
