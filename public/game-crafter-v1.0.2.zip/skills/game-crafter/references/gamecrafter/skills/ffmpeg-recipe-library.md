---
id: ffmpeg-recipe-library
title: "ffmpeg recipes for game reels (ffmpeg_recipes.sh)"
category: promo-marketing
when: "Building trailers/reels from captured frames/stills."
related: []
origin: FNAP
---

# ffmpeg recipes for game reels (ffmpeg_recipes.sh)

**When to use:** Building trailers/reels from captured frames/stills.

## Do this

`source ffmpeg_recipes.sh`; `ffmpeg_recipes.sh selftest` builds test clips and prints `SELFTEST_OK`. All encode `ENC="-c:v libx264 -crf 19 -preset fast -pix_fmt yuv420p -r 30"` so concat can `-c copy`. `GRADE="noise=alls=10:allf=t+u,vignette=PI/5,eq=contrast=1.06:saturation=1.05"`.
```bash
png_seq_to_clip(){ local out=$1 pat=$2 st=$3 n=$4 fps=$5 wh=${6:-1920:1080}
  ffmpeg -v error -y -framerate "$fps" -start_number "$st" -i "$pat" -vf "scale=$wh:flags=lanczos,fps=30,$GRADE,format=yuv420p" -t "$(python3 -c "print($n/$fps)")" $ENC "$out"; }
still_kenburns(){ local out=$1 img=$2 sec=$3 z=${4:-0.0007} wh=${5:-1920x1080}
  ffmpeg -v error -y -loop 1 -framerate 30 -i "$img" -t "$sec" -vf "scale=2400:-1,zoompan=z='1.0+${z}*on':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=$wh:fps=30,$GRADE,format=yuv420p" $ENC "$out"; }
vertical_from_landscape(){ ffmpeg -v error -y -i "$2" -filter_complex "[0:v]split[a][b];[a]scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,boxblur=40:8,eq=brightness=-0.18[bg];[b]scale=-2:1080,crop=1080:1080[fg];[bg][fg]overlay=0:420,format=yuv420p[v]" -map "[v]" -map 0:a? $ENC -c:a aac "$1"; }
concat_clips(){ local out=$1; shift; : > /tmp/gm_concat.txt; for f in "$@"; do echo "file '$(realpath "$f")'" >> /tmp/gm_concat.txt; done
  ffmpeg -v error -y -f concat -safe 0 -i /tmp/gm_concat.txt -c copy "$out"; }
mux_audio(){ ffmpeg -v error -y -i "$2" -i "$3" -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest "$1"; }
loudness_check(){ ffmpeg -hide_banner -nostats -i "$1" -filter_complex ebur128=peak=true -f null - 2>&1 | grep -E "I:|Peak:|LRA:" | tail -4; ffmpeg -hide_banner -i "$1" -af volumedetect -f null - 2>&1 | grep -E "max_volume|mean_volume"; }
contact_sheet(){ ffmpeg -v error -y -i "$1" -vf "fps=1/${3:-2},scale=320:-1,tile=6x4" -frames:v 1 "$2"; }
```
Ken Burns: pre-scale to 2400 wide so zoompan doesn't pixelate; `d=1` with `-loop 1` advances one step per input frame. Concat requires same codec/size/fps/pix_fmt.

## Pitfalls (mistakes seen)

Wrong clip length -> `-frames:v` counts OUTPUT frames after fps filter -> use `-t n/src_fps`.

## Verify

selftest; ffprobe durations; contact sheet viewed.

## Origin

FNAP. Source notes: game-promo-pipeline/scripts/ffmpeg_recipes.sh.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
