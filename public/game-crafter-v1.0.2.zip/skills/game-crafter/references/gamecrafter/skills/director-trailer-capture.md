---
id: director-trailer-capture
title: "Director autoload: scripted, cue-sheet-synced gameplay moments for trailers/reels"
category: promo-marketing
when: "Capturing trailer/reel footage of specific scary moments in sync with music, horizontal or vertical."
related: []
origin: Pickle's Pickle Shop
---

# Director autoload: scripted, cue-sheet-synced gameplay moments for trailers/reels

**When to use:** Capturing trailer/reel footage of specific scary moments in sync with music, horizontal or vertical.

## Do this

`--capture=<moment>` (pickle_eyes_4b, power_out, remi_flashlight, dilly_kitchen, banshee_run, golden_pickle, run_and_pant, assistant_fail, six_am, brine_run) with `--aspect=vertical|horizontal`, `--seed`, `--cues=<sheet.json>#<track>`. Director sets night per moment, loads office, marks all actors `scripted`, places them, hides debug, HUD capture mode (portrait layout repositions every HUD element for 1080x1920; monitor/assistant `apply_portrait`), freezes power drain and clock. Each moment is an async script with `await until("cue_name", default_seconds)` calls (e.g. Dilly: monitor_up 0.5, silence 4.0, monitor_down 5.5, sprint 6.0, lean_out 7.0, reveal 7.4, approach 8.2, door_slam 9.0, door_bang 10.0/10.9/11.8, end 13). Cue sheets (JSON, many tolerated shapes, fps) from music analysis give exact hit times; MOMENT_CLIMAX shifts defaults so the climax lands on the music "hit". Cue audio plays on the Music bus. Prints state summary at end then quits. Combined with Movie Maker / capture for frame-exact footage; RNG seeded for reproducibility.

## Verify

Render each moment; climax frame matches cue time (printed "done at X s (frame N)").

## Origin

Pickle's Pickle Shop. Source notes: scripts/director/director.gd L1-805.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
