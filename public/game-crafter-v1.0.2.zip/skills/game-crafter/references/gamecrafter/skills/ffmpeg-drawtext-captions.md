---
id: ffmpeg-drawtext-captions
title: "Animated captions with drawtext (and its escaping traps)"
category: promo-marketing
when: "Kinetic text on trailers."
related: []
origin: FNAP
---

# Animated captions with drawtext (and its escaping traps)

**When to use:** Kinetic text on trailers.

## Do this

caption with 0.2 s fade in/out:
```bash
caption(){ local out=$1 in=$2 txt=$3 t0=$4 t1=$5 y=${6:-h-220} sz=${7:-84}
  txt=${txt//:/\\:}; txt=${txt//\'/’}
  ffmpeg -v error -y -i "$in" -vf "drawtext=fontfile=$FONT:expansion=none:text='$txt':fontsize=$sz:fontcolor=white:borderw=4:bordercolor=black@0.9:x=(w-text_w)/2:y=$y:enable='between(t,$t0,$t1)':alpha='if(lt(t,$t0),0,if(lt(t,$t0+0.2),(t-$t0)/0.2,if(lt(t,$t1-0.2),1,max(0,($t1-t)/0.2))))'" -c:v libx264 -crf 19 -preset fast -pix_fmt yuv420p -c:a copy "$out"; }
```
Multiple captions: join several drawtext filters with commas in one -vf (assemble.py `dt()` builder adds `shadowx=3:shadowy=3`, `borderw=max(3,size//18)`, cream 0xF4EFE6). Vertical: shorter lines/smaller size (72 if >20 chars else 88) at y=1560, title at y=250 and studio at y=345.

## Pitfalls (mistakes seen)

Literal `:` ends the option -> write `\:`. Apostrophe ends quoted text -> typographic ’. `%` errors ("Stray %" on "100%") -> `expansion=none`.

## Verify

contact sheet shows text.

## Origin

FNAP. Source notes: ffmpeg_recipes.sh caption; templates/fnap_examples/assemble.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
