---
id: mistake-capture-before-settle
title: "Lighting/TAA not settled in shots"
category: mistake
when: "Taking screenshots after a scene/light change."
related: []
origin: FNAP
---

# Lighting/TAA not settled in shots

**When to use:** Taking screenshots after a scene/light change.

## Do this

Wait >= 1 s (2.4 s for flashlight reveals) before `frame_post_draw` capture.

## What happened, root cause, fix, prevention

Symptom: half-lit/ghosted shots. Fix above.

## Verify

Open PNG.

## Origin

FNAP. Source notes: mistakes-log.md M57.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
