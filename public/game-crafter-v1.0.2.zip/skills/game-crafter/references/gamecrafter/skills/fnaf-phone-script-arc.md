---
id: fnaf-phone-script-arc
title: "Writing the nightly phone calls (one instruction, one unfinished thing)"
category: narrative-dialogue
when: "Writing the phone-guy calls for nights 1-5."
related: [mistake-phone-audio-drift-from-script]
origin: FNAP
---

# Writing the nightly phone calls (one instruction, one unfinished thing)

**When to use:** Writing the phone-guy calls for nights 1-5.

## Do this

- Rule: "Each night [the caller] gives one helpful instruction and refuses to finish one thing." The voice never
  explains the whole mystery.
- Length shrinks as dread grows: written estimates N1 ~105 s, N2 ~80, N3 ~70, N4 ~55, N5 ~30 (~835 words total).
  Recorded WAVs were 108.05 / 67.95 / 54.29 / 41.49 / 21.52 s.
- Stage markers in scripts: `(pause)`, `(quiet)`, `(the line cuts)`. The game's subtitle splitter turns them into silent
  beats.
- Voice direction: "tired and clear: contractions, full sentences, no stutter." Read as written.
- Night-by-night content pattern (FNAP):
  - N1: friendly handover + joke; mechanics (stand, walk to door, light/flashlight; doors cost power that never
    returns); cast names; terminal unreliable; "If one of them ever gets all the way into the office, then I don't want
    to say what happens"; caller claims he quit Friday and is at his kitchen table.
  - N2: the runner enemy rules (curtain stages, which door, bangs cost power); "Don't ask the terminal to do it for you.
    It's too slow for her."; first lore crack (cove roped off "for repairs. I used to say that too.").
  - N3: watched-freeze enemy + audio-only enemy, both to the right door; contradiction ("I walked out the east hall last
    night... Friday. I meant Friday.").
  - N4: the hallucination and its single counter ("lift the monitor"); caller is scared; "Whatever you do, don't"
    (the line cuts).
  - N5: 30 s; "Thank you for picking up all week. Not everyone did."; final instruction "Leave through the front door,
    and don't come back for me." (the line cuts).
- Every mechanic the player needs is said out loud by the caller on/before the night it matters (mechanics-as-fiction).

## Pitfalls (mistakes seen)

mistake-phone-audio-drift-from-script.

## Verify

Fact ledger (fnaf-fact-ledger-per-night) row per night has exactly one "helpful instruction" and one "left
unfinished".

## Origin

FNAP. Source notes: CALLS entire; BIBLE "Rules the Story Keeps", "Tone Notes"; REF §3.5 (wav durations), §7 (word count).

## Related skills

- [mistake-phone-audio-drift-from-script](mistake-phone-audio-drift-from-script.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
