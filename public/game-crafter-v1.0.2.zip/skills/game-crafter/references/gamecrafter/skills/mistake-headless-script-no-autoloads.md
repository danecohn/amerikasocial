---
id: mistake-headless-script-no-autoloads
title: "Headless `-s` script can't see autoloads"
category: mistake
when: "Writing headless checks."
related: []
origin: FNAP
---

# Headless `-s` script can't see autoloads

**When to use:** Writing headless checks.

## Do this

`-s` SceneTree scripts start before autoloads attach. Write checks as `.tscn` + script, run `godot --headless --path <proj> res://tools/check.tscn`; print PASS/FAIL; `get_tree().quit(code)`.

## What happened, root cause, fix, prevention

Symptom: autoload null in check. Fix above.

## Verify

Check exits with intended code.

## Origin

FNAP. Source notes: mistakes-log.md M24.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
