---
id: mistake-cta-over-end-card-art
title: "Titles on a burned-in end card covered the art"
category: mistake
when: "Placing CTA text."
related: []
origin: FNAP
---

# Titles on a burned-in end card covered the art

**When to use:** Placing CTA text.

## Do this

Put CTA over a plain frame or the game-over screen; check layout.

## What happened, root cause, fix, prevention

Symptom: text over art. Fix above.

## Verify

Open frame.

## Origin

FNAP. Source notes: mistakes-log.md M68.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
