---
id: itch-page-copy
title: "itch.io page copy template"
category: promo-marketing
when: "Writing itch.io description/tagline/uploads."
related: []
origin: FNAP
---

# itch.io page copy template

**When to use:** Writing itch.io description/tagline/uploads.

## Do this

Short description/tagline (shown when link shared; don't repeat title): one hook sentence, genre + stakes (e.g. "Survive five nights in a shop where the band never stops performing."). Body (Markdown): hook -> what you do (3-4 lines) -> FEATURES bullets (only things in the build) -> platforms (Windows, Mac, Linux, Windows ARM) -> controls -> credits/studio -> socials. Mention Gatekeeper right-click on mac and SmartScreen "Run anyway" on Windows for unsigned builds. Screenshots 3-5 best. Cover 630x500 (+1260x1000), banner 1920x480. Upload files `<Product>_{Windows,Mac,Linux,Windows_ARM64}.zip` with platform tags per file. Do NOT upload unless asked.

## Pitfalls (mistakes seen)

Listing features not in the build.

## Verify

every feature exists.

## Origin

FNAP. Source notes: references/copy-templates.md "itch.io".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
