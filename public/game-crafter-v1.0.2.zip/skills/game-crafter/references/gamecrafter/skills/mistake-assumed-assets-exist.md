---
id: mistake-assumed-assets-exist
title: "Room GLBs missing from recovered PCK; nobody noticed"
category: mistake
when: "Starting from recovered/partial assets; writing code depending on asset files."
related: []
origin: FNAP
---

# Room GLBs missing from recovered PCK; nobody noticed

**When to use:** Starting from recovered/partial assets; writing code depending on asset files.

## Do this

Verify asset presence before writing dependent code (`glb_check.gd`, `loader_check.gd`).

## What happened, root cause, fix, prevention

Symptom: every camera room stayed a coloured box. Root cause: room GLBs not in the first recovered PCK; code assumed assets exist. Fix: asset presence check scripts; missing asset -> visible/log warning. Prevention: loud placeholders; manifest of required assets. Detection: glb_check.

## Verify

glb_check lists every required file present.

## Origin

FNAP. Source notes: mistakes-log.md M07.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
