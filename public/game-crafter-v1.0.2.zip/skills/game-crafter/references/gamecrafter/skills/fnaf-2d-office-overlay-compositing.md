---
id: fnaf-2d-office-overlay-compositing
title: "2D office: plate + door overlays + one-light-at-a-time rules"
category: pixel-art-2d
when: "Compositing the office view from stills in any 2D engine."
related: [mistake-character-plate-under-shut-door]
origin: FNAP
---

# 2D office: plate + door overlays + one-light-at-a-time rules

**When to use:** Compositing the office view from stills in any 2D engine.

## Do this

- Plates: empty (doors open, lights off), left-light-empty, left-remi, left-pickle, left-banshee (end of run),
  right-light-empty, right-dilly, right-pickle, golden-pickle slumped, power-out black, power-out eyes.
- Door shut = transparent 1280x720 overlay at (0,0) on top of any plate (`office-door-left-closed.png`,
  `office-door-right-closed.png`). Baked alternatives exist (empty + overlays, within a few levels/pixel) only if you
  skip overlays.
- Rules: under a shut door use the matching `*-light-empty` plate if that light is on, else the empty plate (or the other
  side's light plate if that side's door is open). NEVER a character plate under a shut door on that side
  ("Dilly leans past the right door frame, so her jar would show").
- Only one door light at a time (switching one on switches the other off) -> no "both lights" plate needed.
- Power out: hide both door overlays (doors lift); panels -> `panel-*-dead.png`.
- Selection sketch:
  ```python
  def office_layers(s):
      if s.power_out:
          return ["office-power-out-eyes" if s.eyes_frame else "office-power-out-black"]
      if s.golden_in_office: plate = "office-seated-golden-pickle"
      elif s.light == "L":
          plate = "office-seated-left-light-empty" if (s.door_L or not s.at_L) else f"office-seated-left-{s.at_L}"
      elif s.light == "R":
          plate = "office-seated-right-light-empty" if (s.door_R or not s.at_R) else f"office-seated-right-{s.at_R}"
      else: plate = "office-seated-empty"
      return [plate] + (["office-door-left-closed"] if s.door_L else []) + (["office-door-right-closed"] if s.door_R else [])
  ```
- Panel sprites per side (96x250): door open/closed x light on/off + dead; or separate 70x86 buttons.

## Pitfalls (mistakes seen)

mistake-character-plate-under-shut-door.

## Verify

Render every door/light/occupant combination to a contact sheet and inspect.

## Origin

FNAP. Source notes: STATEMAP lines 91-127.

## Related skills

- [mistake-character-plate-under-shut-door](mistake-character-plate-under-shut-door.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
