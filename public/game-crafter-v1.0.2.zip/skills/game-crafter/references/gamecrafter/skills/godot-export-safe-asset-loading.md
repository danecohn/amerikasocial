---
id: godot-export-safe-asset-loading
title: "Export-safe asset loading in Godot 4 (packed_name + load, never FileAccess on res://)"
category: godot-engine
when: "Writing any GDScript that lists a res:// folder, checks whether an asset exists, or loads a model/texture/audio at runtime; any report of 'works in the editor but not in the build'."
related: [godot-include-filter-raw-data, mistake-exported-build-shows-placeholders]
origin: FNAP
---

# Export-safe asset loading in Godot 4 (packed_name + load, never FileAccess on res://)

**When to use:** Writing any GDScript that lists a res:// folder, checks whether an asset exists, or loads a model/texture/audio at runtime; any report of "works in the editor but not in the build".

## Do this

- In an EXPORTED build the PCK holds imported resources (`.ctex`, `.scn`, ...) behind `res://x.glb.import` / `res://x.glb.remap` entries. The raw `.glb/.png/.wav/.ogg` are NOT in the pack.
- So `DirAccess.get_files()` returns `office.glb.import` / `office.glb.remap`, not `office.glb`; `FileAccess.file_exists()/open()` and `ProjectSettings.globalize_path()` on raw res:// assets fail in the export.
- Rules:
  1. Pass every directory-listing name through `packed_name()` (strip `.import`/`.remap`) before matching.
  2. Test existence with `ResourceLoader.exists(path)` and load with `load(path)`. `ResourceLoader.exists` is true for imported resources inside a pack; `FileAccess.file_exists` is true only for raw files that were actually included.
  3. Disk paths (`FileAccess`, `GLTFDocument.append_from_file`) are a dev-only FALLBACK, never the primary path.
  4. Textures: `var tex := load("res://x.png") as Texture2D; tex.get_width()` - never `Image.load_from_file(ProjectSettings.globalize_path(...))`.
  5. Audio: use imported audio + `load()`. `AudioStreamOggVorbis.load_from_file()` only works if the raw file is included via include_filter.
- Snippet (`NodeFinder.packed_name`):
  ```gdscript
  static func packed_name(file: String) -> String:
      if file.ends_with(".import") or file.ends_with(".remap"):
          return file.get_basename()
      return file
  # listing:
  for raw in da.get_files():
      var file := packed_name(raw)
  ```
- Existence check that works in both editor and pack (animatronic.gd):
  ```gdscript
  if not ResourceLoader.exists(path) and not FileAccess.file_exists(path): return   # 2nd test = dev disk fallback
  var packed := load(path) as PackedScene
  ```
- Non-resource data needs `include_filter` (see skill godot-include-filter-raw-data).

## Pitfalls (mistakes seen)

see mistake-exported-build-shows-placeholders (the FNAP release showed grey boxes and capsules because every "real model" check used raw-file APIs).

## Verify

`python3 godot-export-release/scripts/lint_export_safety.py <proj>` (flags FileAccess/globalize_path/DirAccess on res:// and raw data not in include_filter); `grep -rnE "FileAccess\.(file_exists|open)|globalize_path|Image\.load_from_file|load_from_file" scripts/` and justify every hit; run the export probe from a built pack (export-probe-template); screenshot the pack and look at it.

## Origin

FNAP. Source notes: S Non-negotiable 1 (line 9); G "Export / resource loading" (lines 5-10); L §2.1 (lines 51-80); T/godot_core/node_finder.gd lines 107-113.

## Related skills

- [godot-include-filter-raw-data](godot-include-filter-raw-data.md)
- [mistake-exported-build-shows-placeholders](mistake-exported-build-shows-placeholders.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
