---
id: fnaf-assistant-auto-mode
title: "Auto mode" helper that runs doors for you (badly), as pure testable logic"
category: ai-enemies
when: "An automated helper should make choices that get worse each night."
related: []
origin: FNAP
---

# Auto mode" helper that runs doors for you (badly), as pure testable logic

**When to use:** An automated helper should make choices that get worse each night.

## Do this

- `AssistantAuto.decide(night, hour, threat_l, threat_r, closed_l, closed_r, rng)` returns
  `{kind, side, close, line_id, line, face}`; kinds: correct / hold / wrong_door / open_bad / alarm / misreport /
  false_close / clear / idle.
- Probabilities from `AssistantAutoTune` Resource arrays indexed by night: check interval 14 s -> 7 s, failure 25% ->
  68%, false close 8% -> 40%.
- Costs power: extra usage bar + percent/sec base + per hour. Physically animates `DoorMotor_*`, `DoorLamp_*`,
  `AlarmLight_Spinner`, `AutoConsole` emissive.
- Pure `RefCounted` so `auto_mode_sim.gd` (SceneTree script) and the real office share the same numbers.

## Pitfalls (mistakes seen)

none.

## Verify

`auto_mode_sim.gd` nights 1-5 always_on vs smart.

## Origin

FNAP. Source notes: REF §2.11 Auto mode, §5.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
