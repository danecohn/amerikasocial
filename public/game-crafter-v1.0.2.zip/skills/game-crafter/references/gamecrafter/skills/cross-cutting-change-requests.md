---
id: cross-cutting-change-requests
title: "requests/<agent>.md — ask the owner instead of editing their file"
category: multi-agent
when: "An agent needs a change to project.godot, autoloads, input map, or another agent's script."
related: []
origin: Caesarea
---

# requests/<agent>.md — ask the owner instead of editing their file

**When to use:** An agent needs a change to project.godot, autoloads, input map, or another agent's script.

## Do this

- Append to `docs/handoff/requests/<yourname>.md`: what, why, exact patch. Release agent applies project.godot/autoload requests; owners or lead apply others. Contract changes also go to LOG.md.
- Real example: characters agent found `art_source/.gdignore` did NOT exist although the brief claimed it did, so Godot was importing every GLB/PNG under art_source (stale duplicate `.import` files). Request: "`touch art_source/.gdignore` (zero content)".

## Pitfalls (mistakes seen)

Brief stated a fact (".gdignore exists") that was false → duplicate imports and confusion. Prevention: agents verify brief claims about the filesystem (`ls -la art_source/.gdignore`) and file a request when wrong.

## Verify

Every request has a matching LOG entry when applied.

## Origin

Caesarea. Source notes: docs/handoff/requests/characters.md, TEAM.md "Cross-cutting requests".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
