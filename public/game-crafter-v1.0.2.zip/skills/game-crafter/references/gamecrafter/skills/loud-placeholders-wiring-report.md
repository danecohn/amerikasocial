---
id: loud-placeholders-wiring-report
title: "Placeholders allowed, silent placeholders forbidden (wiring report)"
category: gdscript-patterns
when: "Any code path that falls back to a placeholder mesh/sound/texture when the authored asset is missing."
related: [mistake-exported-build-shows-placeholders]
origin: FNAP
---

# Placeholders allowed, silent placeholders forbidden (wiring report)

**When to use:** Any code path that falls back to a placeholder mesh/sound/texture when the authored asset is missing.

## Do this

- Every authored asset gets a fallback so the game always runs, BUT the fallback must: (a) `push_warning(...)`, (b) appear in a wiring report listing `role -> real | PLACEHOLDER | missing`, (c) show in a visible debug/menu note.
- Never hide the node that something else drives (door rigs were bound to placeholder shutter boxes).
- Pattern for main scene: `var hero := ModelLoader.load_named(["hero"])`; if null -> `push_warning` + visible placeholder + `print("MAIN: PLACEHOLDER")`; else `print("MAIN: REAL MODEL hero")`.
- ModelLoader's own last line: `push_warning("ModelLoader: no model for %s - caller should fall back LOUDLY, never silently" % [stems])`.

## Pitfalls (mistakes seen)

Silent fallbacks made the export bug invisible until the user saw boxes (mistake-exported-build-shows-placeholders).

## Verify

Run game/pack and grep output for `PLACEHOLDER` / `WARNING`; wiring report shows all roles `real` before release.

## Origin

FNAP. Source notes: S Non-negotiable 2 (line 10); R step 3 (line 19); T/godot_core/model_loader.gd line 30.

## Related skills

- [mistake-exported-build-shows-placeholders](mistake-exported-build-shows-placeholders.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
