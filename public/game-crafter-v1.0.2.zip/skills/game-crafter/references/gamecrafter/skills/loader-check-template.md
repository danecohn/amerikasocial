---
id: loader-check-template
title: "loader_check.gd - prove every model the game asks for by name resolves"
category: testing-qa
when: "After adding/renaming models; release check."
related: []
origin: FNAP
---

# loader_check.gd - prove every model the game asks for by name resolves

**When to use:** After adding/renaming models; release check.

## Do this

```gdscript
extends SceneTree
# usage: godot --headless --path <proj> -s res://scripts/dev/loader_check.gd -- hero villain Room_1A office
func _init() -> void:
    var miss := 0
    for stem in OS.get_cmdline_user_args():
        var n := ModelLoader.load_named([stem])
        print("LOAD ", stem, " -> ", ("OK " + str(n.name)) if n else "MISSING")
        if n == null: miss += 1
        else: n.free()
    print("LOADER_DONE missing=", miss)
    quit(miss)
```
- exit code = number of missing models.

## Pitfalls (mistakes seen)

n/a.

## Verify

`LOADER_DONE missing=0`.

## Origin

FNAP. Source notes: T/godot_dev/loader_check.gd; L §5.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
