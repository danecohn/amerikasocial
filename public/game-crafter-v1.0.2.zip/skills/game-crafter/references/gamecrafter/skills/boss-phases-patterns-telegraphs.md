---
id: boss-phases-patterns-telegraphs
title: "Data-driven bosses: HP-threshold phases, pattern rotation, telegraphs, phase dialogue"
category: ai-enemies
when: "Designing bosses for a roguelike with minimal code."
related: []
origin: Roguelike series
---

# Data-driven bosses: HP-threshold phases, pattern rotation, telegraphs, phase dialogue

**When to use:** Designing bosses for a roguelike with minimal code.

## Do this

- Boss def: `phases: [{at: hp_fraction, gap: seconds, patterns: [{type,...}]}]`, `phase_lines: [[dialogue lines], ...]`, name, title, music, keep, speed, mem (default 25).
- Intro: 1.2s idle + 1.5s invulnerable; phase change when `hp/hp_max <= next.at`: pattern index reset, cd 1.2, 1.0s invuln (pulsing alpha), big ring+burst, shake 8, "boss_roar", clears ALL enemy bullets within 400, then `world.on_boss_phase` plays the phase's lines (player locked).
- Idle movement: approach if dist > keep+20, back off if < keep-25, else strafe.
- Patterns: aimed (n, spread, speed, homing), ring (n, speed; random offset), charge (0.8s wind with "!" text + warn, then 0.6s at speed*4.4), summon (n of enemy), slam (0.9s red telegraph circle drawn growing, then damage 2 within r + 10-bullet ring, shake 7), spiral (dur, turn rate, fire rate, 2 arms at 70 speed), rain (bullets fall from top at random x), teleport (fade out 0.5s, reappear >=60px from player).
- Bosses take 10% knockback, are always drawn with big HP bar at bottom of HUD (260px wide at y 205, danger colour, name above).
- After defeat: `BOSS_DEFEATED <id>` log, increment save boss_kills, clear bullets, music off, 1.6s wait, boss_defeat story beat; final floor boss -> `_end_run(true)`; otherwise 12 mem pickups and a door to Sanctuary.

## Pitfalls (mistakes seen)

none recorded.

## Verify

autorun log contains BOSS_DEFEATED for each floor boss.

## Origin

Roguelike series. Source notes: enemy.gd 92-109, 337-489; run.gd 309-324, 641-667, 686-692; hud.gd boss bar.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
