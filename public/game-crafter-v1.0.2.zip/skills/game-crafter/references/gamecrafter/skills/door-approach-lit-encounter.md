---
id: door-approach-lit-encounter
title: "Door encounter: lit approach with a fair response window, flashlight repel, banging"
category: ai-enemies
when: "FNAF-style door attackers."
related: []
origin: Pickle's Pickle Shop
---

# Door encounter: lit approach with a fair response window, flashlight repel, banging

**When to use:** FNAF-style door attackers.

## Do this

Character waits at its door room for `rand(3,6) * (1 - aggression/200)` s (`_stall_timer`). If the door is closed -> start banging (bang every 3.4 s, first after 1.2 s; give up after 2 bangs (3 for cove character, 1 if player holds breath) -> `retreat(retreat_rooms)` with `door_retreat` clip and `regroup_seconds`). If the player looks at the lit doorway (camera forward dot > 0.55) -> `begin_door_approach()`: walk 1.45 m inward over a 3.25 s window (delta clamped to 0.1 per frame so a hitch never eats the window), `door_peek` on arrival; if door closes during approach -> snap back and bang; Remi is repelled by holding the flashlight on his face for 0.7 s (light_flinch + retreat); at window end, if still open -> jumpscare. HUD status line tells the player: "HOLD FLASHLIGHT ON REMI — OR SHUT THE DOOR" / "SHUT THE DOOR — BACK AWAY". Closed door always refuses a jumpscare (`_closed_door_blocks` -> `refuse_closed_door`). Cove character drains power per bang with escalation 5.0.

## Pitfalls (mistakes seen)

"A hitch must not erase the window" -> clamp delta. "Door encounters own their deadline; route movement must not skip it" -> `_try_move` returns while at door room.

## Verify

patrol_sim / balance_regression headless runs; manual: close door mid-approach.

## Origin

Pickle's Pickle Shop. Source notes: animatronic.gd L77-127, L642-692; office_controller.gd L1093-1114, L1248-1267, L1799-1810.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
