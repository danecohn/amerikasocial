---
id: data-driven-story-conversion-pipeline
title: "Converting screenplay scripts (writer AI output) to dialogue/quest JSON for Godot"
category: narrative-dialogue
when: "A writer produced scripts in `[CHOICE]` / `{flag = value}` / `[IF flag]` / `[CHECK Skill N]` notation and the game needs data files."
related: []
origin: Caesarea
---

# Converting screenplay scripts (writer AI output) to dialogue/quest JSON for Godot

**When to use:** A writer produced scripts in `[CHOICE]` / `{flag = value}` / `[IF flag]` / `[CHECK Skill N]` notation and the game needs data files.

## Do this

- Mapping: `[CHOICE]` → `choices`; `{flag = value}` → `effects`; `[IF flag]` → `if` or `variants`; `[CHECK Speech 20]` → `check {skill, min}` + `fail_next`; `→ [NODE]` → `next`. Write one hand-converted reference file first (`q1_1_porta_subura.json`) and treat it as the spec.
- Converter emits a report (`tools/story_convert_report.txt`) one line per script scene: `P1A: dialogue p1a (24 nodes)`, `BOOT: cutscene`, `Q1.1-A: skipped (already staged; do not fire twice)`, plus a `DROPPED FLAGS` section. Scene IDs → snake ids (`Q1.4-B1` → `q1_4_b1`, `P6.1` → `p6_1`).
- Never convert a scene twice (an already staged file stays the source); record what stays design-only (appendices, advocate speeches folded into another file, thin wrapper scenes with 1–2 nodes) in the MANIFEST so nobody thinks content was lost.
- Cutscene slides as separate data (`data/cutscenes/boot.json`, `p2.json`) even if no player exists yet — say "unplayed".
- Quests: `{id, title, act, giver, location, summary, start_when, on_start, objectives[{id, text, complete_when?, hidden?, optional?, visible_when?, completed_by?}], complete_when: "all_required"|"manual"|cond, fail_when, on_complete, unlocks[]}`. Objective without `complete_when` completes explicitly (zone trigger or effect `objective_complete quest_1_1 reach_shelter`). Chain by `start_when` (1.3 and 1.4 wait for 1.2; 1.5 waits for both).
- Every new flag goes through the ledger generator; validate every file with `DialogueManager.validate` → "61 files, 0 issues".
- Data first: zones only start the conversations they need; "data on disk, not a scene you can walk" is reported honestly.

## Pitfalls (mistakes seen)

Python missing on the converting machine → design table not regenerated; new flags appended to schema JSON — flagged in LOG. Converting scenes already hand-staged would double-fire effects → converter skips them.

## Verify

QA suite: every dialogue validates, no duplicate ids, json id == filename (DialogueManager indexes by filename), every quest referenced by `quest_start|objective_complete X` exists, every `unlocks` target exists, every `DialogueManager.start("id")` in code points to an existing file, conditions contain no unknown ledger keys, objectives have `complete_when` or `completed_by`.

## Origin

Caesarea. Source notes: tools/story_convert_report.txt; MANIFEST "Story data" + "Now data"; design/08 §4.1; tests/qa/qa_test.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
