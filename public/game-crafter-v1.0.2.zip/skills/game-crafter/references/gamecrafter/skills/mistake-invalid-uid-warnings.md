---
id: mistake-invalid-uid-warnings
title: "invalid UID` warnings on import"
category: mistake
when: "Hand-written or recovered .tscn files."
related: []
origin: FNAP
---

# invalid UID` warnings on import

**When to use:** Hand-written or recovered .tscn files.

## Do this

Harmless; delete `uid=` attributes or let Godot re-save.

## What happened, root cause, fix, prevention

Symptom: warnings. Cause: stale `uid://`. Fix: ignore or strip.

## Verify

Import exit 0.

## Origin

FNAP. Source notes: mistakes-log.md M25.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
