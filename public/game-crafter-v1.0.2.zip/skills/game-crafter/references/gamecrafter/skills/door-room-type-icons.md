---
id: door-room-type-icons
title: "Room-choice door icons (16x16 badge = dark disc + coloured ring + icon)"
category: pixel-art-2d
when: "Roguelike door/room choice needs readable reward-type markers above doors."
related: []
origin: Roguelike series
---

# Room-choice door icons (16x16 badge = dark disc + coloured ring + icon)

**When to use:** Roguelike door/room choice needs readable reward-type markers above doors.

## Do this

- 10 frames 16x16: 0 combat (skull #c8c0b0), 1 boon (star #ffd36a), 2 heal (heart #e0304a), 3 memory (drop, accent), 4 event (bell #78b8ff), 5 elite (skull #ff9a30), 6 boss (crown, danger colour), 7 rest (moon #a8c0ff), 8 fragment (note #d8a8ff), 9 spare (ring).
- Badge: `ellipse((0,0,15,15), fill=(10,8,16,220), outline=ring colour)` then icon (12x12) composited at (2,2).
- The ring colour == icon colour gives instant colour-coding (gold star = gift, red heart = heal) as seen in SAINT MARROW'S screenshot above the doors.

## Pitfalls (mistakes seen)

badge fill alpha 220 is the only semi-transparent pixel set in the UI - fine on dark walls; on light walls it looks grey.

## Verify

door_icons.png 160x16.

## Origin

Roguelike series. Source notes: _tools/tiles.py lines 488-500; screenshot_02.png.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
