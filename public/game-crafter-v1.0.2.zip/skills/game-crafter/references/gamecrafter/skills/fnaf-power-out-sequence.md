---
id: fnaf-power-out-sequence
title: "Power-out sequence (doors jam, darkness, music box, final scare)"
category: gameplay-systems
when: "Implementing what happens at 0% power."
related: [fnaf-await-token-guard]
origin: FNAP
---

# Power-out sequence (doors jam, darkness, music box, final scare)

**When to use:** Implementing what happens at 0% power.

## Do this

- `_on_power_depleted` -> `_power_out_sequence` (await-based):
  1. all actives off, doors JAM (lift / cannot close), lights energy 0, fan blades spin down, `power-down` sfx (breaker
     clunk, sparks, fan and hum winding down), force player back to the desk.
  2. after rand 3-12 s: Pickle appears at the LEFT door with a flickering face OmniLight + music-box tune.
     Animation `powerout_sway` speed-matched to the tune: `speed = clip_len * round(tune / clip_len) / tune`
     (clip loops an integer number of times across the tune).
  3. 8-20 s later: fade to 0.92 black, then `trigger_jumpscare(pickle)`.
- Uses `await` + `Director.until(...)` so the SAME function is the live game and the scripted trailer shot.
- Audio assets: `power-down.wav`, `power-out-music-box.wav` (minor-key waltz that slows as it plays),
  `power-out-music-box-loop.wav` (same waltz at steady tempo, 24 s seamless loop for longer outs).
- 2D REBUILD version: `office-power-out-black.png <-> office-power-out-eyes.png` (alternate while music box plays) ->
  black -> `jumpscare-pickle-power-out.png` (same render as normal Pickle scare, re-graded darker/blue). Door overlays
  hidden (doors lift); door panels show `panel-*-dead.png`.

## Pitfalls (mistakes seen)

Any await chain must be token-guarded (fnaf-await-token-guard) so a scene change mid-sequence doesn't fire
a jumpscare in the menu.

## Verify

`--fnap-night=1` + `debug_drain_power` key (debug build) -> sequence completes; Director moment `power_out`.

## Origin

FNAP. Source notes: REF §2.3 "Power out sequence", §2.16; STATEMAP lines 103-104, 126, 157-161, 267-269.

## Related skills

- [fnaf-await-token-guard](fnaf-await-token-guard.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
