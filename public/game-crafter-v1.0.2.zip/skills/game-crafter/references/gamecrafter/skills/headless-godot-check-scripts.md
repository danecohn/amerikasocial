---
id: headless-godot-check-scripts
title: "One-line shell helpers: script check, autoplay log grep, screenshot"
category: testing-qa
when: "Iterating on a Godot project in a cloud container without a display."
related: []
origin: Roguelike series
---

# One-line shell helpers: script check, autoplay log grep, screenshot

**When to use:** Iterating on a Godot project in a cloud container without a display.

## Do this

- Compile/script check: `cd P && timeout 120 godot --headless --path . --quit-after 2 2>&1 | grep -E "SCRIPT ERROR|at: |ERROR" | grep -v "Failed to compile depended" | head -30` (chk.sh).
- Import once before running: `[ -d "$P/.godot" ] || (cd "$P" && timeout 300 godot --headless --path . --import --quit)`.
- Autoplay under Xvfb (autorun.sh): `bash godot_xvfb.sh -r 384x216 -t <secs> -l /tmp/auto.log -- --path "$P" --rendering-driver opengl3 -- <user args>`; then `grep -E "ROOM |BOSS|RUN_END|SCRIPT ERROR|ERROR:|PLACEHOLDER|at: " | grep -v "ERR_CANT_OPEN\|status < 0"`.
- Screenshot (shot.sh): same wrapper with user arg `--shot=<out.png>`; game prints `SHOT_OK`; grep `SHOT_OK|SCRIPT ERROR|ERROR|PLACEHOLDER|WIRING`. Default timeout 240 s (`TMO` env).
- The kit prints greppable markers: `ROOM`, `BOSS`, `RUN_END`, `PLACEHOLDER missing ...`, `WIRING missing_art=0`, `SHOT_OK`.
- Demo/autoplay flags used for a full winning run: `--demo=1 --auto=1 --god=1 --skipevent=1 --press=1.2` (user args after the second `--`).
- Use `--rendering-driver opengl3` under Xvfb for capture; native capture at 384x216 then upscale.

## Pitfalls (mistakes seen)

grep filters hide known-benign noise (`Failed to compile depended`, `ERR_CANT_OPEN`, `status < 0`) - keep the filter list short or real errors get hidden.

## Verify

zero SCRIPT ERROR lines; RUN_END reached.

## Origin

Roguelike series. Source notes: _tools/chk.sh, autorun.sh, shot.sh; WIP_BIBLE_AND_MANIFEST.md Game 2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
