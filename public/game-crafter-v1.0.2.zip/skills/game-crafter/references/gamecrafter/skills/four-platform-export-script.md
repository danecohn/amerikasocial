---
id: four-platform-export-script
title: "Scripted Godot export of Windows x64, Windows ARM64, Linux, macOS with fail-fast"
category: export-release
when: "Producing release builds for all desktop platforms from a cloud Linux box."
related: [mistake-doc-vs-code-split-size]
origin: Roguelike series
---

# Scripted Godot export of Windows x64, Windows ARM64, Linux, macOS with fail-fast

**When to use:** Producing release builds for all desktop platforms from a cloud Linux box.

## Do this

- `release.py <slug> "<Product Name>" <out_dir>`; jobs: ("Windows Desktop", exports/win64/<slug>.exe, "Windows_x64"), ("Windows ARM64", exports/winarm/<slug>.exe, "Windows_ARM64"), ("Linux", exports/linux/<slug>.x86_64, "Linux"), ("macOS", exports/mac/<slug>-mac.zip, "Mac").
- Always run `godot --headless --path P --import --quit` first (timeout 300) so .godot/imported exists, then for each preset `godot --headless --path P --export-release "<preset>" <path>` (timeout 500), check the output file exists, print size; on missing file print last 800 chars of stdout/stderr and exit 1. Do not trust the return code alone.
- `SKIP_EXPORT=1` env re-packages zips from existing exports without re-exporting (fast iteration on README/soundtrack changes).
- macOS export target is a .zip (Godot builds the .app inside); keep it as-is.
- Typical sizes (embedded pck, ~10 MB of assets): Windows x64 zip ~57 MB, ARM64 ~48 MB, Linux ~47.6 MB, Mac universal ~79 MB.

## Pitfalls (mistakes seen)

docstring says "split >29MB parts" but code uses 20,000,000 bytes - see mistake-doc-vs-code-split-size.

## Verify

four "ok <size>" lines; then SHA256.txt has four entries.

## Origin

Roguelike series. Source notes: _tools/release.py L1-18; MANIFEST.md file tables (part sizes).

## Related skills

- [mistake-doc-vs-code-split-size](mistake-doc-vs-code-split-size.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
