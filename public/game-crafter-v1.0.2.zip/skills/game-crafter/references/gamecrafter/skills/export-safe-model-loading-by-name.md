---
id: export-safe-model-loading-by-name
title: "Load .glb models by stem name at runtime, export-safe (.import/.remap aware)"
category: godot-engine
when: "Code-built scenes that look up Blender models by name instead of instancing them in .tscn; anything using DirAccess to list res:// in an exported build."
related: []
origin: Pickle's Pickle Shop
---

# Load .glb models by stem name at runtime, export-safe (.import/.remap aware)

**When to use:** Code-built scenes that look up Blender models by name instead of instancing them in .tscn; anything using DirAccess to list res:// in an exported build.

## Do this

In exported packs, `DirAccess.get_files()` on res:// returns `x.glb.import` / `x.png.remap`, not `x.glb`. Map back with `NodeFinder.packed_name(file) = file.trim_suffix(".import").trim_suffix(".remap")`, then `ResourceLoader.exists(path)` + `load(path)` (never FileAccess on res:// assets). `ModelLoader.load_named(stems)` searches res://assets/models/animated, office, map (plus dev drop dirs for live editing via `GLTFDocument.append_from_file` + `generate_scene`), comparing `NodeFinder.normalize(basename)` (lowercase, strip `.001`-style suffixes, left->l / right->r, alnum only). On a hit, apply loop policy and return; else `push_warning("MISSING MODEL (placeholder will be used): ...")`. Animated characters/fp_arms come ONLY from ANIM_DIR (character/player folders hold non-game-ready GLBs - explicitly excluded). Validate: instance must contain a MeshInstance3D (`NodeFinder.find_mesh`) or it is freed and the placeholder stays. Always add the exact path in export include filters (`*.glb`, `*.json`, data) and run the lint.

## Pitfalls (mistakes seen)

Original symptom in the exported build: placeholder capsules/boxes and no textures because DirAccess listing found `.import` names and skipped them. Fixed with packed_name(); "verified on the Linux export only" at the time. A `push_warning` is the cheap detector: grep exported-run log for "MISSING MODEL" / "ResourceLoader missing".

## Verify

Export probe run from the PCK prints every model found; grep logs; screenshot from the exported build.

## Origin

Pickle's Pickle Shop. Source notes: scripts/core/model_loader.gd; scripts/core/node_finder.gd L95-117; animatronic.gd L301-315; MANIFEST.md "EXPORT FIX".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
