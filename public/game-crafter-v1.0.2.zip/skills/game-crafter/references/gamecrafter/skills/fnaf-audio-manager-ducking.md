---
id: fnaf-audio-manager-ducking
title: "Audio manager: pooled SFX, keyed loops, 3D one-shots, ducking that always releases"
category: audio-music
when: "Building the audio autoload for a horror game with phone/voice ducking."
related: [mistake-ducking-left-on-after-death]
origin: FNAP
---

# Audio manager: pooled SFX, keyed loops, 3D one-shots, ducking that always releases

**When to use:** Building the audio autoload for a horror game with phone/voice ducking.

## Do this

- Lazily loads by id from SFX/MUSIC dirs trying `.wav/.ogg/.mp3`; warns ONCE per missing id and returns null (never
  crashes - "placeholder hook").
- 16-player one-shot pool (steals oldest); keyed loops `play_loop(key, id, vol, bus)` / `stop_loop(key, fade)`;
  `play_sfx_3d` spawns `AudioStreamPlayer3D` at a position and frees on finish; per-id ambience trims
  (`AMBIENCE_TRIM_DB`); `_force_loop(stream)` sets loop flags per stream class at runtime (source files need no import
  loop flag). Buses created at runtime if missing (`_ensure_buses`); layout Master + Music, SFX, Ambience.
- `process_mode = ALWAYS`.
- Ducking: `set_duck(on)` (breath/music) and `set_voice_duck(on)` (phone/terminal voice ducks Ambience) combine in
  `_apply_duck`; `reset_ducks()` is called from `stop_all_loops()`.
- `GameState.change_scene(path)` is the only scene switcher: stops loops, stops MusicClock, then `change_scene_to_file`.

## Pitfalls (mistakes seen)

mistake-ducking-left-on-after-death.

## Verify

`audio_check.gd` resolves every id in `Sfx`/AudioManager/stems, exit 1 on any null.

## Origin

FNAP. Source notes: REF §2.10, §2.1, §1.3, §8.1 I.

## Related skills

- [mistake-ducking-left-on-after-death](mistake-ducking-left-on-after-death.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
