---
id: fnaf-release-zips-exec-bits
title: "Release zips with correct executable bits on every platform"
category: export-release
when: "Packaging Windows/Mac/Linux zips."
related: []
origin: FNAP
---

# Release zips with correct executable bits on every platform

**When to use:** Packaging Windows/Mac/Linux zips.

## Do this

- Zip layout: one top-level folder `<Game>/` with the executable (Linux `.x86_64` mode 755; Mac `.app` extracted from
  Godot's zip), `Soundtrack/` (`.ogg` copies, `00-` studio tracks), `credits.txt`, `PLAYER_README.txt`. Names
  `<Game>_{Windows,Mac,Linux,Windows_ARM64}.zip`; inputs in `DISTRIBUTION/_inputs/`.
- Linux: `zip -qry -9` keeps modes. Windows .NET `ZipArchive`: `ExternalAttributes = (0x8000 + mode) -shl 16` with mode
  493 (0755). Mac: reuse Godot's zip (already has exec bits on the `.app`) and APPEND extras with
  `ZipFileExtensions.CreateEntryFromFile` in Update mode.
- Large zips built ON THE PC (`tools/build_release.ps1`) because the agent bridge had a 30 MB-per-file limit.
- PC scripts: `build_release.ps1 [-Godot path] [-Root dir]`, `build_windows_arm64.ps1`, `make_release.ps1` (sync -> move
  docs -> import -> build all -> ARM64, logs `tools\release.log`), `sync_assets.ps1` (`robocopy /E /XO /XF *.import
  *.uid`), `.bat` wrappers `-NoProfile -ExecutionPolicy Bypass` + `pause`. Hard-coded user paths must become params.

## Pitfalls (mistakes seen)

lost exec bits -> Mac/Linux builds won't launch.

## Verify

`unzip -Z` shows `-rwxr-xr-x` on the binary.

## Origin

FNAP. Source notes: REF §4.3, §4.4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
