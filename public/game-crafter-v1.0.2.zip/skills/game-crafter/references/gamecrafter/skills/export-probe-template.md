---
id: export-probe-template
title: "Export probe - prove the BUILT game finds its assets"
category: testing-qa
when: "Every release; after any asset-loading change; new project setup."
related: []
origin: FNAP
---

# Export probe - prove the BUILT game finds its assets

**When to use:** Every release; after any asset-loading change; new project setup.

## Do this

- Ship `res://tools/export_probe.{gd,tscn}` + `res://tools/probe_manifest.json` (tiny, shipped on purpose).
- Run: `godot --main-pack build/test.pck res://tools/export_probe.tscn` (or a main-scene hook in the exe).
- Manifest: `{"resources":["res://assets/models/office/office.glb","res://assets/models/characters/hero.glb","res://icon.png"], "raw_files":["res://assets/data/lines.json","res://assets/data/notes.txt"], "dirs":[{"dir":"res://assets/models/characters","min_files":1}]}`.
```gdscript
extends Node
const MANIFEST := "res://tools/probe_manifest.json"
func _ready() -> void:
    var fails := 0
    var m: Variant = JSON.parse_string(FileAccess.get_file_as_string(MANIFEST)) if FileAccess.file_exists(MANIFEST) else null
    if m == null:
        print("PROBE_FAIL manifest missing/invalid (add *.json to include_filter): ", MANIFEST); get_tree().quit(2); return
    print("PROBE renderer=", RenderingServer.get_current_rendering_method(), " adapter=", RenderingServer.get_video_adapter_name(), " debug_build=", OS.is_debug_build())
    for p in m.get("resources", []):
        var res: Resource = load(p) if ResourceLoader.exists(p) else null
        print(("PROBE_OK   " if res else "PROBE_FAIL ") + "load " + p); fails += 0 if res else 1
    for p in m.get("raw_files", []):
        var ok2 := FileAccess.file_exists(p)
        print(("PROBE_OK   " if ok2 else "PROBE_FAIL ") + "raw  " + p + ("" if ok2 else "  <- add to include_filter")); fails += 0 if ok2 else 1
    for d in m.get("dirs", []):
        var da := DirAccess.open(d["dir"]); var n := 0
        if da:
            var seen := {}
            for f in da.get_files(): seen[NodeFinder.packed_name(f)] = true
            n = seen.size()
        var ok3 := n >= int(d.get("min_files", 1))
        print(("PROBE_OK   " if ok3 else "PROBE_FAIL ") + "dir  %s files=%d (min %d)" % [d["dir"], n, int(d.get("min_files", 1))]); fails += 0 if ok3 else 1
    print("PROBE_DONE fails=", fails)
    get_tree().quit(1 if fails else 0)
```
- `.tscn`: `[gd_scene load_steps=2 format=3]` / `[ext_resource type="Script" path="res://tools/export_probe.gd" id="1"]` / `[node name="ExportProbe" type="Node"]` / `script = ExtResource("1")`.

## Pitfalls (mistakes seen)

without it, the PCK bug shipped.

## Verify

`PROBE_DONE fails=0`; negative test gives `fails=1`.

## Origin

FNAP. Source notes: T/godot_dev/export_probe.gd, export_probe.tscn, probe_manifest.example.json; R steps 5-6.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
