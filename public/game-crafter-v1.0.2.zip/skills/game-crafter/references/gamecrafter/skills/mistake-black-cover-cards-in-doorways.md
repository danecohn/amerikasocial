---
id: mistake-black-cover-cards-in-doorways
title: "Black cards placed in doorways to fake darkness"
category: mistake
when: "Someone 'fixed' visible halls by covering doorways."
related: []
origin: FNAP
---

# Black cards placed in doorways to fake darkness

**When to use:** Someone "fixed" visible halls by covering doorways.

## What happened, root cause, fix, prevention

- Symptom: flashlight/hall light reveal a flat black wall instead of the hall.
- Root cause: previous authors put QuadMesh / dark unshaded BoxMesh cards in doorways.
- Fix: door code deletes such cards; darkness via environment + sight baffles.
- Prevention: grep for doorway cover meshes; hall_check.

## Verify

hall_check flashlight screenshot shows hall depth.

## Origin

FNAP. Source notes: REF §2.3 Door.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
