---
id: dark-horror-environment-values
title: "Real darkness for 3D horror (Environment values that worked)"
category: 3d-lighting-horror
when: "Lighting dark halls/offices in a FNAF-like or any 3D horror game; user says 'darker'."
related: [camera-feeds-separate-render-layer, mistake-halls-too-bright]
origin: FNAP
---

# Real darkness for 3D horror (Environment values that worked)

**When to use:** Lighting dark halls/offices in a FNAF-like or any 3D horror game; user says "darker".

## Do this

- WorldEnvironment values that worked (FNAP `office_controller.gd _build_environment()`): `ambient_light_energy = 0.008` (was 0.11), tonemap filmic `tonemap_exposure = 1.0`, `glow_intensity = 0.25`, light volumetric/plain fog density ~0.006.
- Hall room lights and `Light_Hall_L/R` energy 0; halls revealed ONLY by the flashlight and hall-light buttons; the "full light" office state must not re-enable hall lights.
- Camera feeds keep their own exposure on a separate render layer (camera-feeds-separate-render-layer).
- Emissive "eyes" that cheat light break dark halls: keep eyes as lit surfaces; emissive only on camera feeds/monitors.
- MSAA 3D 1 or 2 is enough.

## Pitfalls (mistakes seen)

see mistake-halls-too-bright.

## Verify

`scripts/dev/hall_check.tscn` screenshot pair - flashlight off = black, on = revealed - AND office desk still readable (check both ends).

## Origin

FNAP. Source notes: L §2.5 (lines 101-104); G "Rendering look" (lines 38-43); S line 24.

## Related skills

- [camera-feeds-separate-render-layer](camera-feeds-separate-render-layer.md)
- [mistake-halls-too-bright](mistake-halls-too-bright.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
