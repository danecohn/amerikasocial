---
id: godot-install-export-templates
title: "Godot 4.7.2 + export templates install facts (cloud and PC)"
category: environment-tools
when: "`godot` missing, export fails with 'no export template', version mismatch."
related: []
origin: FNAP
---

# Godot 4.7.2 + export templates install facts (cloud and PC)

**When to use:** `godot` missing, export fails with "no export template", version mismatch.

## Do this

- Container layout that worked: `/usr/local/bin/godot -> /opt/tools/godot/Godot_v4.7.2-stable_linux.x86_64`; `godot --version` -> `4.7.2.stable.official.ed1daf0bf`. Standard edition, NOT .NET unless C# wanted.
- Templates folder name must be exactly `<version>.<status>`, e.g. `4.7.2.stable`: Linux `~/.local/share/godot/export_templates/4.7.2.stable/`, Windows `%APPDATA%\Godot\export_templates\4.7.2.stable\`, macOS `~/Library/Application Support/Godot/export_templates/4.7.2.stable/`. Contents: `windows_release_x86_64.exe`, `windows_release_x86_64_console.exe`, `windows_debug_*`, `linux_release.x86_64`, `linux_debug.x86_64`, `macos.zip`, `icudt_godot.dat`, `version.txt` (+ `windows_release_arm64.exe` for ARM64).
- Download `Godot_v4.7.2-stable_linux.x86_64.zip` and `Godot_v4.7.2-stable_export_templates.tpz` from godotengine.org / GitHub releases; a `.tpz` is a zip. (GitHub release downloads work through the sandbox proxy - HTTP 206 on a range request. In FNAP the templates were instead copied from the user's PC tool folder.)
- Other tools: Blender 5.2.2 LTS (`blender -b`), ffmpeg 6.1.1, `xvfb-run`, Python 3 + Pillow 12.3.0; fonts Poppins-Bold/Medium (`/usr/share/fonts/truetype/google-fonts/`), DejaVuSans-Bold.
- Check: `godot --version`, `blender --version | head -1`, `ffmpeg -version | head -1`, `which xvfb-run`.
- Install docs must cover Windows x64, Windows ARM64, macOS, Linux.

## Pitfalls (mistakes seen)

exports failed until templates were installed.

## Verify

`--export-release` succeeds.

## Origin

FNAP. Source notes: L §1.1 (lines 16-28), §1.3 (lines 36-39), §1.2 line 34.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
