---
id: headless-autorun-shot-chk-scripts
title: "Bash wrappers to run a Godot game headless under Xvfb for logs, screenshots and script checks"
category: testing-qa
when: "Verifying a Godot game in a cloud container without GPU/display."
related: []
origin: Roguelike series
---

# Bash wrappers to run a Godot game headless under Xvfb for logs, screenshots and script checks

**When to use:** Verifying a Godot game in a cloud container without GPU/display.

## Do this

- Import once if `.godot/` missing: `cd "$P" && timeout 300 godot --headless --path . --import --quit`.
- chk.sh (fast compile check): `cd "$1" && timeout 120 godot --headless --path . --quit-after 2 2>&1 | grep -E "SCRIPT ERROR|at: |ERROR" | grep -v "Failed to compile depended" | head -30`.
- autorun.sh `<proj> <seconds> [args]`: uses the game-maker skill's `headless-render-capture/scripts/godot_xvfb.sh -r 384x216 -t $T -l /tmp/auto.log -- --path "$P" --rendering-driver opengl3 -- "$@"`, then `grep -E "ROOM |BOSS|RUN_END|SCRIPT ERROR|ERROR:|PLACEHOLDER|at: " | grep -v "ERR_CANT_OPEN\|status < 0" | head -${LINES_MAX:-60}`.
- shot.sh `<proj> <out.png> [args]`: same launcher with `-t ${TMO:-240}` and `-- --shot="$OUT" "$@"`, greps `SHOT_OK|SCRIPT ERROR|ERROR|PLACEHOLDER|WIRING`, per-PID log `/tmp/shot_$$.log` removed after.
- Capture at the native viewport (384x216) and upscale later with nearest neighbour (5x -> 1920x1080 for store screenshots).
- Use `--rendering-driver opengl3` with gl_compatibility so Xvfb + Mesa llvmpipe can render.
- Grep filters remove noise (`ERR_CANT_OPEN`, `status < 0`, "Failed to compile depended") so only actionable errors show.

## Pitfalls (mistakes seen)

Running without the import step makes first run fail to load imported textures -> always import first.

## Verify

script output contains SHOT_OK / RUN_END and no SCRIPT ERROR.

## Origin

Roguelike series. Source notes: _tools/autorun.sh, shot.sh, chk.sh; MANIFEST.md screenshot note.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
