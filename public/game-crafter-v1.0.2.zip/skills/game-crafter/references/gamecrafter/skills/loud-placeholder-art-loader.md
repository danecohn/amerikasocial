---
id: loud-placeholder-art-loader
title: "Texture loader with LOUD magenta placeholders and a missing-art counter"
category: godot-engine
when: "Loading generated art at runtime; must never silently ship missing sprites."
related: []
origin: Roguelike series
---

# Texture loader with LOUD magenta placeholders and a missing-art counter

**When to use:** Loading generated art at runtime; must never silently ship missing sprites.

## Do this

```gdscript
static func tex(path: String) -> Texture2D:
    if _cache.has(path): return _cache[path]
    var t: Texture2D = load(path) as Texture2D if ResourceLoader.exists(path) else null
    if t == null:
        push_warning("PLACEHOLDER missing asset: " + path); print("PLACEHOLDER missing asset: ", path)
        missing.append(path)
        var img := Image.create(16, 16, false, Image.FORMAT_RGBA8); img.fill(Color(1, 0, 1))
        t = ImageTexture.create_from_image(img)
    _cache[path] = t; return t
```
- Boot prints `WIRING game=<id> fonts=true missing_art=<n>`; screenshot tool prints `SHOT_OK <path> <size> missing=<n>`; release gate = `missing_art=0` from the EXPORTED build.

## Pitfalls (mistakes seen)

silent fallbacks hide missing art in exports (the reason for this pattern).

## Verify

grep logs for `PLACEHOLDER`; must be empty.

## Origin

Roguelike series. Source notes: kit/kit/art.gd; game.gd line 50; boot.gd line 85; finish.py MANIFEST text.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
