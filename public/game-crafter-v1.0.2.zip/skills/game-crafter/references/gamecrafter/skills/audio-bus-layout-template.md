---
id: audio-bus-layout-template
title: "Default audio bus layout (Music / SFX / Ambience)"
category: audio-music
when: "New Godot project with music, SFX and ambience that need separate volumes/ducking."
related: []
origin: FNAP
---

# Default audio bus layout (Music / SFX / Ambience)

**When to use:** New Godot project with music, SFX and ambience that need separate volumes/ducking.

## Do this

`default_bus_layout.tres`:
```
[gd_resource type="AudioBusLayout" format=3]
[resource]
bus/1/name = &"Music"
bus/1/send = &"Master"
bus/2/name = &"SFX"
bus/2/send = &"Master"
bus/3/name = &"Ambience"
bus/3/send = &"Master"
```
(each bus also has `solo=false, mute=false, bypass_fx=false, volume_db=0.0`). Ducking targets Music + Ambience buses (e.g. -16 dB during calls).

## Pitfalls (mistakes seen)

n/a.

## Verify

`AudioServer.get_bus_index("Music") != -1` in audio_check.

## Origin

FNAP. Source notes: T/default_bus_layout.tres; L §2.12.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
