---
id: mistake-actors-layers-zero-invisible-in-dark
title: "Dark-hall characters invisible even with flashlight (layers = 0)"
category: mistake
when: "Using VisualInstance3D layers / light cull masks for feeds, flashlights, hall lights."
related: []
origin: FNAP
---

# Dark-hall characters invisible even with flashlight (layers = 0)

**When to use:** Using VisualInstance3D layers / light cull masks for feeds, flashlights, hall lights.

## Do this

A GeometryInstance3D with `layers = 0` is lit by nothing and seen by no camera.

## What happened, root cause, fix, prevention

Symptom: characters in dark hall invisible even with flashlight. Root cause: earlier polish set `GeometryInstance3D.layers = 0` on actors; no layer left for flashlight/hall light. Fix: restore layer 1 every frame unless the node is deliberately on a feed layer (`_present_model`). Prevention: never zero layers; grep `layers = 0`. Detection: hall_check screenshots with light off/on (A/B).

## Verify

A/B screenshots: off = shadow, on = model visible.

## Origin

FNAP. Source notes: mistakes-log.md M05.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
