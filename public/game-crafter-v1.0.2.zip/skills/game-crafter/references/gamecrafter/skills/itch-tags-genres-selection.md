---
id: itch-tags-genres-selection
title: "itch.io tags/genres for a pixel horror roguelike"
category: promo-marketing
when: "Filling genre/tags on itch.io."
related: []
origin: Roguelike series
---

# itch.io tags/genres for a pixel horror roguelike

**When to use:** Filling genre/tags on itch.io.

## Do this

- Genre: pick 2: "Action, Role Playing" - put "roguelike" in tags (itch has no roguelike genre).
- 10 tags in priority order: Roguelike, Horror, Pixel Art, Story Rich, Top-Down (or "Top-Down Shooter" for a shooter, "Psychological Horror" swapped in for the more psychological games), Atmospheric, Dark, Singleplayer, Short, Emotional.
- YouTube tags = first 6 itch tags.

## Pitfalls (mistakes seen)

none.

## Verify

10 tags, no duplicates.

## Origin

Roguelike series. Source notes: itch.txt TAGS (4 games); pack.py L162.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
