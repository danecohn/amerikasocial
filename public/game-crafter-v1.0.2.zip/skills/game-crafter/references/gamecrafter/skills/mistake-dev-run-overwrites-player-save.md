---
id: mistake-dev-run-overwrites-player-save
title: "Test/capture runs overwrite the player's real save"
category: mistake
when: "Using CLI flags to jump nights or capture footage."
related: []
origin: FNAP
---

# Test/capture runs overwrite the player's real save

**When to use:** Using CLI flags to jump nights or capture footage.

## What happened, root cause, fix, prevention

- Symptom: progress changed after running a dev command (e.g. night jumped to 5).
- Root cause: save() runs regardless of dev flags.
- Fix: `_dev_switch_active()` guard in `save()` (capture, no-save, night, screenshot); tests use
  `XDG_DATA_HOME=/tmp/...`.
- Prevention: every dev flag implies no-save.

## Verify

save file mtime unchanged after a flagged run.

## Origin

FNAP. Source notes: REF §1.7, §8.1 G.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
