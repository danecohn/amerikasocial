---
id: fnaf-renderer-fallback-note
title: "Show the active renderer; warn when Forward+ fell back to Compatibility"
category: godot-engine
when: "Shipping a 3D Godot game to unknown PCs ('looks broken' reports)."
related: [mistake-renderer-silent-compatibility-fallback]
origin: FNAP
---

# Show the active renderer; warn when Forward+ fell back to Compatibility

**When to use:** Shipping a 3D Godot game to unknown PCs ("looks broken" reports).

## Do this

- (quoted)
  ```gdscript
  var current: String = RenderingServer.get_current_rendering_method()
  l.text = "Renderer: %s  |  %s" % [current, RenderingServer.get_video_adapter_name()]
  if current != "forward_plus":
  	l.text += "\nLow-quality renderer in use (%s). Update your GPU driver or run the native build for your CPU." % current
  ```
- Compatibility = no glow/shadows -> dark horror looks broken. Native ARM64 build matters on Snapdragon PCs.

## Pitfalls (mistakes seen)

mistake-renderer-silent-compatibility-fallback.

## Verify

Run with `--rendering-driver opengl3`: the note appears.

## Origin

FNAP. Source notes: REF §1.6, §8.2 #14.

## Related skills

- [mistake-renderer-silent-compatibility-fallback](mistake-renderer-silent-compatibility-fallback.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
