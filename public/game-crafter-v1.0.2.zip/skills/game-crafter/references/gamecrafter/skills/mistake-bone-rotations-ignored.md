---
id: mistake-bone-rotations-ignored
title: "Manual bone rotations ignored in Blender"
category: mistake
when: "Scripting pose edits with bpy."
related: []
origin: FNAP
---

# Manual bone rotations ignored in Blender

**When to use:** Scripting pose edits with bpy.

## Do this

`pb.rotation_mode = 'XYZ'` first (bones default to QUATERNION); bake matrices then `obj.animation_data.action = None` so the action doesn't overwrite edits.

## What happened, root cause, fix, prevention

Symptom: edits had no effect. Cause: quaternion mode + assigned action overwrote. Fix above.

## Verify

Render shows changed bones.

## Origin

FNAP. Source notes: mistakes-log.md M41.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
