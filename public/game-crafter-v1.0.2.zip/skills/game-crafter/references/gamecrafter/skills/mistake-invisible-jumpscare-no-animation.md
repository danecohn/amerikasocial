---
id: mistake-invisible-jumpscare-no-animation
title: "Jumpscare shows nothing / no animation (darkness logic hid the attacker)"
category: mistake
when: "Implementing jumpscares in a game that also has darkness/visibility logic, eye glow, HUD overlays, or a scare camera."
related: []
origin: Pickle's Pickle Shop
---

# Jumpscare shows nothing / no animation (darkness logic hid the attacker)

**When to use:** Implementing jumpscares in a game that also has darkness/visibility logic, eye glow, HUD overlays, or a scare camera.

## Do this

Four stacked causes were found for "I got jumpscared and saw no animation": (1) per-frame `_update_dark_visibility()` decided the attacker was in a dark door room and hid every non-eye mesh each frame (eyes-only), overriding the jumpscare; (2) the eye rig set emission 0 in a dark door room (blank face); (3) jumpscare camera framed a fixed head height (1.75) so short characters (Remi) were out of frame; (4) the HUD stayed on top. Fixes: a `jumpscaring` flag on the actor; `_update_dark_visibility` early-returns with `_apply_eyes_only(false)` when jumpscaring; eye rig `if body.jumpscaring: energy = 7.0` as the FIRST branch; scare camera framed from measured model height; HUD hidden before `jumpscare.play`.

## What happened, root cause, fix, prevention

Symptom: invisible attacker / placeholder / no animation at the moment of death. Root cause: state systems (darkness, eyes, HUD) unaware of the "scripted presentation" state. Fix: global presentation flag checked first by every system that touches visibility/emission. Prevention: every new visibility/lighting system must have an explicit "override while jumpscaring/cutscene" branch at the top; probe all characters' jumpscares by screenshot.

## Verify

Probe scene that triggers `Jumpscare.play` for each of 5 characters in the darkest room (door nook, hall light off) and saves screenshots ~0.4 s and ~1.0 s in; confirm textured model, face in frame, animation pose differs between frames.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.1, 3, 4, 5; animatronic.gd L321-345; eye_rig.gd L113-115; jumpscare.gd L28-88; office_controller.gd trigger_jumpscare.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
