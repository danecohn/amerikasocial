# Tool: autorun.sh

**Purpose:** Runs the game with the automatic demo player for N seconds and prints the interesting log lines.

**Usage:** `bash autorun.sh <proj> <seconds> --demo=1 --auto=1`

**Skill:** see `skills/automated-demo-player-bot.md`

**Extract:** save the block below as `autorun.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/bin/bash
# usage: autorun.sh <proj> <seconds> [args]  -> prints interesting log lines
P=$1; T=$2; shift 2
XV=$(echo /root/.claude/plugins/synced/*/game-maker/skills/headless-render-capture/scripts/godot_xvfb.sh)
[ -d "$P/.godot" ] || (cd "$P" && timeout 300 godot --headless --path . --import --quit >/dev/null 2>&1)
bash $XV -r 384x216 -t $T -l /tmp/auto.log -- --path "$P" --rendering-driver opengl3 -- "$@" >/dev/null 2>&1
grep -E "ROOM |BOSS|RUN_END|SCRIPT ERROR|ERROR:|PLACEHOLDER|at: " /tmp/auto.log | grep -v "ERR_CANT_OPEN\|status < 0" | head -${LINES_MAX:-60}
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
