---
id: handoff-prompt-for-another-ai
title: "Writing the paste-in prompt that hands a project to Cursor/another agent"
category: multi-agent
when: "Usage is running out, the user switches tools, or a parallel pass must start. - knowledge (structure of CURSOR_PROMPT.md and attachment.txt):   1. One-paragraph identity: project, engine+version, language, goal ('polished, shippable itch.io release of the Prologue + Act I vertical slice'), content rule and the single credit line.   2. Warning about state: 'several partial, unverified WIP files from an interrupted agent team exist (see MANIFEST.md). Re-run all tests first.'   3. Ordered reading list (MANIFEST, LOG, TEAM, WORKSTREAMS, PAUSED_STATUS, bible, scene plan, systems, art STATUS.md files).   4. Rules: original assets only; never hide meshes/silence warnings; verify the EXPORTED build and look at screenshots; update MANIFEST + LOG after every step; one Godot process at a time; exact Godot exe path.   5. Exact validation commands and the expected line (`RESULT: PASS`).   6. Numbered work order mapped to milestones.   7. 'Be honest in docs about what is placeholder. Work in small verified steps and commit often.' 'Do not upload anything.'   8. For a parallel-pass prompt: ownership split (Blender pass owns meshes/rigs/clips; you own scenes/scripts/tests/manifests), paths for both trees, launcher quirks, what the previous pass finished (exact RESULT lines + harmless warnings to ignore), file list added/changed, 'do not regress' rules with exact ledger expectations, stubs to leave alone, and a **Report back** list (files changed, what you refused to overwrite and why, GLBs noticed but not touched, test line, manifest paths updated, canon guesses)."
related: []
origin: Caesarea
---

# Writing the paste-in prompt that hands a project to Cursor/another agent

**When to use:** Usage is running out, the user switches tools, or a parallel pass must start. - knowledge (structure of CURSOR_PROMPT.md and attachment.txt):   1. One-paragraph identity: project, engine+version, language, goal ("polished, shippable itch.io release of the Prologue + Act I vertical slice"), content rule and the single credit line.   2. Warning about state: "several partial, unverified WIP files from an interrupted agent team exist (see MANIFEST.md). Re-run all tests first."   3. Ordered reading list (MANIFEST, LOG, TEAM, WORKSTREAMS, PAUSED_STATUS, bible, scene plan, systems, art STATUS.md files).   4. Rules: original assets only; never hide meshes/silence warnings; verify the EXPORTED build and look at screenshots; update MANIFEST + LOG after every step; one Godot process at a time; exact Godot exe path.   5. Exact validation commands and the expected line (`RESULT: PASS`).   6. Numbered work order mapped to milestones.   7. "Be honest in docs about what is placeholder. Work in small verified steps and commit often." "Do not upload anything."   8. For a parallel-pass prompt: ownership split (Blender pass owns meshes/rigs/clips; you own scenes/scripts/tests/manifests), paths for both trees, launcher quirks, what the previous pass finished (exact RESULT lines + harmless warnings to ignore), file list added/changed, "do not regress" rules with exact ledger expectations, stubs to leave alone, and a **Report back** list (files changed, what you refused to overwrite and why, GLBs noticed but not touched, test line, manifest paths updated, canon guesses).

## Pitfalls (mistakes seen)

A handoff that states expected warnings ("1 resources still in use at exit", "3 ObjectDB instances were leaked") prevents the next agent from wasting time; omitting them causes false alarms.

## Verify

The receiving agent's first report reproduces the baseline RESULT line.

## Origin

Caesarea. Source notes: docs/handoff/CURSOR_PROMPT.md, /mnt/user-data/uploads/attachment.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
