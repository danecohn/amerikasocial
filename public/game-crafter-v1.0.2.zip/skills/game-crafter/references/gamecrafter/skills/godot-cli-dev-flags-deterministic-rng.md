---
id: godot-cli-dev-flags-deterministic-rng
title: "CLI dev flags after `--` and deterministic RNG for QA/capture"
category: gdscript-patterns
when: "Need to jump to a level, skip intro, bound a run, seed randomness, or take a screenshot from the command line; any automated test or promo capture."
related: []
origin: FNAP
---

# CLI dev flags after `--` and deterministic RNG for QA/capture

**When to use:** Need to jump to a level, skip intro, bound a run, seed randomness, or take a screenshot from the command line; any automated test or promo capture.

## Do this

- Flags go after `--` and are read with `OS.get_cmdline_user_args()`; parse once in the GameState autoload into a `cli` dict. Example: `godot --path . scene.tscn -- --gm-level=3 --gm-no-save --gm-quit-after=8 --gm-seed=1337 --gm-screenshot=x.png`.
- `--gm-quit-after=<seconds>` uses `get_tree().create_timer(sec).timeout.connect(quit_game)` (Godot's own `--quit-after N` counts FRAMES).
- Dev flags (`no-save`, `level`, `screenshot`) disable saving.
- `seed_rng(rng, salt)`: seeded per subsystem when `--gm-seed` given, else `randomize()`.
```gdscript
for arg in OS.get_cmdline_user_args():
    if arg.begins_with("--gm-"):
        var kv := arg.trim_prefix("--gm-").split("=", true, 1)
        cli[kv[0]] = kv[1] if kv.size() > 1 else "1"
if cli.has("seed"): capture_seed = int(cli["seed"]); seed(capture_seed)
if cli.has("level"): level = clampi(int(cli["level"]), 1, MAX_LEVEL)
if cli.has("quit-after"): get_tree().create_timer(float(cli["quit-after"])).timeout.connect(quit_game)
func seed_rng(rng: RandomNumberGenerator, salt: String = "") -> void:
    if cli.has("seed"): rng.seed = hash("%d:%s" % [capture_seed, salt])
    else: rng.randomize()
```
- FNAP capture also used `GameState.cli["skip-intro"]="1"`, `GameState.night=4`.

## Pitfalls (mistakes seen)

a forgotten quit hangs the tool call -> always bound runs with `quit-after`.

## Verify

Run twice with same seed -> identical output; run with `--gm-no-save` -> save file mtime unchanged.

## Origin

FNAP. Source notes: T/godot_core/game_state_template.gd lines 16-43; S Architecture bullet 4 (line 22); G lines 23-24; L §5.3 (line 264).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
