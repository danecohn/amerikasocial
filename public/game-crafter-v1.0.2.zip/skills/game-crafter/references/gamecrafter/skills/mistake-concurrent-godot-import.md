---
id: mistake-concurrent-godot-import
title: "Two Godot imports at once corrupt the import cache"
category: mistake
when: "Several agents/processes may run Godot on one project."
related: []
origin: FNAP
---

# Two Godot imports at once corrupt the import cache

**When to use:** Several agents/processes may run Godot on one project.

## What happened, root cause, fix, prevention

- Symptom: corrupted `.godot/imported` cache, broken resources.
- Root cause: a concurrent second import.
- Fix: single headless import `godot --headless --path <proj> --import --quit > import.log 2>&1` (nohup) and an
  `IMPORT_DONE` barrier file; nobody else runs Godot until it exists. Never commit/stage `.godot/` (~900 MB).
- Prevention: barrier files in multi-agent runs.

## Verify

import.log exit 0, IMPORT_DONE present.

## Origin

FNAP. Source notes: REF §3.2, §7.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
