---
id: canonical-project-folder
title: "Canonical project folder and folder hygiene"
category: project-management
when: "Setting up sync between cloud workspace and user PC; multiple agents/tools (Cursor etc.) share a project."
related: []
origin: FNAP
---

# Canonical project folder and folder hygiene

**When to use:** Setting up sync between cloud workspace and user PC; multiple agents/tools (Cursor etc.) share a project.

## Do this

Agree one canonical project folder that other AI agents build from (FNAP: `<Game>\Godot`). Keep it current: lead commits at milestones, refreshes manifest/docs; every role keeps `changed/<role>.txt` accurate so the lead can sync. Heavy assets synced separately via a PC-side script (`tools\sync_assets.ps1`). Docs, tools, art, DISTRIBUTION live beside it. Never write to folders the user did not name (FNAP: nothing written to DISTRIBUTE, Advertisements, or the other game's folder). Keep a `last_sync` stamp file and reset it after each commit; next sync ~every 20 min.

## Pitfalls (mistakes seen)

M77 delivered but folder had old files; M08 delivered to wrong place.

## Verify

List canonical folder; compare to `changed/*.txt`.

## Origin

FNAP. Source notes: BOARD.md lines 10, 39-40, 42; QA_CHECKLIST.fnap_example.md A9; process-playbook section 0.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
