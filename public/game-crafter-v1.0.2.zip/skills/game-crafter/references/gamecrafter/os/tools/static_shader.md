# Tool: static.gdshader

**Purpose:** Camera-feed static/noise shader for security monitors.

**Usage:** `ShaderMaterial on the feed TextureRect`

**Skill:** see `skills/security-camera-feed-subviewport.md`

**Extract:** save the block below as `static.gdshader` (exact contents) and run it. Adapt paths marked `<...>`.

```glsl
shader_type canvas_item;
// CRT static / scanline overlay for the camera monitor and menus.
uniform float intensity : hint_range(0.0, 1.0) = 0.15;
uniform float scanlines : hint_range(0.0, 1.0) = 0.25;
uniform vec4 tint : source_color = vec4(1.0);

float rand(vec2 co) {
	return fract(sin(dot(co, vec2(12.9898, 78.233))) * 43758.5453);
}

void fragment() {
	vec2 cell = floor(UV * vec2(480.0, 270.0));
	float n = rand(cell + vec2(fract(TIME * 7.13) * 100.0, fract(TIME * 3.7) * 100.0));
	float scan = 0.5 + 0.5 * sin(UV.y * 1080.0 * 1.2 + TIME * 40.0);
	float roll = smoothstep(0.0, 0.08, abs(fract(UV.y - TIME * 0.12) - 0.5));
	float a = intensity * (0.7 + 0.3 * n) + scanlines * 0.15 * scan + (1.0 - roll) * 0.08;
	COLOR = vec4(vec3(n) * tint.rgb, clamp(a, 0.0, 1.0));
}
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
