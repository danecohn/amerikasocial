---
id: mistake-helper-mesh-in-render
title: "Helper mesh visible in Blender render"
category: mistake
when: "Hiding helper objects in Blender scripts."
related: []
origin: FNAP
---

# Helper mesh visible in Blender render

**When to use:** Hiding helper objects in Blender scripts.

## Do this

Set both `obj.hide_render = True` and `obj.hide_viewport = True`.

## What happened, root cause, fix, prevention

Symptom: helper visible in render. Cause: only hide_viewport. Fix above.

## Verify

Render.

## Origin

FNAP. Source notes: mistakes-log.md M42.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
