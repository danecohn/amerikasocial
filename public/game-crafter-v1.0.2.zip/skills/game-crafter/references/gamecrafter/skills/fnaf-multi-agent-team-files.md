---
id: fnaf-multi-agent-team-files
title: "Multi-agent game team coordination files (brief, board, owners, barriers)"
category: multi-agent
when: "Running several agents on one game project."
related: [mistake-concurrent-godot-import, mistake-multi-agent-launch-stalled]
origin: FNAP
---

# Multi-agent game team coordination files (brief, board, owners, barriers)

**When to use:** Running several agents on one game project.

## Do this

- ~16 roles (Pipeline Lead, Build Engineer, Office, Characters, Rooms/cams, Doors/lurkers/flashlight, Curtain, Posters,
  Assistant, Phone/story, Audio, Save/HUD, QA...).
- `BRIEF.md`: hard rules, established facts, tool locations, bridge constraints (no PC shell; only stage/commit; <=50
  files per call, 400 MB per file, each call needs user approval -> batch), update blocks appended in time order (later
  supersede earlier).
- `BOARD.md` append-only log `[HH:MM] <ROLE>(n): msg` incl. `REQUEST #n` messages between owners.
- `OWNERS.md`: one owner per file, function-level ownership for shared files ("surgical edits only").
- `orig/` (copy of every file before first edit), `changed/<role>.txt` manifests, `lead/changed_files.py` emits commit
  batches (<=45 files, warns >30 MB), `lead/sync_docs.py` regenerates board snapshot + manifest status block.
- Zero-byte barrier files: `READY`, `READY_AUDIO`, `IMPORT_DONE`, `last_sync`, `QA_SIGNOFF`. Agents wait for
  `IMPORT_DONE`; nobody runs a second import.
- `_team/*.md` owner-to-owner contracts (what to edit, node names, what NOT to change).
- Handoff docs: `STATE.md`/`STATUS.md` (most useful to agents), `AGENTS.md`, `HANDOFF_CURSOR.md` (honest NOT done list),
  `PROJECT_MANIFEST.md`, `SYNC_LOG.md`, `CHANGELOG.md`, `QA_CHECKLIST.md`, `TEAM_BOARD_SNAPSHOT.md`.
- Principles: evidence-or-it-did-not-happen; canonical project + read-only backup; batch human-approval bridge calls.

## Pitfalls (mistakes seen)

mistake-multi-agent-launch-stalled; mistake-concurrent-godot-import.

## Verify

Board shows each role's last post; QA_SIGNOFF exists before delivery.

## Origin

FNAP. Source notes: REF §7.

## Related skills

- [mistake-concurrent-godot-import](mistake-concurrent-godot-import.md)
- [mistake-multi-agent-launch-stalled](mistake-multi-agent-launch-stalled.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
