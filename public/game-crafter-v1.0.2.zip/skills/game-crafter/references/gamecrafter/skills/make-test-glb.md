---
id: make-test-glb
title: "Tiny test glb for pipeline smoke tests"
category: 3d-blender
when: "Testing Blender->Godot import/export/naming pipeline."
related: []
origin: FNAP
---

# Tiny test glb for pipeline smoke tests

**When to use:** Testing Blender->Godot import/export/naming pipeline.

## Do this

```python
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0,0,0.5)); cube = bpy.context.object; cube.name = "TestCube"
m = bpy.data.materials.new("TestMat"); m.use_nodes = True
m.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = (0.9,0.2,0.2,1)
cube.data.materials.append(m)
e = bpy.data.objects.new("Marker_Door_L", None); e.location = (1,0,0); bpy.context.collection.objects.link(e)
c = bpy.data.objects.new("Cam_Room1", bpy.data.cameras.new("Cam_Room1")); c.location = (3,-3,2); c.rotation_euler = (1.1,0,0.8); bpy.context.collection.objects.link(c)
bpy.ops.export_scene.gltf(filepath=out, export_format='GLB', export_cameras=True, export_extras=True)
```
Names `Marker_Door_L`, `Cam_Room1` should be found by NodeFinder in Godot even after re-export (`.001` suffixes).

## Pitfalls (mistakes seen)

Procedural nodes (Checker/Noise/Voronoi) do NOT survive glTF -> bake to images.

## Verify

inspect_glb shows EMPTY + CAM; Godot finds them.

## Origin

FNAP. Source notes: blender-assets/scripts/make_test_glb.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
