---
id: fnaf-phone-call-playback
title: "Phone call system (ring, voiced wav, ducking, timed subtitles, mute = hang up)"
category: narrative-dialogue
when: "Implementing nightly voiced calls with subtitles."
related: [mistake-ducking-left-on-after-death, mistake-subtitle-overflow, mistake-test-asset-path-drift]
origin: FNAP
---

# Phone call system (ring, voiced wav, ducking, timed subtitles, mute = hang up)

**When to use:** Implementing nightly voiced calls with subtitles.

## Do this

- Flow per night: ring (`phone-ring`, capped 9.7 s; 2D: rings 3 times) -> pickup click -> play `sfx/phone-night-N.wav`
  with `AudioManager.set_voice_duck(true)` (ducks Ambience) -> subtitles by `get_playback_position()` against
  `night-N.cues`.
- `.cues` format: one line per card `seconds|text` (timed to the real wav). Fallback when no cues: split
  `night-N.txt` (script after a `----` line); `[pause]`/`(quiet)` become silent beats; sentences packed into cards
  <=118 chars; time distributed by word count over `duration - 1.2 s`.
- Mute button (2D `btn-mute-call.png` 150x46) = hang up (`phone-hangup-click.wav`). CC toggle on HUD.
- `phone-call-static-bed.wav` 30 s loop under the voice.
- `_token` counter invalidates stale awaits when the call ends / scene exits; `_exit_tree` restores ducks.
- Only nights 1-5 have calls (`phone: n <= 5`).
- Example cue file (illustrative, from CALLS N1 text):
  ```
  0.00|Hey. There you are. Okay. This is Dale.
  2.80|I had the desk before you, so I'm the guy who gets to tell you where the bathrooms are.
  ```
- Fallback splitter sketch:
  ```gdscript
  func _cards_from_script(script: String, duration: float) -> Array:
      var body := script.split("----", true, 1)[-1]
      var cards: Array[String] = []
      var cur := ""
      for s in body.replace("\n", " ").split(". ", false):
          var t := s.strip_edges()
          if t.begins_with("(") or t.begins_with("["): cards.append(""); continue  # silent beat
          if (cur + " " + t).length() > 118: cards.append(cur); cur = t
          else: cur = (cur + " " + t).strip_edges()
      if cur != "": cards.append(cur)
      # then distribute (duration - 1.2) seconds across cards by word count
      return cards
  ```

## Pitfalls (mistakes seen)

mistake-ducking-left-on-after-death; mistake-subtitle-overflow; mistake-test-asset-path-drift (phone wav path).

## Verify

`phone_check.tscn -- <night> [seek_seconds_before_end]` runs a call headless; `make_phone_cues.py` doubles as a
subtitle/wav timing verifier.

## Origin

FNAP. Source notes: REF §2.12, §3.5, §5.2; STATEMAP lines 255-265, 276.

## Related skills

- [mistake-ducking-left-on-after-death](mistake-ducking-left-on-after-death.md)
- [mistake-subtitle-overflow](mistake-subtitle-overflow.md)
- [mistake-test-asset-path-drift](mistake-test-asset-path-drift.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
