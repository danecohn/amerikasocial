---
id: fnaf-everything-in-code-scenes
title: "Tiny .tscn + code-built UI/3D, with placeholders for every asset"
category: godot-engine
when: "AI agents will edit the project; you want no .tscn merge conflicts and an always-runnable game."
related: []
origin: FNAP
---

# Tiny .tscn + code-built UI/3D, with placeholders for every asset

**When to use:** AI agents will edit the project; you want no .tscn merge conflicts and an always-runnable game.

## Do this

- Each `.tscn` = one root node + script (e.g. `office.tscn` is Node3D + `office_controller.gd`). UI/3D built in
  `_ready()` via `UiKit` helpers. ~13 scenes total.
- Pros: no merge conflicts, trivial for AI to edit; con: no editor preview.
- Procedural placeholders for every authored asset (box office, box rooms, capsule + Label3D animatronics, green box
  CRT); real GLBs swapped in when found -> game always runnable with missing art.
- Static helper classes as `RefCounted` with `static func` + `const` (RoomIds, Sfx, NodeFinder, ModelLoader,
  ClipManifest, VoiceBank, UiKit) = the "string registry" so no raw strings are scattered.
- Room id helpers: `RoomIds.short_id`, `room_node_name -> "Room_1A"`, `cam_spot_name -> "CamSpot_1A"`,
  `waypoint_name(room, who) -> "WP_1A_Pickle"`.

## Pitfalls (mistakes seen)

the office orchestrator grew to 1824 lines (level_builder 1069) - function-level ownership was needed when
many agents edited it.

## Verify

Boot the project with the models folder empty: everything still runs on placeholders.

## Origin

FNAP. Source notes: REF §1.4, §1.2, §1.1.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
