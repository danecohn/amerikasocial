---
id: mistake-nodes-authored-out-of-view
title: "Door lamp/motor nodes invisible (authored beside the camera)"
category: mistake
when: "Placing props in Blender for a fixed-camera game."
related: []
origin: FNAP
---

# Door lamp/motor nodes invisible (authored beside the camera)

**When to use:** Placing props in Blender for a fixed-camera game.

## Do this

Dump node positions (`inspect_glb.py`) and move them in Blender into view.

## What happened, root cause, fix, prevention

Symptom: props not visible. Cause: out of view. Fix above.

## Verify

Screenshot from PlayerCamera.

## Origin

FNAP. Source notes: mistakes-log.md M47.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
