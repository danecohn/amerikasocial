---
id: fnaf-cast-one-rule-per-enemy
title: "Design each animatronic around one rule and one counter"
category: ai-enemies
when: "Designing the enemy roster of a FNAF-like, or adding a new enemy."
related: []
origin: FNAP
---

# Design each animatronic around one rule and one counter

**When to use:** Designing the enemy roster of a FNAF-like, or adding a new enemy.

## Do this

FNAP roster (copy the STRUCTURE, rename everything):
| Enemy | Path / side | Rule (how it moves) | Counter | Tell |
|---|---|---|---|---|
| Pickle (lead singer dog) | east -> RIGHT door (also the power-out attacker at LEFT door) | moves only when nobody is watching its room (`moves_only_unwatched`); "patient": waits at the door longer; leaves the stage only after the other two stage actors are gone | don't stare at the stage; shut right door | huff-laugh sfx on move; eyes/teeth in dark hall cams |
| Remi (bass hamster) | west -> LEFT door | normal patrol | flashlight held on his face for 0.7 s makes him retreat, or shut door | footsteps (quick pads + servo) |
| Dilly (duck) | east -> RIGHT door | normal patrol; the Kitchen cam has no picture | listen: pots clatter = she is in the kitchen; shut right door | `kitchen-pots-clatter-loop` |
| Banshee (other dog, in the cove) | cove -> west hall -> LEFT door | waits behind a curtain; curtain opens in stages while NOT watched; then sprints | watch the cove camera; shut LEFT door before she arrives; stay quiet while she bangs | curtain stage, `brine-cove-hum`, gallop sfx |
| Golden Pickle (hallucination) | no path | appears on a back camera / slumped in the office chair | lift the monitor (it vanishes); don't stare | whisper drone; never named |
- Walk speeds (m/s, listed in this order in REF): 0.8 / 0.72 / 0.76 / 0.72 (run 3.3) / 0.64 (Pickle, Remi, Dilly,
  Banshee, Golden). Walk speeds are a team "hard rule" in the brief, i.e. fixed numbers shared by animation and AI.
- Behaviour motive from BIBLE (gives AI a reason): robots "read the person as an unfinished costume and try to complete
  the shop around them. They are not cruel. They are loyal in a way that stopped being safe." The runner is the
  exception: "furious about being left behind the curtain, and that anger is why she runs." Give each enemy a motive
  that explains its movement rule.
- Stage-leave order (STATEMAP CAM 1A note): "Pickle only leaves after Remi and Dilly have both left, as in the original
  game" -> there is no "Pickle gone, others present" state. Ordered departures reduce the number of camera images
  needed and give the player a readable progression.

## Pitfalls (mistakes seen)

Story and AI must agree on sides and rules; the bible states them as "Rules the Story Keeps" so writers and
coders share one truth.

## Verify

For each enemy, a sim run (fnaf-balance-sims) shows the counter works (retreat/regroup happens) and the call for
that night mentions the rule.

## Origin

FNAP. Source notes: BIBLE "Who Built the Robots", "What the Robots Want", "Rules the Story Keeps"; CALLS N2-N4; REF §2.5;
STATEMAP lines 11-17, 77-79.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
