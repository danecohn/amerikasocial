---
id: godot-class-cache-register-via-import
title: "New class_name scripts "not declared" until --import refreshes the global class cache"
category: mistake
when: "Agents add new `class_name` scripts in a copied/merged tree, then run tests without importing. - knowledge/mistakes: Symptom: dependents fail with '<Class> not declared' (LightSensor, Interactor, UITheme, TrimMaterials). Root cause: `.godot/global_script_class_cache.cfg` lacked the new classes (tree copied without `.godot`, or files dropped in externally). Fix: run `godot --headless --path . --import` first; it registered them. Prevention: every validation sequence starts with `--import`; after merging files from another agent always import before testing. Detection: grep test log for 'not declared' / 'Could not find type'."
related: []
origin: Caesarea
---

# New class_name scripts "not declared" until --import refreshes the global class cache

**When to use:** Agents add new `class_name` scripts in a copied/merged tree, then run tests without importing. - knowledge/mistakes: Symptom: dependents fail with "<Class> not declared" (LightSensor, Interactor, UITheme, TrimMaterials). Root cause: `.godot/global_script_class_cache.cfg` lacked the new classes (tree copied without `.godot`, or files dropped in externally). Fix: run `godot --headless --path . --import` first; it registered them. Prevention: every validation sequence starts with `--import`; after merging files from another agent always import before testing. Detection: grep test log for "not declared" / "Could not find type".

## Origin

Caesarea. Source notes: MANIFEST gate (2026-10-09 Cursor).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
