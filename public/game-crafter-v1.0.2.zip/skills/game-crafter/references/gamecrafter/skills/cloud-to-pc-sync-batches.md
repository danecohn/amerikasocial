---
id: cloud-to-pc-sync-batches
title: "sync_to_pc.py — stage changed files and emit device-bridge commit batches"
category: delivery-pc-bridge
when: "Working in a cloud copy whose durable home is the user's PC; bridge has per-call limits."
related: []
origin: Caesarea
---

# sync_to_pc.py — stage changed files and emit device-bridge commit batches

**When to use:** Working in a cloud copy whose durable home is the user's PC; bridge has per-call limits.

## Do this

Walk project, skip dirs `out art_source .godot build dist .git __pycache__ _work .sync_tmp`, skip `.import .tmp .pyc` (keep `.uid`); files newer than `.sync_stamp` (or `--all`); refuse > 30 MB ("TOO BIG (build on PC)"); copy into staging mirror `/mnt/user-data/outputs/<Game>/<rel>`; batches of ≤45 files `{"devicePath": PC + rel.replace("/", "\\"), "stagedPath": ...}` written to JSON; `--mark` updates the stamp only after a successful commit. MANIFEST rule: "Anything not committed to the PC can be lost. Sync often."

## Pitfalls (mistakes seen)

Two trees (OneDrive project of record and a separate work copy) diverged → integration hazard. Keep one project of record; the other is scratch.

## Origin

Caesarea. Source notes: tools/sync_to_pc.py; MANIFEST hard rule 2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
