# Tool: godot_xvfb.sh

**Purpose:** Run Godot with a virtual display and software rendering on a GPU-less cloud machine (screenshots, Movie Maker).

**Usage:** `bash godot_xvfb.sh --path <proj> <args>`

**Skill:** see `skills/headless-screenshot-harness-xvfb.md`

**Extract:** save the block below as `godot_xvfb.sh` (exact contents) and run it. Adapt paths marked `<...>`.

```bash
#!/usr/bin/env bash
# Run Godot WITH A RENDERER on a GPU-less Linux box (software Vulkan via SwiftShader/lavapipe under Xvfb).
# Pure `godot --headless` has a dummy renderer: screenshots from it are black/empty. Use this wrapper for pixels.
# Usage: godot_xvfb.sh [-r WxH] [-t timeout_s] [-l logfile] -- <godot args...>
#   godot_xvfb.sh -r 1280x720 -t 300 -l /tmp/shot.log -- --path ./proj res://scenes/main.tscn -- --gm-quit-after=10
# Notes: ~5 s/frame at 720p on 2 cores. ALWAYS gets a timeout so a hung scene can't block the tool call.
RES=1280x720; TMO=600; LOG=""
while getopts "r:t:l:" o; do case $o in r) RES=$OPTARG;; t) TMO=$OPTARG;; l) LOG=$OPTARG;; esac; done; shift $((OPTIND-1)); [ "${1:-}" = "--" ] && shift
ICD="${VK_ICD_FILENAMES:-}"
[ -z "$ICD" ] && ICD=$(ls /opt/pw-browsers/*/chrome-linux/vk_swiftshader_icd.json 2>/dev/null | head -1)
[ -z "$ICD" ] && ICD=$(ls /usr/share/vulkan/icd.d/lvp_icd*.json 2>/dev/null | head -1)
[ -z "$ICD" ] && { echo "no software Vulkan ICD found; try --rendering-driver opengl3 (llvmpipe) or apt install mesa-vulkan-drivers" >&2; }
export VK_ICD_FILENAMES="$ICD"
GODOT="${GODOT:-godot}"
CMD=(timeout "$TMO" xvfb-run -a -s "-screen 0 ${RES}x24" "$GODOT" --rendering-driver vulkan --resolution "$RES" "$@")
if [ -n "$LOG" ]; then "${CMD[@]}" >"$LOG" 2>&1; rc=$?; tail -5 "$LOG"; else "${CMD[@]}"; rc=$?; fi
[ $rc -eq 124 ] && echo "TIMED OUT after ${TMO}s - scene never quit()? add get_tree().quit() / --quit-after" >&2
exit $rc
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
