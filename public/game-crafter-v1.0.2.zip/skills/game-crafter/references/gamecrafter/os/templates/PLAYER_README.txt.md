# Template: PLAYER_README.txt (ships inside every zip — plain text, no markdown when you save it)
```
<GAME TITLE> v<x.y.z>
by <STUDIO>

HOW TO PLAY
- Windows: unzip, run <Game>.exe. If Windows SmartScreen appears: More info > Run anyway (the game is not code-signed).
- Windows on ARM (Surface, Snapdragon laptops): use the Windows-ARM64 zip.
- macOS: unzip, right-click <Game>.app > Open > Open (first time only; the app is not notarized).
- Linux: unzip, then: chmod +x <Game>.x86_64 && ./<Game>.x86_64

CONTROLS
<table of controls>

SAVES
Progress saves automatically (on each night/level change and when you quit).
Save location: Windows %APPDATA%\Godot\app_userdata\<Game>  ·  macOS ~/Library/Application Support/Godot/app_userdata/<Game>  ·  Linux ~/.local/share/godot/app_userdata/<Game>

SOUNDTRACK
The Soundtrack folder has the game's music as audio files.

CREDITS
<the one credit line>
```
