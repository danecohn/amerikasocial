---
id: export-presets-four-platforms
title: "4-platform export_presets.cfg template"
category: export-release
when: "New project or adding platforms (Windows x64, macOS universal, Linux x86_64, Windows ARM64)."
related: []
origin: FNAP
---

# 4-platform export_presets.cfg template

**When to use:** New project or adding platforms (Windows x64, macOS universal, Linux x86_64, Windows ARM64).

## Do this

Preset names (case-sensitive, must match CLI): `Windows Desktop`, `macOS`, `Linux`, `Windows ARM64` (platform="Windows Desktop", runnable=false). Common: `export_filter="all_resources"`, identical include/exclude filters, `script_export_mode=2`, `encrypt_pck=false`. Windows options: `binary_format/architecture="x86_64"`, `binary_format/embed_pck=true` (single exe), `texture_format/s3tc_bptc=true`, `etc2_astc=false`, `debug/export_console_wrapper=1` (adds console exe for logs), `application/modify_resources=true`, `application/icon="res://icon.ico"` (needs rcedit, otherwise non-fatal Godot icon), company_name/product_name/file_version="1.0.0.0"/product_version. macOS: `architecture="universal"`, `application/bundle_identifier="com.you.game"`, `min_macos_version="11.00"`, `app_category="Games"`, `codesign/codesign=0`, `notarization/notarization=0`, export_path `build/macos/<Name>-mac.zip`. Linux: x86_64, embed_pck=true, s3tc_bptc. ARM64: `architecture="arm64"`, embed_pck, console wrapper, modify_resources. Export paths `build/{windows,macos,linux,windows_arm64}/`. Presets are `[preset.N]` + `[preset.N.options]`; open the Export dialog once in the editor so Godot adds version-specific keys, then merge.

## Pitfalls (mistakes seen)

macOS universal export refused -> project settings lacked `rendering/textures/vram_compression/import_s3tc_bptc=true` AND `import_etc2_astc=true` -> enable both. Missing preset -> export exits non-zero and no file -> always check exit code AND that file exists.

## Verify

All four exports produce files; mac zip contains .app.

## Origin

FNAP. Source notes: templates/export_presets.template.cfg; SKILL.md lines 17-23.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
