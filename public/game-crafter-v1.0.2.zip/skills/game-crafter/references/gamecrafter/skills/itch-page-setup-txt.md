---
id: itch-page-setup-txt
title: "itch.txt - field-by-field copy/paste guide for the itch.io "new project" form"
category: promo-marketing
when: "Preparing a game's itch.io page for the user to publish themselves. - knowledge (fields in form order, all templated from META):   - Header: 'Fill the boxes on https://itch.io/game/new in this order. Copy/paste exactly. (Nothing has been uploaded or published. ... Save as DRAFT first, check the preview, then switch Visibility to Public.)'   - TITLE; PROJECT URL `https://forgottenwoods.itch.io/<itch-slug>` + '(just the last part: <slug>)'; SHORT DESCRIPTION (< ~100 chars, format 'Pixel-art horror roguelike. <three escalating images>.'); CLASSIFICATION Games; KIND Downloadable; RELEASE STATUS Released; PRICING (see itch-pricing-launch-strategy); DESCRIPTION block between rule lines; GENRE top 2 ('Action, Role Playing (roguelike goes in the tags)'); TAGS (10, ordered); CUSTOM NOUN game.   - UPLOADS: all four zips, tick platform on each: Windows_x64 -> Windows, Windows_ARM64 -> Windows ('name it clearly so ARM owners find it'), Linux, Mac -> macOS; Display names 'Windows (64-bit)', 'Windows (ARM64)', 'Linux', 'macOS'; 'played in the browser': NO; 'If split, run DISTRIBUTION\ASSEMBLE_ZIPS.bat first'.   - EMBED blank; COVER `ADVERTISEMENTS\itch_cover_630x500.png` (630x500; min 315x250); SCREENSHOTS 5 in order (1920x1080 real captures, pixel-perfect 5x); GAMEPLAY VIDEO blank until trailer exists.   - COMMUNITY: Comments on ('comments boost the itch.io algorithm'), Discussion board off unless moderating.   - MORE INFORMATION: release date, Author 'Forgotten Woods Studios', average session ('25-40 minutes per descent; about 5 hours to see every ending'), Languages English, Inputs Keyboard, Mouse ('controller is NOT supported yet'), Multiplayer none, Links, Accessibility ('screen shake can be turned off in Options; talk-blips can be turned off; no flashing-light sequences'), Player count Single player.   - CONTENT WARNING: optional mature tick; warnings already in description.   - GENERATIVE AI DISCLOSURE (see itch-ai-disclosure)."
related: []
origin: Roguelike series
---

# itch.txt - field-by-field copy/paste guide for the itch.io "new project" form

**When to use:** Preparing a game's itch.io page for the user to publish themselves. - knowledge (fields in form order, all templated from META):   - Header: "Fill the boxes on https://itch.io/game/new in this order. Copy/paste exactly. (Nothing has been uploaded or published. ... Save as DRAFT first, check the preview, then switch Visibility to Public.)"   - TITLE; PROJECT URL `https://forgottenwoods.itch.io/<itch-slug>` + "(just the last part: <slug>)"; SHORT DESCRIPTION (< ~100 chars, format "Pixel-art horror roguelike. <three escalating images>."); CLASSIFICATION Games; KIND Downloadable; RELEASE STATUS Released; PRICING (see itch-pricing-launch-strategy); DESCRIPTION block between rule lines; GENRE top 2 ("Action, Role Playing (roguelike goes in the tags)"); TAGS (10, ordered); CUSTOM NOUN game.   - UPLOADS: all four zips, tick platform on each: Windows_x64 -> Windows, Windows_ARM64 -> Windows ("name it clearly so ARM owners find it"), Linux, Mac -> macOS; Display names "Windows (64-bit)", "Windows (ARM64)", "Linux", "macOS"; "played in the browser": NO; "If split, run DISTRIBUTION\ASSEMBLE_ZIPS.bat first".   - EMBED blank; COVER `ADVERTISEMENTS\itch_cover_630x500.png` (630x500; min 315x250); SCREENSHOTS 5 in order (1920x1080 real captures, pixel-perfect 5x); GAMEPLAY VIDEO blank until trailer exists.   - COMMUNITY: Comments on ("comments boost the itch.io algorithm"), Discussion board off unless moderating.   - MORE INFORMATION: release date, Author "Forgotten Woods Studios", average session ("25-40 minutes per descent; about 5 hours to see every ending"), Languages English, Inputs Keyboard, Mouse ("controller is NOT supported yet"), Multiplayer none, Links, Accessibility ("screen shake can be turned off in Options; talk-blips can be turned off; no flashing-light sequences"), Player count Single player.   - CONTENT WARNING: optional mature tick; warnings already in description.   - GENERATIVE AI DISCLOSURE (see itch-ai-disclosure).

## Pitfalls (mistakes seen)

none.

## Verify

every file named in itch.txt exists in the folder; slug matches URL.

## Origin

Roguelike series. Source notes: pack.py L15-112; THE LAST LAMP/ADVERTISEMENTS/itch.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
