---
id: boss-sprite-from-recipe
title: "Bosses = creature recipe upscaled 2-3x (nearest) + decorator, then outlined"
category: pixel-art-2d
when: "Need large boss sprites consistent with small enemies."
related: []
origin: Roguelike series
---

# Bosses = creature recipe upscaled 2-3x (nearest) + decorator, then outlined

**When to use:** Need large boss sprites consistent with small enemies.

## Do this

```python
def boss_from(recipe, pal, k=2, seed=1, extra=None, **kw):
    frames = []
    for f in range(2):
        base = RECIPES[recipe](pal, f, random.Random(seed), seed=seed, **kw)
        base = scale_up(base, k)              # chunky k-px pixels
        if extra: extra(base, pal, f)         # 1px-detail decorations at the big size
        frames.append(finish(base, pal, outline=True))
    return frames
```
- Decorator examples: keeper (lantern + cap rects), matron (dress hem lines `(f+i)%2` wiggle + violet hood triangle), marigold (14 random 4x4 lantern squares blinking `(i+f)%3`), dark (red eye blocks + 4 dark tendrils), WARD SEVEN "tone" (flat ECG line `h//2 + ((f+x)%4==0)` in #40ff90).
- Sizes shipped: boss_dark 60x62 (2 frames), boss_keeper 92x50, boss_marigold 112x50 (k=3 blob), boss_matron 68x38.

## Pitfalls (mistakes seen)

mixed pixel density - body pixels are k px but outline, highlights and decorations are 1px, so bosses look higher-res than enemies (visible on THE CHORUS boss). Choose deliberately; for strict 8-bit consistency draw boss recipes at native larger size or apply finish() before scale_up.

## Verify

contact row 3 at 3x.

## Origin

Roguelike series. Source notes: _tools/sprites.py lines 413-426; games/*/spec.py `_x_*` functions; screenshot_03.png.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
