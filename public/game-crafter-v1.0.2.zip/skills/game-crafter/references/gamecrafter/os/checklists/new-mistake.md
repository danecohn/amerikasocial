# Recording a new mistake (LAW 15)
1. Fix it and prove the fix in the exported build.
2. Copy `os/templates/MISTAKE_TEMPLATE.md` → `skills/mistake-<short-name>.md`.
3. Fill: what the user saw (quote them), root cause, exact fix (code), prevention rule, detection check.
4. Add a line in `skills/SKILLS.md` under **Mistakes** with the symptom as the trigger.
5. If a check could catch it automatically, add it to `os/tools/` (lint rule, probe check) and to `pre-delivery.md`.
6. Note it in the project's CHANGELOG.md.
