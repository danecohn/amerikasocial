---
id: fnaf-balance-sims
title: "Balance by simulation (patrol_sim, auto_mode_sim, balance_regression)"
category: testing-qa
when: "Tuning AI tables, power costs, helper failure rates."
related: []
origin: FNAP
---

# Balance by simulation (patrol_sim, auto_mode_sim, balance_regression)

**When to use:** Tuning AI tables, power costs, helper failure rates.

## Do this

- `patrol_sim.gd` (SceneTree script, `godot --headless --path . -s res://scripts/dev/patrol_sim.gd`): replays the real
  patrol rules with the real `.tres` resources vs player styles (turtle / peek / sloppy); reports survival and power.
  Nights 2-5 AI levels were retuned from it.
- `auto_mode_sim.gd`: nights 1-5 for always_on vs smart auto mode using the shared pure `AssistantAuto`.
- `balance_regression.gd`: loads the real office on night 5, sends Remi/Banshee at a shut door, asserts retreat rooms and
  bang power costs; prints `BALANCE_REGRESSION_PASS/FAIL`, exit 0/1.
- Keep decision logic in pure RefCounted classes so sims and game share numbers.

## Pitfalls (mistakes seen)

tuning by feel; sims that re-implement rules drift from the game (use the real resources/classes).

## Verify

The sims' exit code gates the build.

## Origin

FNAP. Source notes: REF §5.1, §5.2, §2.11.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
