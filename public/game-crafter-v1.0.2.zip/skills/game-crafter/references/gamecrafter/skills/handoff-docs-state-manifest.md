---
id: handoff-docs-state-manifest
title: "Keep STATE / STATUS / MANIFEST / SHIP_NOTES so any agent can resume"
category: project-management
when: "After every major change (user's standing instruction: save to the project folder and update manifest and bible)."
related: []
origin: Pickle's Pickle Shop
---

# Keep STATE / STATUS / MANIFEST / SHIP_NOTES so any agent can resume

**When to use:** After every major change (user's standing instruction: save to the project folder and update manifest and bible).

## Do this

Files used: STATE.md (recovered architecture: flow table, autoloads, systems, what's 2D vs 3D, which GLBs load from where, clip list), STATUS.md (this pass, headless checks run with exact commands and results, packages, still missing), AUDIO_STATUS.md (done / still to make / rules for adding audio, voice settings), MANIFEST.md (DONE / ALSO DONE / TODO-NOT DONE / feature notes / export fix / invented characters / dev tools), MINI_SPEC.md (a spec precise enough to hand to sub-agents: files to read, contract, rules of the form, test command, canon), README.txt (folder map: DISTRIBUTION, ADVERTISEMENTS, BIBLE, MANIFEST, GODOT parts + UNPACK bat), SHIP_NOTES.txt (dated: fixed, restored, verified, NOT verified). Always list "NOT verified" explicitly.

## Verify

A fresh agent can answer "what's left" from the docs alone.

## Origin

Pickle's Pickle Shop. Source notes: STATE.md, STATUS.md, AUDIO_STATUS.md, MANIFEST.md, MINI_SPEC.md, README.txt, SHIP_NOTES.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
