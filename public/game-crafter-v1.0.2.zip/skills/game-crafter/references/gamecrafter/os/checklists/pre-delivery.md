# Pre-delivery gate
Don't say "done", "fixed" or "shipped" until every box is ticked or explicitly disclosed as not verified.

## Proof
- [ ] I ran it, and I **opened** the screenshot / video frame / log that proves it (LAW 5).
- [ ] I tested the **exported** build (pack or exe), not just the editor (LAW 1). See `export-verify.md`.
- [ ] Every remote job I launched (PC build, upload, render, edit) — I **read its log/result**.
- [ ] The specific thing the user complained about: reproduced before, gone after, shown with an image.

## Integrity
- [ ] No fix works by hiding a mesh, zeroing a light/layer, flattening a material, or silencing a warning (LAW 4, `os/tools/hide_audit.md`).
- [ ] `lint_export_safety` passes: 0 errors, warnings justified (LAW 2).
- [ ] No placeholder visible anywhere in the release build: characters, props, jumpscares, menus, icons (LAW 3).
- [ ] All animations present: every character has every required clip, including jumpscares (`skills/clip-manifest-json.md`).
- [ ] Standing instructions in STATE.md are all still true (e.g. dark halls stay dark) (LAW 6).
- [ ] If the user edited files since my last session, I merged their changes and re-ran the parse check (LAW 11).
- [ ] Save → quit → relaunch → progress still there.

## Delivery
- [ ] Files are in the exact folder the user named. I listed it and the sizes/timestamps are new (LAW 8).
- [ ] The folder isn't left half old, half new. If a transfer is in progress, I said so.
- [ ] Large files are split with a join script (`BUILD_ALL.bat` / `ASSEMBLE_ZIPS.ps1`) and SHA256 sums.
- [ ] Each zip has: game, `Soundtrack/`, `credits.txt` / README, the correct icon.
- [ ] Nothing was uploaded, published or posted unless asked (LAW 10). No secrets in files.

## Records
- [ ] STATE.md, CHANGELOG.md, MANIFEST.md, KNOWN_GAPS.md updated.
- [ ] New mistakes written as `skills/mistake-*.md` (LAW 15).
- [ ] The reply follows `honest-report.md`.
