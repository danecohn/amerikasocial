# Tool: game_state_template.gd

**Purpose:** Crash-safe save system: atomic write (tmp+rename), save on progress + close request + quit.

**Usage:** `autoload GameState`

**Skill:** see `skills/godot-crash-safe-forward-only-save.md`

**Extract:** save the block below as `game_state_template.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
extends Node
## Game Maker template autoload "GameState": (1) CLI flags for dev/QA/capture, (2) deterministic RNG,
## (3) crash-safe, forward-only save, (4) one quit path, (5) one scene-switch path.
## Register in project.godot:  [autoload]  GameState="*res://scripts/autoload/game_state.gd"
## Proven in Five Nights at Pickles (save survived close/crash tests; dev flags never touched the real save).

const SAVE_PATH := "user://save.cfg"
const SAVE_TMP := "user://save.cfg.tmp"
const SAVE_BAK := "user://save.cfg.bak"
const MAX_LEVEL := 5

var level := 1
var highest_level := 1
var completed := false

## Flags after "--" on the command line:  godot --path . scene.tscn -- --gm-level=3 --gm-no-save --gm-quit-after=8
var cli: Dictionary = {}
var capture_seed := 1337

func _ready() -> void:
	get_tree().set_auto_accept_quit(false)           # so we can save in WM_CLOSE_REQUEST
	load_save()
	for arg in OS.get_cmdline_user_args():
		if arg.begins_with("--gm-"):
			var kv := arg.trim_prefix("--gm-").split("=", true, 1)
			cli[kv[0]] = kv[1] if kv.size() > 1 else "1"
	if cli.has("seed"):
		capture_seed = int(cli["seed"]); seed(capture_seed)
	if cli.has("level"):
		level = clampi(int(cli["level"]), 1, MAX_LEVEL)
	if cli.has("quit-after"):                          # ALWAYS bound headless runs; a forgotten quit() hangs the tool call
		get_tree().create_timer(float(cli["quit-after"])).timeout.connect(quit_game)

## Dev/QA flags must NEVER overwrite a player's real save.
func _dev_switch_active() -> bool:
	return cli.has("no-save") or cli.has("level") or cli.has("screenshot")

## Seed any RandomNumberGenerator reproducibly when capturing/testing, randomize() otherwise.
func seed_rng(rng: RandomNumberGenerator, salt: String = "") -> void:
	if cli.has("seed"):
		rng.seed = hash("%d:%s" % [capture_seed, salt])
	else:
		rng.randomize()

func load_save() -> void:
	for path in [SAVE_PATH, SAVE_BAK, SAVE_TMP]:          # first file that parses AND has our section wins
		var cfg := ConfigFile.new()
		if FileAccess.file_exists(path) and cfg.load(path) == OK and cfg.has_section("progress"):
			highest_level = clampi(int(cfg.get_value("progress", "highest_level", 1)), 1, MAX_LEVEL)
			completed = bool(cfg.get_value("progress", "completed", false))
			level = highest_level
			return

func save() -> void:
	if _dev_switch_active():
		return
	var disk := ConfigFile.new()
	var disk_ok := FileAccess.file_exists(SAVE_PATH) and disk.load(SAVE_PATH) == OK
	if disk_ok:   # forward-only merge: a stale in-memory state can never regress saved progress
		highest_level = maxi(highest_level, clampi(int(disk.get_value("progress", "highest_level", 1)), 1, MAX_LEVEL))
		completed = completed or bool(disk.get_value("progress", "completed", false))
	var out := ConfigFile.new()
	out.set_value("progress", "highest_level", highest_level)
	out.set_value("progress", "completed", completed)
	if out.save(SAVE_TMP) != OK:
		return
	if disk_ok:
		DirAccess.copy_absolute(SAVE_PATH, SAVE_BAK)
	if DirAccess.rename_absolute(SAVE_TMP, SAVE_PATH) != OK:   # rename can fail if the target exists on some filesystems
		DirAccess.remove_absolute(SAVE_PATH)
		DirAccess.rename_absolute(SAVE_TMP, SAVE_PATH)

func _notification(what: int) -> void:
	match what:
		NOTIFICATION_WM_CLOSE_REQUEST, NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_APPLICATION_PAUSED:
			save()
			if what == NOTIFICATION_WM_CLOSE_REQUEST:
				get_tree().quit()

## Every quit path (menu, credits, pause, errors) calls this - never raw get_tree().quit().
func quit_game() -> void:
	save()
	get_tree().quit()

## Every scene change goes through here so loops/music/ducks are stopped consistently.
func change_scene(path: String) -> void:
	# AudioManager.stop_all_loops()  # and reset ducks - a cut-off phone call once left music muted in the next scene
	get_tree().change_scene_to_file(path)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
