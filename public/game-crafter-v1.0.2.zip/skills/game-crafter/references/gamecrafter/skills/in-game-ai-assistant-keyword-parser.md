---
id: in-game-ai-assistant-keyword-parser
title: "Fake "LLM" terminal assistant: fuzzy keyword intent parser (no live model)"
category: gameplay-systems
when: "You want an in-game chatbot/terminal (Pickle-GPT) that understands loose typed commands offline and deterministically."
related: []
origin: Pickle's Pickle Shop
---

# Fake "LLM" terminal assistant: fuzzy keyword intent parser (no live model)

**When to use:** You want an in-game chatbot/terminal (Pickle-GPT) that understands loose typed commands offline and deterministically.

## Do this

Data-driven `assets/data/assistant_lines.json` with keys: name, boot, thinking, intents{intent:{keywords, cost, success[], optional variants like not_at_door/in_office}}, unknown[], failures{mishear, wrong_answer, refusal, hallucination, meme}, room_aliases{CAM_x:[...]}, character_aliases, swapped_poster. Placeholders `{side} {cam} {cam_name} {who} {room} {power} {time} {torch}` filled by `fill()`. Parser: lowercase, split, strip non-alnum (keep '?'); detect side (left/west/l vs right/east/r, Levenshtein<=1 for 4+ letter words, but skip light/night/might/sight/fight/tight/bright so "lights" never reads as a side), camera via regex `(?:cam(?:era)?\s*)?\b([1-7])\s*([abc])?\b` then longest alias, character by alias (golden_pickle checked before pickle). Score each intent: multi-word keyword = 1.5 if substring; single word exact = 1.0; fuzzy Levenshtein <= 1 (len<7) or <= 2 = 0.8. Highest wins. Overrides: forecast words ("forecast", "what should i do") -> forecast unless a command intent; lore entries (Story.lore.gpt_lore keys) win if score>=1 and >= command score and not a command; who present + camera/where -> where; cam only -> camera; door intents need a door/side word; `hall_lights_on` + any of off/out/kill/darken/dark/disable -> `hall_lights_off`. Each intent has a power cost (door_close 1.0, flashlight_charge 3.0, music 1.5, hall_lights_on 1.2, off 0.4, help 0). Reply after random "thinking" delay 1.5-4.0 s * speed with spinner `| / - \` and a thinking loop sound; single-threaded ("One thing at a time! I'm a single-threaded pickle."). Failure rate by night: `clamp(0.08 + 0.08*(night-1) + fail_delta, 0.04, 0.85)` (N1 8% .. N5 40%); help never fails; failure kinds weighted per intent (doors: mishear 40% -> acts on the OTHER side, refusal, meme, hallucination; camera: mishear shows the poster-swapped camera; where: wrong_answer gives a wrong room). Lore answers gated by `Story.gpt_trust` (earned +0.01 per valid command, +0.06 when an archive doc unlocks). Forecast reads the real AI state (who is nearest a door) and gives advice.

## Pitfalls (mistakes seen)

Commands were too long/complex; user asked for "simpler command, like maybe two with one being 'lights on' and one being 'lights off'" -> keywords include 'lights on','lights off','lights' and help text starts with them; HUD hint `T: PickleGPT for Hall Lights ("lights on" / "lights off")`. Typed-array runtime errors silently killed actions.

## Verify

Headless parse test: feed strings ("lights on", "lights off", "turn off the lights", "close left door", "cam 2b", "where is remi", "lihgts on") and assert intent/side/cam.

## Origin

Pickle's Pickle Shop. Source notes: scripts/assistant/assistant_brain.gd L1-222; shop_assistant.gd L274-516; assets/data/assistant_lines.json; transcript summary sec.1, 3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
