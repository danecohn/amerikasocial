---
id: fnaf-await-token-guard
title: "Token-guard every await chain (calls, walk tweens, reveals)"
category: gdscript-patterns
when: "Any coroutine (`await`) can outlive the state that started it."
related: []
origin: FNAP
---

# Token-guard every await chain (calls, walk tweens, reveals)

**When to use:** Any coroutine (`await`) can outlive the state that started it.

## Do this

- `_token += 1` at every restart/exit; after each `await`, `if token != _token: return`. Used in `phone_call.gd`,
`animatronic.gd` (`_visual_token`, `_door_token`).
```gdscript
var _token := 0
func play_call(n: int) -> void:
    _token += 1
    var my := _token
    await get_tree().create_timer(9.7).timeout
    if my != _token: return
    ...
func _exit_tree() -> void:
    _token += 1
    AudioManager.set_voice_duck(false)
```

## Pitfalls (mistakes seen)

stale callbacks firing in a different scene state.

## Verify

Die mid-call, return to menu: no subtitles/ducking persist.

## Origin

FNAP. Source notes: REF §2.12, §8.1 F.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
