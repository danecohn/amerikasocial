---
id: light-resource-darkness-shader
title: "Shrinking light radius resource (OIL/AIR) with dithered darkness post-process"
category: gameplay-systems
when: "Horror top-down games where a light/air meter limits visibility."
related: []
origin: Roguelike series
---

# Shrinking light radius resource (OIL/AIR) with dithered darkness post-process

**When to use:** Horror top-down games where a light/air meter limits visibility.

## Do this

- Data `mechanics.light = {name, radius 130, min 48, drain 0.010-0.012, kill_gain 0.035, dark 0.88-0.92}`.
- Drain only in combat/boss: `light -= drain*delta*(1 - light_regen)`; kills add kill_gain; room clear +0.25; event room exit +0.1; sanctuary refills to 1.
- Radius = `min + (max-min)*light` where max = radius*(1+0.5*(light_stat-1)); flicker `1 + sin(ms*0.013)*0.015 + rand(-0.01..0.01)`; centre = player screen pos (room offset + (0,-8)).
- At 0 light: "THE DARK BITES." - 1 damage every 5s in combat.
- PostFx CanvasLayer layer 10 (HUD layer 20 sits above): full-screen ColorRect with a canvas_item shader reading `hint_screen_texture, filter_nearest`; computes pixel coords `floor(UV*vec2(384,216))`; darkness `k = clamp((d - r*0.55)/(r*0.45))^2`, quantised with a 4x4 Bayer matrix into 5 bands `floor(k*5 + bayer)/5` -> retro dithered falloff; `lit = max(1 - q*dark, 1 - dark)`.
- Same shader also does vignette (`1 - v*d^2`, d=dist*1.45), film grain (hash noise * grain), scanlines (`1 - 0.06*step(0.5, fract(y*0.5))`), hurt red flash (mix to #d90d14 by hurt*0.45, decays 2.5/s), sanity warp + chromatic split + desaturation, global tint and `fade` to black (used for room transitions).
- Per-game fx data: vignette 0.4-0.45, grain 0.05-0.06, tint e.g. [0.95,1.0,1.05].
- `disable_light()` sets radius 99999 (hub/title/ending).

## Pitfalls (mistakes seen)

none recorded.

## Verify

screenshot at full vs low light (`--speed` + wait).

## Origin

Roguelike series. Source notes: run.gd 544-564; postfx.gd shader; spec.py GAME mechanics/fx.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
