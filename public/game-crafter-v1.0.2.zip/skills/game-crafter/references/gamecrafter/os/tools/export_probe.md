# Tool: export_probe.gd

**Purpose:** A probe scene script that loads every required resource from inside the exported pack and prints PROBE_FAIL / PROBE_DONE fails=N.

**Usage:** `godot --main-pack game.pck res://dev/export_probe.tscn`

**Skill:** see `skills/export-probe-template.md`

**Extract:** save the block below as `export_probe.gd` (exact contents) and run it. Adapt paths marked `<...>`.

```gdscript
extends Node
## Game Maker template: EXPORT PROBE. Ship it (it is tiny) so you can prove the BUILT game finds its assets.
## It checks, from inside the exported pack, that every required resource resolves with load()/ResourceLoader
## and that every required raw data file is present, then prints machine-greppable lines and quits.
## Run:  godot --main-pack build/test.pck res://tools/export_probe.tscn   (or the exe: game.exe --export-probe via main scene hook)
## Edit res://tools/probe_manifest.json (json ships by itself, so keep it in the include_filter anyway) -> {"resources":["res://assets/models/office/office.glb", ...], "raw_files":["res://assets/data/lines.json"], "dirs":[{"dir":"res://assets/models/rooms","min_files":3}]}
const MANIFEST := "res://tools/probe_manifest.json"
func _ready() -> void:
	var fails := 0
	var m: Variant = JSON.parse_string(FileAccess.get_file_as_string(MANIFEST)) if FileAccess.file_exists(MANIFEST) else null
	if m == null:
		print("PROBE_FAIL manifest missing/invalid (add *.json to include_filter): ", MANIFEST); get_tree().quit(2); return
	print("PROBE renderer=", RenderingServer.get_current_rendering_method(), " adapter=", RenderingServer.get_video_adapter_name(), " debug_build=", OS.is_debug_build())
	for p in m.get("resources", []):
		var ok := ResourceLoader.exists(p)
		var res: Resource = load(p) if ok else null
		print(("PROBE_OK   " if res else "PROBE_FAIL ") + "load " + p); fails += 0 if res else 1
	for p in m.get("raw_files", []):
		var ok2 := FileAccess.file_exists(p)
		print(("PROBE_OK   " if ok2 else "PROBE_FAIL ") + "raw  " + p + ("" if ok2 else "  <- add to include_filter")); fails += 0 if ok2 else 1
	for d in m.get("dirs", []):
		var da := DirAccess.open(d["dir"])
		var n := 0
		if da:
			var seen := {}
			for f in da.get_files():
				seen[NodeFinder.packed_name(f)] = true
			n = seen.size()
		var ok3 := n >= int(d.get("min_files", 1))
		print(("PROBE_OK   " if ok3 else "PROBE_FAIL ") + "dir  %s files=%d (min %d)" % [d["dir"], n, int(d.get("min_files", 1))]); fails += 0 if ok3 else 1
	print("PROBE_DONE fails=", fails)
	get_tree().quit(1 if fails else 0)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
