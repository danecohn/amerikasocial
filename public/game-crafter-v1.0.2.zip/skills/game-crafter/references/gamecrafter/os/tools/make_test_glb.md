# Tool: make_test_glb.py

**Purpose:** Headless Blender: make a tiny rigged test .glb to prove the Blender→Godot pipeline end to end.

**Usage:** `blender -b -P make_test_glb.py -- out.glb`

**Skill:** see `skills/make-test-glb.md`

**Extract:** save the block below as `make_test_glb.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
"""Create a tiny textured test .glb (cube with a checker material + a named empty + a camera) - used to smoke-test the Godot import/export pipeline.
Usage: blender -b --python make_test_glb.py -- /path/out.glb
Naming contract demo: object names 'Marker_Door_L', 'Cam_Room1' are found by NodeFinder in Godot even after re-export (.001 suffixes)."""
import bpy, sys
out = sys.argv[sys.argv.index("--") + 1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(size=1.0, location=(0, 0, 0.5)); cube = bpy.context.object; cube.name = "TestCube"
m = bpy.data.materials.new("TestMat"); m.use_nodes = True
bsdf = m.node_tree.nodes["Principled BSDF"]
bsdf.inputs["Base Color"].default_value = (0.9, 0.2, 0.2, 1)   # address sockets BY NAME: index order changes between Blender versions
# NOTE: procedural nodes (Checker/Noise/Voronoi) do NOT survive glTF export - only Principled values + IMAGE textures do. Bake procedurals to images first.
cube.data.materials.append(m)
e = bpy.data.objects.new("Marker_Door_L", None); e.location = (1, 0, 0); bpy.context.collection.objects.link(e)
c = bpy.data.objects.new("Cam_Room1", bpy.data.cameras.new("Cam_Room1")); c.location = (3, -3, 2); c.rotation_euler = (1.1, 0, 0.8); bpy.context.collection.objects.link(c)
bpy.ops.export_scene.gltf(filepath=out, export_format='GLB', export_cameras=True, export_extras=True)
print("DONE", out)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
