---
id: mistake-descript-quality-claims
title: "Quality claims about Descript output"
category: mistake
when: "Reporting on Descript edits."
related: []
origin: FNAP
---

# Quality claims about Descript output

**When to use:** Reporting on Descript edits.

## Do this

Agent never plays it back; can't measure clipping; no real flicker/fade/beat-sync verification. Report Underlord's caveats verbatim; tell the user to scrub it.

## What happened, root cause, fix, prevention

Symptom: overclaimed quality. Fix above.

## Verify

Caveats in reply.

## Origin

FNAP. Source notes: mistakes-log.md M88.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
