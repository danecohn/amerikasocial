---
id: descript-directing-underlord
title: "Directing Descript's Agent Underlord"
category: promo-marketing
when: "Polishing a trailer in Descript."
related: []
origin: FNAP
---

# Directing Descript's Agent Underlord

**When to use:** Polishing a trailer in Descript.

## Do this

Underlord plans first on big creative prompts and returns a `<creative-brief>`; reply on the same `conversation_id`: "Yes, go ahead with that plan exactly... Don't ask more questions; make the creative calls yourself and execute everything now." It silently skips parts of long lists -> number requirements; after each pass ask "exactly what you did and what failed"; re-issue skipped items. Expect 2-3 passes (credits: ~12 simple replace, ~4 plan, ~23 first polish, ~27 second). Limits: never plays back (checks still frames); can't measure clipping; cuts from story beats not waveform; no audio fade control (3-step volume drop); no true flicker (black dips); stock SFX only; punch-in sometimes fails; titles can land on burned-in cards. Pass `conversation_id` for continuity, `composition_id` to target one timeline. Brief that worked: structure table with timestamps (hook 0-2 s, build, escalate, scare, end card), look (grade, vignette, grain, glitch transitions), type (bold caps, short lines, safe zones), audio (music -12 dB, stings -6 dB, riser, fade), per-format differences, which assets to use (raw gameplay for B-roll). Call it "Agent Underlord" to the user.

## Pitfalls (mistakes seen)

Assuming all list items were done.

## Verify

Ask Underlord for a done/failed list; user scrubs result.

## Origin

FNAP. Source notes: references/descript-playbook.md "Directing Underlord".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
