---
id: fnaf-seated-view-edge-pan
title: "Seated office camera: edge pan with yaw clamps"
category: gameplay-systems
when: "Implementing the first-person seated look in a 3D office."
related: [fnaf-sight-baffles]
origin: FNAP
---

# Seated office camera: edge pan with yaw clamps

**When to use:** Implementing the first-person seated look in a 3D office.

## Do this

- `OfficeLook`: camera pans with the mouse only at screen edges (`edge_margin 0.32` of the screen), seated yaw clamp
  +-22 deg, door yaw +-28 deg. `look.shake` scales with exhaustion and is set to 1 on jumpscare.
- Typing mode (terminal) locks `OfficeLook` and tweens camera/FOV to the keyboard (FOV 54, pitch -17 deg).
- Clamp the yaw + add sight baffles instead of hiding meshes (fnaf-sight-baffles).
- Vertical capture mode uses FOV 70 with `KEEP_WIDTH`.

## Pitfalls (mistakes seen)

none recorded beyond the sight lesson.

## Verify

`seat_sight_test.gd` from every allowed seated yaw.

## Origin

FNAP. Source notes: REF §2.2, §2.11, §2.16.

## Related skills

- [fnaf-sight-baffles](fnaf-sight-baffles.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
