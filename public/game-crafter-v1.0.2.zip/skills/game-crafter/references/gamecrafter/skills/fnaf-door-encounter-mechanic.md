---
id: fnaf-door-encounter-mechanic
title: "The doorway encounter: peek, stall, approach window, bang or die"
category: ai-enemies
when: "Implementing what an enemy does when it reaches the office door (the core FNAF moment)."
related: [mistake-death-through-closed-door, mistake-frame-hitch-eats-reaction-window]
origin: FNAP
---

# The doorway encounter: peek, stall, approach window, bang or die

**When to use:** Implementing what an enemy does when it reaches the office door (the core FNAF moment).

## Do this

1. Reaching `OFFICE_DOOR_x`: play `door_peek`; if door closed -> `_start_banging()`; else wait a stall timer
   `rand(3..6) * (1 - aggression/200)` (aggression rises when the player is exhausted).
2. If the player lights the doorway AND is looking at it (`dot > 0.55`), `begin_door_approach()` starts a 3.25 s walk
   toward the office (1.45 m inward). During it: closing the door (`blocks_entry`) snaps the actor back and starts
   banging; Remi retreats (`retreat(retreat_rooms)`, `light_flinch`) if the flashlight stays on his face 0.7 s;
   otherwise when time runs out -> `trigger_jumpscare`.
3. Timer is lag-proof: `_approach_left -= min(delta, 0.1)`.
4. Banging: every 3.4 s `bangs++`, sfx, door-power drain; gives up after 2 bangs (3 for the cove attacker; 1 while the
   player holds breath) -> `retreat(rooms)` + `regroup_seconds` (50 s Pickle/Remi/Dilly, 100 s Banshee) before advancing.
5. `trigger_jumpscare()` first checks `_closed_door_blocks(a)`; if the door is shut it calls `a.refuse_closed_door()`
   (no unfair death).
- Sketch:
  ```gdscript
  const APPROACH_TIME := 3.25
  const BANG_EVERY := 3.4
  func _tick_approach(delta: float) -> void:
      _approach_left -= minf(delta, 0.1)          # a frame hitch cannot eat the reaction window
      if office.door(side).blocks_entry():
          _snap_back(); _start_banging(); return
      if data.id == "remi" and office.flashlight_on_actor_time(self) >= 0.7:
          retreat(data.retreat_rooms); play_clip_now("light_flinch"); return
      if _approach_left <= 0.0:
          office.trigger_jumpscare(self)
  func _tick_bang(delta: float) -> void:
      _bang_t -= delta
      if _bang_t > 0.0: return
      _bang_t = BANG_EVERY
      bangs += 1
      office.power.bang(bangs, data.power_drain_per_bang, data.bang_escalation)
      var limit := 1 if office.holding_breath else (3 if data.stages_in_cove else 2)
      if bangs >= limit:
          retreat(data.retreat_rooms); _regroup_left = data.regroup_seconds
  ```
- First reveal sting: `door-light-scare-sting.wav` "the first time a light reveals" an enemy at the door.
- Garble lines: `animatronic-garble-1..3.wav` play at random when a character is at a door/cam (2D package).
- `animatronic-breathing.wav` when someone has slipped into the office.

## Pitfalls (mistakes seen)

mistake-frame-hitch-eats-reaction-window; mistake-death-through-closed-door.

## Verify

`door_lurker_sim.tscn` (Pickle/Dilly advance, Remi flashlight retreat, half-shut door blocks scare);
`balance_regression.gd` sends Remi/Banshee at a shut door and asserts retreat rooms + bang power cost.

## Origin

FNAP. Source notes: REF §2.5 "Door encounter", §8.1 E; STATEMAP lines 222-226, 235.

## Related skills

- [mistake-death-through-closed-door](mistake-death-through-closed-door.md)
- [mistake-frame-hitch-eats-reaction-window](mistake-frame-hitch-eats-reaction-window.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
