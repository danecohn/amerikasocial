---
id: mistake-multi-agent-launch-stalled
title: "Agent team stalled without output"
category: mistake
when: "Launching a long multi-agent run."
related: []
origin: FNAP
---

# Agent team stalled without output

**When to use:** Launching a long multi-agent run.

## What happened, root cause, fix, prevention

- Symptom: first team launch stalled at ~00:55 with no output.
- Root cause: agents stopped early / waited.
- Fix: a "RELAUNCH 01:10" brief that told agents not to stop early; board check-ins.
- Prevention: explicit "do not stop until X" in the brief; barrier files and board timestamps to detect stalls.

## Verify

board shows posts from every role within the expected interval.

## Origin

FNAP. Source notes: REF §7 context.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
