---
id: content-rule-depict-never-endorse
title: "Writing a fascist (or otherwise abhorrent) state: depict, never endorse"
category: narrative-dialogue
when: "The game's setting is an oppressive regime, atrocity, or extremist ideology."
related: []
origin: Caesarea
---

# Writing a fascist (or otherwise abhorrent) state: depict, never endorse

**When to use:** The game's setting is an oppressive regime, atrocity, or extremist ideology.

## Do this

- Rule in every brief/handoff: "Depict fascism, never endorse it." README states it in-game-doc: "The state on screen is fascist. The game does not endorse it."
- Pillars: choice has weight (consequence ledger, no karma meter); moral difficulty over moral points (standing tracks where helping one group betrays another); "living under it" (ration card, papers, curfew, informants as mechanics); seduction and horror together — write the regime as competent ("Trains run on time, clinics are free"), not cartoonish; no faction is a hero.
- Writing rules: every dilemma ≥3 defensible options with real cost and benefit; every major NPC wants something understandable; atrocities via individual named stories first, statistics second; ideology voiced by believable characters "then tested by the world. The story lets the consequences answer the argument."; never present the ideology as correct.
- Tone limits (recommended answers): M-rated New-Vegas level; cruelty shown in setup and aftermath, not spectacle; executions framed/cut away/heard through the crowd; no sexual violence; no torture mini-games; children never killed on screen (offscreen only, learned after); darkest content via documents and photographs.
- Systemic design rule: "Every systemic gain toward one faction costs something somewhere, except acts of plain decency toward the powerless."

## Pitfalls (mistakes seen)

none recorded; the rule appears in every handoff so new agents don't drift.

## Verify

review dilemmas for ≥3 options; check no option is framed as the "correct" ideology.

## Origin

Caesarea. Source notes: master_design_bible.md §1 standing rules, §3; 00_canon_reconciliation §4; README.txt; attachment.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
