---
id: game-json-defaults-and-ui-text
title: "make_game() defaults: version, post-fx, dread names, UI text table"
category: ui-ux
when: "Assembling the game.json for a kit-driven roguelike."
related: []
origin: Roguelike series
---

# make_game() defaults: version, post-fx, dread names, UI text table

**When to use:** Assembling the game.json for a kit-driven roguelike.

## Do this

- `make_game(**kw)` sets `version "1.0.0"`, `fx {"vignette":0.4,"grain":0.05,"tint":[1,1,1]}`, `dread_names ["THE FIRST NIGHT","DREAD I".."DREAD V"]` (6 difficulty levels), and merges a DEFAULT_TEXT table so per-game copy only overrides what differs: controls_hint "WASD: MOVE   ARROWS OR MOUSE: ATTACK   SPACE: ABILITY", room_clear, dark_bites "THE DARK BITES.", death_title "YOU FALL", boon_title "CHOOSE A GIFT", inspect "[E] INSPECT", hub_hint "WALK TO THINGS AND PRESS [E].", descend, abandon "GIVE UP THE RUN", new_game, continue...
- All UI strings live in data -> reskinning a game is copy only.

## Pitfalls (mistakes seen)

none.

## Verify

grep kit for hard-coded English strings; there should be none outside the table.

## Origin

Roguelike series. Source notes: _tools/gk.py L374-391.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
