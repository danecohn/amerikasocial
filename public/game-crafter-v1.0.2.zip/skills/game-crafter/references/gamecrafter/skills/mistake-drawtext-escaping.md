---
id: mistake-drawtext-escaping
title: "ffmpeg drawtext broke on ":" "'" "%"
category: mistake
when: "Burning text into video."
related: []
origin: FNAP
---

# ffmpeg drawtext broke on ":" "'" "%

**When to use:** Burning text into video.

## Do this

Escape `\:`; use typographic `’` instead of `'`; add `expansion=none` for `%`.

## What happened, root cause, fix, prevention

Symptom: filter parse errors. Fix above.

## Verify

Render a frame and look.

## Origin

FNAP. Source notes: mistakes-log.md M61.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
