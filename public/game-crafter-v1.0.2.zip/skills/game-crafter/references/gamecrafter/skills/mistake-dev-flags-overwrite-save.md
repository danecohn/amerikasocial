---
id: mistake-dev-flags-overwrite-save
title: "Dev/QA flags overwrote a real save"
category: mistake
when: "Adding CLI dev flags (`--level`, `--screenshot`, `--no-save`)."
related: []
origin: FNAP
---

# Dev/QA flags overwrote a real save

**When to use:** Adding CLI dev flags (`--level`, `--screenshot`, `--no-save`).

## Do this

`_dev_switch_active()` returns true if any dev flag in `OS.get_cmdline_user_args()`; `save()` returns early then.

## What happened, root cause, fix, prevention

Symptom: user's progress overwritten by test run. Root cause: tests used normal save(). Fix above.

## Verify

Run with flag; save mtime unchanged.

## Origin

FNAP. Source notes: mistakes-log.md M23.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
