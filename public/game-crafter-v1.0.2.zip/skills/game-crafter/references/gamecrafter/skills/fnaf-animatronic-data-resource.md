---
id: fnaf-animatronic-data-resource
title: "Data-driven enemy definition (one script, one .tres per enemy)"
category: ai-enemies
when: "Implementing several patrolling enemies without one script each."
related: []
origin: FNAP
---

# Data-driven enemy definition (one script, one .tres per enemy)

**When to use:** Implementing several patrolling enemies without one script each.

## Do this

- `AnimatronicData` (Resource) exports: `id, display_name, start_room, path[], attack_side ("L"|"R"), move_interval,
  moves_only_unwatched, stages_in_cove, is_hallucination, laugh_on_move, footstep_id, idle_clip, idle_fallbacks[],
  showcase_clip, move_clip, room_clips{}, arrive_clips{}, power_drain_per_bang, retreat_rooms, regroup_seconds,
  bang_escalation, walk_speed, run_speed, jumpscare_clip`.
- Files `resources/ai/{pickle,remi,dilly,banshee,golden_pickle}.tres`; `OfficeController.CHARACTER_RESOURCES` ->
  `Animatronic.setup(data)`.
- Per-clip loop flags and walk speeds come from `assets/models/animated/clips.json` (`ClipManifest`, tolerant recursive
  JSON ingest).
- Skeleton:
  ```gdscript
  class_name AnimatronicData extends Resource
  @export var id := ""
  @export var start_room := "CAM_1A"
  @export var path: Array[String] = []
  @export_enum("L", "R") var attack_side := "R"
  @export var move_interval := 5.0
  @export var moves_only_unwatched := false
  @export var stages_in_cove := false
  @export var is_hallucination := false
  @export var power_drain_per_bang := 1.0
  @export var bang_escalation := 0.0
  @export var retreat_rooms: Array[String] = []
  @export var regroup_seconds := 50.0
  @export var walk_speed := 0.8
  @export var run_speed := 0.0
  @export var jumpscare_clip := "jumpscare"
  ```

## Pitfalls (mistakes seen)

none.

## Verify

`char_check.tscn` (GLB loaded? clips? visible? speeds? screenshots at doors).

## Origin

FNAP. Source notes: REF §2.5, §1.5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
