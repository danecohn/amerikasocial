---
id: fnaf-jumpscare-3d
title: "3D jumpscare (dedicated camera, lunge, flash, sting)"
category: gameplay-systems
when: "Implementing the loss moment in a 3D FNAF-like."
related: [mistake-death-through-closed-door]
origin: FNAP
---

# 3D jumpscare (dedicated camera, lunge, flash, sting)

**When to use:** Implementing the loss moment in a 3D FNAF-like.

## Do this

- Spot 0.75 m in front of the player camera on the floor plane; face the model at the player (models face +Z, `look_at`
  aims -Z, so aim AWAY: e.g. `look_at(2*pos - cam_pos)` or rotate 180).
- Add an OmniLight "face light" and a dedicated `JumpscareCamera` (fov 42) on the actor; play the `jumpscare` clip;
  lunge 0.28 m in 0.18 s; play `jumpscare-<id>` sfx + music sting; `look.shake = 1`; red flash overlay (CanvasLayer 60);
  hold 1.6 s (2.6 s for the hallucination); emit `finished` -> game over.
- Placeholder capsule gets a scale pop instead.
- Per-character jumpscare sounds (2D list): Remi shrill ring-modulated squeal over low groan; Dilly nasal quack-honk
  scream + jar smash; Pickle clank + barking roar into distorted mechanical scream; Banshee snarling AM-gated rising
  howl; Golden deep warped bit-crushed roar with long tail.

## Pitfalls (mistakes seen)

mistake-death-through-closed-door (check doors before the scare).

## Verify

Director moments / promo capture forced Banshee `trigger_jumpscare`; screenshot mid-scare.

## Origin

FNAP. Source notes: REF §2.6; STATEMAP lines 246-250.

## Related skills

- [mistake-death-through-closed-door](mistake-death-through-closed-door.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
