# Tool: cover.py

**Purpose:** Builds a 630x500 itch.io cover from a native-resolution screenshot + title font.

**Usage:** `python3 cover.py shot.png title.ttf line1 line2 tagline out.png`

**Skill:** see `skills/itch-cover-630x500-from-screenshot.md`

**Extract:** save the block below as `cover.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""cover.py <shot.png 384x216> <title.ttf> <line1> <line2> <tagline> <out630x500.png> [cropx=100] [cropy=40] [title_color=#hex] [accent=#hex]
Native 210x167 pixel composition, nearest x3 -> 630x500. Forgotten Woods icon bottom-left."""
import sys
from PIL import Image, ImageDraw, ImageFont
shot, ttf, l1, l2, tag, out = sys.argv[1:7]
cx = int(sys.argv[7]) if len(sys.argv) > 7 else 100
cy = int(sys.argv[8]) if len(sys.argv) > 8 else 40
tc = sys.argv[9] if len(sys.argv) > 9 else "#f2e7c8"
ac = sys.argv[10] if len(sys.argv) > 10 else "#ff9a3c"
src = Image.open(shot).convert("RGBA").crop((cx, cy, cx + 210, cy + 105))
im = Image.new("RGBA", (210, 167), (6, 8, 12, 255))
# sky band: darkened blur of the shot top for mood
band = Image.open(shot).convert("RGBA").crop((cx, cy, cx + 210, cy + 62)).resize((210, 62), Image.NEAREST)
bd = Image.new("RGBA", band.size, (6, 8, 12, 255)); band = Image.alpha_composite(band, bd)
im.alpha_composite(band, (0, 0)); im.alpha_composite(src, (0, 62))
ov = Image.new("RGBA", im.size, (0, 0, 0, 0)); d0 = ImageDraw.Draw(ov)
for y in range(62, 76): d0.line((0, y, 209, y), fill=(6, 8, 12, int((76 - y) * 14)))
for y in range(150, 167): d0.line((0, y, 209, y), fill=(0, 0, 0, int((y - 150) * 10)))
im = Image.alpha_composite(im, ov)
def fit(text, maxw, start=24):
    s = start
    while s > 8:
        f = ImageFont.truetype(ttf, s)
        if f.getlength(text) <= maxw: return f
        s -= 1
    return ImageFont.truetype(ttf, 8)
d = ImageDraw.Draw(im)
def shadow(xy, text, f, col):
    x, y = xy
    for dx, dy in ((1, 1), (0, 1), (1, 0)): d.text((x + dx, y + dy), text, font=f, fill=(0, 0, 0, 255))
    d.text((x, y), text, font=f, fill=col)
f1 = fit(l1, 192, 20); f2 = fit(l2, 192, 20) if l2 else None
y = 4
w = f1.getlength(l1); shadow(((210 - w) // 2, y), l1, f1, tc); y += f1.size + 1
if l2:
    w = f2.getlength(l2); shadow(((210 - w) // 2, y), l2, f2, tc)
ft = fit(tag, 196, 10); w = ft.getlength(tag)
shadow(((210 - w) // 2, 49), tag, ft, ac)
ic = Image.open("/home/claude/evac/kit/assets/branding/fw_icon.png").convert("RGBA").resize((16, 16), Image.NEAREST)
im.alpha_composite(ic, (3, 148))
im = im.convert("RGB").resize((630, 500), Image.NEAREST)
im.save(out); print("cover", out)
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
