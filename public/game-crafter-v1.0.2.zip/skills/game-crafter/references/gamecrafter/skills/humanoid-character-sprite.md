---
id: humanoid-character-sprite
title: "Humanoid player/NPC recipe with hats, held items, kid variant and 4-frame walk"
category: pixel-art-2d
when: "Making the player, NPCs, or human bosses."
related: []
origin: Roguelike series
---

# Humanoid player/NPC recipe with hats, held items, kid variant and 4-frame walk

**When to use:** Making the player, NPCs, or human bosses.

## Do this

- Canvas 16x20 (18x22 after outline). Parts (cx = 8): legs `rect(cx-3,14,cx-1,18+step⁺)` and `rect(cx+1,14,cx+3,18+(-step)⁺)` in base2; body `rect(cx-4,7+bob,cx+4,14+bob)` in cloth (= pal.base); 1px arms at x=cx±5 in `dark(cloth,.2)`; head ellipse `(cx-4,bob,cx+4,8+bob)` skin; hair rect top 3 rows + left side column; eyes 1px outline colour at (cx±2, 4+bob).
- Walk: `step = [0,1,0,-1][frame%4]`, `bob = 1 if frame%2 else 0`.
- Hats (kw `hat`): hood (cloth ellipse around a smaller face), cap (accent band + eye-colour badge), helmet (accent dome + yellow lamp), bow (two accent triangles), bandage (cream band + shade line), crown (3 accent triangles). Held: `"lamp"` = 3x4 `#ffd36a` box at cx+5 with outline hanger.
- Kid variant: draw the adult, then remove rows 11..13 (`crop_rows(img, 11, 14)`) after finish - 3px shorter, same art.
- Ghostly NPC: multiply alpha (e.g. 0.85) after finish.
- Boss humans: same recipe scaled 3x + `extra()` decorations (cap, mask, ruler, briefcase...).

## Pitfalls (mistakes seen)

- Walk cycle is weak: frames 0 and 2 identical, legs only lengthen by 1px; reads as a shuffle at 8 fps. Prevention: shift feet horizontally too (±1px), swing arms opposite to legs.
- "cap" puts a `pal.eye` badge on the forehead; with a red eye colour the player looks wounded (visible in all LAST LAMP screenshots). Choose a neutral badge colour.

## Verify

player.png 72x22 = 4 frames of 18x22; play at 8 fps.

## Origin

Roguelike series. Source notes: _tools/sprites.py lines 326-372; buildgame.py crop_rows/make_creature lines 39-67; screenshot_01.png.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
