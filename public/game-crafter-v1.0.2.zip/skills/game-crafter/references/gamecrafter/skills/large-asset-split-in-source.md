---
id: large-asset-split-in-source
title: "Ship oversized source assets (e.g. 54 MB office.glb) as parts + a join bat"
category: delivery-pc-bridge
when: "A single project asset exceeds the bridge per-file limit when syncing source to the PC."
related: []
origin: Pickle's Pickle Shop
---

# Ship oversized source assets (e.g. 54 MB office.glb) as parts + a join bat

**When to use:** A single project asset exceeds the bridge per-file limit when syncing source to the PC.

## Do this

office.glb (~54 MB) delivered as `assets/models/office/office.glb.part00-02` + `JOIN_OFFICE_GLB.bat` (copy /b parts -> office.glb). Tell the user they must run it before opening the project in the editor. The full Godot project for the user was also delivered "in parts + UNPACK_GODOT_PROJECT.bat". Restore missing large assets from the legacy folder rather than regenerating.

## Pitfalls (mistakes seen)

User's new project folder lacked office.glb and .ico files ("Some larger assets may be missing") -> restored from legacy; without office.glb the game falls back to the box office.

## Verify

After join, file size matches; Godot import OK.

## Origin

Pickle's Pickle Shop. Source notes: transcript summary sec.3; SHIP_NOTES.txt; README.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
