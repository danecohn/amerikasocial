---
id: mistake-agents-editing-project-settings
title: "Agents silently changed project.godot (version, texture compression flags)"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Agents silently changed project.godot (version, texture compression flags)

**When to use:** 

## What happened, root cause, fix, prevention

After the agent burst, `config/version="0.1.0"` and `[rendering] textures/vram_compression/import_s3tc_bptc=true` + `import_etc2_astc=true` were missing and had to be restored. ETC2/ASTC import is required for macOS universal/arm64 exports (preset has `texture_format/etc2_astc=true` for macOS). Prevention: project.godot owned by one agent (release); others file requests; diff project.godot in the integration gate.

## Origin

Caesarea. Source notes: MANIFEST gate; export_presets.cfg preset.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
