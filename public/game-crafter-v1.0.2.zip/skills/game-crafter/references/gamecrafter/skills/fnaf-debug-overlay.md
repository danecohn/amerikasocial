---
id: fnaf-debug-overlay
title: "Debug overlay + debug-only keys + wiring report"
category: testing-qa
when: "Tuning AI/power live, diagnosing missing art."
related: []
origin: FNAP
---

# Debug overlay + debug-only keys + wiring report

**When to use:** Tuning AI/power live, diagnosing missing art.

## Do this

- F-key overlay printing `OfficeController.debug_text()`: power, stamina, music bar/beat, each animatronic's
  room/AI/aggression/state, FPS.
- `OS.is_debug_build()`-gated keys: skip hour, drain power. `--fnap-debug-print=<sec>` prints to stdout.
- `office_wiring` report (role -> office / PLACEHOLDER / missing). `--fnap-bench-monitor` perf probe.

## Pitfalls (mistakes seen)

shipping debug keys ungated.

## Verify

Release export: F-key overlay and debug keys inactive.

## Origin

FNAP. Source notes: REF §2.13, §5.4.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
