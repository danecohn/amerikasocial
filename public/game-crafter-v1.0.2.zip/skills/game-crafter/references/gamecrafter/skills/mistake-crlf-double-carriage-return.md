---
id: mistake-crlf-double-carriage-return
title: "Writing "\r\n"-joined text with newline="\r\n" produces "\r\r\n" line endings"
category: mistake
when: "Generating .bat/.ps1/.txt files for Windows from Python."
related: []
origin: Roguelike series
---

# Writing "\r\n"-joined text with newline="\r\n" produces "\r\r\n" line endings

**When to use:** Generating .bat/.ps1/.txt files for Windows from Python.

## Do this

Choose one: `open(p, "w", newline="\r\n").write("\n".join(lines) + "\n")` OR `open(p, "w", newline="").write("\r\n".join(lines) + "\r\n")`, or write bytes.

## What happened, root cause, fix, prevention

- Symptom: delivered ASSEMBLE_ZIPS.bat/.ps1 contain `\r\r\n` (verified with `od -c`: `@echo off\r\r\n`). cmd/PowerShell tolerate it, but editors show blank lines/odd endings and stricter tools can choke.
- Root cause: release.py does `open(..., newline="\r\n").write("\r\n".join(bat)+"\r\n")`; text mode translates each "\n" to "\r\n" again.
- Fix: one of the patterns above.
- Prevention/detection: `python3 -c "print(open(p,'rb').read().count(b'\r\r\n'))"` must be 0 before delivery.

## Verify

`file ASSEMBLE_ZIPS.bat` says "with CRLF line terminators" and the count check is 0.

## Origin

Roguelike series. Source notes: _tools/release.py L65-66; THE LAST LAMP/DISTRIBUTION/ASSEMBLE_ZIPS.bat bytes.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
