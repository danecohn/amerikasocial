---
id: fnaf-difficulty-curve-tables
title: "Difficulty curve: per-night AI table, drain multiplier, helper failure rate"
category: planning-design
when: "Tuning nights 1-5, custom night defaults, or any escalating multi-night difficulty."
related: [fnaf-balance-sims, fnaf-fact-ledger-per-night]
origin: FNAP
---

# Difficulty curve: per-night AI table, drain multiplier, helper failure rate

**When to use:** Tuning nights 1-5, custom night defaults, or any escalating multi-night difficulty.

## Do this

- AI levels 0-20 per enemy per night (`GameState.AI_BY_NIGHT`, retuned with `patrol_sim.gd`):
  ```
  order: pickle, remi, dilly, banshee, golden
  N1 0,2,1,0,0 | N2 0,3,2,2,0 | N3 1,4,3,3,2 | N4 1,5,4,3,4 | N5 2,6,4,4,7 | N6 (custom defaults) 16,18,18,19,10
  ```
- Move chance = `ai_level / 20` per move tick, so AI 2 = 10%, AI 20 = 100%.
- Power drain multiplier `1 + 0.08*(night-1)` (N1 1.00 ... N5 1.32).
- +1 AI to every active enemy at hours 2,3,4 (in-night ramp).
- Terminal helper failure rate `clamp(0.12 + 0.07*(night-1) + fail_delta, 0.04, 0.85)` (N1 12% .. N5 40%).
- Auto-mode tuning arrays indexed by night: check interval 14 s -> 7 s, failure 25% -> 68%, false close 8% -> 40%.
- Narrative difficulty curve runs in parallel: calls get shorter and less helpful (105 -> 80 -> 70 -> 55 -> 30 s spoken).
- Introduce one new threat per night: N1 Remi/Dilly (low), N2 Banshee (call explains her), N3 Pickle (call explains),
  N4 Golden (call explains), N5 everything.
- Retune with simulations, not by feel (fnaf-balance-sims).

## Pitfalls (mistakes seen)

- Observed check (derived from the data, not logged as a bug): Golden Pickle has AI 2 on Night 3 but the call that
explains him is Night 4. Rule: an enemy's AI must be 0 until the night whose call introduces it (or the introduction
must move earlier). Audit table vs fact ledger (fnaf-fact-ledger-per-night).

## Verify

`patrol_sim.gd` survival/power report per night for turtle/peek/sloppy player styles is monotonic harder N1->N5;
`balance_regression.gd` prints BALANCE_REGRESSION_PASS.

## Origin

FNAP. Source notes: REF §2.3 AI table, §2.2, §2.11 (failure_rate, auto tune), §5.2; CALLS durations; LEARN table.

## Related skills

- [fnaf-balance-sims](fnaf-balance-sims.md)
- [fnaf-fact-ledger-per-night](fnaf-fact-ledger-per-night.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
