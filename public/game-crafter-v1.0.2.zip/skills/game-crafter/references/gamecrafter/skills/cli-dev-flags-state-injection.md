---
id: cli-dev-flags-state-injection
title: "CLI user-args to jump to any scene/floor/state for testing and screenshots"
category: testing-qa
when: "Need to reach a specific moment (boss, floor 3, ending, hub after 5 deaths) quickly for testing or marketing screenshots."
related: []
origin: Roguelike series
---

# CLI user-args to jump to any scene/floor/state for testing and screenshots

**When to use:** Need to reach a specific moment (boss, floor 3, ending, hub after 5 deaths) quickly for testing or marketing screenshots.

## Do this

- Parse: Game.gd collects `--key=value` from `OS.get_cmdline_user_args()` (args after a bare `--` on the godot command line).
- Scene/boot: `--scene=splash|title|hub|run|ending|credits`, `--fresh=1` (new save, keeps settings), `--skip_intro=1`.
- Save injection (boot `_apply_cli_save`): `--wins= --deaths= --runs= --memories= --best_floor= --dread= --max_dread=` ints; `--frags=6` (first N fragment ids), `--flags=a,b`, `--bosses=keeper,matron`, `--seen=beatid,...`, `--seen_all=1`, `--meta=2` (every meta upgrade to level 2).
- Run injection (RunScene `_begin`): `--boons=dmg,crit` (adds boons then full HP), `--mem=200`, `--hp=3`, `--god=1`, `--demo=1`, `--floor=2`, `--room=4`, `--kind=boss|combat|elite|event|rest`, `--reward=boon|mem|heal|fragment`.
- Global: `--seed=N`, `--speed=2.0` (time scale preserved through hitstop/scene changes via `Game.base_scale`), `--dbg=1`.
- Capture: `--shot=/path/out.png` (sets capture_mode: no fullscreen change), `--shots=5 --wait=4 --gap=3` (multiple frames, `_N` suffix), `--keep=1` (don't quit after). Capture waits `RenderingServer.frame_post_draw` then `get_viewport().get_texture().get_image().save_png()` and prints `SHOT_OK path size missing=N`.
- Examples: boss screenshot: `--scene=run --floor=1 --kind=boss --god=1 --shot=boss.png --wait=6`; hub late-story: `--scene=hub --deaths=5 --bosses=keeper,matron --flags=remembers --skip_intro=1 --press=1.2 --shot=hub.png`.

## Pitfalls (mistakes seen)

All tooling flags must be inert in normal play (only active when the arg exists) - the kit guards each with `Game.cli.has(...)`.

## Verify

SHOT_OK printed; image shows intended state.

## Origin

Roguelike series. Source notes: game.gd 21-36; boot.gd 20-28, 48-87; run.gd 60-80.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
