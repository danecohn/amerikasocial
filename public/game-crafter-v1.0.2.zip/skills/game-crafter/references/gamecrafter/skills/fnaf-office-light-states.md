---
id: fnaf-office-light-states
title: "Office light states and emissive bulbs that follow their lights"
category: 3d-lighting-horror
when: "Implementing office lighting that changes with power."
related: [mistake-shared-material-tint]
origin: FNAP
---

# Office light states and emissive bulbs that follow their lights

**When to use:** Implementing office lighting that changes with power.

## Do this

- States `full / lamp / dark / off`; auto-drops to `lamp` below 20% power; `dark` on power-out. `full` never re-lights
  halls (`keep_halls_dark()`).
- Named lights: `Light_Fluorescent`, `Light_Pendant`, `Light_DeskLamp`, `Light_Ambient_Night`, `Light_Storeroom`; bulb
  meshes `Fluorescent_Tube`, `Pendant_Bulb`, `DeskLamp_Bulb`, `Storeroom_Light`.
- `_set_emit(mesh, on)` duplicates the surface material ONCE and caches base emission energy per mesh, so an emissive
  bulb dims with its light without affecting other meshes sharing the material.
- Fan blades spin down on power-out; clock hands follow `clock.progress()`.

## Pitfalls (mistakes seen)

mistake-shared-material-tint.

## Verify

Screenshot each light state (visual_check tour).

## Origin

FNAP. Source notes: REF §2.2, §8.1 L.

## Related skills

- [mistake-shared-material-tint](mistake-shared-material-tint.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
