---
id: mistake-halls-too-bright
title: "Horror halls too bright"
category: mistake
when: "Lighting dark horror areas in Godot."
related: []
origin: FNAP
---

# Horror halls too bright

**When to use:** Lighting dark horror areas in Godot.

## Source 1: FNAP

### Do this

Working values: `ambient_light_energy 0.008`, tonemap exposure 1.0, glow 0.25, hall light energy 0; flashlight / hall-light button reveals; camera feeds keep their own exposure (separate Environment).

### What happened, root cause, fix, prevention

Symptom: halls too bright, no dread. Root cause: ambient 0.11, high exposure/glow, hall lights non-zero. Fix: values above. Prevention: A/B screenshots light off/on. Detection: screenshot review.

### Verify

Can't see down hall without flashlight (screenshot), can with.

### Origin

FNAP. Source notes: mistakes-log.md M12; QA fnap D3.1-D3.4.

## Source 2: FNAP — Mistake - horror halls too bright (user: "darker halls")

### What happened, root cause, fix, prevention

- Symptom: user asked for "darker halls"; halls visible without the flashlight.
- Root cause: ambient 0.11 + tonemap/glow too high; hall OmniLight energies non-zero; "full light" office state re-enabled hall lights.
- Fix: ambient 0.008, exposure 1.0, glow 0.25, hall lights 0, reveal by flashlight/buttons only.
- Prevention: define the darkness spec in numbers up front; screenshot pairs on every lighting change.
- Detection: hall_check screenshot pair; mean luminance of hall region with flashlight off near 0.

### Verify

both screenshots viewed; desk still readable.

### Origin

FNAP. Source notes: L §2.5; G line 39.

## Source 3: FNAP — Halls not dark (ambient too high) - horror loses its tension

### What happened, root cause, fix, prevention

- Symptom: dark halls readable from the office; no fear.
- Root cause: ambient 0.11 and exposure too high.
- Fix: ambient 0.008, exposure 1.0; monitor feed gets its own exposure + FeedExposure light.
- Prevention: hall_check "dark" screenshot must be black.

### Verify

hall_check.

### Origin

FNAP. Source notes: REF §8.2 #7, §2.2.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
