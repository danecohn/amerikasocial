---
id: mistake-glb-aabb-off-contract
title: "Art piece exceeded its contract box by a hinge pin"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Art piece exceeded its contract box by a hinge pin

**When to use:** 

## What happened, root cause, fix, prevention

Symptom: `barrier hinge extends +X` FAIL. Measured pos (−0.042, −0.060, −0.084) size (7.642, 0.120, 0.168) vs expected pos (0, −0.060, −0.080) size (7.6, 0.12, 0.16). Root cause: a hinge primitive behind the origin. Fix: trim the pin in the .blend, re-export to both trees; origin stays at hinge, arm +X 7.6 m, rest pose lowered. NOT: edit the test, rotate/scale in Godot, or delete the GLB. Prevention: Blender bots self-check AABB vs contract before export; QA bot report with measured vs expected.

## Origin

Caesarea. Source notes: godot_import_report.md; glb_report.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
