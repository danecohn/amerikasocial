---
id: mistake-half-shut-door-death
title: "Unfair death through a half-shut door"
category: mistake
when: "Door/gate blocking logic for enemies."
related: []
origin: FNAP
---

# Unfair death through a half-shut door

**When to use:** Door/gate blocking logic for enemies.

## Do this

`blocks_entry()` true at progress >= 0.5; jumpscare entry checks it and calls `refuse_closed_door()`.

## What happened, root cause, fix, prevention

Symptom: died though door was closing. Root cause: only fully closed doors counted. Fix as above. Detection: door sim.

## Verify

Sim: door at 0.5 blocks.

## Origin

FNAP. Source notes: mistakes-log.md M16; QA fnap D4.6.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
