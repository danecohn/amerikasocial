---
id: mistake-capture-never-exits
title: "Capture process never exits and blocks the tool call"
category: mistake
when: "Any scripted Godot run."
related: []
origin: FNAP
---

# Capture process never exits and blocks the tool call

**When to use:** Any scripted Godot run.

## Do this

Every capture script ends `get_tree().quit()`; wrap in `timeout`; use `--quit-after <frames>`; background + poll.

## What happened, root cause, fix, prevention

Symptom: hung tool call. Cause: no quit(). Fix above.

## Verify

Process exits.

## Origin

FNAP. Source notes: mistakes-log.md M54.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
