---
id: mistake-hexc-ignores-alpha-moon-icon
title: "hexc("#00000000") paints opaque black - transparency lost when "erasing" with a colour"
category: mistake
when: "Trying to erase/cut shapes in Pillow by drawing with a transparent colour."
related: []
origin: Roguelike series
---

# hexc("#00000000") paints opaque black - transparency lost when "erasing" with a colour

**When to use:** Trying to erase/cut shapes in Pillow by drawing with a transparent colour.

## What happened, root cause, fix, prevention

- Symptom: CONFIRMED in shipped THE LAST LAMP icons.png: 4 stray pure-black (0,0,0,255) pixels at the right edge of the moon icon (strip x=165-166, y=1,2,7,8) - leftover from the 'transparent' ellipse.
- Root cause: `hexc` reads only 6 hex digits and always returns alpha 255 (unless the `a` arg is passed); the moon draws `ellipse(..., fill=hexc("#00000000"))` = opaque black, then a separate pixel loop clears a circle `(x-6)^2+(y-3.5)^2 < 14` that only roughly matches the ellipse; any black pixel outside the cleared circle survives (and then gets outlined as part of the shape).
- Fix: cut shapes by drawing onto a mask (`Image.new("L")`) and applying it, or pass `(0,0,0,0)` directly and note ImageDraw REPLACES pixels (it does not blend) so a (0,0,0,0) fill truly erases.
- Prevention: colour helpers should parse 8-digit hex or raise; erase with explicit (0,0,0,0) tuples.
- Detection: count pure black `(0,0,0,255)` pixels in icons (outline is #0b0a10, so pure black should be 0).

## Verify

icons.png contains no (0,0,0,255) pixels.

## Origin

Roguelike series. Source notes: _tools/tiles.py lines 429-435; sprites.py hexc.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
