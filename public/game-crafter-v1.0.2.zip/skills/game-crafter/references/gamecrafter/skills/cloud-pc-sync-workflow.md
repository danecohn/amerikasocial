---
id: cloud-pc-sync-workflow
title: "Cloud working copy + staging mirror + changed-files batches"
category: delivery-pc-bridge
when: "Syncing a project between cloud and the user's PC repeatedly."
related: []
origin: FNAP
---

# Cloud working copy + staging mirror + changed-files batches

**When to use:** Syncing a project between cloud and the user's PC repeatedly.

## Do this

Keep working copy in cloud (`/home/claude/<game>/`), a staging mirror under `/mnt/user-data/outputs/<proj>/` for anything that must reach the PC, and a stamp file for last sync. changed_files script: walk project, skip `.godot/`, `*.import`, `*.uid`, and heavy dirs (`assets/models`, `assets/audio`, ...), copy files with mtime > stamp into mirror, output JSON commit batches of 45, warn on files >30 MB:
```python
for r,d,f in os.walk(G):
    rel=os.path.relpath(r,G)
    if rel==".godot" or rel.startswith(".godot/"): d[:]=[]; continue
    for n in f:
        if n.endswith((".import",".uid")): continue
        p=os.path.join(r,n); q=os.path.relpath(p,G)
        if q.startswith(SKIP_DIRS): continue
        if os.path.getmtime(p)>stamp:
            os.makedirs(os.path.dirname(f"{O}/{q}"),exist_ok=True); shutil.copy2(p,f"{O}/{q}")
            out.append({"devicePath":PC_ROOT+"\\"+q.replace("/","\\"),"stagedPath":f"{O}/{q}"})
big=[o for o in out if os.path.getsize(o["stagedPath"])>30e6]
for i in range(0,len(out),45): print(json.dumps(out[i:i+45]))
```
Touch the stamp after a verified sync.

## Pitfalls (mistakes seen)

Staging `.godot/` (hundreds of MB) -> never; syncing `*.import`/`*.uid` -> regenerated, never sync.

## Verify

batches committed, listing matches.

## Origin

FNAP. Source notes: pc-bridge-delivery/SKILL.md Workflow 1-2; templates/changed_files.fnap_example.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
