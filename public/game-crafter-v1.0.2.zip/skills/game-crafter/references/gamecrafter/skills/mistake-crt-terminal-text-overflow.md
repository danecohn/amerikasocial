---
id: mistake-crt-terminal-text-overflow
title: "Mistake - terminal/CRT reply text overflowing (SubViewport + HUD duplicates)"
category: mistake
when: "Drawing in-game terminal/AI-assistant text on a CRT mesh and in HUD subtitles."
related: []
origin: FNAP
---

# Mistake - terminal/CRT reply text overflowing (SubViewport + HUD duplicates)

**When to use:** Drawing in-game terminal/AI-assistant text on a CRT mesh and in HUD subtitles.

## What happened, root cause, fix, prevention

- Symptom: long replies overflowed the CRT screen and overlapped HUD meters.
- Root cause: reply text drawn into a 640x480 SubViewport on a CRT mesh AND assigned to the HUD subtitle label; no clipping.
- Fix: clip the terminal label (`clip_text`/autowrap + fixed size), move subtitles clear of meters, use one text source.
- Prevention: test the longest possible string; define UI safe zones.
- Detection: screenshot with max-length text.

## Verify

screenshot.

## Origin

FNAP. Source notes: L §2.13 (lines 141-142).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
