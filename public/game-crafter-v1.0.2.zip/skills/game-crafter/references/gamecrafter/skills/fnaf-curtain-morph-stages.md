---
id: fnaf-curtain-morph-stages
title: "Curtain stages via blend shapes + stage meshes"
category: 3d-blender
when: "An enemy hides behind a curtain that opens in stages."
related: [mistake-curtain-morph-all-weights-one]
origin: FNAP
---

# Curtain stages via blend shapes + stage meshes

**When to use:** An enemy hides behind a curtain that opens in stages.

## Do this

- Morph mesh with blend shapes `Peek/Leaning/Open`; code zeroes all, shows `Curtain_Stage0_Closed`, hides stages 1-3.
  `set_curtain_state(state)` sets exactly one shape to 1, toggles the matching stage mesh + SFX
  (`curtain-hide/peek/rip`) and moves `curtain_grip` to `Curtain_Grip_L[_Peek|_Leaning]`.
- (quoted)
  ```gdscript
  for i in mesh.get_blend_shape_count():
  	var shape_name := String(mesh.get_blend_shape_name(i)).to_lower()
  	var on := (key == "peek" and shape_name == "peek") or (key == "lean" and shape_name == "leaning") or (key == "rip" and shape_name == "open")
  	_curtain_mesh.set_blend_shape_value(i, 1.0 if on else 0.0)
  ```
- Owner contract file `_team/curtain.md` documented exactly which functions/nodes to touch.

## Pitfalls (mistakes seen)

mistake-curtain-morph-all-weights-one.

## Verify

`curtain_check.tscn` shoots each state from `Cam_1C`, prints blend weights + stage visibility.

## Origin

FNAP. Source notes: REF §2.7, §8.2 #4, §7.

## Related skills

- [mistake-curtain-morph-all-weights-one](mistake-curtain-morph-all-weights-one.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
