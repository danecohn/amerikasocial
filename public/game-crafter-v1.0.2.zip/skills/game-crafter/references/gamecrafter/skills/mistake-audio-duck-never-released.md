---
id: mistake-audio-duck-never-released
title: "Mistake - a cut-off phone call left Music/Ambience ducked"
category: mistake
when: "Implementing ducking (voice over music), scene changes, stop-all."
related: []
origin: FNAP
---

# Mistake - a cut-off phone call left Music/Ambience ducked

**When to use:** Implementing ducking (voice over music), scene changes, stop-all.

## What happened, root cause, fix, prevention

- Symptom: music/ambience stayed quiet (muted) after a phone call was interrupted or the scene changed.
- Root cause: duck applied at call start, release only at call end; interruption skipped the release.
- Fix: `reset_ducks()` restoring bus volumes; call it from `stop_all_loops()` / `stop_all()` and from `GameState.change_scene()`.
- Prevention: ducks are always released by the stop paths, not only the happy path.
- Detection: audio_check prints `DUCK ambience bus ducked=-16.0 after_reset=0.0`.

## Verify

`AUDIO_CHECK PASS`.

## Origin

FNAP. Source notes: L §2.12 line 136; T/godot_core/game_state_template.gd line 87; S line 25.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
