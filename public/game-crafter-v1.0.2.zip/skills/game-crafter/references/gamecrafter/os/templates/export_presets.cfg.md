# Template: export_presets.cfg (Windows x64, Windows ARM64, macOS, Linux)
Copy into the project root as `export_presets.cfg`. Fill include_filter for every non-resource data file your code reads (json/csv/txt/cues, raw voice/face frames). Keep export_path empty or relative; the release script passes the output path.
ARM64 trick: the Windows preset's `binary_format/architecture` is "x86_64" or "arm64" — duplicate the preset or flip it per build. Verify with the PE machine type: 0x8664 = x64, 0xaa64 = ARM64.

```ini
; Game Maker export_presets.cfg template - 4 presets. Replace __NAME__ (exe name), __COMPANY__, __PRODUCT__, __BUNDLE__ (com.you.game).
; Keys proven in Five Nights at Pickles. Platform keys not shown take Godot defaults; open the Export dialog once in the editor
; to let Godot add any new ones for your version, then merge. Presets are numbered [preset.N] with matching [preset.N.options].
;
; THE TWO FILTERS THAT MATTER:
;  include_filter  - raw (non-resource) files are NOT exported unless listed: csv, txt, cues, xml, cfg (json ships raw), raw ogg/png scanned by DirAccess, .ogv ...
;  exclude_filter  - keep dev scenes/tools/backups/old content out of shipped builds.
; Both must be IDENTICAL in every preset (copy/paste mistakes caused "works on Windows, missing on Mac").

[preset.0]
name="Windows Desktop"
platform="Windows Desktop"
runnable=true
advanced_options=false
dedicated_server=false
custom_features=""
export_filter="all_resources"
include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, assets/audio/voice/*, assets/branding/*, tools/probe_manifest.json"
exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"
export_path="build/windows/__NAME__.exe"
patches=PackedStringArray()
encryption_include_filters=""
encryption_exclude_filters=""
seed=0
encrypt_pck=false
encrypt_directory=false
script_export_mode=2

[preset.0.options]
binary_format/architecture="x86_64"
binary_format/embed_pck=true
texture_format/s3tc_bptc=true
texture_format/etc2_astc=false
debug/export_console_wrapper=1
application/modify_resources=true
application/icon="res://icon.ico"
application/company_name="__COMPANY__"
application/product_name="__PRODUCT__"
application/file_version="1.0.0.0"
application/product_version="1.0.0.0"
application/copyright=""

[preset.1]
name="macOS"
platform="macOS"
runnable=true
export_filter="all_resources"
include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, assets/audio/voice/*, assets/branding/*, tools/probe_manifest.json"
exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"
export_path="build/macos/__NAME__-mac.zip"
script_export_mode=2

[preset.1.options]
binary_format/architecture="universal"
application/bundle_identifier="__BUNDLE__"
application/min_macos_version="11.00"
application/app_category="Games"
codesign/codesign=0
notarization/notarization=0
; macOS UNIVERSAL export is REFUSED unless project settings enable BOTH rendering/textures/vram_compression/import_s3tc_bptc AND import_etc2_astc.

[preset.2]
name="Linux"
platform="Linux"
runnable=true
export_filter="all_resources"
include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, assets/audio/voice/*, assets/branding/*, tools/probe_manifest.json"
exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"
export_path="build/linux/__NAME__.x86_64"
script_export_mode=2

[preset.2.options]
binary_format/architecture="x86_64"
binary_format/embed_pck=true
texture_format/s3tc_bptc=true

[preset.3]
name="Windows ARM64"
platform="Windows Desktop"
runnable=false
export_filter="all_resources"
include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, assets/audio/voice/*, assets/branding/*, tools/probe_manifest.json"
exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*"
export_path="build/windows_arm64/__NAME__.exe"
script_export_mode=2

[preset.3.options]
binary_format/architecture="arm64"
binary_format/embed_pck=true
texture_format/s3tc_bptc=true
debug/export_console_wrapper=1
application/modify_resources=true
application/company_name="__COMPANY__"
application/product_name="__PRODUCT__"
; Needs the arm64 Windows export template (windows_release_arm64.exe) from the SAME version's .tpz. If the .tpz in your container lacks it,
; build this target on the ARM64 PC.
```
