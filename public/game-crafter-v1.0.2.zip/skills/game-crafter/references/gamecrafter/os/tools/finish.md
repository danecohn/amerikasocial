# Tool: finish.py

**Purpose:** Zips the project source, writes MANIFEST.md, stages the whole game folder for delivery.

**Usage:** `python3 finish.py games/gN`

**Skill:** see `skills/per-game-delivery-folder-layout.md`

**Extract:** save the block below as `finish.py` (exact contents) and run it. Adapt paths marked `<...>`.

```python
#!/usr/bin/env python3
"""finish.py <games/gN> : zip PROJECT source, write MANIFEST.md, stage everything into /mnt/user-data/outputs/Eva C Variety Games/<folder>"""
import sys, os, importlib.util, shutil, zipfile, hashlib, glob, datetime, json
gdir = os.path.abspath(sys.argv[1])
spec = importlib.util.spec_from_file_location("meta", os.path.join(gdir, "meta.py")); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
M = m.META; OUT = f"/home/claude/evac/out/{M['folder']}"; B = f"/home/claude/evac/build/{M['slug']}"
os.makedirs(f"{OUT}/PROJECT", exist_ok=True)
zp = f"{OUT}/PROJECT/{M['zip_prefix']}_GodotProject_Source.zip"
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
    for root, ds, fs in os.walk(f"{B}/project"):
        ds[:] = [d for d in ds if d not in (".godot", "build", "exports")]
        for f in fs:
            if f.endswith(".import"): continue
            p = os.path.join(root, f); z.write(p, f"{M['zip_prefix']}/" + os.path.relpath(p, f"{B}/project"))
    # the generator tools + game spec so the game can be rebuilt
    for src, arc in ((gdir, "generator/game"), ("/home/claude/evac/_tools", "generator/_tools"), ("/home/claude/evac/kit", "generator/kit")):
        for root, ds, fs in os.walk(src):
            ds[:] = [d for d in ds if d not in ("__pycache__", "bb_out", "bb_synth", ".godot", "node_modules")]
            for f in fs:
                p = os.path.join(root, f)
                if os.path.getsize(p) > 3_000_000: continue
                z.write(p, f"{M['zip_prefix']}/{arc}/" + os.path.relpath(p, src))
lines = []
for root, ds, fs in os.walk(OUT):
    for f in sorted(fs):
        if f == "MANIFEST.md": continue
        p = os.path.join(root, f); rel = os.path.relpath(p, OUT)
        lines.append((rel, os.path.getsize(p), hashlib.sha256(open(p, "rb").read()).hexdigest()[:16]))
lines.sort()
man = f"""# MANIFEST - {M['title']}
Studio: Forgotten Woods Studios | Built {datetime.date.today()} | Engine Godot 4.7.2 | Version 1.0.0

## Verified
- Full autoplay run (hub -> 4 floors -> 4 bosses -> win -> ending -> hub -> new run) completed with no script errors.
- Exported pack probe: PROBE_DONE fails=0 (72 resources). Export lint: 0 errors. Linux export binary launched under a virtual display and showed real art (WIRING missing_art=0).
- 5 screenshots are real captures from the built game (native 384x216, nearest-scaled 5x to 1920x1080).

## NOT verified (be aware)
- Windows x64, Windows ARM64 and macOS builds were exported but not launched (no such machine in the build environment). The same pack runs on all four; only the platform runtime differs.
- macOS app is unsigned: players must right-click > Open. Windows exe is unsigned: SmartScreen "More info > Run anyway".
- Split zips (*.zip.001...) need DISTRIBUTION\\ASSEMBLE_ZIPS.bat run once (joins the parts and checks SHA-256) because the transfer to your PC is limited to ~30 MB per file.
- beepbox.co could not be reached from the build environment. Music is real BeepBox synth output (BeepBox source compiled and run offline) and the links in DOCS\\soundtrack.txt open the same songs on beepbox.co - they were not hand-edited in the website. Sound effects are numpy-synthesised, not BeepBox.
- No gamepad support. Nothing has been uploaded or published.

## Files
| File | Bytes | SHA-256 (first 16) |
|---|---|---|
""" + "".join(f"| {r} | {s} | {h} |\n" for r, s, h in lines)
open(f"{OUT}/MANIFEST.md", "w").write(man)
dst = f"/mnt/user-data/outputs/Eva C Variety Games/{M['folder']}"
shutil.rmtree(dst, ignore_errors=True); shutil.copytree(OUT, dst)
n = sum(len(f) for _, _, f in os.walk(dst)); sz = sum(os.path.getsize(os.path.join(r, x)) for r, _, f in os.walk(dst) for x in f)
print("staged", dst, n, "files", sz // 1048576, "MB")
```

---
Part of GameCrafter — Developed by Forgotten Woods Studios.
