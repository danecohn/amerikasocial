---
id: mistake-dark-hall-actors-invisible-layers-zero
title: "Enemies in dark halls invisible even under flashlight (render layers zeroed)"
category: mistake
when: "An enemy can't be seen with flashlight/hall light; after any 'darkness polish' pass."
related: []
origin: FNAP
---

# Enemies in dark halls invisible even under flashlight (render layers zeroed)

**When to use:** An enemy can't be seen with flashlight/hall light; after any "darkness polish" pass.

## Do this

Visibility fixers must restore layer 1 but skip nodes currently on the camera-feed layer.

## What happened, root cause, fix, prevention

- Symptom: Actors standing in the dark hall never appear, even with the flashlight on them.
- Root cause: an earlier "hall polish" set `GeometryInstance3D.layers = 0` on dark-hall actors, so no light/camera could
  ever render them.
- Fix (quoted): `_present_model()` every frame:
  ```gdscript
  func _present_model() -> void:
  	if _model == null or not is_instance_valid(_model) or not visible:
  		return
  	_model.visible = true
  	for node in NodeFinder.collect(_model):
  		if node is not GeometryInstance3D:
  			continue
  		var geo := node as GeometryInstance3D
  		if geo.layers & CAMERA_FEED_LAYER:
  			continue
  		if geo.layers == 0 or not geo.get_layer_mask_value(1):
  			geo.layers = 1
  ```
- Prevention: darkness comes from lighting/environment, never from removing render layers. Grep `layers = 0` in QA.

## Verify

hall_check flashlight screenshot shows the actor.

## Origin

FNAP. Source notes: REF §2.5 "Dark-hall bug lesson", §8.2 #1, §5.3.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
