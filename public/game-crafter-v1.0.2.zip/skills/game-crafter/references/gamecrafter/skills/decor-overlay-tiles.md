---
id: decor-overlay-tiles
title: "Transparent decor overlays (bones, puddle, web, blood, candle...) blended onto floors"
category: pixel-art-2d
when: "Adding environmental storytelling details without new floor tiles."
related: []
origin: Roguelike series
---

# Transparent decor overlays (bones, puddle, web, blood, candle...) blended onto floors

**When to use:** Adding environmental storytelling details without new floor tiles.

## Do this

- Drawn on a transparent 16x16 with rng(seed): bones (#d8d0b8 line + skull ellipse with 2 dark eye pixels), puddle (theme `puddle` colour ellipse + light glint line), moss (14 green specks), crack (9-step random walk of dark pixels, steps from [0,1,1]), candle (#e8e2c8 stick, #ffcc44/#ff9a30 flame pixels, dark base), blood (#6a0f18 ellipse + 3 droplets), rubble (6 grey 2x2 chips), flowers, web (lines + 2 quarter arcs from corner), paper, salt (white specks), glass (#a8d0e0 2px diagonals), ash, petals, chain, toys.
- Composited with `Image.blend_rect` (alpha blend) at 4.5% of free floor cells, never on solid cells.
- 4 decor kinds chosen per theme to match the place (hospital: paper/glass/crack/puddle; chapel: candle/petals/flowers/blood).

## Pitfalls (mistakes seen)

none recorded.

## Verify

rooms show sparse props, not a carpet of them.

## Origin

Roguelike series. Source notes: _tools/tiles.py lines 271-341; room.gd lines 155-160.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
