---
id: export-presets-three-platforms
title: "export_presets.cfg for Windows/Linux/macOS with embedded PCK and company metadata"
category: export-release
when: "Creating presets for a Godot 4.7 3D game."
related: []
origin: Caesarea
---

# export_presets.cfg for Windows/Linux/macOS with embedded PCK and company metadata

**When to use:** Creating presets for a Godot 4.7 3D game.

## Do this

Windows Desktop: `binary_format/architecture="x86_64"`, `embed_pck=true`, `debug/export_console_wrapper=1`, `texture_format/s3tc_bptc=true`, `application/company_name`, `product_name`, `file_version`, `product_version`, `copyright` = studio; `script_export_mode=2`; `export_filter="all_resources"`. Linux: x86_64, embed_pck. macOS: `binary_format/architecture="universal"`, `export_path="build/macos/<Game>.zip"`, bundle id `com.<studio>.<game>`, `min_macos_version="10.15"`, `display/high_res=true`, `codesign/codesign=0`, s3tc_bptc AND etc2_astc true (project setting `import_etc2_astc=true` required). Zip names `build/<Game>-<ver>-<platform>.zip`; record byte sizes in LOG (Win 128 MB, Linux 118 MB, macOS 150 MB for this slice). Linux/macOS "not launched on those systems" stated. Don't upload; user uploads to itch.io.

## Pitfalls (mistakes seen)

Several handoff rules said "Do not export builds / create presets" (owner's rule: internal until production-ready) while a later pass created presets + zips; PAUSED_STATUS then contradicted reality. Rule: honour the latest owner instruction and update every status doc when you export.

## Origin

Caesarea. Source notes: export_presets.cfg; LOG 11:16; PAUSED_STATUS §6; attachment.txt.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
