---
id: crt-terminal-on-3d-mesh
title: "Render a typing terminal onto a 3D CRT mesh via SubViewport"
category: ui-ux
when: "Diegetic computer screens in 3D (terminals, consoles, assistant faces)."
related: []
origin: Pickle's Pickle Shop
---

# Render a typing terminal onto a 3D CRT mesh via SubViewport

**When to use:** Diegetic computer screens in 3D (terminals, consoles, assistant faces).

## Do this

SubViewport 640x480 UPDATE_ALWAYS with ColorRect bg (0.01,0.04,0.02), RichTextLabel (bbcode, scroll_following, AUTOWRAP_WORD_SMART, clip_contents, pixel font size 22, green), scanline ColorRect with the static shader (intensity 0.04, scanlines 0.6, tint green). Apply to the screen mesh as `material_override` StandardMaterial3D: albedo_texture and emission_texture = viewport texture, emission energy 1.4, UNSHADED. Keep last MAX_LINES=14 lines; reveal replies 2 chars/frame then commit; escape user text `[` -> `[lb]`. Typing input is a LineEdit on a CanvasLayer (layer 8) at the bottom; Esc (pause_menu action) closes. On open: lock look, tween camera rig to a pose behind the keyboard (offset (0,-0.36,-0.46) looking at the CRT), fov 54, pitch -17 deg over 0.35 s; arms play `fp_type`/`fp_dock`; restore on close. Subtitle only when reply <= 48 chars (long replies overflowed the HUD subtitle). Speaker LED emission flickers 2-6 while talking, blinks while thinking. Animated face: SpriteFrames from PNG folders (idle_smug, listening, talking, glitch, apologies) + manifest.json (fps, loop, hold_frame), AnimatedSprite2D inside the viewport and pushed as texture to a second console screen.

## Pitfalls (mistakes seen)

Long text assigned to both terminal and HUD subtitle overflowed (1400x130 label) -> only short lines to subtitle.

## Verify

`--shot-assistant="help" --screenshot=...` forces a line and saves after the reveal completes.

## Origin

Pickle's Pickle Shop. Source notes: shop_assistant.gd L87-272, L553-570, L719-748, L966-1101; STATE.md "LLM computer".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
