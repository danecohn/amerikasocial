---
id: cli-dev-flags-for-screenshots
title: "In-game CLI flags for deterministic screenshots and checks"
category: testing-qa
when: "Need repeatable screenshots/benchmarks of specific game states (headless or for promo)."
related: []
origin: Pickle's Pickle Shop
---

# In-game CLI flags for deterministic screenshots and checks

**When to use:** Need repeatable screenshots/benchmarks of specific game states (headless or for promo).

## Do this

GameState parses `OS.get_cmdline_user_args()`: every `--fnap-key=value` -> `cli[key]` ("1" if no value), plus `--capture`, `--aspect`, `--seed`, `--cues`. Flags used: `night=N`, `quit-after=S`, `skip-intro`, `no-save`, `windowed`, `screenshot=PATH` (+`shot-frames`, `shot-pan`), `shot-door=L|R` (poses lurker, walks to door, screenshots on arrival + 0.5 s), `shot-monitor=CAM_x` (opens feed, places a character), `shot-assistant="text"` (forces a successful line, shots when reveal completes), `quit-on-shot`, `debug-print=secs`, `bench-monitor=full|room`, `hour=seconds_per_hour`, `brine-test`, `mini=<id>`, `mini-auto`, `mini-pick=<idx>`, `shots=1`, `mini-hold`, `no-mini`. Saves are suppressed whenever capture/no-save/night/screenshot flags are present (don't pollute the player's save). Capture mode seeds every RNG via `seed_rng(rng, salt)` -> `hash("%d:%s" % [capture_seed, salt])` for reproducible footage. Screenshot: `await RenderingServer.frame_post_draw` then `get_viewport().get_texture().get_image().save_png(path)`.

## Pitfalls (mistakes seen)

Custom args are only `OS.get_cmdline_user_args()` (after `--`); in exported release probes they were not parsed -> environment variables.

## Verify

Run with flags under Xvfb; PNG exists and shows the expected state.

## Origin

Pickle's Pickle Shop. Source notes: scripts/autoload/game_state.gd L47-70, L82-86, L161-162; office_controller.gd L132-183, L1888-1894.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
