---
id: descript-jobs-and-publish
title: "Descript jobs, publish and download links"
category: promo-marketing
when: "Waiting on Descript work / exporting."
related: []
origin: FNAP
---

# Descript jobs, publish and download links

**When to use:** Waiting on Descript work / exporting.

## Do this

`wait_for_job(job_id, wait_seconds<=200)`; MCP call times out at 230 s ("timed out after 230s") -> just call again; agent jobs ran 25 s to 4.5 min; send the user a status line while waiting. `publish_project(project_id, composition_id, resolution="1080p", access_level="unlisted")`; one publish at a time per project ("A publish job is already running"). Result: `share_url` + 24 h `download_url`. Sandbox and PC browser pane couldn't fetch the download host -> give the user both links, tell them where to save and that old unpolished files in the folder should be replaced. Offer more passes (tighter cuts, harder flashes, recut B-roll), captions, other aspect ratios.

## Pitfalls (mistakes seen)

Parallel publishes rejected.

## Verify

share_url opens.

## Origin

FNAP. Source notes: references/descript-playbook.md "Jobs", "Publish & download".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
