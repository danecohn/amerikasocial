---
id: mistake-death-through-closed-door
title: "Unfair death while the door is (half) shut"
category: mistake
when: "Implementing jumpscare triggers."
related: []
origin: FNAP
---

# Unfair death while the door is (half) shut

**When to use:** Implementing jumpscare triggers.

## What happened, root cause, fix, prevention

- Symptom: player shut the door at the last moment but still died.
- Root cause: jumpscare didn't check the door, or required fully closed.
- Fix: `blocks_entry()` at `progress >= 0.5` (QA requirement); `trigger_jumpscare` checks `_closed_door_blocks(a)` and
  calls `a.refuse_closed_door()` instead.
- Prevention: single jumpscare entry point that always checks doors.

## Verify

door_lurker_sim "half-shut door blocks scare".

## Origin

FNAP. Source notes: REF §2.3, §2.5 step 4, §8.1 E.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
