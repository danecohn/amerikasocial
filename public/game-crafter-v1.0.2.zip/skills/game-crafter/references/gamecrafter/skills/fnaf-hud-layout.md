---
id: fnaf-hud-layout
title: "Office HUD (clock, night, power + usage bars, stamina, status, subtitles)"
category: ui-ux
when: "Building the in-night HUD."
related: [mistake-subtitle-overflow]
origin: FNAP
---

# Office HUD (clock, night, power + usage bars, stamina, status, subtitles)

**When to use:** Building the in-night HUD.

## Do this

- CanvasLayer 4 built in code: clock + night label (top right), power % + 5 usage bars, stamina and flashlight
  ProgressBars, status line ("LEFT DOOR: LATCHED / HOLDING / OPEN", plus prompts like "HOLD FLASHLIGHT ON REMI - OR SHUT
  THE DOOR"), 10 s fading control hint, "CAMERAS" hover bar at the bottom, phone controls (Mute Call, CC toggle),
  subtitle label, full-screen fade/black, vignette ColorRect (`vignette.gdshader`), GPT Commands card generated from
  the parser.
- Layers used: HUD 4, monitor 5, jumpscare flash 60.
- `_fit_subtitle()` shrinks the font from 28 down to 16 in steps until `get_multiline_string_size` fits; `SUBTITLE_MAX`.
  Sketch:
  ```gdscript
  func _fit_subtitle(text: String) -> void:
      var font := sub.get_theme_font("font")
      for size in range(28, 15, -2):
          var s := font.get_multiline_string_size(text, HORIZONTAL_ALIGNMENT_CENTER, sub.size.x, size)
          if s.y <= sub.size.y:
              sub.add_theme_font_size_override("font_size", size); break
      sub.text = text
  ```
- `apply_capture(portrait)` re-lays out for vertical video.
- Palette: Night `#1B1035`, Plum `#3A2263`, Gold `#F5C542`, Amber `#C48020`, Pickle `#7ED957`, Cream `#F4EFE6`. Pixel
  art always `TEXTURE_FILTER_NEAREST`, integer scaling.

## Pitfalls (mistakes seen)

mistake-subtitle-overflow.

## Verify

Screenshot with the longest subtitle line; no overflow.

## Origin

FNAP. Source notes: REF §2.9, §1.2 Palette, §8.2 #9.

## Related skills

- [mistake-subtitle-overflow](mistake-subtitle-overflow.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
