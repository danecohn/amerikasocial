---
id: install-godot-blender-linux-mac
title: "Install Godot + templates + Blender (install_tools.sh)"
category: environment-tools
when: "godot/blender missing on Linux/macOS."
related: []
origin: FNAP
---

# Install Godot + templates + Blender (install_tools.sh)

**When to use:** godot/blender missing on Linux/macOS.

## Do this

`GV=4.7.2 BV=5.2.2 PREFIX=/opt/tools bash install_tools.sh [--godot-only|--blender-only]`; idempotent; falls back to `$HOME/tools` and `$HOME/.local/bin` if not writable. Godot asset names: Linux x86_64 `Godot_v${GV}-stable_linux.x86_64.zip`, Linux aarch64 `Godot_v${GV}-stable_linux.arm64.zip`, macOS `Godot_v${GV}-stable_macos.universal.zip` (-> /Applications/Godot.app, binary `Contents/MacOS/Godot`). Base `https://github.com/godotengine/godot/releases/download/${GV}-stable`. Templates `Godot_v${GV}-stable_export_templates.tpz` -> unzip -> copy `templates/*` into the templates dir. Blender: `https://download.blender.org/release/Blender${BMAJ}/blender-${BV}-linux-x64.tar.xz` (`tar -xf --strip-components=1`), mac dmgs `-macos-arm64.dmg`/`-macos-x64.dmg` (or `brew install --cask godot blender`). No official Linux arm64 Blender. fetch() checks HTTP 200 and prints a failure instead of looping; on failure prints MANUAL FALLBACK (archive URLs, templates dirs per OS). Finishes with `check_env.sh`. Extras: `apt-get install -y xvfb ffmpeg zip unzip && pip install --break-system-packages pillow numpy`.
Manual Linux:
```
curl -L -o g.zip https://github.com/godotengine/godot/releases/download/4.7.2-stable/Godot_v4.7.2-stable_linux.x86_64.zip && unzip g.zip && chmod +x Godot_v4.7.2-stable_linux.x86_64
ln -sf $PWD/Godot_v4.7.2-stable_linux.x86_64 /usr/local/bin/godot
curl -L -o t.zip .../Godot_v4.7.2-stable_export_templates.tpz && unzip t.zip
mkdir -p ~/.local/share/godot/export_templates/4.7.2.stable && cp -r templates/* ~/.local/share/godot/export_templates/4.7.2.stable/
```

## Pitfalls (mistakes seen)

Proxy 403 on blender.org -> use preinstalled Blender; don't hunt mirrors.

## Verify

`godot --version` -> `4.7.2.stable.official.<hash>`; `blender --version | head -1` -> `Blender 5.2.2 LTS`; then verify_export.sh on a tiny project.

## Origin

FNAP. Source notes: install-godot-blender/scripts/install_tools.sh; references/install-guide.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
