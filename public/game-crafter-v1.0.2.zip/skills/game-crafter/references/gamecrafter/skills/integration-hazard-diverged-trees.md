---
id: integration-hazard-diverged-trees
title: "Merging a validated work copy into a diverged project of record safely"
category: multi-agent
when: "Two copies of a project exist (cloud/work copy vs PC/OneDrive project of record) and both changed."
related: []
origin: Caesarea
---

# Merging a validated work copy into a diverged project of record safely

**When to use:** Two copies of a project exist (cloud/work copy vs PC/OneDrive project of record) and both changed.

## Do this

- Before replacing anything: back up every file you will replace to `_backup\<date>b\` with the same relative paths; verify the backup is complete before further changes.
- Never overwrite a richer file wholesale (project-of-record `game.gd` had version, flow, inventory, settings, pending_load, launch, go_to_title, play_sting, menu music). Merge only the needed bits (three color constants).
- Intended replacements are listed explicitly (game_root.tscn, player_controller.gd, tests/test_main.gd); everything else is kept. Old flows are re-registered, not deleted (`porta_subura_legacy`; id aliases `porta_subura`, `roma_subura` → `roma` so old saves still load; `FALLBACK_ZONE`).
- "If two game roots disagree, this slice's game_root.tscn is what the title loads."
- Test count may differ between trees (203 vs 163) because a compile sweep counts every script; "0 failed is the bar", never delete scripts to match a count.
- Never copy `.godot/`, `_work/`, `godot_check/`, `*.blend1`, or dev-only inspection scripts.

## Pitfalls (mistakes seen)

Deleting older work to "force the count to 163" — forbidden; fix compile errors or report.

## Verify

backup tree exists and file count matches replaced list; tests 0 failed in project of record.

## Origin

Caesarea. Source notes: attachment.txt "Integration hazard", MANIFEST "Reconciliation", godot_import_report.md.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
