---
id: death-screen-and-run-end
title: "Death flow: fade, stats card, flavour line, death story beat, back to hub"
category: gameplay-systems
when: "Implementing permadeath feedback in a roguelite."
related: []
origin: Roguelike series
---

# Death flow: fade, stats card, flavour line, death story beat, back to hub

**When to use:** Implementing permadeath feedback in a roguelite.

## Do this

- `_end_run(win)` guarded by `ended`; prints `RUN_END win=.. floor=..`; computes and saves currency/stats first; resets Engine.time_scale.
- Lose: music off, "death" sfx, post fade over 1.2s after 0.8s; death card on CanvasLayer 60: title font 40 in danger colour (`tr_ui("death_title")`), random line from `death_lines` (10 per game), "FLOOR n   SLAIN n   CURRENCY n", "[ENTER]" hint; waits 0.8s then for interact/accept/confirm; then `Story.play("death")` (death-count beats) then `Game.goto("hub")`.
- Win: fade 1.5s then `Game.goto("ending", {"gain": gain})`.
- Ending scene: picks first ending whose `when` passes; music; records ending id in save; applies `set` flags; optional full-screen image fade; plays scene; scrolling credits (title + credits text + epilogue + "THANK YOU FOR PLAYING.", 22 px/s, x3 while holding interact, Esc skips) -> hub.

## Pitfalls (mistakes seen)

all tweens here use TWEEN_PAUSE_PROCESS (see black-screen mistake).

## Verify

`--hp=1` + walk into enemy; `--scene=ending --flags=choice_release`.

## Origin

Roguelike series. Source notes: run.gd 699-777; ending.gd.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
