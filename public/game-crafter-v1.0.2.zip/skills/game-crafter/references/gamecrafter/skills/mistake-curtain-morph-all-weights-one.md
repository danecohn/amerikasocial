---
id: mistake-curtain-morph-all-weights-one
title: "Curtain shows all stages at once / wrong state (blend weights exported [1,1,1])"
category: mistake
when: "Morph-target props look wrong after GLB import; staged props misbehave."
related: []
origin: FNAP
---

# Curtain shows all stages at once / wrong state (blend weights exported [1,1,1])

**When to use:** Morph-target props look wrong after GLB import; staged props misbehave.

## What happened, root cause, fix, prevention

- Symptom: curtain wrong/invisible; later curtain transitions broken.
- Root cause: curtain exported with blend weights `[1,1,1]` and `hidden_by_default`; plus an early `return` before
  recording stage meshes broke later transitions.
- Fix: zero all shapes at load, set exactly one to 1 per state; special-case the `Curtain` node in the hidden-by-default
  pass; keep stage 0 visible; record stages before any early return.
- Prevention: `curtain_check` prints blend weights + stage visibility per state.

## Verify

curtain_check output.

## Origin

FNAP. Source notes: REF §8.2 #4, §2.7.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
