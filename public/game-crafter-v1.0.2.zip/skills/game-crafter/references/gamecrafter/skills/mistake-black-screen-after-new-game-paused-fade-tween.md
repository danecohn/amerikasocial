---
id: mistake-black-screen-after-new-game-paused-fade-tween
title: "Black screen after New Game (dialogue pause froze the fade-in tween)"
category: mistake
when: "Any fade/transition tween combined with dialogue or menus that set get_tree().paused = true; any 'screen stays black' report."
related: []
origin: Roguelike series
---

# Black screen after New Game (dialogue pause froze the fade-in tween)

**When to use:** Any fade/transition tween combined with dialogue or menus that set get_tree().paused = true; any "screen stays black" report.

## Do this

In Godot 4 a tween created by a node is bound to that node and by default (TWEEN_PAUSE_BOUND) stops when the node does not process during pause. The kit's dialogue and menus pause the tree.

## What happened, root cause, fix, prevention

- Symptom (user saw it in THE LAST LAMP): choosing NEW GAME -> screen stays black forever (game audio/dialogue blips might run but nothing visible).
- Root cause: boot.change_scene added the hub, then started the fade-out-of-black tween; the hub's `_intro()` (call_deferred) immediately played the intro dialogue, which sets `get_tree().paused = true`. The boot node is PAUSABLE, so its fade tween froze at alpha 1 -> black screen while the dialogue waited for input it could not show.
- Fix: every transition tween uses `create_tween().set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)` (boot fades, run room fades, death fade, ending image fade). Dialogue/Menus/Game/AudioKit/TalkBlips nodes use `process_mode = PROCESS_MODE_ALWAYS`.
- Prevention rule: "tweens that must finish (fades, UI) must run while paused". Grep rule: every `create_tween()` used for fades must be followed by `.set_pause_mode(Tween.TWEEN_PAUSE_PROCESS)` or live in an ALWAYS node. Timers that must run while paused: `get_tree().create_timer(t, true, false, true)` (process_always=true, ignore_time_scale=true).
- Detection: automated screenshot of first run after New Game (`--fresh=1`), check the image is not all-black (mean brightness > threshold). The release check "first-run intro screenshot" on the exported build exists for this reason.

## Verify

fresh save -> title -> New Game -> screenshot shows hub with dialogue box.

## Origin

Roguelike series. Source notes: WIP_BIBLE_AND_MANIFEST.md "Black-screen-after-New-Game bug FIXED (dialogue pause froze the fade tween; fade tweens now run while paused)"; boot.gd 94,114; run.gd 157,196,722,730; ending.gd 51.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
