---
id: await-cancellation-tokens
title: "Tokenised awaits (cancel stale coroutines)"
category: gdscript-patterns
when: "Any `await` sequence (jumpscares, phone calls, door animations, cutscenes) that can be interrupted or restarted."
related: []
origin: FNAP
---

# Tokenised awaits (cancel stale coroutines)

**When to use:** Any `await` sequence (jumpscares, phone calls, door animations, cutscenes) that can be interrupted or restarted.

## Do this

```gdscript
var _token := 0
func play_sequence() -> void:
    _token += 1
    var my := _token
    await get_tree().create_timer(1.0).timeout
    if my != _token: return          # superseded/cancelled
    ...
func cancel() -> void: _token += 1
```
- Check the token after EVERY await.

## Pitfalls (mistakes seen)

stale awaits continuing after a scene state changed (implied by rule list).

## Verify

interrupt test in a check scene.

## Origin

FNAP. Source notes: S line 27; G line 46.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
