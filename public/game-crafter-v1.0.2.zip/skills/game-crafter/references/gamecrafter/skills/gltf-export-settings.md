---
id: gltf-export-settings
title: "glTF export settings and asset layout"
category: 3d-blender
when: "Exporting models for Godot."
related: []
origin: FNAP
---

# glTF export settings and asset layout

**When to use:** Exporting models for Godot.

## Do this

glTF Binary (.glb), include Cameras, Lights (punctual), Custom Properties (extras), Shape Keys, Animation (actions as separate clips, "Group by NLA Track" off), Apply Modifiers, +Y up. Materials: Principled BSDF with image textures only. `bpy.ops.export_scene.gltf(filepath=out, export_format='GLB', export_cameras=True, export_extras=True)`. Files: `res://assets/models/{characters|animated, office, rooms, props}/name.glb`; Godot extracts textures as `<glb>_<tex>.png/jpg` next to glb; `clips.json` beside characters. Texture naming: characters `<model>_<Material>_BaseColor/Normal/ORM.png`; rooms `*_albedo/_normal/_orm.jpg` (ORM = AO/Roughness/Metal packed -> Godot ORM slot).

## Pitfalls (mistakes seen)

Procedural shaders not exported -> bake.

## Verify

inspect_glb + Godot glb_check.gd.

## Origin

FNAP. Source notes: references/blender-godot-pipeline.md; SKILL.md textures bullet.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
