---
id: mistake-morph-weights-imported-as-one
title: "Mistake - glTF morph targets (blend shapes) arrive with weights [1,1,1]"
category: mistake
when: "Using shape keys (curtains, faces, doors) from Blender in Godot."
related: []
origin: FNAP
---

# Mistake - glTF morph targets (blend shapes) arrive with weights [1,1,1]

**When to use:** Using shape keys (curtains, faces, doors) from Blender in Godot.

## What happened, root cause, fix, prevention

- Symptom: the curtain started in Peek + Leaning + Open all at once.
- Root cause: the glTF mesh `weights` [1,1,1] were imported as-is.
- Fix: on bind set every blend shape to 0.0, then drive by `get_blend_shape_name(i).to_lower()` match. Do not `return` before registering stage nodes; do not `visible=false` ALL `Curtain_Stage*` (it hid `Curtain_Stage0_Closed`, the default state).
  ```gdscript
  for i in mesh_inst.get_blend_shape_count():
      mesh_inst.set_blend_shape_value(i, 0.0)
  func set_shape(name: String, w: float) -> void:
      for i in mesh_inst.get_blend_shape_count():
          if mesh_inst.mesh.get_blend_shape_name(i).to_lower() == name: mesh_inst.set_blend_shape_value(i, w)
  ```
- Prevention: after import normalise morph weights; make the default state the visible one; write a `curtain_check`-style script.
- Detection: print all blend shape values on bind; screenshot default state.

## Verify

curtain_check screenshot shows the closed default state.

## Origin

FNAP. Source notes: L §2.7 (lines 111-115); G line 30 (M46/M47 area).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
