---
id: headless-screenshot-harness-xvfb
title: "Real-renderer screenshots on a GPU-less box (Xvfb + software Vulkan) with perf JSON"
category: testing-qa
when: "Need pixels/visual verification in a cloud container."
related: []
origin: Caesarea
---

# Real-renderer screenshots on a GPU-less box (Xvfb + software Vulkan) with perf JSON

**When to use:** Need pixels/visual verification in a cloud container.

## Do this

- `--headless` uses a dummy renderer → black/empty images. Use `godot_xvfb.sh`: pick ICD from `VK_ICD_FILENAMES` or Chrome's SwiftShader `/opt/pw-browsers/*/chrome-linux/vk_swiftshader_icd.json` or Mesa lavapipe `/usr/share/vulkan/icd.d/lvp_icd*.json`; run `timeout $TMO xvfb-run -a -s "-screen 0 ${RES}x24" godot --rendering-driver vulkan --resolution $RES ...`; always a timeout ("scene never quit()? add get_tree().quit()"); ~5 s/frame at 720p on 2 cores, keep waits short; serialize with the godot lock.
- shot.gd (scene, so autoloads exist) user args after `--`: `<scene> <out.png> [wait=2.5] cam=x,y,z,lx,ly,lz spawn=Marker fov=70 force=1`; waits, `await RenderingServer.frame_post_draw`, saves PNG + `out.png.json` with load_ms, renderer, nodes, objects/tris/draw calls in frame, video/texture memory, mesh instance count, MultiMesh instances, lights, shadow lights, static tris, and meshes repeated ≥20 times without MultiMesh (perf smell).
- capture_shots.gd (windowed, not headless): refuses when `DisplayServer.get_name() == "headless"` (exit 2); places a Camera3D per zone (eye, look); after 8 frames + frame_post_draw checks it's a "real view": downscale to 48×27, quantize colors into 6 levels per channel, require ≥ 6 distinct buckets; otherwise delete the PNG and fail (`SHOT_NOT_A_VIEW`).

## Pitfalls (mistakes seen)

- Log showed `Required Vulkan instance extension VK_KHR_xlib_surface not found` → Godot fell back to OpenGL3 llvmpipe; fine for shots but know which renderer you got (record it in the JSON).
- `shot.gd:39 Parse Error: Cannot infer the type of "c" variable` from `var c := _args["cam"].split_floats(",")` (Dictionary value is Variant) → type explicitly: `var c: PackedFloat64Array = ...`. The harness itself never ran until fixed — run your tools once before relying on them.
- Many LOG entries say "Not screenshotted" — screenshots were finally real Vulkan window captures; never present a headless frame as a view.

## Origin

Caesarea. Source notes: tools/qa/godot_xvfb.sh, shot.gd, shot.sh, capture_shots.gd, docs/handoff/shots/qa/title.log, LOG.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
