---
id: living-project-docs
title: "Living project docs: STATE, MANIFEST, CHANGELOG, KNOWN_GAPS updated with every change"
category: project-management
when: "After any change to a game project, and at the start of every session."
related: [project-doc-set, handoff-docs-state-manifest, known-gaps-honesty-doc, mistake-stale-docs]
origin: FNAP, Caesarea, Roguelike series
---

# Living project docs

> **Rule:** Update the docs in the same turn as the change. Stale docs are worse than none, because the next AI believes them.

## Do this
1. Create from `os/templates/`: STATE.md, GAME_BIBLE.md, MANIFEST.md, CHANGELOG.md, KNOWN_GAPS.md (plus docs/handoff/LOG.md for team projects).
2. After every change: STATE.md (status, last change, verified/not verified, next steps) and a CHANGELOG line.
3. After every delivery: MANIFEST.md (files, sizes, SHA256, verified/not verified).
4. Never hard-code "verified" text in a generator. Compute it (counts, hashes) at build time.
5. Keep the docs in the project of record, not just in the cloud copy.
6. See `os/memory/PROJECT_MEMORY.md` for the read order at session start.

## Pitfalls
- **Manifests claimed "72 resources" when the real lists had 75 and 77** (roguelikes) → the text was a fixed template → generate the numbers.
- **INDEX said "all three games" after the fourth shipped** → update the series index with each release.
- **Status docs contradicted the actual builds** (Caesarea) → STATE.md must describe the exported build you last verified.

## Verify
- `git diff`/file timestamps show the docs changed in the same work block as the code.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
