---
id: art-status-files-per-team
title: "STATUS.md per art folder, read first when resuming"
category: project-management
when: "Multiple art teams (animation, audio, characters, architecture kits)."
related: []
origin: Caesarea
---

# STATUS.md per art folder, read first when resuming

**When to use:** Multiple art teams (animation, audio, characters, architecture kits).

## Do this

Each art area keeps a STATUS.md (`art_source/animation/STATUS.md`, `art_source/audio/STATUS.md`, `animation/combat/STATUS.md`, `models/characters/STATUS.md`, `models/architecture/<kit>/STATUS.md`) with what exists, what's verified, band tables/specs, and what is still to make ("The audio still to make is listed in art_source/audio/STATUS.md"). Code references specs from them (trim band V ranges came from colosseum STATUS.md). Builder scripts live beside (`build_arch.py`, `bld_shell_WIP.py`, `build_legionary.py`, run with `blender -b -P script`).

## Origin

Caesarea. Source notes: PAUSED_STATUS Art, How to resume; trim_materials.gd comment; MANIFEST decisions.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
