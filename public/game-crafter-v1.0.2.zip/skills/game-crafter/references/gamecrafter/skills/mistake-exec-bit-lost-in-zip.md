---
id: mistake-exec-bit-lost-in-zip
title: "Mistake: Linux/mac executables lose exec bit in zips"
category: mistake
when: "Zipping builds on Windows or with generic zip tools."
related: []
origin: FNAP
---

# Mistake: Linux/mac executables lose exec bit in zips

**When to use:** Zipping builds on Windows or with generic zip tools.

## What happened, root cause, fix, prevention

Symptom: Linux players must `chmod +x`; mac app won't launch. Root cause: PowerShell `Compress-Archive`/ZipArchive writes no unix mode; unzip/rezip of .app on Windows drops modes and symlinks. Fix: `ExternalAttributes = (0x8000 + 493) -shl 16` for binaries; on Linux `chmod 755` + `zip -qry`; keep Godot's mac zip and append extras. Prevention: use build_release scripts only. Detection: `zipinfo <zip> | grep x86_64` shows `-rwxr-xr-x`.

## Verify

zipinfo modes.

## Origin

FNAP. Source notes: SKILL.md line 38; build_release.ps1 lines 24-36.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
