# Workflow: deliver to the user's computer
1. Know the channel: `pc-bridge-capabilities-and-limits`, `pc-bridge-commit-files-rules`, `pc-unreachable-or-too-big`.
2. Small files (code, docs): commit directly, batched (`cloud-to-pc-sync-batches`).
3. Big files: split (`split-zip-parts-and-build-all-bat`), or build on the PC with a launcher (`run-on-pc-via-bat-launcher`, `build-release-ps1`, `powershell-script-rules`, `robocopy-asset-sync`) and read its log back.
4. If you have a shell on the PC, use it directly and keep results next to the sources.
5. Confirm it landed (`deliver-and-confirm`, `bridge-mtime-guard-and-verification`).
6. Never leave mixed old/new parts. Say exactly what the user must run (e.g. BUILD_ALL.bat).
Mistakes: `mistake-staged-path-400`, `mistake-30mb-commit-limit`, `mistake-commit-not-landing-mtime`, `mistake-unread-pc-results`, `mistake-cannot-delete-on-pc`.
