---
id: fnaf-fact-ledger-per-night
title: "What the player can learn" ledger (facts said per night + never-said list)"
category: narrative-dialogue
when: "Planning lore drip, writing calls/notes/easter eggs, auditing that mysteries stay unanswered."
related: []
origin: FNAP
---

# What the player can learn" ledger (facts said per night + never-said list)

**When to use:** Planning lore drip, writing calls/notes/easter eggs, auditing that mysteries stay unanswered.

## Do this

- A table with columns: Night | Facts said out loud | Helpful instruction | Left unfinished. FNAP rows:
  - 1: facts (11 months, two dark halls, walk to the door, doors cost power, four robots, terminal unreliable, quit
    Friday/kitchen table) | check the doorway before shutting; don't spend power from nerves | what happens if a robot
    reaches the office.
  - 2: runner rules | watch the curtain; shut the left door before she arrives; stay quiet | why the cove is roped off.
  - 3: watched-freeze + audio-only enemies, right door, caller contradicts himself | don't stare at the stage; listen for
    pots; keep the right hall in mind | where the caller actually is.
  - 4: something not one of the four; wrong color; lifting monitor makes it go away; others getting closer to the phone
    | lift the monitor; don't talk to it | what it is, and its name.
  - 5: the bell is coming; only a minute; thanks | leave through the front door | why not come back for him.
- "Never said out loud" list: whether the caller is alive / where he calls from; what is in the brine; who ordered the
  secret room and what the runner is kept from; what the hallucination is (name never spoken); what happened to the guard
  before; whether 6 AM is a real ending.
- Use the ledger as an audit list for every player-facing string and rare swap (e.g. newspaper clippings must not answer
  a never-said item).

## Pitfalls (mistakes seen)

Cross-check against the AI table: an enemy active before its row (Golden AI 2 on N3, explained N4).

## Verify

grep all player-facing text (UI, subtitles, swaps, terminal JSON) for never-said answers/names.

## Origin

FNAP. Source notes: LEARN entire; BIBLE "What the Player Should Still Not Understand".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
