---
id: mistake-icon-not-embedded
title: "Windows icon not embedded in exe (no rcedit on Linux/ARM)"
category: mistake
when: "Exporting Windows from Linux/ARM host."
related: []
origin: FNAP
---

# Windows icon not embedded in exe (no rcedit on Linux/ARM)

**When to use:** Exporting Windows from Linux/ARM host.

## Do this

Non-fatal; document it; set icon on a Windows host if needed.

## What happened, root cause, fix, prevention

Symptom: default Godot icon on exe. Cause: rcedit unavailable. Fix: note caveat / build on Windows.

## Verify

Caveat in handoff.

## Origin

FNAP. Source notes: mistakes-log.md M28; BOARD.md line 11.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
