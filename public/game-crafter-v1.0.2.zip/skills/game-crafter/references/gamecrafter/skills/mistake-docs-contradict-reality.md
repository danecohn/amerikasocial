---
id: mistake-docs-contradict-reality
title: "Status docs contradicting each other (presets, controls, fallback scene)"
category: mistake
when: ""
related: []
origin: Caesarea
---

# Status docs contradicting each other (presets, controls, fallback scene)

**When to use:** 

## What happened, root cause, fix, prevention

PAUSED_STATUS said "no export presets / nothing exported" while export_presets.cfg + 3 zips existed; README/PLAY described voxel controls after retirement (fixed later); scene plan M2 row said New Game falls back to world.tscn while it fell back to the test yard; kit README advertised unbuilt builders; MANIFEST held both "STATE AT HAND-OFF ~09:50" and later passes that superseded it; TEAM.md said Blender unavailable while another machine had a Blender pass. Root cause: many agents, each updating only their own doc. Fix/prevention: one live status file (MANIFEST) with dated sections and "superseded by" notes; the integrator's gate includes a doc sweep (grep for the old scene names/controls); user-facing docs (README, PLAY, ITCH_PAGE, KNOWN_GAPS) updated in the same step as the change.

## Origin

Caesarea. Source notes: PAUSED_STATUS vs export_presets.cfg/LOG 11:16; PAUSED_STATUS Half-done Docs; kit README diff.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
