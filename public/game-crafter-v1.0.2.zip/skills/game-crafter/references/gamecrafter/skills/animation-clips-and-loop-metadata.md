---
id: animation-clips-and-loop-metadata
title: "Animation clips, loops, morph targets from Blender to Godot"
category: 3d-blender
when: "Rigged characters with clips; blend shapes."
related: []
origin: FNAP
---

# Animation clips, loops, morph targets from Blender to Godot

**When to use:** Rigged characters with clips; blend shapes.

## Do this

Actions become Godot clips inside the GLB. Loop flags don't survive -> `clips.json` (`loop`, `walk_speed_mps`) + an AnimImport step. Keep one-shots (jumpscare, die, attack) explicit. FNAP enemy clips: `idle, walk, run, door_peek, jumpscare, door_retreat, light_flinch, appear, showcase`. First-person arms (`fp_arms.glb`): `fp_get_up, fp_sit_down, fp_walk_to_door, fp_lean_out_L/R, fp_door_yank_L/R, fp_monitor_up/down, fp_dock/undock, fp_type, fp_jumpscare_react, fp_death, fp_flashlight_dies`; bone `CameraShake` drives authored camera motion. Eyes: bones `eye.L/eye.R` + iris meshes with `pupil_shrink` blend shape -> `LookAtModifier3D` tracking. Speeds 0.64-0.8 m/s walkers, 3.3 m/s run. Morph targets: export Shape Keys; Godot gets blend shapes with exported weights (can be `[1,1,1]`) -> zero them on bind.

## Pitfalls (mistakes seen)

Blend shapes all at 1 on load -> zero on bind. Looping lost -> clips.json.

## Verify

clips play/loop correctly in Godot.

## Origin

FNAP. Source notes: blender-assets/SKILL.md Animation/Morph bullets; references "Character clip names".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
