---
id: cloud-proxy-download-rules
title: "Downloads behind the cloud egress proxy"
category: environment-tools
when: "Any download fails (403, CONNECT tunnel failed) in a cloud sandbox."
related: []
origin: FNAP
---

# Downloads behind the cloud egress proxy

**When to use:** Any download fails (403, CONNECT tunnel failed) in a cloud sandbox.

## Do this

In the Claude sandbox GitHub release downloads worked (HTTP 206 on a range request), while `download.blender.org`, Descript storage and media hosts returned `CONNECT tunnel failed, response 403`. Check `curl -sS "$HTTPS_PROXY/__agentproxy/status"`; never unset the proxy or disable TLS. If blocked: use preinstalled tools, ask the user to attach the file, or run the PC installer. Don't hunt mirrors.

## Pitfalls (mistakes seen)

Wasting turns trying to bypass -> stop, use fallback.

## Verify

status endpoint shows allow-list.

## Origin

FNAP. Source notes: install-godot-blender/SKILL.md rule 4; blender-assets SKILL.md last bullet; descript-playbook.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
