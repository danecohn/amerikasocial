---
id: communication-rules
title: "How to talk to the user during long game jobs"
category: project-management
when: "Every user-facing message during a game job, especially long waits and angry feedback."
related: []
origin: FNAP
---

# How to talk to the user during long game jobs

**When to use:** Every user-facing message during a game job, especially long waits and angry feedback.

## Do this

- First reply: one sentence of what you are about to do, then work.
- Before any long wait (import, render, export, Descript job) send a one-line status; run long jobs in the background and poll (`bg_run.sh`). The user interrupted silent waits more than once.
- Plain words to the user; no tool names.
- If the user is angry ("it still looks like shit"): do not argue or theorize - reproduce on the BUILT artifact, find root cause, fix, prove with an image.
- If something is impossible from here (blocked host, 30 MB bridge limit, no PC shell): say so in one line and give the nearest working route. Never retry blocked network hosts or try to bypass a proxy.
- Ambiguous short instruction ("import the videos to the folder")? Re-read the previous turn's goal; state your interpretation or ask one question.
- Never invent what you could not fetch (a demo you could not download, a sound you did not hear).

## Pitfalls (mistakes seen)

M93 silent waits interrupted; M95 literal answer to ambiguous instruction; M75 can't stage demo -> never invent.

## Verify

Each long job preceded by a status line; no unverified claims.

## Origin

FNAP. Source notes: SKILL.md "Communication rules that mattered" (40-45).

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
