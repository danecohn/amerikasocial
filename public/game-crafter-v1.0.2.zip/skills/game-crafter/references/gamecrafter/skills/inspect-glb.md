---
id: inspect-glb
title: "Inspect a .glb (inspect_glb.py)"
category: 3d-blender
when: "Before posing, wiring node names, or debugging missing/misplaced nodes."
related: []
origin: FNAP
---

# Inspect a .glb (inspect_glb.py)

**When to use:** Before posing, wiring node names, or debugging missing/misplaced nodes.

## Do this

```python
import bpy, sys
path = sys.argv[sys.argv.index("--") + 1]
bpy.ops.wm.read_factory_settings(use_empty=True); bpy.ops.import_scene.gltf(filepath=path)
for o in bpy.data.objects:
    if o.type == 'ARMATURE':
        print("ARM", o.name, len(o.data.bones), "bones")
        for b in o.data.bones: print("BONE", b.name, [round(x,2) for x in b.head_local], "->", [round(x,2) for x in b.tail_local])
    elif o.type == 'MESH':
        print("MESH", o.name, "dims", [round(d,2) for d in o.dimensions], "mats", [m.name for m in o.data.materials if m])
        if o.data.shape_keys: print("SHAPEKEYS", o.name, [k.name for k in o.data.shape_keys.key_blocks])
    elif o.type == 'CAMERA': print("CAM", o.name, [round(x,2) for x in o.location], "fov", round(o.data.angle,3))
    elif o.type == 'LIGHT': print("LIGHT", o.name, o.data.type, "energy", o.data.energy)
    elif o.type == 'EMPTY': print("EMPTY", o.name, [round(x,2) for x in o.location])
    if o.keys(): print("EXTRAS", o.name, {k: o[k] for k in o.keys() if not k.startswith("_")})
for a in bpy.data.actions: print("ACT", a.name, "frames", [round(x) for x in a.frame_range])
```
Use it to dump positions: nodes placed out of view (e.g. a door lamp beside the camera) are invisible bugs.

## Pitfalls (mistakes seen)

Guessing bone/action names.

## Verify

Output lists expected contract names.

## Origin

FNAP. Source notes: blender-assets/scripts/inspect_glb.py.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
