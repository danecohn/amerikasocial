# Credits
**GameCrafter v1.0 — Developed by Forgotten Woods Studios** ("A Horror Experience Company").

Knowledge harvested from Forgotten Woods Studios productions:
FNAP / Five Nights at Pickles · Pickle's Pickle Shop (FNAP Reimagined) · Caesarea · The Last Lamp · Saint Marrow's · Salt Mine 9 · Ward Seven.

Third-party tools referenced (not bundled): Godot Engine (MIT), Blender (GPL), BeepBox synth (MIT, github.com/johnnesky/beepbox), ffmpeg (LGPL/GPL), Pillow, numpy, fontTools.
