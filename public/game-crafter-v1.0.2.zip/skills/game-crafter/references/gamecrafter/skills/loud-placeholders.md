---
id: loud-placeholders
title: "Loud placeholders and wiring report"
category: gdscript-patterns
when: "Writing any code that loads an authored asset (model, texture, audio, node by name) with a fallback."
related: []
origin: FNAP
---

# Loud placeholders and wiring report

**When to use:** Writing any code that loads an authored asset (model, texture, audio, node by name) with a fallback.

## Do this

Every authored asset gets a placeholder so the game always runs, but fallback use must be LOUD: `push_warning("PLACEHOLDER: <role> (<path> missing)")` + an on-screen debug note. Keep a "role -> real | PLACEHOLDER | missing" wiring report printed at load (FNAP `office_wiring`). Look up on the real model first, placeholder second. Never hide the placeholder node that a rig lives on; rigs adopt real nodes.
```gdscript
var wiring := {}  # role -> "real" | "PLACEHOLDER" | "missing"
func _resolve(role: String, real_root: Node, name: String, fallback: Node) -> Node:
    var n := real_root.find_child(name, true, false) if real_root else null
    if n: wiring[role] = "real"; return n
    if fallback: wiring[role] = "PLACEHOLDER"; push_warning("PLACEHOLDER " + role); return fallback
    wiring[role] = "missing"; push_error("MISSING " + role); return null
# after wiring: print(JSON.stringify(wiring))
```

## Pitfalls (mistakes seen)

M01 silent placeholder fallback shipped; M06 door rigs broke when placeholders hidden; M07 missing room GLBs unnoticed.

## Verify

Wiring report has no PLACEHOLDER/missing for required roles in the EXPORTED build.

## Origin

FNAP. Source notes: SKILL.md loop step 3; mistakes-log M06, M07; process-playbook 4.3; QA template D.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
