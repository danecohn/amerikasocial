---
id: headless-capture-checklist
title: "Headless capture checklist"
category: testing-qa
when: "Before/after any capture session."
related: []
origin: FNAP
---

# Headless capture checklist

**When to use:** Before/after any capture session.

## Do this

1. Import done (`IMPORT_DONE` marker), swap on, ICD found (`check_env.sh`). 2. One capture at a time; log to file; poll. 3. Open PNGs yourself before building art/video. 4. Clean `promo/clips/*.png` after encoding.

## Pitfalls (mistakes seen)

Building art from unseen (broken) frames.

## Verify

Checklist ticks.

## Origin

FNAP. Source notes: headless-render-capture/SKILL.md "Checklist".

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
