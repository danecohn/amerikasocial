---
id: fnaf-flashlight-beam-check
title: "Flashlight hit test (cone + physics ray) to make enemies flinch/retreat"
category: gameplay-systems
when: "An enemy should react to being lit (flinch, retreat, pupils shrink)."
related: [mistake-unshaded-import-flashlight-cant-light]
origin: FNAP
---

# Flashlight hit test (cone + physics ray) to make enemies flinch/retreat

**When to use:** An enemy should react to being lit (flinch, retreat, pupils shrink).

## Do this

- `_beam_check()` every 0.15 s: for each visible animatronic where `is_exposed_to_beam(leaning)`, test the cone
  (`angle_to <= spot_angle`) and a physics ray from the light to chest height; if clear -> `on_flashlight_hit()`:
  flinch clip, pupil shrink (`EyeRig.pinprick()`), 1.8 s cooldown, stall.
- `is_flashlight_on_actor(a)` is the stricter test used by Remi's 0.7 s retreat rule.
- Sketch:
  ```gdscript
  func _beam_check() -> void:
      var spot := flashlight as SpotLight3D
      var fwd := -spot.global_transform.basis.z
      for a in animatronics:
          if not a.visible or not a.is_exposed_to_beam(leaning): continue
          var chest := a.global_position + Vector3.UP * 1.2
          var to := chest - spot.global_position
          if rad_to_deg(fwd.angle_to(to)) > spot.spot_angle: continue
          var q := PhysicsRayQueryParameters3D.create(spot.global_position, chest)
          if get_world_3d().direct_space_state.intersect_ray(q).is_empty():
              a.on_flashlight_hit()
  ```

## Pitfalls (mistakes seen)

mistake-unshaded-import-flashlight-cant-light (unshaded materials ignore the flashlight).

## Verify

`door_lurker_sim` Remi flashlight retreat case.

## Origin

FNAP. Source notes: REF §2.3 Flashlight.

## Related skills

- [mistake-unshaded-import-flashlight-cant-light](mistake-unshaded-import-flashlight-cant-light.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
