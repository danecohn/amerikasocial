---
id: fnaf-deterministic-seeded-rng
title: "Deterministic RNG per system (salted seeds) for captures and tests"
category: gdscript-patterns
when: "Trailer capture or tests must reproduce the same AI rolls."
related: []
origin: FNAP
---

# Deterministic RNG per system (salted seeds) for captures and tests

**When to use:** Trailer capture or tests must reproduce the same AI rolls.

## Do this

- `GameState.seed_rng(rng, salt)` seeds from `hash("%d:%s" % [capture_seed, salt])` when capturing, else `randomize()`.
  Every random system (animatronics, office, assistant, roguelite) calls it with its own salt, so adding a roll in one
  system doesn't shift another.
  ```gdscript
  func seed_rng(rng: RandomNumberGenerator, salt: String) -> void:
      if capture != "":
          rng.seed = hash("%d:%s" % [capture_seed, salt])
      else:
          rng.randomize()
  ```
- `--seed=1337` in captures.

## Pitfalls (mistakes seen)

none.

## Verify

Two captures with the same seed produce identical frames.

## Origin

FNAP. Source notes: REF §1.7, §8.1 H, §6.1.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
