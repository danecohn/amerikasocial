---
id: mistake-hardcoded-toolchain-paths
title: "Generator scripts hard-code the build machine's absolute paths"
category: mistake
when: "Shipping or moving a procedural art toolchain."
related: []
origin: Roguelike series
---

# Generator scripts hard-code the build machine's absolute paths

**When to use:** Shipping or moving a procedural art toolchain.

## What happened, root cause, fix, prevention

- Symptom: running the shipped `generator/` on another machine fails (`ModuleNotFoundError: sprites` / missing fw_icon.png / wrong output dir).
- Root cause: `sys.path.insert(0, "/home/claude/evac/_tools")` in gk.py and every spec.py; cover.py opens `/home/claude/evac/kit/assets/branding/fw_icon.png`; finish.py writes to `/home/claude/evac/out` and `/mnt/user-data/outputs/...`; buildgame.py looks for the export template under `/root/.claude/plugins/synced/*`.
- Fix: derive paths from `__file__` (`HERE = os.path.dirname(os.path.abspath(__file__))`) like buildgame.py already does for ROOT; pass output roots as CLI args/env vars.
- Prevention: grep for `/home/` and `/root/` before packaging; test the generator from the extracted source zip in a clean dir.

## Verify

unzip source zip to /tmp/x, run `python3 generator/_tools/buildgame.py generator/game --no-music` successfully.

## Origin

Roguelike series. Source notes: _tools/gk.py line 5; games/*/spec.py line 2; _tools/cover.py line 40; _tools/finish.py lines 6,16,50; buildgame.py lines 19-23.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
