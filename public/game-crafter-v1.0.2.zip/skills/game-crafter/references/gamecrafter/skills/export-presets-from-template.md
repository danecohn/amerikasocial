---
id: export-presets-from-template
title: "Generate export_presets.cfg for 4 platforms from one template"
category: export-release
when: "A new Godot project needs Windows x64, Windows ARM64, macOS, Linux presets; automating presets per game."
related: [mistake-old-studio-name-in-identifiers]
origin: Roguelike series
---

# Generate export_presets.cfg for 4 platforms from one template

**When to use:** A new Godot project needs Windows x64, Windows ARM64, macOS, Linux presets; automating presets per game.

## Do this

- Keep one template with placeholders `__NAME__`, `__COMPANY__`, `__PRODUCT__`, `__BUNDLE__`; strip `;` comment lines; string-replace filters and names; write `export_presets.cfg`.
- Filters that worked for a JSON-driven kit: `include_filter="*.txt, *.csv, *.cues, *.xml, *.cfg, game/*, tools/probe_manifest.json"` (non-resource files must be listed or they are NOT packed), `exclude_filter="_backup/*, scripts/dev/*, *_check.gd, *.py, *.log, docs/*, build/*"`.
- Set `application/modify_resources=false` and remove the `application/icon="res://icon.ico"` line when there is no .ico and no rcedit (cloud Linux cannot edit Windows exe resources).
- Resulting presets (exact): preset.0 "Windows Desktop" x86_64, embed_pck=true, s3tc_bptc=true, etc2_astc=false, debug/export_console_wrapper=1, company "Forgotten Woods Studios", product name, file/product version "1.0.0.0"; preset.1 "macOS" architecture "universal", bundle_identifier `com.<studio>.<slugnounderscores>`, min_macos_version "11.00", app_category "Games", codesign=0, notarization=0, export path `build/macos/<slug>-mac.zip`; preset.2 "Linux" x86_64 embed_pck; preset.3 "Windows ARM64" platform "Windows Desktop", architecture "arm64", runnable=false (only one runnable preset per platform). All `script_export_mode=2`, `export_filter="all_resources"`.
- In project.godot enable both `import_s3tc_bptc` and `import_etc2_astc` or the macOS universal/ARM export fails/has missing textures.

## Pitfalls (mistakes seen)

bundle id still used the old studio name (`com.evacstudios.thelastlamp`) after the rebrand - see mistake-old-studio-name-in-identifiers.

## Verify

`godot --headless --path P --export-release "<preset>" <path>` produces a file for each of the 4 presets (release.py prints `rc .. ok <size>`).

## Origin

Roguelike series. Source notes: buildgame.py L189-200, L215; roguelikes/*/export_presets.cfg (both games diff only in names/paths).

## Related skills

- [mistake-old-studio-name-in-identifiers](mistake-old-studio-name-in-identifiers.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
