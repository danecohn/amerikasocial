---
id: fnaf-cove-runner-enemy
title: "The "runner" enemy (curtain stages while unwatched, then a sprint to one door)"
category: ai-enemies
when: "Implementing a Foxy-style enemy that must be checked on camera and blocked with a door at the right moment."
related: [mistake-curtain-morph-all-weights-one, mistake-runner-fixed-sprint-time]
origin: FNAP
---

# The "runner" enemy (curtain stages while unwatched, then a sprint to one door)

**When to use:** Implementing a Foxy-style enemy that must be checked on camera and blocked with a door at the right moment.

## Do this

- Player-facing rule (CALLS N2): "The curtain opens a little at a time. A little, then more, then all the way, and then
  the stage is empty. When it's empty, she's already running. She comes down the west hall to the left door. Shut it
  before she gets there, and then stay quiet while she bangs on it. She'll give up... every bang costs you power."
- Cove state machine `curtain -> peeking -> (leaning, hooked by curtain code) -> running`. Timer: while the cove camera
  is watched the timer DECAYS; unwatched it GROWS by `step*(1+ai/10)`. >25 -> peeking; >20 more -> `_start_sprint()`.
- Sprint: lerp from the CAM_2A waypoint to the left door over `distance / (run_speed * speed_multiplier)` seconds
  (run_speed 3.3 m/s). It was a fixed 6 s originally (bug, see mistake-runner-fixed-sprint-time).
- Door shut on arrival -> bangs (gives up after 3 bangs for the cove attacker, 1 while holding breath) ->
  `reset_to_cove()`; regroup 100 s. Each bang drains power with escalation.
- Sketch:
  ```gdscript
  func _tick_cove(delta: float) -> void:
      if office.is_room_watched("CAM_1C"):
          _cove_t = maxf(0.0, _cove_t - delta)
      else:
          _cove_t += step * (1.0 + ai_level / 10.0) * delta
      if cove_state == "curtain" and _cove_t > 25.0:
          set_cove_state("peeking")
      elif cove_state == "peeking" and _cove_t > 45.0:
          _start_sprint()
  func _start_sprint() -> void:
      var d := wp("CAM_2A").distance_to(wp("OFFICE_DOOR_L"))
      _sprint_len = d / (data.run_speed * speed_multiplier)
  ```
- 2D REBUILD "BANSHEE RUN" frame list (one image per state): 1C curtains closed -> peek -> leaning -> empty cove;
  2A run far -> mid -> close -> lunge (passing under the lens); office left doorway burst; jumpscare. If the LEFT DOOR IS
  SHUT when she arrives: no office plate change, play `banshee-door-bang.wav`, drain power, reset to stage 1.
- Audio: `brine-cove-hum.wav` (humming behind the curtain), `banshee-run.wav` (4-beat gallop), `banshee-door-bang.wav`.
- Adaptive music: three Banshee stems (tick/march/chase) crossfaded equal-power over 0.1 s on the next bar.

## Pitfalls (mistakes seen)

mistake-runner-fixed-sprint-time (also the `leaning` state never triggered); mistake-curtain-morph-all-weights-one.

## Verify

`door_lurker_sim` drives a Banshee sprint; `curtain_check` shoots each curtain state from `Cam_1C` and prints
blend weights + stage visibility; `balance_regression.gd` asserts bang power cost and retreat.

## Origin

FNAP. Source notes: REF §2.5 Banshee, §2.7, §2.10, §8.2 #8; CALLS N2; STATEMAP "BANSHEE RUN" lines 130-149.

## Related skills

- [mistake-curtain-morph-all-weights-one](mistake-curtain-morph-all-weights-one.md)
- [mistake-runner-fixed-sprint-time](mistake-runner-fixed-sprint-time.md)

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
