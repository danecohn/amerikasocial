---
id: fnaf-clickable-area3d
title: "Clicking world props without colliders in the imported model"
category: gdscript-patterns
when: "Levers, buttons, posters, phone, terminal etc. in an imported GLB must be clickable."
related: []
origin: FNAP
---

# Clicking world props without colliders in the imported model

**When to use:** Levers, buttons, posters, phone, terminal etc. in an imported GLB must be clickable.

## Do this

- `_make_clickable(names, action)`: find the node by name, attach an `Area3D` + `BoxShape3D` sized 1.6x the mesh AABB
  (min 0.12), `set_meta("office_action", action)`.
- `_click_world`: ray-cast with `collide_with_areas = true, collide_with_bodies = false`, `match` the meta string
  (`lever_L/R`, `light_L/R`, `poster`, `dock`, `phone`, `assistant`).
- Sketch:
  ```gdscript
  func _make_clickable(names: Array, action: String) -> void:
      var n := find_office(names) as Node3D
      if n == null: return
      var mesh := NodeFinder.find_mesh(n)
      var aabb := mesh.get_aabb() if mesh else AABB(Vector3.ZERO, Vector3.ONE * 0.12)
      var area := Area3D.new()
      var shape := CollisionShape3D.new()
      var box := BoxShape3D.new()
      box.size = (aabb.size * 1.6).max(Vector3.ONE * 0.12)
      shape.shape = box
      shape.position = aabb.get_center()
      area.add_child(shape)
      area.set_meta("office_action", action)
      n.add_child(area)
  ```
- Easter egg: clicking Pickle's nose on the office poster plays `pickle-poster-squeak.wav`.

## Pitfalls (mistakes seen)

none.

## Verify

Click each target in a debug run; print action.

## Origin

FNAP. Source notes: REF §2.2, §8.1 C; STATEMAP line 266.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
