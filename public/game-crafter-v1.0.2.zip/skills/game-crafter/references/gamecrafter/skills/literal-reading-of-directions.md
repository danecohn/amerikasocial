---
id: literal-reading-of-directions
title: "Read user art/delivery directions literally"
category: project-management
when: "User gives a pose, path, count, music or tool instruction."
related: []
origin: FNAP
---

# Read user art/delivery directions literally

**When to use:** User gives a pose, path, count, music or tool instruction.

## Do this

Examples from FNAP:
- "Posed Pickle, weight on one foot, other stepped in, one hand up" -> NOT a T-pose; pose it exactly.
- "Zips in THAT folder" -> exact path, verified by listing.
- "4 screenshots" -> give a few more to choose from and say which are the best 4.
- "Use the game's music" -> mix the actual shipped audio files.
- "Make it on Descript" -> do the editing IN Descript; do not pre-bake a weak final in ffmpeg.

## Pitfalls (mistakes seen)

M40 T-pose title art rejected; M66 reel not made in Descript; M08 wrong folder.

## Verify

Re-read the instruction against the output before delivery.

## Origin

FNAP. Source notes: process-playbook.md section 5.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
