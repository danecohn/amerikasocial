---
id: mistake-export-placeholders-pck-remap
title: "Exported game shows grey boxes/capsules (raw files not in PCK)"
category: mistake
when: "Writing any runtime asset discovery/loading in Godot 4; user says exported game looks different from editor / 'like the old version'."
related: []
origin: FNAP
---

# Exported game shows grey boxes/capsules (raw files not in PCK)

**When to use:** Writing any runtime asset discovery/loading in Godot 4; user says exported game looks different from editor / "like the old version".

## Do this

In an export the PCK holds imported resources behind `.import`/`.remap` entries, NOT raw `.glb/.png`. Use `load()` / `ResourceLoader.exists()`; strip `.import`/`.remap` from listed names.
```gdscript
static func packed_name(f: String) -> String:
    if f.ends_with(".import"): return f.trim_suffix(".import")
    if f.ends_with(".remap"): return f.trim_suffix(".remap")
    return f
for f in DirAccess.get_files_at(dir):
    var n := packed_name(f)
    if n.ends_with(".glb") and ResourceLoader.exists(dir.path_join(n)): load(dir.path_join(n))
```

## What happened, root cause, fix, prevention

Symptom: user ran exported game: grey boxes for office, capsules for characters, none of the upgrades; user: "It still looks like shit... like you're still compiling with the old version of the scripts". Assistant first suspected stale scripts. Root cause: `DirAccess.get_files()` returns `office.glb.import`; `FileAccess.file_exists()` / `ProjectSettings.globalize_path()` on `res://` fail in export; every "load the real model" check failed silently -> placeholder fallback. Editor runs had raw files so looked perfect. Fix: list dirs through `NodeFinder.packed_name()`, load with `load()`/`ResourceLoader.exists()`. Prevention: never judge from the editor; test exported pack + screenshot before claiming a fix; don't blame "old version" without timestamps/version proof. Detection: `verify_export.sh`, `lint_export_safety.py` (flags FileAccess.file_exists/globalize_path/get_files on res://).

## Verify

Screenshot from exported pack shows real models; probe fails=0.

## Origin

FNAP. Source notes: mistakes-log.md M01.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
