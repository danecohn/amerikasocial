---
id: game-autoload-state-save-settings
title: "Global Game autoload: definition JSON, save, settings, flags, helpers"
category: gdscript-patterns
when: "Designing the global state singleton for a data-driven game with persistent meta progression."
related: []
origin: Roguelike series
---

# Global Game autoload: definition JSON, save, settings, flags, helpers

**When to use:** Designing the global state singleton for a data-driven game with persistent meta progression.

## Do this

- `Game` autoload, `process_mode = PROCESS_MODE_ALWAYS`. Holds `def` (game.json), `save`, `settings`, `pal` (palette Colors), fonts, `rng`, `audio` (AudioKit child), `blips` (TalkBlips child), `boot`, `shake_amt`, `run` (live run dict), `capture_mode`, `base_scale`, `cli`.
- Parses CLI user args (after `--`): `for a in OS.get_cmdline_user_args(): if a.begins_with("--") and a.contains("="): cli[a.get_slice("=",0).substr(2)] = a.get_slice("=",1)`. Flags: --shot (capture_mode), --speed (Engine.time_scale), --seed (rng.seed).
- Save file path per game: `user://%s_save.json % def.id` so several games of the series never collide.
- Default save keys: runs, deaths, wins, memories, best_floor, boss_kills{}, meta{}, flags{}, beats{}, fragments[], dread, max_dread, kills, playtime, settings, seen_intro, endings[]. Load = start from defaults then overlay saved keys (forward compatible when new keys are added).
- Settings defaults `{"music":0.8,"sfx":0.9,"shake":true,"blips":true,"fullscreen":false}` are stored inside the save; New Game keeps settings (`var keep := settings; save = _default_save(); save["settings"] = keep; write_save()`).
- `has_save()` = runs>0 or seen_intro -> controls CONTINUE on title.
- apply_settings: volumes; fullscreen only if `not capture_mode and DisplayServer.get_name() != "headless"`.
- Helpers: `label(text,size,color,title)` builds a pixel-font Label with mouse_filter IGNORE; `tr_ui(key, fallback)` reads `def.text` overrides so each game re-words UI ("THE ROOM IS QUIET.", "YOU FELL"); `speaker(id)` defaults `{name: id.to_upper(), color:"#e8e0d0"}`; `shake(a)` respects setting; `sfx`, `music`, `goto`.
- Prints a wiring line at startup: `WIRING game=<id> fonts=<bool> missing_art=<n>` - used by tooling greps.

## Pitfalls (mistakes seen)

Missing game.json -> `push_error("game.json missing or invalid")` (loud). Missing fonts -> `PLACEHOLDER font missing:` print and null font (labels fall back to default).

## Verify

run twice; save JSON exists in user://; `WIRING ... fonts=true missing_art=0`.

## Origin

Roguelike series. Source notes: kit/kit/game.gd whole file.

---
*GameCrafter skill — Developed by Forgotten Woods Studios.*
